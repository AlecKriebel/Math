# Zenodo upload kit

Upload only paper.pdf and source-and-verification.zip. Use the metadata object in api-metadata.json exactly. The root repository manifest is the canonical live-deposit path; the kit manifest is an offline convenience and must not create a second deposit after staging has begun.

Check SHA256SUMS before uploading. The source archive includes its own inventory and binds this PDF. It contains source, pinned exact checks, source provenance, priority evidence, and AI adversarial reviews. Review status and AI disclosure are explicit in the paper and metadata. DOI and publication receipts are recorded separately after publication.
