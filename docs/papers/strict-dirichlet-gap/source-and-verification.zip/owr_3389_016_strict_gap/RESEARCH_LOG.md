# Research log — OWR-3389-016 candidate audit

All timestamps UTC. Completion percentages estimate progress toward validating a **novel full resolution of the cited problem**, not the likelihood that a theorem is true.

## 2026-09-23T03:44:51Z — Intake checkpoint — 10%

- Hypothesis: for every bounded nonempty open set in R^n and finite J, the candidate strict Dirichlet spectral gap inequality holds and resolves the linked open problem.
- Success criteria: exact primary-source match; rigorous proof covering multiplicities and arbitrary open-set boundaries; priority audit without a known direct predecessor; concise verified publication artifacts only if these gates pass.
- Three independent reviewers assigned: functional-analysis falsification, independent derivation, and primary-source matching. Primary agent checking literature and repository integration.
- Repository main branch, origin https://github.com/AlecKriebel/Math.git. Pre-existing unrelated tracked and untracked work must be preserved.
- Initial exact webpage access failed (web tool inaccessible; HTTP 429). Related AIM problem compilation asks a growth upper bound; this is a source-matching concern, not yet a verdict on the linked entry.
- Mathematical audit provisionally supports the proof after spelling out the form-defined Dirichlet operator domain. No novelty claim is established.
- No communications with outside individuals; no GitHub release or DOI deposit authorized by this workflow stage.

## 2026-09-23T03:48:42Z — Proof and source checkpoint — 55%

- Functional-analysis referee found no mathematical gap; domain, convergence, and extension details supplied in audit/proof-audit.md.
- An initially independent derivation rediscovered the candidate mechanism, then supplied a different and shorter self-adjointness obstruction to equality. This simplification is undergoing cross-review.
- Source reviewer visually verified OWR 2009/06, printed p. 415: the saturation question is explicit and separate from the neighboring growth question. The current unsolvedmath entry was successfully inspected in a browser and uses the candidate's squared M_2 normalization.
- The primary report prints M_1^2-M_2 despite defining M_p as a root mean. Treat the missing square as a disclosed dimensional typo; do not silently claim a literal match.
- Independent priority audit ongoing. No direct predecessor identified yet; absence of a match is not a proof of originality.
- Computational checks are being prepared as algebra/example checks, not a proof certificate for arbitrary domains.

## 2026-09-23T03:57:22Z — Audit gates passed — 90%

- Mathematical and final-manuscript audits pass. Real-valued wording repair incorporated; no unclosed proof gap identified.
- Exact linked-source scope confirmed. Missing square in the original report disclosed.
- Key Ashbaugh 2002 full text recovered from a lawful archival snapshot and visually checked; p. 12 explicitly leaves Yang1 strictness undecided. Scoped priority audit found no direct prior resolution. This is not an exhaustive novelty certificate.
- Parent reproduced 7,016 exact checks, 1,312 box/index cases, 600 zero gaps, 12 repeated-ground cases, and three negative controls; deterministic JSON agrees.
- Preparing concise three-page manuscript, scoped website, and manual Zenodo upload kit. No separate supplemental paper is needed because the main proof is complete.
- Publication uses only this effort’s folder plus its dedicated Pages deployment directory, preserving concurrent work.

## 2026-09-23T04:04:43Z — Publication preparation checkpoint — 95%

Three-page paper, source ZIP, Zenodo kit, metadata, and dedicated static site are ready. Final local PDF, schema, archive, checksum, script, and browser checks pass. Independent package review is completing. Final remote deployment will be logged in DEPLOYMENT.md after publication, rather than rewriting an already verified archive. No DOI has been minted.

## 2026-09-23T13:34:27Z — Additional adversarial preprint review opened — 25%

The user requested fresh adversarial review cycles, repairs propagated through all publication artifacts, and a new independent reviewer after repairs, continuing until a complete round identifies no actionable issues. This percentage tracks the new preprint-readiness review, not reversal of the prior mathematical conclusion. A fresh reviewer is independently checking the proof before reading previous audit verdicts. The parent reproduced all 7,016 exact checks and is checking publication consistency. No journal submission, outside communication, or DOI deposit is in scope.

## 2026-09-23T13:40:53Z — First new adversarial round complete — 65%

The fresh round-one reviewer found no new actionable issue after independent proof reconstruction, source checks, PDF inspection, and reproducing all 7,016 exact checks. The parent repaired two minor presentation defects: missing package link in the standalone paper and missing PDF metadata. Version 1.0.1 retains the exact mathematical argument and remains three pages. Current citation, upload fields, and site versions are synchronized; old audit records remain explicitly historical. A fresh second reviewer will attack the revised manuscript and package before publication.

## 2026-09-23T13:48:05Z — Fresh second round clean; preprint-ready — 95%

Round two independently reconstructed the complete proof before consulting old verdicts, freshly inspected all PDF pages and selected primary sources, reproduced normal/optimized/extracted verification, and rebuilt both current ZIPs byte-for-byte. It found no actionable issue and requested no revision. The two-round stopping criterion is met. Version 1.0.1 has only presentation changes; current TeX/PDF hashes are frozen in the round-two and consolidated reports. Both reports are being included in the refreshed source/Zenodo/site payloads. Mathematical and preprint review is 100% complete; final publication and live-download checks remain. No journal, outreach, or DOI work is in scope.
