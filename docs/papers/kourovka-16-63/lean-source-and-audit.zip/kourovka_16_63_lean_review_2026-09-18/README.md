# Kourovka 16.63 — partial Lean source and local audit

Start with `lean/README.md` and `audit/VERIFICATION_REPORT.md`.
The complete finite-group theorem is not formalized in this package.
The audit distinguishes accepted source from missing proof obligations.

The source project is in `lean/`; enter that directory before running the documented build commands. No compiler or dependency caches are included.
