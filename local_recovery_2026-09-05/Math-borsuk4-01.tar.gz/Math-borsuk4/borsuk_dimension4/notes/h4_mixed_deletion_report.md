# Arbitrary-deletion audit for two-level mixed golden H4 ties

**Checkpoint:** 2026-08-01  
**Status:** exact partial deletion theorem; no counterexample and no proof of
the four-dimensional Borsuk conjecture.

No construction catalogue or Borsuk literature was consulted. The audit was
performed from the exact product tables already derived for the 120 golden
roots and the 600 scaled K4 centroids.

## 1. Family and tie equations

Let (A) be the 120-vector orbit of squared norm (16), and let (B) be
the 600-vector orbit of squared norm

\[
        N=112+48\sqrt5.
\]

At radial ratio (r>0), consider arbitrary subsets of (A\cup rB). If
(u,t,c\in\mathbb Z[\sqrt5]) are respectively an (A)-product, a
(B)-product, and a cross product, the three squared-distance levels are

\[
 A_u=32-2u,\qquad
 B_t=2r^2(N-t),\qquad
 X_c=16+Nr^2-2cr.
\]

Their exact tie equations are

\[
\begin{array}{rcl}
 A_u=B_t&:&(N-t)r^2+u-16=0,\\
 A_u=X_c&:&Nr^2-2cr+2u-16=0,\\
 B_t=X_c&:&(N-2t)r^2+2cr-16=0.
\end{array}
\]

The product spectra have 8, 30, and 15 levels. The checker isolates every
positive root of the last two equations over the positive embedding of
(\mathbb Q(\sqrt5)). It finds

| pair tie | positive level-root records | triple records | pure two-class records |
|---|---:|---:|---:|
| (A=X) | 101 | 23 | 78 |
| (B=X) | 372 | 23 | 349 |

The 23 triple records agree exactly under the two enumerations. They are
excluded from every two-class claim below. “Record” is deliberate: distinct
level pairs can share the same numerical radial ratio.

Root counts, common-root tests, and strict compatibility cutoffs use exact
field arithmetic and verified rational isolating intervals. Floating point
only proposes an initial interval and is never used to accept a sign.

## 2. Two immediate deletion theorems

Two classes require no search.

1. If cross edges are the only diameter edges, the graph is bipartite.

2. At a pure (A=B) tie there are no cross diameter edges. The diameter
   graph is the disjoint union of an admissible (A)-threshold graph and an
   admissible (B)-threshold graph. The two prior exact all-threshold audits
   five-color each component with the same palette. Hence every arbitrary
   subset at every pure (A=B) tie is five-colorable.

These statements apply to arbitrary vertex deletion, not just full or
projective orbits.

## 3. Exact screens for a cross tie

At a pure (A=X) tie the (B) side is independent in the diameter graph.
For fixed (b\in B), define

\[
 \omega_A(u,c)=\max\{|Q|:Q\subseteq A,\ a\cdot b=c\ (a\in Q),
                         \ a\cdot a'\ge u\ (a,a'\in Q)\}.
\]

H4 transitivity makes this independent of (b). If
(\omega_A(u,c)\le4), color the admissible (A) side with five colors and
extend each independent (B)-vertex using a color absent from its at most
four cross neighbors. If the admissible (A)-threshold graph is known to be
four-colorable, use a fifth color on all of (B). A verified full
five-coloring of the (A) relation also extends whenever every cross
neighborhood omits a color.

The symmetric quantity (\omega_B(t,c)) applies at a pure (B=X) tie. It
is combined with explicit full four-colorings at

\[
 t\in\{-112-48\sqrt5,-104-48\sqrt5,-76-36\sqrt5,
          76+36\sqrt5,104+48\sqrt5\}.
\]

All 570 local clique numbers are computed by an exact maximum-clique search.
The row-major table digests are

```text
AX ec7469c40f0dcbcead7b10629bb2197a3733cf3cf9f586c597625367c1f71b30
BX 1dcd5094dce65344df591d83989d3b6a381e5d6ff64122093f16c0e23b0c8d87
```

The rank-four vector-five condition cannot reject these graphs: every
compatible graph is already realized by a subset of an exact configuration
in (\mathbb R^4). The six-vertex local obstruction—(K_6) with at most a
matching of nonedges—is included as a later sanity screen.

## 4. Compatible minimum-degree-five search

The remaining exact rejection method is based on criticality.

If a compatible diameter graph were not five-colorable, it would contain a
vertex-critical six-chromatic induced subgraph (H). Thus
(\delta(H)\ge5). The prior single-orbit audits show that (H) must meet
both orbits. On a pure (A=X) tie, choose a (B)-vertex of (H); on a pure
(B=X) tie, choose an (A)-vertex. H4 transitivity moves it to the fixed
vertex 0.

The checker enumerates five mutually compatible relation-neighbors of that
anchor. It quotients these seeds by the anchor stabilizer, then recursively
repairs a deficient chosen vertex. If it needs (q) more relation-neighbors,
the search branches over every compatible (q)-subset of the available
neighbors. Every vertex added remains compatible with the entire chosen
set. Consequently, if a compatible minimum-degree-five core exists, one
branch stays inside it until either a (possibly smaller) core is found or
the branch is contradicted.

Schreier generators are reconstructed from the four exact H4 reflections.
The checked group data are

| fixed vertex | action on seed orbit | stabilizer order |
|---|---|---:|
| (B_0) | 120 roots | 24 |
| (A_0) | 600 centroids | 120 |

The reflection actions preserve every cross product exactly. The most
expensive completed negative row used 196,226 recursive nodes. A default
cap of 2,000,000 nodes per row makes accidental search expansion fail
closed.

## 5. A–cross result and correction

Of the 78 pure (A=X) records, 77 are now proved five-colorable. The methods
include the local extension screens, the compatible-core exhaustion, and
two frozen five-colorings of the entire 720-vertex equality graph. The
latter are stronger than necessary: they ignore compatibility, so every
admissible subset inherits the coloring. Their SHA-256 digests are

```text
(u,c)=((-4,-4),(-16,-8))  5bf52763cc64ef09a90147e9b4b1579082d84a468ff5e00c72ecb5d489418bf6
(u,c)=((-8,0),(-16,-8))   3184e49599e3f4b76c7e8bb151e1b0864ea6c74a9e09e464faa691d49ff97446
```

The strings are stored in the checker and verified edge by edge.

An earlier exploratory count incorrectly tested the frozen
(u=-8) root coloring only at the transitivity-fixed (B_0). Although the
geometry is transitive, that particular coloring is not invariant under the
stabilizer. Across all 600 (B)-vertices, two additional neighborhoods use
all five colors. The present 77/78 theorem does not use that invalid
reduction.

### Sole live pure A–cross record

The unresolved record is

\[
       u=-8,\qquad c=-12-4\sqrt5.
\]

Its radial ratio is the unique positive root relevant here of

\[
 (14+6\sqrt5)r^2+(3+\sqrt5)r-4=0,
 \qquad 0.2982<r<0.2983.
\]

It also satisfies

\[
       4r^4+6r^3-27r^2-6r+4=0,
\]

with the preceding interval and positive (\sqrt5)-embedding selecting the
intended root. The diameter squared is exactly (D^2=48). Compatibility and
diameter equality are:

| pair | compatible exactly when | diameter edge exactly when |
|---|---|---|
| (A,A) | (a\cdot a'\ge-8) | (a\cdot a'=-8) |
| (A,B) | (a\cdot b\ge-12-4\sqrt5) | (a\cdot b=-12-4\sqrt5) |
| (B,B) | (b\cdot b'\ge-16-8\sqrt5) | never at this pure tie |

The first compatible minimum-degree-five core has 17 vertices: 16 from
(A), one from (B). Its vertex-list digest is

```text
7845daf1804e4183b26f7a91865a50b31bb8d623cc6907c10b78a88e90ff377c
```

This core is only 3-chromatic. Moreover, an exact search anchored once in
each H4 orbit proves that **no compatible six-set anywhere at this radius**
induces (K_6) with at most a matching deleted. Thus the survivor passes the
rank/local/Hom-oriented screens but the displayed core is not itself remotely
a counterexample; it only prevents the four-degeneracy argument from closing
this radius. A stronger exact coloring or critical-subgraph search is still
required.

## 6. B–cross result

There are 349 pure (B=X) records. The family-wide local and full
four-color screens eliminate 53. Complete stabilizer-reduced core searches
were then run on these structured subfamilies:

| (t) | cross levels | pure root records |
|---|---|---:|
| (44+20\sqrt5) | all 15 | 15 |
| (56+24\sqrt5=N/2) | all positive cross levels | 6 (one further record is triple) |
| (60+28\sqrt5) | (24+8\sqrt5,20+12\sqrt5) | 4 |
| (72+32\sqrt5) | (24+8\sqrt5,20+12\sqrt5) | 4 |

All 29 selected pure records are five-colorable; 3 overlap the family-wide
screen. Hence the certified eliminated union is

\[
       79/349
\]

pure (B=X) records. The remaining 270 are explicitly open. No search over
all (2^{720}) subsets, or an unstructured scan over all 720 vertices, was
performed.

## 7. Reproduction

Run the two single-orbit prerequisites and then the mixed deletion checker:

```text
python3 borsuk_dimension4/search/h4_all_thresholds_search.py
python3 borsuk_dimension4/search/h4_dual_subset_search.py
python3 borsuk_dimension4/search/h4_mixed_deletion_search.py
```

The final command reconstructs all points and tables, classifies algebraic
roots and triple ties, verifies the frozen colorings, rebuilds both
stabilizers, and replays every claimed compatible-core exhaustion. On the
current machine it takes about 20 seconds.

The next high-value step is narrow: solve the sole pure (A=X) record by an
exact maximal-compatible-set/SAT audit, then continue (B=X) by increasing
compatibility sparsity rather than by scanning arbitrary subsets.
