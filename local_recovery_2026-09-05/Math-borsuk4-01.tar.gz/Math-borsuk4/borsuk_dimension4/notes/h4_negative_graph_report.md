# Exact audit of the negative-product golden graph

**Checkpoint:** 2026-08-01  
**Scope:** first-principles exact graph, coloring, symmetry, and diameter-
subgraph audit; no construction catalogue or literature search was used.

## Status

Let (R) be the 120-vector golden root orbit described below and let

\[
   uv\in E(G_-)
   \quad\Longleftrightarrow\quad
   \langle u,v\rangle<0.
\]

The exact result of this audit is

\[
             |V(G_-)|=120,qquad |E(G_-)|=2700,qquad
             \alpha(G_-)=20,qquad \boxed{\chi(G_-)=7}.
\]

This does **not** give a Borsuk counterexample.  A 38-vertex induced
six-chromatic core contains (K_6) with a perfect matching deleted.  A
general Euclidean-distance-matrix lemma proved here shows that no diameter
graph in (mathbb R^4) can contain that subgraph, even when accidental
diameter edges are allowed.  The core also contains a second forbidden
subgraph (K_1\mathbin\vee K_{3,3}).

Deleting edges from the core produces a frozen 38-vertex, 173-edge graph
(H_{173}) that is proper-subgraph-critical six-chromatic and passes both
new obstructions and all earlier exact graph screens.  Its rank-four
diameter realization remains unresolved.  It is therefore a live, but
numerically adverse, graph-first target rather than a claimed point
configuration.

The standard-library checker is

```text
borsuk_dimension4/search/h4_negative_graph.py
```

## 1. Exact root and graph definition

Write (s=\sqrt5), using its positive real embedding, and represent
(a+bs) by the integer pair `(a,b)`.  The checker constructs the following
120 vectors, each scaled by four:

1. the eight vectors obtained from ((\pm4,0,0,0));
2. all sixteen vectors ((\pm2,\pm2,\pm2,\pm2));
3. every even coordinate permutation of
   ((0,2,1+s,-1+s)), with independent signs on its three nonzero
   coordinates.

Duplicates are removed and the result is lexicographically sorted.  Every
vector has squared norm 16.  The complete off-diagonal product census is

| product | unordered pairs |
|---:|---:|
| (-16) | 60 |
| (-4-4s) | 720 |
| (-8) | 1200 |
| (4-4s) | 720 |
| (0) | 1800 |
| (-4+4s) | 720 |
| (8) | 1200 |
| (4+4s) | 720 |

The first four values are negative.  Their union is (G_-), so (G_-) is
45-regular with 2700 edges.  Every comparison is made by the exact sign
test for (a+b\sqrt5): only the sign of (a^2-5b^2) is needed when the
rational and radical parts oppose one another.

The displayed root coordinates are not a diameter realization of (G_-):
its four edge relations have four different lengths.  They do give the
unit-vector assignment (n_v=v/4), for which every graph edge satisfies

\[
 \langle n_u,n_v\rangle
 \le {1-\sqrt5\over4}<-{1\over4}.
\]

Thus the full graph and all of its subgraphs pass the exact rank-four
center-vector necessary condition for a diameter subgraph in four
dimensions.

## 2. Exact chromatic number seven

### 2.1 Upper bound

`FULL_SEVEN_COLORING` in the checker is an edge-by-edge verified proper
seven-coloring.  In the frozen root order its color-class sizes are

```text
(20, 16, 18, 20, 18, 17, 11).
```

Hence (chi(G_-)\le7).

### 2.2 Independence number

An independent set in (G_-) is exactly a root subset whose pair products
are all nonnegative.  Exact Bron--Kerbosch enumeration of the compatibility
graph finds all 30,000 maximal such sets:

```text
size 20: 28,800
size 17:  1,200
SHA256: 5ea861917eac9194187f318d6a8532176c5910f5a72dd375b1583d696a025e9a
```

The digest encodes the sorted maximal sets as semicolon-separated,
comma-separated root indices.  In particular, (alpha(G_-)=20), so
(chi(G_-)\ge6).

### 2.3 Exact exclusion of six colors

The four reflections in the exact roots

```text
(4,0,0,0)
(1+s,1-s,0,2)
(2,2,2,2)
(2,2,2,-2)
```

act by verified permutations of the 120 roots and preserve every product
relation.  Their action splits the 28,800 maximum independent sets into
four orbits of sizes

```text
(7200, 4800, 14400, 2400).
```

Frozen representatives are stored in
`MAXIMUM_INDEPENDENT_ORBIT_REPRESENTATIVES`.

If a six-coloring existed, all six classes would have size 20, since six
classes of size at most (alpha=20) must cover 120 vertices.  Fixing the
first class to one representative from each orbit reduces the question to
an exact cover by five further maximum independent sets.  A bit-parallel
complete search chooses an uncovered vertex having the fewest available
rows; when two rows remain it checks the complementary row by direct table
lookup.  All four searches are unsatisfiable, with deterministic search-node
counts

```text
(1154, 1226, 953, 1411).
```

This proves (chi(G_-)\ne6).  Together with the explicit seven-coloring,
(chi(G_-)=7).

## 3. A 38-vertex induced six-critical core

In global root indices, the frozen core is

```text
(59,60,62,63,64,65,70,71,72,73,74,75,76,77,78,79,80,81,82,
 84,85,86,101,102,103,104,105,109,110,111,112,113,114,115,
 116,117,118,119).
```

Its induced graph has 288 edges.  Complete DSATUR backtracking proves that
it is not five-colorable, and `CORE_SIX_COLORING` proves that it is
six-colorable.  Deleting any one of its 38 vertices gives an explicitly
verified five-coloring.  It is therefore vertex-critical six-chromatic.

This promising core is nevertheless geometrically impossible for a very
small exact reason.  For example, the vertices

```text
(59,70,72,75,80,82)
```

induce (K_6) minus the perfect matching

```text
(59,75), (70,80), (72,82).
```

There are exactly 19 such induced copies in the core.  Listed as
`six vertices | three missing pairs`, they are

```text
59,70,72,75,80,82       | 59-75,70-80,72-82
59,70,72,75,80,102      | 59-75,70-80,72-102
59,70,72,80,82,104      | 59-104,70-80,72-82
59,70,75,80,82,102      | 59-75,70-80,82-102
60,71,73,76,79,81       | 60-76,71-79,73-81
60,71,73,76,79,101      | 60-76,71-79,73-101
60,71,73,79,81,103      | 60-103,71-79,73-81
60,71,76,79,81,101      | 60-76,71-79,81-101
62,63,74,75,76,84       | 62-75,63-76,74-84
62,63,74,75,84,102      | 62-75,63-102,74-84
62,63,74,76,84,101      | 62-101,63-76,74-84
62,73,76,79,84,110      | 62-79,73-84,76-110
62,74,75,76,84,102      | 62-75,74-84,76-102
63,72,75,80,84,109      | 63-80,72-84,75-109
63,74,75,76,84,101      | 63-76,74-84,75-101
64,65,74,75,76,105      | 64-75,65-76,74-105
70,71,72,73,103,104     | 70-71,72-73,103-104
70,72,75,80,82,104      | 70-80,72-82,75-104
71,73,76,79,81,103      | 71-79,73-81,76-103
```

The encoding digest is

```text
67a1521f50c197d18efd681ea77603d0d539043286550b40a55892a284d5598b
```

## 4. General deleted-matching simplex obstruction

The preceding six vertices are ruled out by a dimension-independent lemma.

> **Lemma.** A diameter graph of distinct points in (mathbb R^d) cannot
> contain (K_{d+2}) with only a matching of edges deleted.  The deleted
> matching may have any size; accidental diameter edges on its pairs are
> allowed.

### Proof

Normalize the squared diameter to one and write (n=d+2).  Let
(Delta) be the squared-distance matrix of the selected (n) points.  All
off-diagonal entries are one except possibly matching pairs (u_kv_k),
whose squared distances are (a_k\in(0,1]).  For every
(lambda\in\mathbf1^\perp),

\[
 \lambda^{\mathsf T}\Delta\lambda
 =-\sum_i\lambda_i^2
   +2\sum_k(a_k-1)\lambda_{u_k}\lambda_{v_k}.       \tag{1}
\]

For each matched pair put

\[
 s_k={\lambda_{u_k}+\lambda_{v_k}\over\sqrt2},
 \qquad
 d_k={\lambda_{u_k}-\lambda_{v_k}\over\sqrt2}.
\]

Its contribution to (1) is

\[
             (a_k-2)s_k^2-a_kd_k^2.                 \tag{2}
\]

Every unmatched coordinate contributes (-\lambda_i^2).  Since
(0<a_k\le1), (1) is strictly negative for every nonzero
(lambda\in\mathbf1^\perp).  Consequently the centered Gram matrix

\[
             B=-\tfrac12 H\Delta H,
 \qquad H=I-\tfrac1nJ,
\]

is positive definite on the ((n-1)=(d+1))-dimensional space
(mathbf1^\perp).  Thus (operatorname{rank}B\ge d+1), whereas points in
(mathbb R^d) give (operatorname{rank}B\le d), a contradiction.
(square)

This strictly generalizes the earlier (K_6-e) screen in dimension four.
It is not subsumed by the crossed-two-edge-block obstruction: in
(K_{2,2,2}=K_6) minus a perfect matching, two blocks that each contain two
edges cannot be completely cross-joined.

## 5. A second obstruction: (K_1\vee K_{3,3})

The full graph and the 38-vertex induced core also fail independently.  In
global core indices,

```text
center 74
left   (62,64,75)
right  (63,65,76)
```

span (K_1\vee K_{3,3}) as a non-induced subgraph.

> **Lemma.** No equal-length graph in (mathbb R^4), and hence no diameter
> graph there, contains (K_1\vee K_{3,3}).

### Proof

Normalize the common edge length to (D>0).  Denote the center by (z),
the left triple by (x_1,x_2,x_3), and the right triple by
(y_1,y_2,y_3).  Put

\[
 U=\operatorname{span}\{x_i-x_1\},
 \qquad V=\operatorname{span}\{y_j-y_1\}.
\]

Alternating four cross-distance equations gives (U\perp V).  Each triple
lies on the sphere of radius (D) centered at (z).  A line meets that
sphere in at most two points, so both triples are noncollinear and
(dim U=dim V=2).  Hence (mathbb R^4=U\mathbin\perp V).

The two affine planes meet at a unique point (c).  Write
(x_i=c+u_i), (y_j=c+v_j), with (u_i\in U), (v_j\in V).  All nine
cross distances equal (D), so

\[
       \|u_i\|^2+\|v_j\|^2=D^2.
\]

It follows that all (|u_i|) equal a radius (r), and all
(|v_j|) equal a radius (s), with

\[
                    r^2+s^2=D^2.                    \tag{3}
\]

Because (z) is equidistant from three noncollinear points in the left
plane, its (U)-component relative to (c) is the unique circumcenter,
zero.  The right triple similarly forces its (V)-component to be zero.
Thus (z=c).  The six center edges now give (r=s=D), contradicting (3).
(square)

This obstruction is independent of the deleted-matching lemma.  It is also
absent from the stripped graph (H_{173}).

## 6. Exact symmetry-reduced Gram audit

The nine product relations, including the diagonal, form a commutative
association scheme.  The checker constructs every intersection number by
counting, checks constancy on each relation, and verifies all 81 products of
the following common eigenspaces.  For the negative adjacency matrix, the
resulting spectrum is

| multiplicity | eigenvalue |
|---:|---:|
| 1 | (45) |
| 25 | (-3) |
| 36 | (-1) |
| 16 | (4) |
| 9+9 | (5) |
| 4 | (-11+6\sqrt5) |
| 16 | (0) |
| 4 | (-11-6\sqrt5) |

The trace identities for all nine relation matrices verify the displayed
multiplicities.  In particular the ordinary center-vector spectral screen
(45\le-4\tau), with (	au=-11-6\sqrt5), passes.

There are only two primitive invariant spaces of rank at most four.  After
normalizing the diagonal to one, their Gram values on the four negative
relations

```text
(-16), (-4-4sqrt(5)), (-8), (4-4sqrt(5))
```

are respectively

\[
 \left(-1,-{1+\sqrt5\over4},-{1\over2},{1-\sqrt5\over4}\right)
\]

and its Galois conjugate

\[
 \left(-1,{-1+\sqrt5\over4},-{1\over2},{1+\sqrt5\over4}\right).
\]

All four values are distinct in either row.  Therefore no centered,
fully (H_4)-invariant positive-semidefinite Gram matrix of rank at most
four can make all (G_-) edges have one length.  This symmetry-reduced
calculation alone would not exclude a symmetry-breaking deformation; the
six-vertex lemmas above do exclude every deformation of the full graph and
the induced core.

## 7. Complete graph-screen audit

For every unordered root-pair relation, reflection transitivity reduces the
common-neighborhood calculation to one representative.  The exact table is
`(number of vertices, number of induced edges, chromatic number)`:

| pair product | common-neighborhood data |
|---:|---:|
| (-16) | `(0,0,0)` |
| (-4-4sqrt(5)) | `(1,0,1)` |
| (-8) | `(7,0,1)` |
| (4-4sqrt(5)) | `(12,5,3)` |
| (0) | `(16,2,2)` |
| (-4+4sqrt(5)) | `(23,15,3)` |
| (8) | `(26,18,3)` |
| (4+4sqrt(5)) | `(34,46,3)` |

The outcomes below use “reject” when a forbidden diameter subgraph is
actually present and “pass” when the screen finds none.

| exact screen | full (G_-) | induced 38-core | (H_{173}) |
|---|---:|---:|---:|
| clique number at most four / no (K_5) | pass | pass | pass; 38 copies of (K_4) |
| (K_6) minus a matching | reject | reject; 19 induced witnesses | pass |
| (K_1\vee K_{3,3}) | reject | reject | pass |
| (K_2\vee C_4) | pass | pass | pass |
| edge common neighborhood is 3-colorable | pass | pass | pass |
| two cross-complete blocks, two edges in each | pass | pass | pass |
| no universal vertex | pass | pass | pass |
| rank-four center-vector necessary condition | pass strictly | pass strictly | pass strictly |
| fully invariant rank-four equal-edge Gram | reject | not applicable | not applicable |

The crossed-block verifier uses a complete but memory-light formulation:
fix one edge in the left block, enumerate pairs of edges in its common
neighborhood, and test whether the common neighborhood of the resulting
right support contains two edges.  The equivalent support-set enumeration
has 3,000,010 distinct supports in the full graph and 13,793 in
(H_{173}).  The latter count is checked in the default run; the former can
be replayed with `--heavy-support-count`.

## 8. The live 173-edge target

Start with the 288 core edges in lexicographic local order.  Consider them
in reverse order, deleting an edge exactly when complete five-color DSATUR
still returns UNSAT.  This deterministically produces (H_{173}).  Its 38
open-neighborhood masks are frozen as `CRITICAL_173_MASKS`; the checker also
regenerates them from the rule above.  The SHA-256 digest of its global edge
list is

```text
9024557b01880a4d2e5a74b3ae555ffae41356957165ce559cadbc68dcb2d204
```

Exact properties are:

```text
vertices: 38
edges: 173
chromatic number: 6
every single-edge deletion: 5-colorable
every proper subgraph: 5-colorable
minimum/maximum degree: 5/13
K4 count: 38
edge products inherited from roots:
    123 at 4-4sqrt(5), 36 at -8, 14 at -4-4sqrt(5)
```

Because every vertex has positive degree, five-colorability after every
edge deletion also implies five-colorability after every vertex deletion;
thus the graph is proper-subgraph-critical.

Its sorted degree sequence is

```text
5,5,5,6,6,6,6,6,7,7,7,8,8,8,8,8,8,9,9,9,
10,10,10,10,11,11,11,11,11,11,11,12,12,12,13,13,13,13.
```

For its 173 edge common neighborhoods, the size histogram is

```text
0:4, 1:26, 2:38, 3:49, 4:29, 5:23, 6:4,
```

and their exact chromatic-number histogram is

```text
0:4, 1:76, 2:78, 3:15.
```

### Non-certificate numerical diagnostic

A separate 32-start Levenberg--Marquardt rank-four unit-edge search did not
find a solution for the frozen graph.  Its best squared residual cost was
approximately `0.0060554`, with maximum squared-edge error approximately
`0.03136`.  This is evidence against easy realizability, not a proof.

The K4-generated subcomplex on local vertices

```text
(11,12,13,14,15,16,17,18,19,20,21,24,25,27,28,29,30,31,32,33,34,35,36,37)
```

has 24 vertices, 83 edges, and 36 connected (K_4)'s.  Numerical searches
solve its unit-edge equations, as well as every extension by one, two, or
three remaining vertices, to numerical precision.  Any obstruction seen by
the full residual therefore appears later than these small extensions.  No
floating-point statement in this subsection is used in an exact conclusion.

## 9. Reproduction

Run the full exact audit with

```text
python3 borsuk_dimension4/search/h4_negative_graph.py
```

Useful optional outputs are

```text
python3 borsuk_dimension4/search/h4_negative_graph.py --emit-edges
python3 borsuk_dimension4/search/h4_negative_graph.py --emit-matching-witnesses
python3 borsuk_dimension4/search/h4_negative_graph.py --heavy-support-count
```

The default run reconstructs the roots and graph, proves the four
maximum-independent-set orbits and four failed exact covers, verifies the
association algebra, checks the 38-core and all 19 matching witnesses,
regenerates the 173-edge graph, proves all 173 edge-deletion colorings, and
runs every listed obstruction screen.

## 10. Research checkpoints

All work for this route is contained in this report and its companion
checker.

- **2026-08-01:** Constructed (G_-) exactly and found a seven-coloring.
- **2026-08-01:** Proved (alpha=20); split all 28,800 maximum sets into
  four exact reflection orbits; excluded six colors by four exact-cover
  searches.
- **2026-08-01:** Extracted the 38-vertex induced six-critical core and found
  19 copies of (K_6) minus a perfect matching.
- **2026-08-01:** Proved the general (K_{d+2})-minus-matching EDM
  obstruction and the independent (K_1\vee K_{3,3}) obstruction.
- **2026-08-01:** Completed the exact association-scheme Gram audit.
- **2026-08-01:** Froze and independently reverified the reverse-lexicographic
  173-edge proper-subgraph-critical survivor; it passes all current exact
  screens, while its rank-four diameter realization remains open.
