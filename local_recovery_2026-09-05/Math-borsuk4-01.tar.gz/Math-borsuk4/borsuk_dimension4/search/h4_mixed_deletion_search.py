#!/usr/bin/env python3
"""Exact arbitrary-deletion audit for two-level mixed golden H4 ties.

Let A be the 120 norm-16 golden roots and let B be the 600 scaled K4
centroid vectors of norm N=112+48*sqrt(5).  This checker studies subsets of

                         A union r B,       r > 0,

at radial ratios where two kinds of squared distance agree.  Unlike the
full-orbit audit in ``h4_mixed_orbit_search.py``, arbitrary vertices and all
pairs whose distance is too large may be deleted.

The finite searches below are exact.  A non-five-colorable graph has a
six-critical induced subgraph and hence an induced subgraph of minimum
degree five.  At a two-class A--cross tie the B side has no diameter edges;
at a two-class B--cross tie the A side has none.  We fix a vertex on that
independent side by H4 transitivity, quotient the five-neighbor seeds by its
exact stabilizer, and exhaustively search compatible minimum-degree-five
cores.

This is a deliberately bounded audit, not a claim that the arbitrary-
deletion problem for A union rB is finished.  It proves all cross-only and
A--B two-class cases, all but one *pure* A--cross radius, and the explicitly
listed low-complexity B--cross subfamilies.  Triple ties are counted and
excluded from the two-class assertions.

Only the Python standard library is used.  Every coordinate, product,
comparison, root isolation, group action, and graph search is checked over
Q(sqrt(5)); floating point is used only to choose initial rational brackets,
which are then verified exactly.
"""

from __future__ import annotations

import argparse
import collections
import functools
import hashlib
import itertools
import math
from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable, Iterator, Sequence

from h4_all_thresholds_search import (
    ALPHA_LINE_COLORING,
    BETA_LINE_COLORING,
    NEGATIVE_EIGHT_ORIENTED_COLORING,
    canonical_lines,
    projective_point_colors,
)
from h4_dual_subset_search import (
    Point,
    Quadratic,
    REFLECTION_ROOTS,
    THRESHOLDS as B_THRESHOLDS,
    compatibility_masks,
    dot_table,
    dual_centroid_orbit,
    qcompare,
    qdot,
    qmul,
    qsign,
    qsub,
    reflect,
    relation_masks,
)
from h4_mixed_orbit_search import (
    DUAL_NORM,
    EXPECTED_CROSS_SPECTRUM,
    ROOT_NORM,
    exact_sorted,
    verify_cross_spectrum,
)


Q = tuple[Fraction, Fraction]
Polynomial = tuple[Q, Q, Q]  # coefficient order r^2,r,1


def fq(value: Quadratic | Q | Fraction | int) -> Q:
    if isinstance(value, (int, Fraction)):
        return Fraction(value), Fraction(0)
    return Fraction(value[0]), Fraction(value[1])


ZERO: Q = fq(0)
ONE: Q = fq(1)


def qadd(x: Q, y: Q) -> Q:
    return x[0] + y[0], x[1] + y[1]


def qneg(x: Q) -> Q:
    return -x[0], -x[1]


def qscale(x: Q, scalar: Fraction | int) -> Q:
    scalar = Fraction(scalar)
    return scalar * x[0], scalar * x[1]


def qmultiply(x: Q, y: Q) -> Q:
    return x[0] * y[0] + 5 * x[1] * y[1], x[0] * y[1] + x[1] * y[0]


def qdivide(x: Q, y: Q) -> Q:
    denominator = y[0] * y[0] - 5 * y[1] * y[1]
    assert denominator
    return (
        (x[0] * y[0] - 5 * x[1] * y[1]) / denominator,
        (x[1] * y[0] - x[0] * y[1]) / denominator,
    )


def qexact_sign(x: Q) -> int:
    # h4_dual_subset_search.qsign also works for Fractions.
    return qsign(x)  # type: ignore[arg-type]


def qfloat(x: Q | Quadratic) -> float:
    return float(x[0]) + float(x[1]) * math.sqrt(5.0)


def q_at_r(x: Q, r: Fraction) -> Q:
    return qscale(x, r)


def polynomial_value(polynomial: Polynomial, r: Fraction) -> Q:
    a, b, c = polynomial
    return qadd(qadd(qscale(a, r * r), qscale(b, r)), c)


def polynomial_at_q(polynomial: Polynomial, r: Q) -> Q:
    a, b, c = polynomial
    return qadd(qadd(qmultiply(a, qmultiply(r, r)), qmultiply(b, r)), c)


def polynomial_negate(polynomial: Polynomial) -> Polynomial:
    return tuple(qneg(coefficient) for coefficient in polynomial)  # type: ignore[return-value]


def convolution(left: Sequence[Fraction], right: Sequence[Fraction]) -> list[Fraction]:
    result = [Fraction(0)] * (len(left) + len(right) - 1)
    for i, x in enumerate(left):
        for j, y in enumerate(right):
            result[i + j] += x * y
    return result


def normalized_polynomial(polynomial: Polynomial) -> Polynomial:
    a, b, c = polynomial
    leading = a if a != ZERO else (b if b != ZERO else c)
    assert leading != ZERO
    return polynomial if qexact_sign(leading) > 0 else polynomial_negate(polynomial)


@dataclass
class PositiveRoot:
    """A positive real root, isolated by exact rational endpoints."""

    polynomial: Polynomial
    index: int  # increasing order among the positive roots of this polynomial
    low: Fraction
    high: Fraction
    exact: Q | None = None

    def refine(self) -> None:
        middle = (self.low + self.high) / 2
        if self.exact is not None:
            comparison = qexact_sign(qadd(self.exact, qneg(fq(middle))))
            assert comparison != 0 or self.low < middle < self.high
            if comparison <= 0:
                self.high = middle
            else:
                self.low = middle
            return
        p = normalized_polynomial(self.polynomial)
        left_sign = qexact_sign(polynomial_value(p, self.low))
        middle_sign = qexact_sign(polynomial_value(p, middle))
        right_sign = qexact_sign(polynomial_value(p, self.high))
        assert left_sign * right_sign < 0
        if left_sign * middle_sign <= 0:
            self.high = middle
        else:
            self.low = middle

    def isolate_bits(self, bits: int = 80) -> None:
        while self.high - self.low > Fraction(1, 1 << bits):
            self.refine()


def positive_roots(polynomial: Polynomial) -> list[PositiveRoot]:
    """Count and isolate the distinct positive roots exactly."""
    if polynomial[0] == polynomial[1] == ZERO:
        assert polynomial[2] != ZERO
        return []
    p = normalized_polynomial(polynomial)
    a, b, c = p
    if a == ZERO:
        assert b != ZERO
        root = qdivide(qneg(c), b)
        if qexact_sign(root) <= 0:
            return []
        approximate = qfloat(root)
        denominator = 1 << 12
        low = Fraction(math.floor(approximate * denominator), denominator)
        high = low + Fraction(1, denominator)
        while qexact_sign(qadd(root, qneg(fq(low)))) <= 0:
            low -= Fraction(1, denominator)
        while qexact_sign(qadd(root, qneg(fq(high)))) >= 0:
            high += Fraction(1, denominator)
        assert qexact_sign(polynomial_value(p, low)) < 0
        assert qexact_sign(polynomial_value(p, high)) > 0
        return [PositiveRoot(polynomial, 0, low, high, root)]

    assert qexact_sign(a) > 0
    discriminant = qadd(qmultiply(b, b), qscale(qmultiply(a, c), -4))
    disc_sign = qexact_sign(discriminant)
    if disc_sign < 0:
        return []
    if disc_sign == 0:
        root = qdivide(qneg(b), qscale(a, 2))
        if qexact_sign(root) <= 0:
            return []
        approximate = qfloat(root)
        denominator = 1 << 12
        low = Fraction(math.floor(approximate * denominator), denominator)
        high = low + Fraction(1, denominator)
        while qexact_sign(qadd(root, qneg(fq(low)))) <= 0:
            low -= Fraction(1, denominator)
        while qexact_sign(qadd(root, qneg(fq(high)))) >= 0:
            high += Fraction(1, denominator)
        result = PositiveRoot(polynomial, 0, low, high, root)
        result.isolate_bits(48)
        return [result]
    c_sign = qexact_sign(c)
    b_sign = qexact_sign(b)
    if c_sign < 0:
        positive_count = 1
    elif c_sign == 0:
        positive_count = int(b_sign < 0)
    else:
        positive_count = 2 if b_sign < 0 else 0
    if not positive_count:
        return []

    af, bf, cf = map(qfloat, p)
    disc = bf * bf - 4.0 * af * cf
    assert disc > 0.0
    approximations = sorted(
        root for root in ((-bf - math.sqrt(disc)) / (2 * af),
                          (-bf + math.sqrt(disc)) / (2 * af))
        if root > 0.0
    )
    assert len(approximations) == positive_count

    answer: list[PositiveRoot] = []
    for index, approximate in enumerate(approximations):
        # Find an exact sign-changing dyadic bracket around this approximate
        # value.  The approximation is never trusted without these checks.
        for bits in range(8, 50):
            denominator = 1 << bits
            center = math.floor(approximate * denominator)
            candidates = [
                Fraction(center + offset, denominator)
                for offset in range(-4, 5)
                if center + offset >= 0
            ]
            candidates = sorted(set(candidates))
            bracket = None
            for left, right in itertools.combinations(candidates, 2):
                left_sign = qexact_sign(polynomial_value(p, left))
                right_sign = qexact_sign(polynomial_value(p, right))
                if left_sign * right_sign < 0:
                    bracket = left, right
                    break
            if bracket is not None:
                root = PositiveRoot(polynomial, index, *bracket)
                root.isolate_bits(48)
                answer.append(root)
                break
        else:
            raise AssertionError((polynomial, approximate))
    return answer


def common_root(root: PositiveRoot, other: Polynomial) -> bool:
    """Test exactly whether ``other`` vanishes at this isolated root."""
    if root.exact is not None:
        return polynomial_at_q(other, root.exact) == ZERO
    f = root.polynomial
    a, b, c = f
    d, e, h = other
    if a == ZERO:
        candidate = qdivide(qneg(c), b)
        return polynomial_at_q(other, candidate) == ZERO
    linear = qadd(qmultiply(a, e), qneg(qmultiply(d, b)))
    constant = qadd(qmultiply(a, h), qneg(qmultiply(d, c)))
    if linear == ZERO:
        return constant == ZERO
    candidate = qdivide(qneg(constant), linear)
    if polynomial_at_q(f, candidate) != ZERO:
        return False
    # If f has two positive roots, identify the isolated one exactly.
    return (
        qexact_sign(qadd(candidate, qneg(fq(root.low)))) > 0
        and qexact_sign(qadd(fq(root.high), qneg(candidate))) > 0
    )


def sign_at_root(root: PositiveRoot, polynomial: Polynomial) -> int:
    if root.exact is not None:
        return qexact_sign(polynomial_at_q(polynomial, root.exact))
    if common_root(root, polynomial):
        return 0
    for _ in range(300):
        left = qexact_sign(polynomial_value(polynomial, root.low))
        right = qexact_sign(polynomial_value(polynomial, root.high))
        if left == right and left:
            return left
        root.refine()
    raise AssertionError("failed to separate two distinct algebraic roots")


def ax_polynomial(u: Quadratic, c: Quadratic) -> Polynomial:
    # A_u = X_c: N r^2 - 2 c r + 2u - 16 = 0.
    return fq(DUAL_NORM), qscale(fq(c), -2), qadd(qscale(fq(u), 2), fq(-16))


def bx_polynomial(t: Quadratic, c: Quadratic) -> Polynomial:
    # B_t = X_c: (N-2t) r^2 + 2 c r - 16 = 0.
    return qadd(fq(DUAL_NORM), qscale(fq(t), -2)), qscale(fq(c), 2), fq(-16)


def ab_polynomial(u: Quadratic, t: Quadratic) -> Polynomial:
    # A_u = B_t: (N-t)r^2 + u - 16 = 0.
    return qadd(fq(DUAL_NORM), qneg(fq(t))), ZERO, qadd(fq(u), fq(-16))


def a_minus_b_polynomial(u: Quadratic, t: Quadratic) -> Polynomial:
    # A_u-B_t.
    return qscale(qadd(fq(DUAL_NORM), qneg(fq(t))), -2), ZERO, qadd(fq(32), qscale(fq(u), -2))


def b_minus_a_polynomial(t: Quadratic, u: Quadratic) -> Polynomial:
    return polynomial_negate(a_minus_b_polynomial(u, t))


@dataclass(frozen=True)
class TieRoot:
    left: Quadratic
    cross: Quadratic
    root_index: int
    root: PositiveRoot
    triple_levels: tuple[Quadratic, ...]


def classify_ties(
    a_thresholds: Sequence[Quadratic],
    b_thresholds: Sequence[Quadratic],
    cross_thresholds: Sequence[Quadratic],
) -> tuple[list[TieRoot], list[TieRoot]]:
    ax: list[TieRoot] = []
    for u in a_thresholds:
        for c in cross_thresholds:
            for root in positive_roots(ax_polynomial(u, c)):
                triples = tuple(
                    t for t in b_thresholds
                    if common_root(root, a_minus_b_polynomial(u, t))
                )
                assert len(triples) <= 1
                ax.append(TieRoot(u, c, root.index, root, triples))

    bx: list[TieRoot] = []
    for t in b_thresholds:
        for c in cross_thresholds:
            for root in positive_roots(bx_polynomial(t, c)):
                triples = tuple(
                    u for u in a_thresholds
                    if common_root(root, b_minus_a_polynomial(t, u))
                )
                assert len(triples) <= 1
                bx.append(TieRoot(t, c, root.index, root, triples))
    return ax, bx


def maximum_clique_size(vertices: int, adjacency: Sequence[int]) -> int:
    """Tomita-style exact maximum clique with greedy coloring bounds."""
    best = 0

    def color_order(candidates: int) -> tuple[list[int], list[int]]:
        order: list[int] = []
        bounds: list[int] = []
        remaining = candidates
        color = 0
        while remaining:
            color += 1
            available = remaining
            while available:
                bit = available & -available
                vertex = bit.bit_length() - 1
                order.append(vertex)
                bounds.append(color)
                remaining ^= bit
                available &= ~bit
                available &= ~adjacency[vertex]
        return order, bounds

    def expand(candidates: int, chosen_size: int) -> None:
        nonlocal best
        if not candidates:
            best = max(best, chosen_size)
            return
        order, bounds = color_order(candidates)
        for vertex, bound in reversed(list(zip(order, bounds))):
            if chosen_size + bound <= best:
                return
            bit = 1 << vertex
            if candidates & bit:
                expand(candidates & adjacency[vertex], chosen_size + 1)
                candidates ^= bit

    expand(vertices, 0)
    return best


def local_clique_tables(
    roots: Sequence[Point],
    duals: Sequence[Point],
    root_table: Sequence[Sequence[Quadratic]],
    dual_table: Sequence[Sequence[Quadratic]],
    a_thresholds: Sequence[Quadratic],
    cross_thresholds: Sequence[Quadratic],
) -> tuple[dict[tuple[Quadratic, Quadratic], int],
           dict[tuple[Quadratic, Quadratic], int], str, str]:
    a_omega: dict[tuple[Quadratic, Quadratic], int] = {}
    for u in a_thresholds:
        compatible = compatibility_masks(root_table, u)
        for c in cross_thresholds:
            neighbors = sum(
                1 << i for i, root in enumerate(roots)
                if qdot(root, duals[0]) == c
            )
            a_omega[u, c] = maximum_clique_size(neighbors, compatible)

    b_omega: dict[tuple[Quadratic, Quadratic], int] = {}
    for t in B_THRESHOLDS:
        compatible = compatibility_masks(dual_table, t)
        for c in cross_thresholds:
            neighbors = sum(
                1 << j for j, dual in enumerate(duals)
                if qdot(roots[0], dual) == c
            )
            b_omega[t, c] = maximum_clique_size(neighbors, compatible)

    a_values = tuple(a_omega[u, c] for u in a_thresholds for c in cross_thresholds)
    b_values = tuple(b_omega[t, c] for t in B_THRESHOLDS for c in cross_thresholds)
    a_digest = hashlib.sha256(repr(a_values).encode()).hexdigest()
    b_digest = hashlib.sha256(repr(b_values).encode()).hexdigest()
    return a_omega, b_omega, a_digest, b_digest


def verify_coloring(adjacency: Sequence[int], colors: Sequence[int], count: int) -> None:
    assert len(adjacency) == len(colors)
    assert set(colors) <= set(range(count))
    for vertex, mask in enumerate(adjacency):
        work = mask
        while work:
            bit = work & -work
            work ^= bit
            other = bit.bit_length() - 1
            assert colors[vertex] != colors[other]


def deterministic_coloring(adjacency: Sequence[int], k: int) -> tuple[int, ...] | None:
    """Complete deterministic DSATUR, fast on the sparse full relations here."""
    colors = [-1] * len(adjacency)

    def search(colored: int, used: int) -> bool:
        if colored == len(adjacency):
            return True
        vertex = max(
            (v for v in range(len(adjacency)) if colors[v] < 0),
            key=lambda v: (
                len({colors[w] for w in bit_vertices(adjacency[v]) if colors[w] >= 0}),
                sum(colors[w] < 0 for w in bit_vertices(adjacency[v])),
                adjacency[v].bit_count(),
                v,
            ),
        )
        forbidden = {colors[w] for w in bit_vertices(adjacency[vertex]) if colors[w] >= 0}
        choices = [color for color in range(used) if color not in forbidden]
        if used < k and used not in forbidden:
            choices.append(used)
        for color in choices:
            colors[vertex] = color
            if search(colored + 1, max(used, color + 1)):
                return True
            colors[vertex] = -1
        return False

    if not search(0, 0):
        return None
    verify_coloring(adjacency, colors, k)
    return tuple(colors)


def bit_vertices(mask: int) -> Iterator[int]:
    while mask:
        bit = mask & -mask
        mask ^= bit
        yield bit.bit_length() - 1


def root_full_colorings(
    roots: Sequence[Point], root_table: Sequence[Sequence[Quadratic]]
) -> dict[Quadratic, tuple[int, ...]]:
    lines = canonical_lines(roots)
    alpha = tuple(projective_point_colors(roots, lines, ALPHA_LINE_COLORING))
    beta = tuple(projective_point_colors(roots, lines, BETA_LINE_COLORING))
    result = {
        (-4, -4): alpha,
        (4, 4): alpha,
        (4, -4): beta,
        (-4, 4): beta,
        (-8, 0): tuple(NEGATIVE_EIGHT_ORIENTED_COLORING),
    }
    for threshold, colors in result.items():
        verify_coloring(relation_masks(root_table, threshold), colors, 5)
    return result


FOUR_COLORABLE_B_LEVELS: dict[Quadratic, int] = {
    (-112, -48): 2,
    (-104, -48): 3,
    (-76, -36): 4,
    (76, 36): 3,
    (104, 48): 4,
}


# Full 720-vertex relation colorings discovered after the core screen.  They
# color every A--A and A--B equality edge, without using compatibility, so
# they eliminate every admissible subset at these two pure AX radii.  The
# deterministic vertex order is A[0:120], B[0:600].
FULL_AX_COLORINGS: dict[tuple[Quadratic, Quadratic], str] = {
    ((-4, -4), (-16, -8)): (
        "224244231212441111111241142112411204033003021443002024212132102420111133"
        "001244234201121000033000003340000300030301133000212422422121141411112222"
        "222222222222222244444444444433343334222222222222222222224444444444444444"
        "444444444244442222211233121331113313331112211212111111111212222222222222"
        "224144111111441442222222222111114314423333200021111111111111111111112113"
        "121121131112333131331222111111222202222222222330034440043344444303300022"
        "444333332232333333224440000000000000003222322333333233333333333333333333"
        "333333200202222220020000000000000000000000000013333133331333333333111111"
        "111110001001012233322222233333333314133141104111300330243320022343224130"
        "110000000000000003330333323233330000033033003030000000003333333300000003"
    ),
    ((-8, 0), (-16, -8)): (
        "322442224343224133131423123433233022402441131222444422313123143234313113"
        "141322432441131000000000000020400040101041101010223232223333321211232222"
        "233333222222222222222222222222222222343343333344443344432222224224444442"
        "444222222222222222222222333331111122221444443333311111344413333333333333"
        "332112111111211123323333333111112111222222444441111111111111111111133333"
        "333333131133333111113333311111303003003030000000002224422221211240000020"
        "220222022000200000404404444444402000002020030300200000000022222111112202"
        "100000444443033044404000004444411111444414441111111111111110100000111111"
        "111111111000003033030330030330000011111111111111111111022204440311031124"
        "110000000000000000000000000000000000000000000000000000000000000000000000"
    ),
}


EXPECTED_FULL_AX_DIGESTS = {
    ((-4, -4), (-16, -8)):
        "5bf52763cc64ef09a90147e9b4b1579082d84a468ff5e00c72ecb5d489418bf6",
    ((-8, 0), (-16, -8)):
        "3184e49599e3f4b76c7e8bb151e1b0864ea6c74a9e09e464faa691d49ff97446",
}


def dual_four_colorings(
    dual_table: Sequence[Sequence[Quadratic]],
) -> tuple[dict[Quadratic, tuple[int, ...]], dict[Quadratic, str]]:
    colorings: dict[Quadratic, tuple[int, ...]] = {}
    digests: dict[Quadratic, str] = {}
    for threshold, count in FOUR_COLORABLE_B_LEVELS.items():
        relation = relation_masks(dual_table, threshold)
        colors = deterministic_coloring(relation, count)
        assert colors is not None
        encoded = "".join(map(str, colors))
        colorings[threshold] = colors
        digests[threshold] = hashlib.sha256(encoded.encode()).hexdigest()
    return colorings, digests


def reflection_actions(
    roots: Sequence[Point], duals: Sequence[Point]
) -> tuple[tuple[tuple[int, ...], ...], tuple[tuple[int, ...], ...]]:
    root_index = {point: i for i, point in enumerate(roots)}
    dual_index = {point: i for i, point in enumerate(duals)}
    root_generators = tuple(
        tuple(root_index[reflect(point, normal)] for point in roots)
        for normal in REFLECTION_ROOTS
    )
    dual_generators = tuple(
        tuple(dual_index[reflect(point, normal)] for point in duals)
        for normal in REFLECTION_ROOTS
    )
    assert all(len(set(p)) == len(roots) for p in root_generators)
    assert all(len(set(p)) == len(duals) for p in dual_generators)
    for root_g, dual_g in zip(root_generators, dual_generators):
        for i, root in enumerate(roots):
            for j, dual in enumerate(duals):
                assert qdot(roots[root_g[i]], duals[dual_g[j]]) == qdot(root, dual)
    return root_generators, dual_generators


def compose(left: Sequence[int], right: Sequence[int]) -> tuple[int, ...]:
    """Permutation left o right."""
    return tuple(left[right[i]] for i in range(len(right)))


def inverse(permutation: Sequence[int]) -> tuple[int, ...]:
    result = [0] * len(permutation)
    for i, image in enumerate(permutation):
        result[image] = i
    return tuple(result)


def stabilizer_action(
    orbit_generators: Sequence[Sequence[int]],
    other_generators: Sequence[Sequence[int]],
    base: int,
    expected_orbit: int,
    expected_stabilizer: int,
) -> tuple[tuple[int, ...], ...]:
    """Schreier generators and closure on the 'other' point orbit."""
    orbit_size = len(orbit_generators[0])
    other_size = len(other_generators[0])
    assert len(orbit_generators) == len(other_generators)
    identity_other = tuple(range(other_size))

    transversal_other: list[tuple[int, ...] | None] = [None] * orbit_size
    transversal_other[base] = identity_other
    queue = collections.deque([base])
    while queue:
        vertex = queue.popleft()
        current = transversal_other[vertex]
        assert current is not None
        for orbit_g, other_g in zip(orbit_generators, other_generators):
            image = orbit_g[vertex]
            if transversal_other[image] is None:
                transversal_other[image] = compose(other_g, current)
                queue.append(image)
    reached = [i for i, item in enumerate(transversal_other) if item is not None]
    assert len(reached) == expected_orbit == orbit_size

    schreier: set[tuple[int, ...]] = set()
    for vertex in reached:
        tx = transversal_other[vertex]
        assert tx is not None
        for orbit_g, other_g in zip(orbit_generators, other_generators):
            image = orbit_g[vertex]
            ty = transversal_other[image]
            assert ty is not None
            element = compose(inverse(ty), compose(other_g, tx))
            if element != identity_other:
                schreier.add(element)

    closure = {identity_other}
    queue_permutations = collections.deque([identity_other])
    while queue_permutations:
        current = queue_permutations.popleft()
        for generator in schreier:
            image = compose(generator, current)
            if image not in closure:
                closure.add(image)
                queue_permutations.append(image)
    assert len(closure) == expected_stabilizer
    return tuple(sorted(closure))


def clique_subsets(mask: int, size: int, compatibility: Sequence[int]) -> Iterator[int]:
    def search(chosen: int, candidates: int, remaining: int) -> Iterator[int]:
        if remaining == 0:
            yield chosen
            return
        if candidates.bit_count() < remaining:
            return
        while candidates:
            bit = candidates & -candidates
            candidates ^= bit
            vertex = bit.bit_length() - 1
            yield from search(
                chosen | bit,
                candidates & compatibility[vertex],
                remaining - 1,
            )
    return search(0, mask, size)


def permute_mask(mask: int, permutation: Sequence[int]) -> int:
    return sum(1 << permutation[vertex] for vertex in bit_vertices(mask))


def seed_orbit_representatives(
    neighbor_mask: int,
    compatibility: Sequence[int],
    stabilizer: Sequence[Sequence[int]],
) -> tuple[list[int], collections.Counter[int], int]:
    seeds = list(clique_subsets(neighbor_mask, 5, compatibility))
    seed_set = set(seeds)
    unseen = set(seeds)
    representatives: list[int] = []
    orbit_sizes: collections.Counter[int] = collections.Counter()
    while unseen:
        seed = min(unseen)
        orbit = {permute_mask(seed, permutation) for permutation in stabilizer}
        assert orbit <= seed_set
        unseen -= orbit
        representatives.append(min(orbit))
        orbit_sizes[len(orbit)] += 1
    return representatives, orbit_sizes, len(seeds)


@dataclass(frozen=True)
class MixedCoreResult:
    core: int | None
    total_seeds: int
    seed_orbits: int
    orbit_sizes: tuple[tuple[int, int], ...]
    search_nodes: int
    maximum_chosen_size: int


def find_mixed_five_core(
    relation: Sequence[int],
    compatibility: Sequence[int],
    anchor: int,
    seed_stabilizer: Sequence[Sequence[int]],
    seed_offset: int,
    node_cap: int | None = None,
) -> MixedCoreResult:
    """Complete compatible minimum-degree-five search from one fixed anchor."""
    n = len(relation)
    all_vertices = (1 << n) - 1
    # Stabilizer permutations are local to the orbit containing the anchor's
    # relation neighbors.  Convert its relation and compatibility masks.
    local_neighbors = relation[anchor] >> seed_offset
    local_size = len(seed_stabilizer[0])
    local_mask = (1 << local_size) - 1
    local_neighbors &= local_mask
    local_compatibility = tuple(
        (compatibility[seed_offset + i] >> seed_offset) & local_mask
        for i in range(local_size)
    )
    representatives, orbit_sizes, total_seeds = seed_orbit_representatives(
        local_neighbors, local_compatibility, seed_stabilizer
    )

    search_nodes = 0
    maximum_chosen_size = 0
    failed: set[tuple[int, int]] = set()

    def search(chosen: int, candidates: int) -> int | None:
        nonlocal search_nodes, maximum_chosen_size
        search_nodes += 1
        if node_cap is not None and search_nodes > node_cap:
            raise RuntimeError(f"core-search node cap {node_cap} exceeded")
        maximum_chosen_size = max(maximum_chosen_size, chosen.bit_count())
        deficits: list[tuple[int, int, int, int]] = []
        for vertex in bit_vertices(chosen):
            needed = 5 - (relation[vertex] & chosen).bit_count()
            if needed > 0:
                available = relation[vertex] & candidates
                if available.bit_count() < needed:
                    return None
                deficits.append((available.bit_count() - needed,
                                 available.bit_count(), -needed, vertex))
        if not deficits:
            return chosen
        state = chosen, candidates
        if state in failed:
            return None
        failed.add(state)
        _, _, negative_needed, vertex = min(deficits)
        needed = -negative_needed
        available = relation[vertex] & candidates
        for addition in clique_subsets(available, needed, compatibility):
            next_candidates = candidates & ~addition
            for new_vertex in bit_vertices(addition):
                next_candidates &= compatibility[new_vertex]
            result = search(chosen | addition, next_candidates)
            if result is not None:
                return result
        return None

    for local_seed in representatives:
        seed = local_seed << seed_offset
        chosen = (1 << anchor) | seed
        candidates = all_vertices & ~chosen
        for vertex in bit_vertices(chosen):
            candidates &= compatibility[vertex]
        core = search(chosen, candidates)
        if core is not None:
            return MixedCoreResult(
                core, total_seeds, len(representatives),
                tuple(sorted(orbit_sizes.items())), search_nodes,
                maximum_chosen_size,
            )
    return MixedCoreResult(
        None, total_seeds, len(representatives),
        tuple(sorted(orbit_sizes.items())), search_nodes,
        maximum_chosen_size,
    )


def cross_masks(
    roots: Sequence[Point], duals: Sequence[Point],
    predicate,
) -> tuple[list[int], list[int]]:
    a_to_b = [0] * len(roots)
    b_to_a = [0] * len(duals)
    for i, root in enumerate(roots):
        for j, dual in enumerate(duals):
            if predicate(qdot(root, dual)):
                a_to_b[i] |= 1 << j
                b_to_a[j] |= 1 << i
    return a_to_b, b_to_a


def combined_masks_ax(
    roots: Sequence[Point], duals: Sequence[Point],
    root_table: Sequence[Sequence[Quadratic]],
    dual_table: Sequence[Sequence[Quadratic]],
    tie: TieRoot,
) -> tuple[tuple[int, ...], tuple[int, ...], Quadratic | None]:
    assert not tie.triple_levels
    u, c = tie.left, tie.cross
    aa_relation = relation_masks(root_table, u)
    aa_compat = compatibility_masks(root_table, u)
    ab_relation, ba_relation = cross_masks(roots, duals, lambda value: value == c)
    ab_compat, ba_compat = cross_masks(
        roots, duals, lambda value: qsign(qsub(value, c)) >= 0
    )

    allowed_b = [
        t for t in B_THRESHOLDS
        if sign_at_root(tie.root, a_minus_b_polynomial(u, t)) > 0
    ]
    minimum_b = min(allowed_b, key=functools.cmp_to_key(qcompare), default=None)
    if minimum_b is not None:
        assert allowed_b == [
            t for t in B_THRESHOLDS if qcompare(t, minimum_b) >= 0
        ]
    bb_compat = (
        tuple(0 for _ in duals) if minimum_b is None
        else compatibility_masks(dual_table, minimum_b)
    )
    # No equality is permitted in a pure two-class tie.
    assert all(sign_at_root(tie.root, a_minus_b_polynomial(u, t)) != 0
               for t in B_THRESHOLDS)

    relation = []
    compatibility = []
    for i in range(len(roots)):
        relation.append(aa_relation[i] | (ab_relation[i] << len(roots)))
        compatibility.append(aa_compat[i] | (ab_compat[i] << len(roots)))
    for j in range(len(duals)):
        relation.append(ba_relation[j])
        compatibility.append(ba_compat[j] | (bb_compat[j] << len(roots)))
    return tuple(relation), tuple(compatibility), minimum_b


def combined_masks_bx(
    roots: Sequence[Point], duals: Sequence[Point],
    root_table: Sequence[Sequence[Quadratic]],
    dual_table: Sequence[Sequence[Quadratic]],
    tie: TieRoot,
) -> tuple[tuple[int, ...], tuple[int, ...], Quadratic | None]:
    assert not tie.triple_levels
    t, c = tie.left, tie.cross
    bb_relation = relation_masks(dual_table, t)
    bb_compat = compatibility_masks(dual_table, t)
    ab_relation, ba_relation = cross_masks(roots, duals, lambda value: value == c)
    ab_compat, ba_compat = cross_masks(
        roots, duals, lambda value: qsign(qsub(value, c)) >= 0
    )

    allowed_a = [
        u for u in A_THRESHOLDS
        if sign_at_root(tie.root, b_minus_a_polynomial(t, u)) > 0
    ]
    minimum_a = min(allowed_a, key=functools.cmp_to_key(qcompare), default=None)
    if minimum_a is not None:
        assert allowed_a == [
            u for u in A_THRESHOLDS if qcompare(u, minimum_a) >= 0
        ]
    aa_compat = (
        tuple(0 for _ in roots) if minimum_a is None
        else compatibility_masks(root_table, minimum_a)
    )
    assert all(sign_at_root(tie.root, b_minus_a_polynomial(t, u)) != 0
               for u in A_THRESHOLDS)

    relation = []
    compatibility = []
    for i in range(len(roots)):
        relation.append(ab_relation[i] << len(roots))
        compatibility.append(aa_compat[i] | (ab_compat[i] << len(roots)))
    for j in range(len(duals)):
        relation.append(ba_relation[j] | (bb_relation[j] << len(roots)))
        compatibility.append(ba_compat[j] | (bb_compat[j] << len(roots)))
    return tuple(relation), tuple(compatibility), minimum_a


def has_k6_minus_matching(adjacency: Sequence[int], vertices: int) -> tuple[int, ...] | None:
    """Find six vertices inducing K6 with at most a matching deleted."""
    candidates = list(bit_vertices(vertices))

    def search(chosen: tuple[int, ...], missing: tuple[int, ...], start: int):
        if len(chosen) == 6:
            return chosen
        if len(candidates) - start < 6 - len(chosen):
            return None
        for position in range(start, len(candidates)):
            vertex = candidates[position]
            new_missing = list(missing) + [0]
            valid = True
            for index, other in enumerate(chosen):
                if not ((adjacency[vertex] >> other) & 1):
                    new_missing[index] += 1
                    new_missing[-1] += 1
                    if new_missing[index] > 1 or new_missing[-1] > 1:
                        valid = False
                        break
            if valid:
                result = search(chosen + (vertex,), tuple(new_missing), position + 1)
                if result is not None:
                    return result
        return None

    return search((), (), 0)


def has_compatible_k6_minus_matching(
    adjacency: Sequence[int], compatibility: Sequence[int], anchors: Sequence[int]
) -> tuple[int, ...] | None:
    """Search every compatible near-K6, reduced to one anchor per H4 orbit."""
    n = len(adjacency)
    all_vertices = (1 << n) - 1

    def anchored(anchor: int) -> tuple[int, ...] | None:
        def search(
            chosen: tuple[int, ...], missing: tuple[int, ...], candidates: int
        ) -> tuple[int, ...] | None:
            if len(chosen) == 6:
                return chosen
            if candidates.bit_count() < 6 - len(chosen):
                return None

            # A new vertex may miss at most one chosen vertex, and it must be
            # adjacent to every chosen vertex that has already used its one
            # permitted nonedge.
            filtered = 0
            for vertex in bit_vertices(candidates):
                misses = 0
                valid = True
                for index, other in enumerate(chosen):
                    if not ((adjacency[vertex] >> other) & 1):
                        misses += 1
                        if misses > 1 or missing[index]:
                            valid = False
                            break
                if valid:
                    filtered |= 1 << vertex

            remaining = filtered
            while remaining:
                bit = remaining & -remaining
                remaining ^= bit
                vertex = bit.bit_length() - 1
                new_missing = list(missing) + [0]
                for index, other in enumerate(chosen):
                    if not ((adjacency[vertex] >> other) & 1):
                        new_missing[index] += 1
                        new_missing[-1] += 1
                result = search(
                    chosen + (vertex,), tuple(new_missing),
                    remaining & compatibility[vertex],
                )
                if result is not None:
                    return result
            return None

        return search((anchor,), (0,), compatibility[anchor] & ~(1 << anchor) & all_vertices)

    for anchor in anchors:
        result = anchored(anchor)
        if result is not None:
            return result
    return None


def is_bipartite(adjacency: Sequence[int], vertices: int) -> bool:
    colors: dict[int, int] = {}
    for start in bit_vertices(vertices):
        if start in colors:
            continue
        colors[start] = 0
        queue = collections.deque([start])
        while queue:
            vertex = queue.popleft()
            for other in bit_vertices(adjacency[vertex] & vertices):
                if other not in colors:
                    colors[other] = 1 - colors[vertex]
                    queue.append(other)
                elif colors[other] == colors[vertex]:
                    return False
    return True


def core_digest(mask: int) -> str:
    return hashlib.sha256(repr(tuple(bit_vertices(mask))).encode()).hexdigest()


def induced_masks(adjacency: Sequence[int], vertices: int) -> tuple[int, ...]:
    chosen = tuple(bit_vertices(vertices))
    local = {vertex: i for i, vertex in enumerate(chosen)}
    return tuple(
        sum(1 << local[other] for other in bit_vertices(adjacency[vertex] & vertices))
        for vertex in chosen
    )


A_THRESHOLDS: tuple[Quadratic, ...] = (
    (-16, 0), (-4, -4), (-8, 0), (4, -4),
    (0, 0), (-4, 4), (8, 0), (4, 4),
)


@dataclass(frozen=True)
class AuditRow:
    family: str
    left: Quadratic
    cross: Quadratic
    root_index: int
    method: str
    cutoff: Quadratic | None = None
    seeds: int = 0
    seed_orbits: int = 0
    nodes: int = 0
    maximum: int = 0


def audit(node_cap: int | None = 2_000_000) -> None:
    roots, _, duals = dual_centroid_orbit()
    root_table = dot_table(roots)
    dual_table = dot_table(duals)
    verify_cross_spectrum(roots, duals)
    cross_thresholds = exact_sorted(qdot(root, dual) for root in roots for dual in duals)
    assert tuple(item[0] for item in EXPECTED_CROSS_SPECTRUM) == tuple(cross_thresholds)
    assert tuple(exact_sorted(root_table[i][j] for i in range(120) for j in range(i))) == A_THRESHOLDS

    ax_ties, bx_ties = classify_ties(A_THRESHOLDS, B_THRESHOLDS, cross_thresholds)
    assert len(ax_ties) == 101
    assert len(bx_ties) == 372
    ax_triples = [tie for tie in ax_ties if tie.triple_levels]
    bx_triples = [tie for tie in bx_ties if tie.triple_levels]
    assert len(ax_triples) == len(bx_triples) == 23
    triple_keys_ax = {
        (tie.left, tie.triple_levels[0], tie.cross) for tie in ax_triples
    }
    triple_keys_bx = {
        (tie.triple_levels[0], tie.left, tie.cross) for tie in bx_triples
    }
    assert triple_keys_ax == triple_keys_bx

    a_omega, b_omega, a_digest, b_digest = local_clique_tables(
        roots, duals, root_table, dual_table, A_THRESHOLDS, cross_thresholds
    )
    # These freeze all 570 exact local clique computations.
    assert a_digest == "ec7469c40f0dcbcead7b10629bb2197a3733cf3cf9f586c597625367c1f71b30"
    assert b_digest == "1dcd5094dce65344df591d83989d3b6a381e5d6ff64122093f16c0e23b0c8d87"

    a_colors = root_full_colorings(roots, root_table)
    _, b_color_digests = dual_four_colorings(dual_table)

    root_generators, dual_generators = reflection_actions(roots, duals)
    b0_stabilizer_on_a = stabilizer_action(
        dual_generators, root_generators, 0, 600, 24
    )
    a0_stabilizer_on_b = stabilizer_action(
        root_generators, dual_generators, 0, 120, 120
    )

    ax_rows: list[AuditRow] = []
    ax_survivors: list[tuple[TieRoot, MixedCoreResult, tuple[int, ...]]] = []
    for tie in ax_ties:
        if tie.triple_levels:
            continue
        u, c = tie.left, tie.cross
        if u in {(-16, 0), (0, 0), (8, 0)}:
            ax_rows.append(AuditRow("AX", u, c, tie.root_index, "A-side-at-most-4"))
            continue
        if a_omega[u, c] <= 4:
            ax_rows.append(AuditRow("AX", u, c, tie.root_index, "local-neighborhood-at-most-4"))
            continue
        if u in a_colors:
            diversity = max(
                len({a_colors[u][i] for i, root in enumerate(roots)
                     if qdot(root, dual) == c})
                for dual in duals
            )
            if diversity <= 4:
                ax_rows.append(AuditRow("AX", u, c, tie.root_index,
                                        "fixed-A-coloring-extends"))
                continue
        relation, compatibility, cutoff = combined_masks_ax(
            roots, duals, root_table, dual_table, tie
        )
        if (u, c) in FULL_AX_COLORINGS:
            encoded = FULL_AX_COLORINGS[u, c]
            assert len(encoded) == len(relation) == 720
            assert hashlib.sha256(encoded.encode()).hexdigest() == EXPECTED_FULL_AX_DIGESTS[u, c]
            verify_coloring(relation, tuple(map(int, encoded)), 5)
            ax_rows.append(AuditRow(
                "AX", u, c, tie.root_index, "full-mixed-relation-5-coloring",
                cutoff,
            ))
            continue
        result = find_mixed_five_core(
            relation, compatibility, 120, b0_stabilizer_on_a, 0, node_cap
        )
        method = "compatible-core-survives" if result.core is not None else "no-compatible-5-core"
        ax_rows.append(AuditRow(
            "AX", u, c, tie.root_index, method, cutoff,
            result.total_seeds, result.seed_orbits, result.search_nodes,
            result.maximum_chosen_size,
        ))
        if result.core is not None:
            ax_survivors.append((tie, result, relation))

    assert len(ax_rows) == 78
    assert len(ax_survivors) == 1
    survivor_tie, survivor_result, survivor_relation = ax_survivors[0]
    assert (survivor_tie.left, survivor_tie.cross, survivor_tie.root_index) == (
        (-8, 0), (-12, -4), 0
    )
    assert tuple(qscale(coefficient, Fraction(1, 8))
                 for coefficient in survivor_tie.root.polynomial) == (
        fq((14, 6)), fq((3, 1)), fq(-4)
    )
    # Eliminate sqrt(5) from
    # (14+6s)r^2+(3+s)r-4 = A(r)+s B(r).
    rational_part = [Fraction(-4), Fraction(3), Fraction(14)]
    radical_part = [Fraction(0), Fraction(1), Fraction(6)]
    resultant = [
        x - 5 * y for x, y in zip(
            convolution(rational_part, rational_part),
            convolution(radical_part, radical_part),
        )
    ]
    assert resultant == [16, -24, -108, 24, 16]
    assert survivor_result.core is not None
    assert sum(v < 120 for v in bit_vertices(survivor_result.core)) >= 1
    assert sum(v >= 120 for v in bit_vertices(survivor_result.core)) >= 1
    forbidden_six = has_k6_minus_matching(survivor_relation, survivor_result.core)
    assert forbidden_six is None
    # Any six-set contains an A or a B vertex; joint H4 transitivity moves
    # one such vertex to A0 or B0.  Hence these two anchors cover the entire
    # surviving compatibility family.
    survivor_relation_all, survivor_compatibility_all, _ = combined_masks_ax(
        roots, duals, root_table, dual_table, survivor_tie
    )
    global_forbidden_six = has_compatible_k6_minus_matching(
        survivor_relation_all, survivor_compatibility_all, (0, 120)
    )
    assert global_forbidden_six is None
    local_survivor = induced_masks(survivor_relation, survivor_result.core)
    survivor_chromatic = None
    for count in range(1, 6):
        if deterministic_coloring(local_survivor, count) is not None:
            survivor_chromatic = count
            break
    assert survivor_chromatic is not None

    # First-stage BX screens are family-wide.  The bounded core audit then
    # covers all pure roots at t=44+20s and t=N/2, and both roots at the two
    # sparse cross levels for t=60+28s and 72+32s.
    selected_sparse = {
        ((60, 28), (24, 8)), ((60, 28), (20, 12)),
        ((72, 32), (24, 8)), ((72, 32), (20, 12)),
    }
    bx_rows: list[AuditRow] = []
    bx_screened_keys: set[tuple[Quadratic, Quadratic, int]] = set()
    bx_core_keys: set[tuple[Quadratic, Quadratic, int]] = set()
    bx_selected_pure: set[tuple[Quadratic, Quadratic, int]] = set()
    for tie in bx_ties:
        if tie.triple_levels:
            continue
        t, c = tie.left, tie.cross
        key = t, c, tie.root_index
        if b_omega[t, c] <= 4:
            bx_rows.append(AuditRow("BX", t, c, tie.root_index,
                                    "local-neighborhood-at-most-4"))
            bx_screened_keys.add(key)
            continue
        if t in FOUR_COLORABLE_B_LEVELS:
            bx_rows.append(AuditRow("BX", t, c, tie.root_index,
                                    "B-side-at-most-4"))
            bx_screened_keys.add(key)
            continue
        selected = t in {(44, 20), (56, 24)} or (t, c) in selected_sparse
        if not selected:
            continue
        bx_selected_pure.add(key)
        relation, compatibility, cutoff = combined_masks_bx(
            roots, duals, root_table, dual_table, tie
        )
        result = find_mixed_five_core(
            relation, compatibility, 0, a0_stabilizer_on_b, 120, node_cap
        )
        assert result.core is None
        bx_rows.append(AuditRow(
            "BX", t, c, tie.root_index, "no-compatible-5-core", cutoff,
            result.total_seeds, result.seed_orbits, result.search_nodes,
            result.maximum_chosen_size,
        ))
        bx_core_keys.add(key)

    pure_bx = [tie for tie in bx_ties if not tie.triple_levels]
    assert len(pure_bx) == 349
    # Selected theorem sizes before overlap with the family-wide screen.
    all_selected = {
        (tie.left, tie.cross, tie.root_index)
        for tie in pure_bx
        if tie.left in {(44, 20), (56, 24)}
        or (tie.left, tie.cross) in selected_sparse
    }
    assert len(all_selected) == 29  # 15 at t44, 6 pure at t56, 8 sparse
    assert bx_selected_pure == all_selected - bx_screened_keys
    bx_eliminated = bx_screened_keys | bx_core_keys

    # A rank-four vector-five representation is automatic here: all graph
    # vertices are an exact subset of an R4 configuration.  The new local
    # forbidden-six screen is nevertheless independently checked above.
    survivor_core = survivor_result.core
    assert survivor_core is not None
    survivor_bipartite = is_bipartite(survivor_relation, survivor_core)

    survivor_tie.root.isolate_bits(90)
    assert survivor_tie.root.low > Fraction(2982, 10000)
    assert survivor_tie.root.high < Fraction(2983, 10000)
    print("mixed H4 arbitrary-deletion two-class exact audit passed")
    print("cross_only_all_bipartite=true")
    print("A_B_two_class_all_five_colorable=true (composition of single-orbit audits)")
    print(f"A_thresholds={len(A_THRESHOLDS)} B_thresholds={len(B_THRESHOLDS)} cross_thresholds={len(cross_thresholds)}")
    print(f"AX_positive_roots={len(ax_ties)} AX_triples_excluded={len(ax_triples)} AX_pure={len(ax_rows)}")
    print(f"AX_pure_eliminated={len(ax_rows)-len(ax_survivors)} AX_pure_survivors={len(ax_survivors)}")
    print("AX_methods=" + repr(collections.Counter(row.method for row in ax_rows)))
    print("AX_local_omega_digest=" + a_digest)
    print("BX_local_omega_digest=" + b_digest)
    print("dual_four_coloring_digests=" + repr(b_color_digests))
    print("stabilizers=(B0_on_A:24,A0_on_B:120)")
    print("AX core-search rows:")
    for row in ax_rows:
        if "core" in row.method:
            print(row)
    print("AX_survivor=(u,c,root)=", survivor_tie.left, survivor_tie.cross,
          survivor_tie.root_index)
    print("AX_survivor_polynomial=", survivor_tie.root.polynomial)
    print("AX_survivor_radius_interval=", survivor_tie.root.low,
          survivor_tie.root.high)
    print("AX_survivor_core_size=", survivor_core.bit_count(),
          "A_vertices=", (survivor_core & ((1 << 120) - 1)).bit_count(),
          "B_vertices=", (survivor_core >> 120).bit_count(),
          "digest=", core_digest(survivor_core))
    print("AX_survivor_core_bipartite=", survivor_bipartite,
          "chromatic=", survivor_chromatic,
          "K6_minus_matching_core=", forbidden_six,
          "K6_minus_matching_all_compatible=", global_forbidden_six)
    print(f"BX_positive_roots={len(bx_ties)} BX_triples_excluded={len(bx_triples)} BX_pure={len(pure_bx)}")
    print(f"BX_familywide_screened={len(bx_screened_keys)} BX_selected_exact={len(all_selected)} BX_eliminated_union={len(bx_eliminated)}")
    print("BX_recorded_methods=" + repr(collections.Counter(row.method for row in bx_rows)))
    print("BX selected core-search rows:")
    for row in bx_rows:
        if row.method == "no-compatible-5-core":
            print(row)
    print("triple_ties_not_claimed=23")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--node-cap", type=int, default=2_000_000,
        help="fail safely if any individual complete core audit grows past this cap",
    )
    parser.add_argument(
        "--uncapped", action="store_true",
        help="remove the conservative per-audit node cap",
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_args()
    audit(None if arguments.uncapped else arguments.node_cap)


if __name__ == "__main__":
    main()
