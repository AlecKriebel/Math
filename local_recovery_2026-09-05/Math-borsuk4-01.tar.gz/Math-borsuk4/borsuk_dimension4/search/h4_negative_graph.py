#!/usr/bin/env python3
"""Exact certificates and obstruction screens for the negative H4 graph.

Coordinates are stored in ``Z[sqrt(5)]`` as pairs ``(a,b)`` denoting
``a+b*sqrt(5)``.  They are four times the usual unit H4 roots.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import itertools
import json
from typing import Iterable, Sequence


Quadratic = tuple[int, int]
Point = tuple[Quadratic, Quadratic, Quadratic, Quadratic]


# The relation order used by the association-scheme audit.  R_0 is the
# diagonal and the remaining entries are the eight pair-product values.
RELATIONS: tuple[Quadratic, ...] = (
    (16, 0),
    (-16, 0),
    (-4, -4),
    (-8, 0),
    (4, -4),
    (0, 0),
    (-4, 4),
    (8, 0),
    (4, 4),
)

NEGATIVE_RELATIONS = frozenset(RELATIONS[1:5])


# A proper seven-coloring of the full 120-vertex negative-product graph.
FULL_SEVEN_COLORING = (
    6, 1, 6, 0, 5, 0, 0, 3, 4, 4, 5, 4, 5, 6, 0, 6, 4, 4, 3, 4,
    5, 0, 6, 4, 5, 5, 6, 5, 6, 6, 5, 6, 6, 0, 5, 1, 0, 1, 3, 2,
    2, 3, 2, 4, 3, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1, 3, 4, 5, 3, 1,
    5, 2, 1, 5, 1, 5, 4, 5, 4, 3, 3, 3, 2, 4, 4, 1, 5, 1, 0, 1,
    3, 4, 5, 6, 4, 4, 5, 2, 1, 2, 2, 3, 1, 2, 2, 1, 2, 2, 3, 1,
    3, 0, 0, 0, 0, 3, 2, 4, 2, 1, 3, 3, 0, 2, 4, 3, 3, 2, 2, 2,
)


# The 28,800 maximum independent sets have four orbits under the four exact
# root reflections below.  These representatives use global root indices.
MAXIMUM_INDEPENDENT_ORBIT_REPRESENTATIVES = (
    (0, 1, 2, 3, 4, 5, 6, 13, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32),
    (0, 1, 3, 4, 5, 6, 9, 13, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32),
    (0, 1, 2, 3, 4, 5, 6, 13, 21, 22, 23, 25, 26, 27, 28, 29, 30, 31, 32, 75),
    (0, 1, 2, 3, 5, 6, 11, 13, 21, 22, 23, 25, 26, 27, 28, 29, 30, 31, 32, 75),
)


# Each root has squared norm 16.  Reflection in r^perp is
# x -> x-2(x.r)/(r.r) r, and therefore remains exact in Z[sqrt(5)].
REFLECTION_ROOTS: tuple[Point, ...] = (
    ((4, 0), (0, 0), (0, 0), (0, 0)),
    ((1, 1), (1, -1), (0, 0), (2, 0)),
    ((2, 0), (2, 0), (2, 0), (2, 0)),
    ((2, 0), (2, 0), (2, 0), (-2, 0)),
)


# Common eigenvalue rows for the nine relation matrices, paired with their
# multiplicities.  Every entry is an exact element a+b*sqrt(5).
ASSOCIATION_CHARACTERS: tuple[tuple[int, tuple[Quadratic, ...]], ...] = (
    (25, ((1, 0), (1, 0), (0, 0), (-4, 0), (0, 0), (6, 0), (0, 0), (-4, 0), (0, 0))),
    (36, ((1, 0), (-1, 0), (2, 0), (0, 0), (-2, 0), (0, 0), (2, 0), (0, 0), (-2, 0))),
    (1, ((1, 0), (1, 0), (12, 0), (20, 0), (12, 0), (30, 0), (12, 0), (20, 0), (12, 0))),
    (16, ((1, 0), (-1, 0), (-3, 0), (5, 0), (3, 0), (0, 0), (-3, 0), (-5, 0), (3, 0))),
    (9, ((1, 0), (1, 0), (2, -2), (0, 0), (2, 2), (-10, 0), (2, 2), (0, 0), (2, -2))),
    (9, ((1, 0), (1, 0), (2, 2), (0, 0), (2, -2), (-10, 0), (2, -2), (0, 0), (2, 2))),
    (4, ((1, 0), (-1, 0), (-3, 3), (-10, 0), (3, 3), (0, 0), (-3, -3), (10, 0), (3, -3))),
    (16, ((1, 0), (1, 0), (-3, 0), (5, 0), (-3, 0), (0, 0), (-3, 0), (5, 0), (-3, 0))),
    (4, ((1, 0), (-1, 0), (-3, -3), (-10, 0), (3, -3), (0, 0), (-3, 3), (10, 0), (3, 3))),
)


# Global indices in the lexicographically sorted 120-root list.
CRITICAL_38_VERTICES = (
    59, 60, 62, 63, 64, 65, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
    80, 81, 82, 84, 85, 86, 101, 102, 103, 104, 105, 109, 110, 111,
    112, 113, 114, 115, 116, 117, 118, 119,
)


# A frozen edge-minimal six-chromatic subgraph on the preceding local vertex
# order.  The graph was obtained by considering the 288 induced-core edges in
# reverse lexicographic order and deleting an edge whenever non-5-colorability
# survived.  Each hexadecimal integer is one local open-neighborhood mask.
CRITICAL_173_MASKS = (
    0x0481A50148,
    0x0302428284,
    0x04D088160A,
    0x0348480D05,
    0x10240014E0,
    0x0824000CD0,
    0x0841864831,
    0x1042461032,
    0x020B008009,
    0x0410011006,
    0x0060C0183C,
    0x21042D0468,
    0x20841A8694,
    0x2640360000,
    0x3838398040,
    0x28916A5102,
    0x310A9C4A01,
    0x228120B0C2,
    0x25021128C1,
    0x201CC1D80C,
    0x3462257000,
    0x2A6112E801,
    0x000008848A,
    0x0000090445,
    0x0A80228141,
    0x1500150182,
    0x0000081830,
    0x0000094108,
    0x000008C204,
    0x1800304430,
    0x06003024CC,
    0x0001029005,
    0x000205080A,
    0x004122210A,
    0x0042142205,
    0x002120C060,
    0x0022114090,
    0x00003FF800,
)


CORE_SIX_COLORING = (
    2, 3, 0, 1, 2, 1, 0, 0, 3, 2, 3, 2, 1, 0, 1, 0, 0, 2, 3,
    3, 2, 3, 2, 1, 1, 1, 0, 2, 4, 0, 4, 3, 4, 5, 5, 2, 3, 4,
)


CRITICAL_173_SIX_COLORING = (
    4, 0, 4, 1, 3, 4, 1, 1, 0, 5, 0, 2, 2, 1, 2, 1, 1, 4, 0,
    0, 4, 0, 2, 2, 2, 2, 1, 3, 3, 1, 2, 0, 3, 3, 3, 3, 0, 3,
)


EXPECTED_COMMON_NEIGHBORHOODS = {
    (-16, 0): (0, 0, 0),
    (-4, -4): (1, 0, 1),
    (-8, 0): (7, 0, 1),
    (4, -4): (12, 5, 3),
    (0, 0): (16, 2, 2),
    (-4, 4): (23, 15, 3),
    (8, 0): (26, 18, 3),
    (4, 4): (34, 46, 3),
}


def qadd(x: Quadratic, y: Quadratic) -> Quadratic:
    return x[0] + y[0], x[1] + y[1]


def qscale(c: int, x: Quadratic) -> Quadratic:
    return c * x[0], c * x[1]


def qmul(x: Quadratic, y: Quadratic) -> Quadratic:
    return x[0] * y[0] + 5 * x[1] * y[1], x[0] * y[1] + x[1] * y[0]


def qsign(x: Quadratic) -> int:
    """Sign in the embedding sqrt(5)>0, using integer arithmetic only."""
    a, b = x
    if b == 0:
        return (a > 0) - (a < 0)
    if a == 0:
        return (b > 0) - (b < 0)
    if (a > 0) == (b > 0):
        return 1 if a > 0 else -1
    comparison = a * a - 5 * b * b
    assert comparison != 0  # Five is not a rational square.
    return (1 if a > 0 else -1) * ((comparison > 0) - (comparison < 0))


def qdot(x: Point, y: Point) -> Quadratic:
    result = (0, 0)
    for a, b in zip(x, y):
        result = qadd(result, qmul(a, b))
    return result


def permutation_parity(permutation: Sequence[int]) -> int:
    return sum(
        permutation[i] > permutation[j]
        for i in range(len(permutation))
        for j in range(i + 1, len(permutation))
    ) % 2


def golden_vectors_scaled_by_four() -> list[Point]:
    """Construct the exact 120-vector orbit in its frozen sorted order."""
    points: list[Point] = []
    zero = (0, 0)

    for coordinate in range(4):
        for sign in (-1, 1):
            point = [zero] * 4
            point[coordinate] = (4 * sign, 0)
            points.append(tuple(point))  # type: ignore[arg-type]

    for signs in itertools.product((-1, 1), repeat=4):
        points.append(tuple((2 * sign, 0) for sign in signs))  # type: ignore[arg-type]

    base: Point = ((0, 0), (2, 0), (1, 1), (-1, 1))
    for permutation in itertools.permutations(range(4)):
        if permutation_parity(permutation):
            continue
        permuted = tuple(base[permutation[i]] for i in range(4))
        nonzero = [i for i, value in enumerate(permuted) if value != zero]
        assert len(nonzero) == 3
        for signs in itertools.product((-1, 1), repeat=3):
            point = list(permuted)
            for coordinate, sign in zip(nonzero, signs):
                a, b = point[coordinate]
                point[coordinate] = sign * a, sign * b
            points.append(tuple(point))  # type: ignore[arg-type]

    answer = sorted(set(points))
    assert len(answer) == 120
    assert {qdot(point, point) for point in answer} == {(16, 0)}
    return answer


def dot_table(points: Sequence[Point]) -> list[list[Quadratic]]:
    result = [[(0, 0)] * len(points) for _ in points]
    for i, point in enumerate(points):
        result[i][i] = qdot(point, point)
        for j in range(i):
            result[i][j] = result[j][i] = qdot(point, points[j])
    return result


def negative_adjacency(table: Sequence[Sequence[Quadratic]]) -> list[set[int]]:
    result = [set() for _ in table]
    for i in range(len(table)):
        for j in range(i):
            if qsign(table[i][j]) < 0:
                result[i].add(j)
                result[j].add(i)
    return result


def edge_list(adjacency: Sequence[set[int]]) -> list[tuple[int, int]]:
    return [
        (i, j)
        for i, neighbors in enumerate(adjacency)
        for j in sorted(neighbors)
        if i < j
    ]


def adjacency_masks(adjacency: Sequence[set[int]]) -> tuple[int, ...]:
    return tuple(sum(1 << j for j in neighbors) for neighbors in adjacency)


def induced_adjacency(
    adjacency: Sequence[set[int]], vertices: Sequence[int]
) -> list[set[int]]:
    index = {vertex: i for i, vertex in enumerate(vertices)}
    return [
        {index[w] for w in adjacency[vertex] if w in index}
        for vertex in vertices
    ]


def verify_coloring(
    adjacency: Sequence[set[int]], colors: Sequence[int], color_count: int
) -> None:
    assert len(adjacency) == len(colors)
    assert set(colors) <= set(range(color_count))
    assert all(
        colors[i] != colors[j]
        for i, neighbors in enumerate(adjacency)
        for j in neighbors
    )


def frozen_critical_173_adjacency() -> list[set[int]]:
    """Return the frozen 38-vertex graph in local indices 0,...,37."""
    return [
        {j for j in range(len(CRITICAL_173_MASKS)) if (mask >> j) & 1}
        for mask in CRITICAL_173_MASKS
    ]


def exact_k_coloring(adjacency: Sequence[set[int]], k: int) -> list[int] | None:
    """Complete deterministic DSATUR backtracking with color symmetry broken."""
    colors = [-1] * len(adjacency)

    def search(colored: int, used: int) -> bool:
        if colored == len(adjacency):
            return True
        vertex = max(
            (v for v in range(len(adjacency)) if colors[v] < 0),
            key=lambda v: (
                len({colors[w] for w in adjacency[v] if colors[w] >= 0}),
                sum(colors[w] < 0 for w in adjacency[v]),
                len(adjacency[v]),
                v,
            ),
        )
        forbidden = {colors[w] for w in adjacency[vertex] if colors[w] >= 0}
        choices = [color for color in range(used) if color not in forbidden]
        if used < k and used not in forbidden:
            choices.append(used)
        for color in choices:
            colors[vertex] = color
            if search(colored + 1, max(used, color + 1)):
                return True
            colors[vertex] = -1
        return False

    if not search(0, 0):
        return None
    verify_coloring(adjacency, colors, k)
    return colors


def maximal_cliques(adjacency: Sequence[int]) -> list[tuple[int, ...]]:
    """Enumerate all maximal cliques by exact Bron--Kerbosch pivoting."""
    n = len(adjacency)
    result: list[tuple[int, ...]] = []

    def search(chosen: tuple[int, ...], candidates: int, excluded: int) -> None:
        if not candidates and not excluded:
            result.append(tuple(sorted(chosen)))
            return
        possible_pivots = candidates | excluded
        if possible_pivots:
            pivot = max(
                (v for v in range(n) if (possible_pivots >> v) & 1),
                key=lambda v: (candidates & adjacency[v]).bit_count(),
            )
            extensions = candidates & ~adjacency[pivot]
        else:
            extensions = candidates
        while extensions:
            bit = extensions & -extensions
            extensions ^= bit
            vertex = bit.bit_length() - 1
            search(
                chosen + (vertex,),
                candidates & adjacency[vertex],
                excluded & adjacency[vertex],
            )
            candidates ^= bit
            excluded |= bit

    search((), (1 << n) - 1, 0)
    result.sort()
    assert len(result) == len(set(result))
    return result


def clique_digest(cliques: Sequence[tuple[int, ...]]) -> str:
    encoding = ";".join(",".join(map(str, clique)) for clique in cliques)
    return hashlib.sha256(encoding.encode()).hexdigest()


def bits(mask: int) -> Iterable[int]:
    while mask:
        bit = mask & -mask
        mask ^= bit
        yield bit.bit_length() - 1


def find_clique(adjacency: Sequence[set[int]], target: int) -> tuple[int, ...] | None:
    masks = adjacency_masks(adjacency)

    def search(chosen: tuple[int, ...], candidates: int) -> tuple[int, ...] | None:
        need = target - len(chosen)
        if need == 0:
            return chosen
        while candidates.bit_count() >= need:
            bit = candidates & -candidates
            candidates ^= bit
            vertex = bit.bit_length() - 1
            answer = search(chosen + (vertex,), candidates & masks[vertex])
            if answer is not None:
                return answer
        return None

    return search((), (1 << len(adjacency)) - 1)


def delete_vertex(adjacency: Sequence[set[int]], omitted: int) -> list[set[int]]:
    vertices = [v for v in range(len(adjacency)) if v != omitted]
    index = {v: i for i, v in enumerate(vertices)}
    return [
        {index[w] for w in adjacency[v] if w != omitted}
        for v in vertices
    ]


def edge_count_in_mask(adjacency: Sequence[set[int]], mask: int) -> int:
    return sum(
        1
        for u in bits(mask)
        for v in adjacency[u]
        if u < v and (mask >> v) & 1
    )


def reflect(point: Point, root: Point) -> Point:
    assert qdot(root, root) == (16, 0)
    product = qdot(point, root)
    result: list[Quadratic] = []
    for coordinate, root_coordinate in zip(point, root):
        correction = qmul(product, root_coordinate)
        assert correction[0] % 8 == correction[1] % 8 == 0
        result.append((
            coordinate[0] - correction[0] // 8,
            coordinate[1] - correction[1] // 8,
        ))
    return tuple(result)  # type: ignore[return-value]


def reflection_permutations(
    points: Sequence[Point], table: Sequence[Sequence[Quadratic]]
) -> tuple[tuple[int, ...], ...]:
    index = {point: i for i, point in enumerate(points)}
    permutations = tuple(
        tuple(index[reflect(point, root)] for point in points)
        for root in REFLECTION_ROOTS
    )
    for permutation in permutations:
        assert len(set(permutation)) == len(points)
        for i in range(len(points)):
            for j in range(i):
                assert table[permutation[i]][permutation[j]] == table[i][j]

    reached = {0}
    boundary = [0]
    while boundary:
        vertex = boundary.pop()
        for permutation in permutations:
            image = permutation[vertex]
            if image not in reached:
                reached.add(image)
                boundary.append(image)
    assert len(reached) == len(points)
    return permutations


def permute_mask(mask: int, permutation: Sequence[int]) -> int:
    return sum(1 << permutation[v] for v in bits(mask))


def mask_orbit(seed: int, permutations: Sequence[Sequence[int]]) -> set[int]:
    reached = {seed}
    boundary = [seed]
    while boundary:
        mask = boundary.pop()
        for permutation in permutations:
            image = permute_mask(mask, permutation)
            if image not in reached:
                reached.add(image)
                boundary.append(image)
    return reached


def verify_pair_orbits(
    table: Sequence[Sequence[Quadratic]],
    permutations: Sequence[Sequence[int]],
) -> dict[Quadratic, tuple[int, int]]:
    """Show that each non-diagonal product relation is one group orbit."""
    pairs_by_relation: dict[Quadratic, set[tuple[int, int]]] = {
        relation: set() for relation in RELATIONS[1:]
    }
    for i in range(len(table)):
        for j in range(i):
            pairs_by_relation[table[i][j]].add((j, i))

    representatives: dict[Quadratic, tuple[int, int]] = {}
    for relation, target in pairs_by_relation.items():
        seed = min(target)
        reached = {seed}
        boundary = [seed]
        while boundary:
            pair = boundary.pop()
            for permutation in permutations:
                image = tuple(sorted((permutation[pair[0]], permutation[pair[1]])))
                if image not in reached:
                    reached.add(image)
                    boundary.append(image)
        assert reached == target
        representatives[relation] = seed

    expected_sizes = {
        (-16, 0): 60,
        (-4, -4): 720,
        (-8, 0): 1200,
        (4, -4): 720,
        (0, 0): 1800,
        (-4, 4): 720,
        (8, 0): 1200,
        (4, 4): 720,
    }
    assert {r: len(p) for r, p in pairs_by_relation.items()} == expected_sizes
    return {
        relation: (representatives[relation][0], representatives[relation][1])
        for relation in RELATIONS[1:]
    }


def association_intersection_numbers(
    table: Sequence[Sequence[Quadratic]],
) -> list[list[list[int]]]:
    """Construct and independently verify all association intersection numbers."""
    relation_index = {relation: i for i, relation in enumerate(RELATIONS)}
    indices = [
        [relation_index[table[i][j]] for j in range(len(table))]
        for i in range(len(table))
    ]
    seen = [False] * len(RELATIONS)
    tensors: list[list[list[int]]] = [
        [[0] * len(RELATIONS) for _ in RELATIONS] for _ in RELATIONS
    ]

    # For every ordered (x,y), count z by the two relation labels x-z,z-y.
    # Constancy on R_k is checked rather than assumed.
    signatures: list[tuple[tuple[int, ...], ...] | None] = [None] * len(RELATIONS)
    for x in range(len(table)):
        for y in range(len(table)):
            k = indices[x][y]
            counts = [[0] * len(RELATIONS) for _ in RELATIONS]
            for z in range(len(table)):
                counts[indices[x][z]][indices[z][y]] += 1
            signature = tuple(tuple(row) for row in counts)
            if signatures[k] is None:
                signatures[k] = signature
                seen[k] = True
            else:
                assert signatures[k] == signature

    assert all(seen)
    for k, signature in enumerate(signatures):
        assert signature is not None
        for i in range(len(RELATIONS)):
            for j in range(len(RELATIONS)):
                tensors[i][j][k] = signature[i][j]

    # The algebra is commutative.
    assert all(
        tensors[i][j] == tensors[j][i]
        for i in range(len(RELATIONS))
        for j in range(len(RELATIONS))
    )
    return tensors


def verify_association_characters(
    table: Sequence[Sequence[Quadratic]],
) -> collections.Counter[Quadratic]:
    intersection = association_intersection_numbers(table)
    assert sum(multiplicity for multiplicity, _ in ASSOCIATION_CHARACTERS) == 120
    assert len({row for _, row in ASSOCIATION_CHARACTERS}) == 9

    for multiplicity, row in ASSOCIATION_CHARACTERS:
        assert len(row) == len(RELATIONS) and row[0] == (1, 0)
        for i in range(len(RELATIONS)):
            for j in range(len(RELATIONS)):
                right = (0, 0)
                for k in range(len(RELATIONS)):
                    right = qadd(right, qscale(intersection[i][j][k], row[k]))
                assert qmul(row[i], row[j]) == right

    # Trace(A_i)=120 for the identity relation and zero otherwise.
    for i in range(len(RELATIONS)):
        trace = (0, 0)
        for multiplicity, row in ASSOCIATION_CHARACTERS:
            trace = qadd(trace, qscale(multiplicity, row[i]))
        assert trace == ((120, 0) if i == 0 else (0, 0))

    # The two multiplicity-four rows give the only invariant PSD primitive
    # spaces of rank at most four.  Four times their edge-relation Gram values
    # lambda_i/k_i are displayed here; neither can equalize all four edges.
    rank_four_rows = [row for multiplicity, row in ASSOCIATION_CHARACTERS if multiplicity == 4]
    assert len(rank_four_rows) == 2
    scaled_edge_grams = []
    valencies = (1, 1, 12, 20, 12, 30, 12, 20, 12)
    for row in rank_four_rows:
        values = []
        for i in range(1, 5):
            numerator = qscale(4, row[i])
            assert numerator[0] % valencies[i] == numerator[1] % valencies[i] == 0
            values.append((numerator[0] // valencies[i], numerator[1] // valencies[i]))
        assert len(set(values)) == 4
        scaled_edge_grams.append(tuple(values))
    assert set(scaled_edge_grams) == {
        ((-4, 0), (-1, -1), (-2, 0), (1, -1)),
        ((-4, 0), (-1, 1), (-2, 0), (1, 1)),
    }

    spectrum: collections.Counter[Quadratic] = collections.Counter()
    for multiplicity, row in ASSOCIATION_CHARACTERS:
        eigenvalue = (0, 0)
        for i in range(1, 5):
            eigenvalue = qadd(eigenvalue, row[i])
        spectrum[eigenvalue] += multiplicity
    assert spectrum == collections.Counter({
        (45, 0): 1,
        (-3, 0): 25,
        (-1, 0): 36,
        (4, 0): 16,
        (5, 0): 18,
        (-11, 6): 4,
        (0, 0): 16,
        (-11, -6): 4,
    })
    return spectrum


def enumerate_maximal_independent_sets(
    table: Sequence[Sequence[Quadratic]],
) -> list[tuple[int, ...]]:
    """Enumerate all maximal sets whose pair products are nonnegative."""
    compatibility = tuple(
        sum(
            1 << j
            for j in range(len(table))
            if i != j and qsign(table[i][j]) >= 0
        )
        for i in range(len(table))
    )
    result = maximal_cliques(compatibility)
    assert collections.Counter(map(len, result)) == {20: 28800, 17: 1200}
    assert clique_digest(result) == "5ea861917eac9194187f318d6a8532176c5910f5a72dd375b1583d696a025e9a"
    return result


def verify_maximum_set_orbits(
    maximum_sets: Sequence[tuple[int, ...]],
    permutations: Sequence[Sequence[int]],
) -> tuple[int, ...]:
    maximum_masks = {sum(1 << v for v in row) for row in maximum_sets}
    assert len(maximum_masks) == 28800
    uncovered = set(maximum_masks)
    sizes = []
    for representative in MAXIMUM_INDEPENDENT_ORBIT_REPRESENTATIVES:
        seed = sum(1 << v for v in representative)
        assert seed in uncovered
        orbit = mask_orbit(seed, permutations)
        assert orbit <= maximum_masks
        assert orbit <= uncovered
        uncovered -= orbit
        sizes.append(len(orbit))
    assert not uncovered
    assert tuple(sizes) == (7200, 4800, 14400, 2400)
    return tuple(sizes)


def exact_cover_completion_nodes(
    maximum_sets: Sequence[tuple[int, ...]], first_class: Sequence[int]
) -> tuple[bool, int]:
    """Try to complete a fixed size-20 color class to a six-coloring."""
    n = 120
    rows = sorted(sum(1 << v for v in row) for row in maximum_sets)
    row_lookup = set(rows)
    rows_by_vertex = [0] * n
    for index, row in enumerate(rows):
        for vertex in bits(row):
            rows_by_vertex[vertex] |= 1 << index

    all_vertices = (1 << n) - 1
    available = (1 << len(rows)) - 1
    used = sum(1 << v for v in first_class)
    for vertex in bits(used):
        available &= ~rows_by_vertex[vertex]

    nodes = 0

    def search(covered: int, candidates: int, classes_left: int) -> bool:
        nonlocal nodes
        nodes += 1
        remaining = all_vertices ^ covered
        vertex = min(
            bits(remaining),
            key=lambda v: (candidates & rows_by_vertex[v]).bit_count(),
        )
        choices = candidates & rows_by_vertex[vertex]

        if classes_left == 2:
            while choices:
                bit = choices & -choices
                choices ^= bit
                row = rows[bit.bit_length() - 1]
                if (remaining ^ row) in row_lookup:
                    return True
            return False

        while choices:
            bit = choices & -choices
            choices ^= bit
            row = rows[bit.bit_length() - 1]
            next_candidates = candidates
            for v in bits(row):
                next_candidates &= ~rows_by_vertex[v]
            if search(covered | row, next_candidates, classes_left - 1):
                return True
        return False

    return search(used, available, 5), nodes


def verify_full_chromatic_number(
    table: Sequence[Sequence[Quadratic]],
    adjacency: Sequence[set[int]],
    permutations: Sequence[Sequence[int]],
) -> dict[str, object]:
    verify_coloring(adjacency, FULL_SEVEN_COLORING, 7)
    assert collections.Counter(FULL_SEVEN_COLORING) == {
        0: 20, 1: 16, 2: 18, 3: 20, 4: 18, 5: 17, 6: 11,
    }

    maximal = enumerate_maximal_independent_sets(table)
    maximum = [row for row in maximal if len(row) == 20]
    orbit_sizes = verify_maximum_set_orbits(maximum, permutations)
    cover_results = tuple(
        exact_cover_completion_nodes(maximum, representative)
        for representative in MAXIMUM_INDEPENDENT_ORBIT_REPRESENTATIVES
    )
    assert cover_results == (
        (False, 1154),
        (False, 1226),
        (False, 953),
        (False, 1411),
    )

    # alpha=20 gives chi>=6.  Equality would make all six color classes
    # maximum independent sets; the four orbit-reduced exact-cover failures
    # exclude it.  The displayed coloring proves chi<=7.
    return {
        "alpha": 20,
        "maximal_independent_sets": len(maximal),
        "maximum_independent_sets": len(maximum),
        "maximum_set_orbit_sizes": orbit_sizes,
        "six_cover_nodes": tuple(nodes for _, nodes in cover_results),
        "chi": 7,
    }


def chromatic_number(adjacency: Sequence[set[int]], maximum: int = 5) -> int:
    if not adjacency:
        return 0
    for k in range(1, maximum + 1):
        if exact_k_coloring(adjacency, k) is not None:
            return k
    raise AssertionError(f"chromatic number exceeds supplied maximum {maximum}")


def common_neighborhood_table(
    adjacency: Sequence[set[int]],
    table: Sequence[Sequence[Quadratic]],
    representatives: dict[Quadratic, tuple[int, int]],
) -> dict[Quadratic, tuple[int, int, int]]:
    result = {}
    for relation in RELATIONS[1:]:
        u, v = representatives[relation]
        common = sorted(adjacency[u] & adjacency[v])
        local = induced_adjacency(adjacency, common)
        result[relation] = (
            len(common),
            len(edge_list(local)),
            chromatic_number(local),
        )
    assert result == EXPECTED_COMMON_NEIGHBORHOODS
    return result


def k6_minus_matching_witnesses(
    adjacency: Sequence[set[int]],
) -> list[tuple[tuple[int, ...], tuple[tuple[int, int], ...]]]:
    """Find six-sets whose missing pairs form a matching (possibly empty)."""
    result = []
    for vertices in itertools.combinations(range(len(adjacency)), 6):
        missing = tuple(
            (u, v)
            for u, v in itertools.combinations(vertices, 2)
            if v not in adjacency[u]
        )
        if all(sum(vertex in pair for pair in missing) <= 1 for vertex in vertices):
            result.append((vertices, missing))
    return result


def cone_k33_witness(
    adjacency: Sequence[set[int]],
) -> tuple[int, tuple[int, int, int], tuple[int, int, int]] | None:
    """Find K_1 join K_3,3 as a non-induced subgraph."""
    masks = adjacency_masks(adjacency)
    for center, neighbors in enumerate(masks):
        for left in itertools.combinations(bits(neighbors), 3):
            right = neighbors
            for vertex in left:
                right &= masks[vertex]
            right &= ~sum(1 << vertex for vertex in left)
            if right.bit_count() >= 3:
                chosen = tuple(itertools.islice(bits(right), 3))
                return center, left, chosen  # type: ignore[return-value]
    return None


def k2_join_c4_witness(
    adjacency: Sequence[set[int]],
) -> tuple[tuple[int, int], tuple[int, int, int, int]] | None:
    """Find an edge whose common neighborhood contains a four-cycle."""
    for u, v in edge_list(adjacency):
        common = adjacency[u] & adjacency[v]
        for a, c in itertools.combinations(sorted(common), 2):
            opposite_common = (adjacency[a] & adjacency[c] & common) - {a, c}
            if len(opposite_common) >= 2:
                b, d = sorted(opposite_common)[:2]
                return (u, v), (a, b, c, d)
    return None


def crossed_two_edge_blocks(
    adjacency: Sequence[set[int]],
) -> tuple[tuple[int, ...], tuple[int, ...]] | None:
    """Find cross-complete blocks each containing two graph edges.

    Completeness of the test follows by fixing one edge in the left block:
    both right edges then lie in its common neighborhood.  Conversely, the
    common neighborhood of the right support must contain two left edges.
    """
    edges = edge_list(adjacency)
    masks = adjacency_masks(adjacency)
    for u, v in edges:
        common = masks[u] & masks[v]
        internal = [
            edge for edge in edges
            if (common >> edge[0]) & 1 and (common >> edge[1]) & 1
        ]
        for first, second in itertools.combinations(internal, 2):
            right = sum(1 << x for x in {*first, *second})
            left_common = (1 << len(adjacency)) - 1
            for vertex in bits(right):
                left_common &= masks[vertex]
            if edge_count_in_mask(adjacency, left_common) >= 2:
                left_edges = [
                    edge for edge in edges
                    if (left_common >> edge[0]) & 1 and (left_common >> edge[1]) & 1
                ][:2]
                left = tuple(sorted({*left_edges[0], *left_edges[1]}))
                return left, tuple(bits(right))
    return None


def two_edge_support_count(adjacency: Sequence[set[int]]) -> int:
    edges = edge_list(adjacency)
    return len({
        sum(1 << vertex for vertex in {*first, *second})
        for first, second in itertools.combinations(edges, 2)
    })


def edge_common_neighborhood_statistics(
    adjacency: Sequence[set[int]],
) -> tuple[collections.Counter[int], collections.Counter[int]]:
    size_histogram: collections.Counter[int] = collections.Counter()
    chromatic_histogram: collections.Counter[int] = collections.Counter()
    for u, v in edge_list(adjacency):
        common = sorted(adjacency[u] & adjacency[v])
        local = induced_adjacency(adjacency, common)
        size_histogram[len(common)] += 1
        chromatic_histogram[chromatic_number(local)] += 1
    return size_histogram, chromatic_histogram


def count_k_cliques(adjacency: Sequence[set[int]], k: int) -> int:
    return sum(
        all(v in adjacency[u] for u, v in itertools.combinations(vertices, 2))
        for vertices in itertools.combinations(range(len(adjacency)), k)
    )


def greedy_reverse_edge_critical(
    adjacency: Sequence[set[int]],
) -> list[set[int]]:
    """Deterministically strip reverse-lex edges while retaining chi>5."""
    result = [set(neighbors) for neighbors in adjacency]
    for u, v in reversed(edge_list(adjacency)):
        result[u].remove(v)
        result[v].remove(u)
        if exact_k_coloring(result, 5) is not None:
            result[u].add(v)
            result[v].add(u)
    return result


def globalize_witnesses(
    witnesses: Sequence[tuple[tuple[int, ...], tuple[tuple[int, int], ...]]],
    vertices: Sequence[int],
) -> list[tuple[tuple[int, ...], tuple[tuple[int, int], ...]]]:
    return [
        (
            tuple(vertices[v] for v in chosen),
            tuple((vertices[u], vertices[v]) for u, v in missing),
        )
        for chosen, missing in witnesses
    ]


def matching_witness_digest(
    witnesses: Sequence[tuple[tuple[int, ...], tuple[tuple[int, int], ...]]]
) -> str:
    encoding = ";".join(
        ",".join(map(str, vertices))
        + "|"
        + ",".join(f"{u}-{v}" for u, v in missing)
        for vertices, missing in witnesses
    )
    return hashlib.sha256(encoding.encode()).hexdigest()


def verify_core_and_obstructions(
    full_adjacency: Sequence[set[int]],
) -> tuple[list[set[int]], list[tuple[tuple[int, ...], tuple[tuple[int, int], ...]]]]:
    core = induced_adjacency(full_adjacency, CRITICAL_38_VERTICES)
    assert len(edge_list(core)) == 288
    assert exact_k_coloring(core, 5) is None
    verify_coloring(core, CORE_SIX_COLORING, 6)

    vertex_deletion_colorings = []
    for vertex in range(len(core)):
        coloring = exact_k_coloring(delete_vertex(core, vertex), 5)
        assert coloring is not None
        vertex_deletion_colorings.append(coloring)
    encoding = ";".join(",".join(map(str, coloring)) for coloring in vertex_deletion_colorings)
    assert hashlib.sha256(encoding.encode()).hexdigest() == (
        "1a4a84c1a1400b380715d40406bba07e7031b29d696304c7ba2381b6909eace4"
    )

    local_witnesses = k6_minus_matching_witnesses(core)
    global_witnesses = globalize_witnesses(local_witnesses, CRITICAL_38_VERTICES)
    assert len(global_witnesses) == 19
    assert global_witnesses[0] == (
        (59, 70, 72, 75, 80, 82),
        ((59, 75), (70, 80), (72, 82)),
    )
    assert matching_witness_digest(global_witnesses) == (
        "67a1521f50c197d18efd681ea77603d0d539043286550b40a55892a284d5598b"
    )

    # A second, independent unit-distance obstruction is already visible.
    assert cone_k33_witness(core) == (10, (2, 4, 11), (3, 5, 12))
    return core, global_witnesses


def verify_critical_173(
    core: Sequence[set[int]],
    table: Sequence[Sequence[Quadratic]],
) -> dict[str, object]:
    critical = frozen_critical_173_adjacency()
    assert all(i not in neighbors for i, neighbors in enumerate(critical))
    assert all(i in critical[j] for i, neighbors in enumerate(critical) for j in neighbors)
    assert all(critical[i] <= core[i] for i in range(len(core)))
    assert adjacency_masks(critical) == CRITICAL_173_MASKS
    assert len(edge_list(critical)) == 173

    regenerated = greedy_reverse_edge_critical(core)
    assert adjacency_masks(regenerated) == CRITICAL_173_MASKS
    assert exact_k_coloring(critical, 5) is None
    verify_coloring(critical, CRITICAL_173_SIX_COLORING, 6)

    edge_deletion_colorings = []
    for u, v in edge_list(critical):
        deleted = [set(neighbors) for neighbors in critical]
        deleted[u].remove(v)
        deleted[v].remove(u)
        coloring = exact_k_coloring(deleted, 5)
        assert coloring is not None
        edge_deletion_colorings.append(((u, v), coloring))
    encoding = ";".join(
        f"{u}-{v}:" + ",".join(map(str, coloring))
        for (u, v), coloring in edge_deletion_colorings
    )
    assert hashlib.sha256(encoding.encode()).hexdigest() == (
        "045d34b2a0a8b1fa0beb81d8e7e4fd24172dd0a2743b7c9117ec1391ba4c0784"
    )

    local_edges = edge_list(critical)
    global_edges = [
        (CRITICAL_38_VERTICES[u], CRITICAL_38_VERTICES[v]) for u, v in local_edges
    ]
    global_edge_encoding = ";".join(f"{u},{v}" for u, v in global_edges)
    assert hashlib.sha256(global_edge_encoding.encode()).hexdigest() == (
        "9024557b01880a4d2e5a74b3ae555ffae41356957165ce559cadbc68dcb2d204"
    )

    relation_counts = collections.Counter(
        table[CRITICAL_38_VERTICES[u]][CRITICAL_38_VERTICES[v]]
        for u, v in local_edges
    )
    assert relation_counts == {
        (4, -4): 123,
        (-8, 0): 36,
        (-4, -4): 14,
    }
    # Dividing the root products by 16 gives unit vectors.  Their largest
    # edge product is (1-sqrt(5))/4 < -1/4 because sqrt(5)>2.
    assert qsign((2, -1)) < 0

    assert find_clique(critical, 4) is not None
    assert find_clique(critical, 5) is None
    assert count_k_cliques(critical, 4) == 38
    assert k6_minus_matching_witnesses(critical) == []
    assert cone_k33_witness(critical) is None
    assert k2_join_c4_witness(critical) is None
    assert crossed_two_edge_blocks(critical) is None
    assert two_edge_support_count(critical) == 13793
    assert max(map(len, critical)) < len(critical) - 1

    common_sizes, common_chromatic = edge_common_neighborhood_statistics(critical)
    assert common_sizes == {0: 4, 1: 26, 2: 38, 3: 49, 4: 29, 5: 23, 6: 4}
    assert common_chromatic == {0: 4, 1: 76, 2: 78, 3: 15}

    degrees = tuple(sorted(map(len, critical)))
    assert degrees == (
        5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 7, 8, 8, 8, 8, 8, 8, 9, 9,
        9, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 13,
        13, 13, 13,
    )
    return {
        "vertices": len(critical),
        "edges": len(local_edges),
        "degrees": degrees,
        "k4_count": 38,
        "edge_common_size_histogram": dict(common_sizes),
        "edge_common_chromatic_histogram": dict(common_chromatic),
        "global_edge_digest": hashlib.sha256(global_edge_encoding.encode()).hexdigest(),
        "screens": "all listed screens passed",
    }


def verify(heavy_support_count: bool = False) -> dict[str, object]:
    points = golden_vectors_scaled_by_four()
    table = dot_table(points)
    pair_spectrum = collections.Counter(
        table[i][j] for i in range(len(points)) for j in range(i)
    )
    assert pair_spectrum == collections.Counter({
        (-16, 0): 60,
        (-4, -4): 720,
        (-8, 0): 1200,
        (4, -4): 720,
        (0, 0): 1800,
        (-4, 4): 720,
        (8, 0): 1200,
        (4, 4): 720,
    })
    assert {relation for relation in RELATIONS[1:] if qsign(relation) < 0} == NEGATIVE_RELATIONS

    negative = negative_adjacency(table)
    assert len(edge_list(negative)) == 2700
    assert {len(neighbors) for neighbors in negative} == {45}
    assert all(
        qsign(qadd(table[u][v], (4, 0))) < 0
        for u, v in edge_list(negative)
    )
    assert find_clique(negative, 4) is not None
    assert find_clique(negative, 5) is None
    assert max(map(len, negative)) < len(negative) - 1

    permutations = reflection_permutations(points, table)
    pair_representatives = verify_pair_orbits(table, permutations)
    common_table = common_neighborhood_table(negative, table, pair_representatives)
    association_spectrum = verify_association_characters(table)
    tau = (-11, -6)
    assert association_spectrum[tau] == 4
    assert qsign(qadd((45, 0), qscale(4, tau))) < 0  # k <= -4*tau passes.

    full_chromatic = verify_full_chromatic_number(table, negative, permutations)
    core, matching_witnesses = verify_core_and_obstructions(negative)
    critical = verify_critical_173(core, table)

    # Standard monotone diameter-subgraph screens on the full graph.
    assert k2_join_c4_witness(negative) is None
    assert crossed_two_edge_blocks(negative) is None
    assert cone_k33_witness(negative) == (0, (33, 35, 36), (41, 42, 44))
    assert max(value[2] for value in common_table.values()) == 3

    support_count = None
    if heavy_support_count:
        support_count = two_edge_support_count(negative)
        assert support_count == 3000010

    return {
        "full_graph": {
            "vertices": 120,
            "edges": 2700,
            "degree": 45,
            **full_chromatic,
            "clique_number": 4,
            "pair_common_neighborhood_table": {
                str(relation): value for relation, value in common_table.items()
            },
            "adjacency_spectrum": {
                str(eigenvalue): multiplicity
                for eigenvalue, multiplicity in association_spectrum.items()
            },
            "two_edge_support_count": support_count,
        },
        "induced_core": {
            "vertices": 38,
            "edges": 288,
            "chi": 6,
            "vertex_critical": True,
            "k6_minus_matching_witness_count": len(matching_witnesses),
            "first_matching_witness": matching_witnesses[0],
            "cone_k33_witness_local": (10, (2, 4, 11), (3, 5, 12)),
        },
        "critical_173": critical,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--heavy-support-count",
        action="store_true",
        help="also reconstruct the 3,000,010 full-graph two-edge supports",
    )
    parser.add_argument(
        "--emit-edges",
        action="store_true",
        help="print the 173 global-index edges after verification",
    )
    parser.add_argument(
        "--emit-matching-witnesses",
        action="store_true",
        help="print all 19 K6-minus-matching witnesses after verification",
    )
    arguments = parser.parse_args()
    summary = verify(arguments.heavy_support_count)
    print(json.dumps(summary, indent=2, sort_keys=True))

    if arguments.emit_edges:
        critical = frozen_critical_173_adjacency()
        print("critical_173_global_edges =")
        print([
            (CRITICAL_38_VERTICES[u], CRITICAL_38_VERTICES[v])
            for u, v in edge_list(critical)
        ])

    if arguments.emit_matching_witnesses:
        points = golden_vectors_scaled_by_four()
        core = induced_adjacency(negative_adjacency(dot_table(points)), CRITICAL_38_VERTICES)
        witnesses = globalize_witnesses(
            k6_minus_matching_witnesses(core), CRITICAL_38_VERTICES
        )
        print("k6_minus_matching_witnesses =")
        print(witnesses)


if __name__ == "__main__":
    main()
