#!/usr/bin/env python3
"""Discovery-only random search for the r=2 target-information inequality.

This builds the exact geometric-union event kernel in floating arithmetic,
computes its stationary law, and reports the largest observed I_2-2.  Any
positive output is only a candidate and must be rerun over exact rationals.
"""

from __future__ import annotations

import argparse
from itertools import combinations

import numpy as np
import scipy.linalg


def union_law(row: np.ndarray, fitness: float) -> dict[int, float]:
    support = np.flatnonzero(row > 0)
    values = np.zeros(1 << len(support))
    for mask in range(1, len(values)):
        mass = sum(row[support[j]] for j in range(len(support)) if mask >> j & 1)
        values[mask] = mass / (fitness - (fitness - 1.0) * mass)
    for j in range(len(support)):
        for mask in range(len(values)):
            if mask >> j & 1:
                values[mask] -= values[mask ^ (1 << j)]
    answer: dict[int, float] = {}
    for mask in range(1, len(values)):
        if values[mask] > 1e-15:
            actual = sum(1 << int(support[j]) for j in range(len(support)) if mask >> j & 1)
            answer[actual] = values[mask]
    return answer


def stationary_i2(weights: np.ndarray, fitness: float) -> tuple[float, float, float, float]:
    n = len(weights)
    P = weights / weights.sum(axis=1)[:, None]
    states = np.arange(1, 1 << n, dtype=int)
    index = {int(state): pos for pos, state in enumerate(states)}
    laws = [union_law(P[v], fitness) for v in range(n)]
    kernels = []
    average = np.zeros((len(states), len(states)))
    for v in range(n):
        kernel = np.zeros_like(average)
        for pos, A in enumerate(states):
            if not (A >> v) & 1:
                kernel[pos, pos] = 1.0
            else:
                for U, probability in laws[v].items():
                    B = (int(A) & ~(1 << v)) | U
                    kernel[pos, index[B]] += probability
        kernels.append(kernel)
        average += kernel / n
    matrix = average.T - np.eye(len(states))
    matrix[-1] = 1.0
    rhs = np.zeros(len(states))
    rhs[-1] = 1.0
    pi = scipy.linalg.solve(matrix, rhs, assume_a="gen", check_finite=False)
    residual = float(np.max(np.abs(pi @ average - pi)))
    i2 = 0.0
    individual_excess = []
    densities = []
    for v, kernel in enumerate(kernels):
        mu = pi @ kernel
        density = np.zeros_like(pi)
        support = pi > 1e-14
        density[support] = mu[support] / pi[support]
        densities.append(density)
        i2 += float(np.sum(mu[support] * mu[support] / pi[support])) / n
        holes = np.array([not (int(A) >> v) & 1 for A in states])
        e = density - holes.astype(float)
        individual_excess.append(float(np.sum(pi * e * e) - np.sum(pi * holes)))
    mean = float(sum(pi[pos] * int(A).bit_count() for pos, A in enumerate(states)))
    pointwise = []
    for pos, A in enumerate(states[:-1]):
        active = sum(
            float(kernels[v][pos] @ densities[v])
            for v in range(n) if A >> v & 1
        )
        pointwise.append(active - n)
    return i2, mean, residual, max(pointwise), max(individual_excess)


def random_weights(rng: np.random.Generator, n: int, log_scale: float) -> np.ndarray:
    weights = np.zeros((n, n))
    for i, j in combinations(range(n), 2):
        value = np.exp(np.clip(rng.normal(0.0, log_scale), -20.0, 20.0))
        weights[i, j] = weights[j, i] = value
    return weights


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--samples", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260802)
    parser.add_argument("--fitness", type=float, default=2.0)
    args = parser.parse_args()
    rng = np.random.default_rng(args.seed)
    best = (-np.inf, None)
    for sample in range(args.samples):
        scale = (0.05, 0.2, 0.8, 2.0, 5.0, 10.0)[sample % 6]
        weights = random_weights(rng, args.size, scale)
        try:
            value, mean, residual, pointwise, individual = stationary_i2(weights, args.fitness)
        except (np.linalg.LinAlgError, ValueError):
            continue
        if residual < 1e-8 and value - args.fitness > best[0]:
            best = (value - args.fitness, (value, mean, residual, pointwise, individual, weights.copy()))
        if residual < 1e-8 and value > args.fitness + 1e-7:
            print("CANDIDATE", sample, value, mean, residual, "pointwise", pointwise, "individual", individual)
            print(repr(weights))
            return
    print("NO CANDIDATE", args.size, args.samples)
    print("best excess", best[0])
    print("best data", best[1][:3] if best[1] else None)
    if best[1]:
        print("pointwise excess", best[1][3])
        print("individual excess", best[1][4])
        print(repr(best[1][5]))


if __name__ == "__main__":
    main()
