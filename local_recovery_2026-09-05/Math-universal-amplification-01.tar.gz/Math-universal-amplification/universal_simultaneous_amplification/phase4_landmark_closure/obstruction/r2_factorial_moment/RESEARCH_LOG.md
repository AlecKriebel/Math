# Fitness-two factorial-moment domination

Date: 2026-08-08 (America/Los_Angeles)

## Objective

Let `Pi_P` be the stationary law of the fair-geometric dual at fitness two
for a loopless irreducible reversible vertex kernel `P`.  The exact open
finite-baseline inequality is

\[
 E_{\Pi_P}|A|\le
 m_K=\frac{(n-1)2^{n-2}}{2^{n-1}-1}.
\]

This branch tests the stronger factorial-moment hierarchy

\[
 E_{\Pi_P}\binom{|A|}{j}
 \le
 \frac{\sum_{k=1}^{n-1}\binom{n-1}{k}\binom{k}{j}}
 {2^{n-1}-1},
 \qquad 1\le j\le n-1.                     \tag{FM_j}
\]

The right side is the corresponding moment of
`Binomial(n-1,1/2)` conditioned to be nonzero, which is exactly the complete
dual rank law.  Equivalently, all `(FM_j)` imply

\[
 E_{\Pi_P}t^{|A|}
 \le \frac{(1+t)^{n-1}-1}{2^{n-1}-1},
 \qquad t\ge1.                                    \tag{PGF}
\]

The hierarchy is not inferred from plots.  It will first be screened by
exact stationary solves on the frozen hostile corpus and exhaustive small
graphs.  Any failed member will be saved as an exact route counterexample;
only an all-order proof of `FM_1` would prove the universal `r=2` theorem.

## Initial observations

- On unweighted `P3`, the rank law is `(7/9,2/9)`, below the complete mean
  law `(2/3,1/3)` in every factorial moment.
- On the regular weighted `K4` witness, first-order stochastic domination
  already fails at the rank-one cut, but all factorial moments remain below
  complete.  Thus this route is a moment/PGF order, not a tail injection.
- If the hierarchy survives, the next task is to derive exact stationarity
  recurrences for falling factorials of the hole count and identify where
  reversibility enters their sign.

Status: **OPEN / EXACT SCREEN IN PROGRESS**.
