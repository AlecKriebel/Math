#!/usr/bin/env python3
"""Exact screen for factorial-moment domination of the r=2 dual rank law.

Finite checks are discovery/audit only.  They do not prove the universal
inequality.  Every comparison is made with Fraction arithmetic.
"""

from __future__ import annotations

import sys
from fractions import Fraction as F
from math import comb
from pathlib import Path


HERE = Path(__file__).resolve().parent
OBSTRUCTION = HERE.parent
CHI = OBSTRUCTION / "r2_entropy_certificate" / "chi_square_channel"
COLLISION = OBSTRUCTION / "r2_collision_closure"
sys.path.insert(0, str(CHI))
sys.path.insert(0, str(COLLISION))

from verify_resolvent_identities import solve  # noqa: E402
from verify_direct_flow_screen import (  # noqa: E402
    connected,
    deterministic_graphs,
    exhaustive_graphs,
    matrix_from_edges,
)


def complete_factorial_moment(n: int, order: int) -> F:
    numerator = sum(
        comb(n - 1, rank) * comb(rank, order)
        for rank in range(1, n)
    )
    return F(numerator, 2 ** (n - 1) - 1)


def exact_moments(weights):
    _, states, _, _, stationary = solve(weights)
    n = len(weights)
    moments = []
    for order in range(1, n):
        value = sum(
            (probability * comb(state.bit_count(), order)
             for state, probability in zip(states, stationary)),
            F(0),
        )
        moments.append(value)
    return moments


def audit_graph(weights, label):
    moments = exact_moments(weights)
    n = len(weights)
    slacks = [
        complete_factorial_moment(n, order) - moments[order - 1]
        for order in range(1, n)
    ]
    if not all(slack >= 0 for slack in slacks):
        failed = [i + 1 for i, slack in enumerate(slacks) if slack < 0]
        raise AssertionError((label, failed, slacks, weights))
    return slacks


def main():
    frozen = [
        ("P3", matrix_from_edges(3, (1, 1, 0))),
        ("P3-1-4", matrix_from_edges(3, (1, 4, 0))),
        ("triangle-1-1-5", matrix_from_edges(3, (1, 5, 1))),
        ("K4-cycle4-diagonal1", matrix_from_edges(4, (4, 1, 4, 4, 1, 4))),
        (
            "n6-split",
            matrix_from_edges(
                6,
                (3, 300, 2, 5, 1, 3, 3, 1, 300, 1, 1, 1, 20, 1, 1),
            ),
        ),
    ]
    for label, weights in frozen:
        slacks = audit_graph(weights, label)
        print(label, "PASS", [float(value) for value in slacks])

    counts = []
    for n, values in ((3, (0, 1, 2, 5)), (4, (0, 1, 2))):
        count = 0
        for weights in exhaustive_graphs(n, values):
            if not connected(weights):
                continue
            audit_graph(weights, f"exhaustive-n{n}-{count}")
            count += 1
        counts.append((n, count))
        print(f"exhaustive n={n}: {count} connected graphs PASS")

    count = 0
    for weights in deterministic_graphs(5, 48, 26080805):
        if not connected(weights):
            continue
        audit_graph(weights, f"deterministic-n5-{count}")
        count += 1
    counts.append((5, count))
    print(f"deterministic n=5: {count} connected graphs PASS")
    print("EXACT FINITE SCREEN PASS", counts)
    print("OPEN: universal factorial-moment hierarchy")


if __name__ == "__main__":
    main()
