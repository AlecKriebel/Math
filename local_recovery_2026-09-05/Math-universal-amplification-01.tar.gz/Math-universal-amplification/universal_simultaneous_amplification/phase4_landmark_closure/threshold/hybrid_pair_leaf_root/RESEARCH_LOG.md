# Research log: bounded-defect pair--leaf hybrid

Started: 2026-08-08 (America/Los_Angeles).

## Motivation

At `r=3/2`, the exact `K_2--K_20` endpoint witness supplies a dB gain
and a Bd loss whose tangent vector lies just beyond slope `1/2`.  A bounded
hub leaf supplies the opposite Bd-gain/dB-loss direction.  This folder tests
whether a continuously weighted leaf can combine the two mechanisms into an
actual simultaneous endpoint amplifier.

## Graph family under discovery

The graph has four equitable classes: a special pair `A`, a singleton hub
`H`, a bulk clique `C`, and a singleton leaf `L`.  The union `H+C` is a unit
clique of size `m`; the pair edge has weight `gamma*m`; every pair--clique
edge has weight `beta/m`; and the hub--leaf edge has weight `tau*m`.  All
parameters are independent of fitness.  Mutant configurations lump exactly
to `(i,h,j,l)` by the action `S_2 x S_(m-1)`.

Numerical solves in this folder are discovery only until a rational family,
exact finite verifier, and controlled asymptotic proof are supplied.

