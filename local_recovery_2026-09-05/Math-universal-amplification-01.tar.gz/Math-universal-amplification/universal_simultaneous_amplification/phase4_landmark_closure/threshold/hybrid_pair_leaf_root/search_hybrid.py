#!/usr/bin/env python3
"""Sparse exact-lumping search for the bounded pair--leaf endpoint hybrid."""

from __future__ import annotations

import argparse
from itertools import product

import numpy as np
from scipy.optimize import differential_evolution, minimize
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve


R = 1.5


def baseline(n: int, rule: str) -> float:
    if rule == "Bd":
        return (1 - 1 / R) / (1 - R ** (-n))
    return (n - 1) / n * (1 - 1 / R) / (1 - R ** (1 - n))


def classes(m: int, gamma: float, beta: float, tau: float):
    # A,H,C,L.  Diagonal entries are within-class pair weights.
    sizes = np.array([2, 1, m - 1, 1], dtype=int)
    w = np.zeros((4, 4), dtype=float)
    w[0, 0] = gamma * m
    w[1, 2] = w[2, 1] = 1.0
    w[2, 2] = 1.0
    cross = beta / m
    w[0, 1] = w[1, 0] = cross
    w[0, 2] = w[2, 0] = cross
    w[1, 3] = w[3, 1] = tau * m
    return sizes, w


def state_space(sizes: np.ndarray):
    full = tuple(int(x) for x in sizes)
    zero = tuple(0 for _ in sizes)
    return tuple(s for s in product(*(range(int(q) + 1) for q in sizes)) if s not in (zero, full))


def changing_rates(state, sizes, w, rule):
    state = np.asarray(state, dtype=int)
    degrees = (sizes - 1) * np.diag(w) + w @ sizes - np.diag(w) * sizes
    # Equivalent transparent form, guarded against diagonal double counting.
    degrees = np.array([
        (sizes[a] - 1) * w[a, a] + sum(sizes[b] * w[a, b] for b in range(4) if b != a)
        for a in range(4)
    ])
    moves = []
    for target_class in range(4):
        mutants = int(state[target_class])
        residents = int(sizes[target_class] - mutants)
        if residents:
            if rule == "Bd":
                parent_mass = 0.0
                for source in range(4):
                    count = state[source] - (1 if source == target_class else 0) * 0
                    parent_mass += count * w[source, target_class] / degrees[source]
                rate = R * residents * parent_mass
            else:
                mutant_weight = sum(state[source] * w[target_class, source] for source in range(4))
                resident_weight = degrees[target_class] - mutant_weight
                rate = residents * R * mutant_weight / (R * mutant_weight + resident_weight)
            if rate:
                target = list(state)
                target[target_class] += 1
                moves.append((tuple(target), rate))
        if mutants:
            if rule == "Bd":
                parent_mass = 0.0
                for source in range(4):
                    resident_count = sizes[source] - state[source]
                    parent_mass += resident_count * w[source, target_class] / degrees[source]
                rate = mutants * parent_mass
            else:
                # The dying mutant itself is excluded automatically because w_aa
                # has no loop contribution: subtract one mutant in its class.
                mutant_weight = sum(
                    (state[source] - (1 if source == target_class else 0)) * w[target_class, source]
                    for source in range(4)
                )
                resident_weight = degrees[target_class] - mutant_weight
                rate = mutants * resident_weight / (R * mutant_weight + resident_weight)
            if rate:
                target = list(state)
                target[target_class] -= 1
                moves.append((tuple(target), rate))
    return moves


def fixation(m: int, gamma: float, beta: float, tau: float, rule: str) -> float:
    sizes, w = classes(m, gamma, beta, tau)
    transient = state_space(sizes)
    index = {s: k for k, s in enumerate(transient)}
    full = tuple(int(x) for x in sizes)
    mat = lil_matrix((len(transient), len(transient)), dtype=float)
    rhs = np.zeros(len(transient))
    for state, row in index.items():
        moves = changing_rates(state, sizes, w, rule)
        mat[row, row] = sum(rate for _, rate in moves)
        for target, rate in moves:
            if target == full:
                rhs[row] += rate
            elif any(target):
                mat[row, index[target]] -= rate
    sol = spsolve(mat.tocsr(), rhs)
    n = int(sizes.sum())
    value = 0.0
    for a, count in enumerate(sizes):
        singleton = [0] * 4
        singleton[a] = 1
        value += count / n * sol[index[tuple(singleton)]]
    return float(value)


def score(m: int, log_parameters, verbose=False):
    gamma, beta, tau = np.exp(log_parameters)
    n = m + 3
    rb = fixation(m, gamma, beta, tau, "Bd") / baseline(n, "Bd")
    rd = fixation(m, gamma, beta, tau, "dB") / baseline(n, "dB")
    if verbose:
        print(f"m={m} gamma={gamma:.12g} beta={beta:.12g} tau={tau:.12g} x={rb:.12g} y={rd:.12g} M={min(rb,rd):.12g}")
    return min(rb, rd), rb, rd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--m", type=int, default=80)
    parser.add_argument("--maxiter", type=int, default=80)
    args = parser.parse_args()
    bounds = [(-4, 5), (-8, 2), (-8, 4)]
    objective = lambda z: -score(args.m, z)[0]
    result = differential_evolution(
        objective,
        bounds,
        seed=26080808,
        popsize=10,
        maxiter=args.maxiter,
        polish=False,
        workers=1,
        updating="immediate",
    )
    polished = minimize(objective, result.x, method="Nelder-Mead", options={"maxiter": 400})
    score(args.m, polished.x, verbose=True)


if __name__ == "__main__":
    main()
