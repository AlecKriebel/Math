#!/usr/bin/env python3
"""Independent exact algebra for the dilute pair--leaf leading interval.

This does not prove the stochastic dilute-additivity lemma.  It verifies the
finite algebraic component that will apply once that lemma is established.
"""

from __future__ import annotations

import sympy as sp


def main() -> None:
    r, sigma = sp.symbols("r sigma", positive=True)
    f_bd = 2 * (sigma - 1) / (1 + sigma * (r**2 - 1))
    f_db = 2 * (r * (2 - r) - sigma) / (sigma + 2 * r * (r - 1))
    lower = sp.factor(-(r - 1) * f_bd)
    upper = sp.factor(f_db)

    # Exact rational endpoint checkpoint used for finite discovery.
    r0 = sp.Rational(3, 2)
    sigma0 = sp.Rational(19, 137)
    lambda0 = sp.Rational(20, 27)
    bd_margin = sp.factor((f_bd + lambda0 / (r - 1)).subs({r: r0, sigma: sigma0}))
    db_margin = sp.factor((f_db - lambda0).subs({r: r0, sigma: sigma0}))
    assert bd_margin == sp.Rational(232, 17361)
    assert db_margin == sp.Rational(65, 12123)

    # The admissible leaf-per-pair interval is lower < lambda < upper.
    gap_num = sp.factor(sp.together(upper - lower).as_numer_denom()[0])
    discriminant = sp.factor(sp.discriminant(gap_num, sigma))
    polynomial = r**6 - 8 * r**5 + 22 * r**4 - 30 * r**3 + 21 * r**2 - 6 * r + 1
    assert discriminant == 4 * r**2 * polynomial

    # There is exactly one algebraic endpoint R in (3/2,151/100).
    assert polynomial.subs(r, sp.Rational(3, 2)) == sp.Rational(1, 64)
    assert polynomial.subs(r, sp.Rational(151, 100)) < 0
    assert sp.Poly(polynomial, r).count_roots(sp.Rational(3, 2), sp.Rational(151, 100)) == 1
    root = sp.RootOf(polynomial, 0)  # first (and smaller) real root.
    assert sp.Rational(3, 2) < root < sp.Rational(151, 100)

    sigma_star_expression = (-r**3 + 4 * r**2 - 3 * r - 1) / (2 * (r - 1))
    sigma_star = sigma_star_expression.subs(r, root)
    lambda_star = sp.factor(lower.subs({r: root, sigma: sigma_star}))
    assert 0 < sigma_star < 1
    assert 0 < lambda_star < 1
    endpoint_gap = sp.factor(sp.together((upper - lower).subs(sigma, sigma_star_expression)))
    assert endpoint_gap == -2 * r * polynomial / (
        (r - 1) * (r**3 - 2 * r**2 - 3 * r + 1) * (3 * r**3 - 4 * r**2 + r - 1)
    )
    # RootOf is defined by polynomial(root)=0, so endpoint_gap vanishes at R.

    # For fixed sigma_star, L increases and U decreases throughout (1,R).
    d_lower = sp.factor(sp.diff(lower, r))
    d_upper = sp.factor(sp.diff(upper, r))
    assert sp.cancel(
        d_lower
        - 2 * (sigma - 1) * (r**2 * sigma - 2 * r * sigma + sigma - 1) / (r**2 * sigma - sigma + 1) ** 2
    ) == 0
    assert sp.cancel(d_upper - 4 * r * (sigma - r) / (2 * r**2 - 2 * r + sigma) ** 2) == 0
    # Since 0<sigma_star<1 and 1<r<R<2, both factors give strict signs:
    # sigma_star*(r-1)^2<1 makes dL>0, and sigma_star-r<0 makes dU<0.

    print(f"endpoint rational margins: Bd={bd_margin}, dB={db_margin}")
    print(f"R={sp.N(root, 24)}")
    print(f"sigma*={sp.N(sigma_star, 24)}")
    print(f"lambda*={sp.N(lambda_star, 24)}")
    print("PASS exact leading pair--leaf interval algebra")
    print("OPEN stochastic dilute-additivity/post-establishment lemma")


if __name__ == "__main__":
    main()
