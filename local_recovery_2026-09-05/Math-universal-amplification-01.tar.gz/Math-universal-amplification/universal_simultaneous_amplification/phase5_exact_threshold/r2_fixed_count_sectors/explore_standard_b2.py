#!/usr/bin/env python3
"""Exact rank-block exploration for the standard fixed-count coefficient.

For a standard perturbation ``delta=E(s)``, write ``u=sum_(i in B)s_i``
and ``v=s_target``.  The first response and every subsequent complete-chain
iterate have the form ``a_k v+b_k u``.  The final averaged application of
``Delta`` depends only on ``b`` and has positive coefficients.

This is a discovery script.  The formulas have been checked against the
full active chain for orders three through seven, but the all-time sign of
the cumulative recurrence is not yet proved here.
"""

from __future__ import annotations

from fractions import Fraction as Q
from math import comb

from explore_symmetric_b2 import rank_step


def initial_features(h: list[Q], n: int) -> tuple[list[Q], list[Q]]:
    N = n - 1
    a = [Q(0)] * (N + 1)
    b = [Q(0)] * (N + 1)
    for k in range(1, N + 1):
        d = h[k] - h[k + 1] if k < N else Q(0)
        d_previous = h[k - 1] - h[k] if k > 1 else Q(0)
        a[k] = Q(k, 2 * n * (N - 1)) * d
        b[k] = (
            Q(N, 2 * n * (N - 1)) * d
            + Q(k - 1, 2 * k * (N - 1)) * d_previous
        )
    return a, b


def feature_step(a: list[Q], b: list[Q], n: int) -> tuple[list[Q], list[Q]]:
    N = n - 1
    ap = [Q(0)] * (N + 1)
    bp = [Q(0)] * (N + 1)
    for k in range(1, N + 1):
        q = N + 1 - k
        a_previous = a[k - 1] if k > 1 else Q(0)
        b_previous = b[k - 1] if k > 1 else Q(0)
        a_next = a[k + 1] if k < N else Q(0)
        b_next = b[k + 1] if k < N else Q(0)
        ap[k] = (k * a[k] + (N - k) * a_next - b_next) / (2 * N)
        bp[k] = (
            (k - 1) * a_previous
            + q * a[k]
            + (k - 1) ** 2 * b_previous
            + k * (N - k - 1) * b_next
            + (k * N - q) * b[k]
        ) / (2 * k * N)
    return ap, bp


def output_at_rank(b: list[Q], n: int, k: int) -> Q:
    """Return E_k Delta(a v+b u)/||s||^2; all a terms cancel."""

    N = n - 1
    q = N + 1 - k
    b_previous = b[k - 1] if k > 1 else Q(0)
    b_next = b[k + 1] if k < N else Q(0)
    return (
        Q(N - k, 2 * n * N * (N - 1))
        * (k * b[k] + (N - 1 - k) * b_next)
        + Q(q, 2 * n * N * (N - 1))
        * ((k - 1) * b_previous + (N - k) * b[k])
    )


def averaged_output(b: list[Q], n: int) -> Q:
    N = n - 1
    return sum(
        Q(comb(N - 1, k - 1), 2 ** (N - 1)) * output_at_rank(b, n, k)
        for k in range(1, N + 1)
    )


def cumulative_coefficient(n: int, time: int) -> tuple[Q, list[Q]]:
    """Return the unnormalised triangular b_(t,2) numerator and its b field."""

    N = n - 1
    radial = [Q(0)] + [Q(1, k) for k in range(1, N + 1)]
    source_a = [Q(0)] * (N + 1)
    source_b = [Q(0)] * (N + 1)
    total_a = [Q(0)] * (N + 1)
    total_b = [Q(0)] * (N + 1)
    for _ in range(time + 1):
        a, b = initial_features(radial, n)
        source_a = [left + right for left, right in zip(source_a, a)]
        source_b = [left + right for left, right in zip(source_b, b)]
        total_a, total_b = feature_step(total_a, total_b, n)
        total_a = [left + right for left, right in zip(total_a, source_a)]
        total_b = [left + right for left, right in zip(total_b, source_b)]
        radial = rank_step(radial, n)
    return averaged_output(total_b, n), total_b


def main() -> None:
    for n in range(3, 16):
        for time in (0, 1, 2, 4, 8, 16, 32, 64):
            value, b = cumulative_coefficient(n, time)
            assert value > 0
            assert min(b[1:]) >= 0
        print(f"n={n}: positive through cumulative time 64")


if __name__ == "__main__":
    main()
