#!/usr/bin/env python3
"""Exact rank-block exploration for the symmetric fixed-count coefficient.

This is a discovery script, not a verifier.  It implements the two-feature
complete-refresh block and the independently derived second-perturbation
output functional for a symmetric, row-zero perturbation.  Values are
normalized by ``sum_ij delta_ij**2``.
"""

from __future__ import annotations

from fractions import Fraction as Q
from math import comb


def rank_step(values: list[Q], n: int) -> list[Q]:
    """Complete active rank chain acting on a radial column function."""

    N = n - 1
    out = [Q(0)] * (N + 1)
    for k in range(1, N + 1):
        up = Q(N - k, 2 * N)
        down = Q(k - 1, 2 * N)
        out[k] = (1 - up - down) * values[k]
        if k < N:
            out[k] += up * values[k + 1]
        if k > 1:
            out[k] += down * values[k - 1]
    return out


def initial_features(h: list[Q], n: int) -> tuple[list[Q], list[Q]]:
    """Return f,g in Delta h = f_k x + g_k y."""

    N = n - 1
    f = [Q(0)] * (N + 1)
    g = [Q(0)] * (N + 1)
    for k in range(1, N):
        f[k] = (h[k] - h[k + 1]) / 2
    for k in range(2, N + 1):
        g[k] = (h[k - 1] - h[k]) / (2 * k)
    return f, g


def feature_step(f: list[Q], g: list[Q], n: int) -> tuple[list[Q], list[Q]]:
    """Apply K0 to f_k x+g_k y in the symmetric balanced sector."""

    N = n - 1
    fp = [Q(0)] * (N + 1)
    gp = [Q(0)] * (N + 1)
    for k in range(1, N + 1):
        fkp1 = f[k + 1] if k < N else Q(0)
        gkp1 = g[k + 1] if k < N else Q(0)
        fp[k] = (k * f[k] + (N - k - 1) * fkp1 - 2 * gkp1) / (2 * N)

        numerator = Q(0)
        if k > 1:
            numerator += (k - 1) * f[k - 1]
            numerator += (k - 1) * (k - 2) * g[k - 1]
        numerator += (N - k) * f[k]
        numerator += ((k - 2) * N + k) * g[k]
        gp[k] = numerator / (2 * k * N)
        if k < N:
            gp[k] += (N - k - 2) * gkp1 / (2 * N)
    return fp, gp


def output_at_rank(f: list[Q], g: list[Q], n: int, k: int) -> Q:
    """Conditional E_k[Delta(fx+gy)] / sum_ij delta_ij^2."""

    N = n - 1
    q = n - k
    fm = f[k - 1] if k > 1 else Q(0)
    fp = f[k + 1] if k < N else Q(0)
    gm = g[k - 1] if k > 1 else Q(0)
    gp = g[k + 1] if k < N else Q(0)

    ex2 = Q(k * (N - k), n * N * (N - 1)) if N > 1 else Q(0)
    exy = (
        Q(-2 * k * (k - 1) * (q - 1), n * N * (N - 1) * (N - 2))
        if N > 2
        else Q(0)
    )
    eu = Q(N - k, n * N)
    ev = Q(-k * (q - 1), n * N * (N - 1)) if N > 1 else Q(0)
    et2 = Q(k * (k - 1) * q, n * N * (N - 1)) if N > 1 else Q(0)
    ey2 = (
        Q(2 * k * (k - 1) * q * (q - 1), n * N * (N - 1) * (N - 2))
        if N > 2
        else Q(0)
    )
    eus = Q(k * q, n * N)
    evs = Q(-k * (k - 1) * q, n * N * (N - 1)) if N > 1 else Q(0)

    continuing = (
        (f[k] - fp) * ex2
        + (g[k] - gp) * exy
        + fp * eu
        + 2 * gp * ev
    ) / 2
    stopping = (
        (fm - 2 * gm - f[k] + 2 * g[k]) * et2
        + (gm - g[k]) * ey2
        + f[k] * eus
        + 2 * g[k] * evs
    ) / (2 * k)
    return continuing + stopping


def averaged_output(f: list[Q], g: list[Q], n: int) -> Q:
    N = n - 1
    return sum(
        Q(comb(N - 1, k - 1), 2 ** (N - 1)) * output_at_rank(f, g, n, k)
        for k in range(1, N + 1)
    )


def atoms(n: int, t: int) -> list[tuple[int, int, Q]]:
    N = n - 1
    radial = [Q(0)] + [Q(1, k) for k in range(1, N + 1)]
    total: list[tuple[int, int, Q]] = []
    for m in range(t - 1):
        f, g = initial_features(radial, n)
        for ell in range(t - 1 - m):
            total.append((ell, m, averaged_output(f, g, n)))
            f, g = feature_step(f, g, n)
        radial = rank_step(radial, n)
    return total


def main() -> None:
    for n in range(4, 13):
        for t in (2, 3, 4, 8, 16, 32):
            values = atoms(n, t)
            total = sum((value for _, _, value in values), Q(0))
            minimum = min(values, key=lambda item: item[2])
            print(
                f"n={n:2d} t={t:2d} total={float(total): .9e} "
                f"min_atom=({minimum[0]},{minimum[1]}) {float(minimum[2]): .9e}"
            )


if __name__ == "__main__":
    main()
