#!/usr/bin/env python3
"""Discovery-only hostile search for rank-H plus rank-K0 potentials."""

from __future__ import annotations

from itertools import product
import argparse

import numpy as np
from scipy.optimize import differential_evolution, linprog


class CombinedQuotient:
    def __init__(self, sizes: tuple[int, ...]):
        self.sizes = sizes
        self.q = len(sizes)
        self.n = sum(sizes)
        self.empty = (0,) * self.q
        self.full = sizes
        all_states = list(product(*(range(size + 1) for size in sizes)))
        self.nonempty = [state for state in all_states if state != self.empty]
        self.transient = [state for state in self.nonempty if state != self.full]
        self.index = {state: j for j, state in enumerate(self.nonempty)}
        self.baseline = (
            (self.n - 1) * 2 ** (self.n - 2)
            / (self.n * (2 ** (self.n - 1) - 1))
        )

    def solve(self, weights: np.ndarray, mode: str = "both"):
        degrees = np.array([
            (self.sizes[a] - 1) * weights[a, a]
            + sum(
                self.sizes[b] * weights[a, b]
                for b in range(self.q) if b != a
            )
            for a in range(self.q)
        ])
        total_degree = sum(
            self.sizes[a] * degrees[a] for a in range(self.q)
        )
        pi = degrees / total_degree
        pair_names = (
            ("internal", "collision")
            if mode == "both"
            else (mode,)
        )
        block = self.q + len(pair_names)
        evaluation = np.zeros((len(self.nonempty), (self.n + 1) * block))
        for state in self.nonempty:
            rank = sum(state)
            offset = rank * block
            row = evaluation[self.index[state]]
            row[offset] = 1
            for a in range(self.q - 1):
                row[offset + 1 + a] = state[a]
            internal = sum(
                weights[a, a] * state[a] * (state[a] - 1) / 2
                for a in range(self.q)
            ) + sum(
                weights[a, b] * state[a] * state[b]
                for a in range(self.q) for b in range(a + 1, self.q)
            )
            collision = 0.0
            for a, size in enumerate(self.sizes):
                weighted_mutants = sum(
                    weights[a, b] * state[b] for b in range(self.q)
                )
                if state[a]:
                    x = (weighted_mutants - weights[a, a]) / degrees[a]
                    collision += state[a] * pi[a] * x * (1 - x)
                if state[a] < size:
                    x = weighted_mutants / degrees[a]
                    collision += (size - state[a]) * pi[a] * x * (1 - x)
            for pair_index, pair_name in enumerate(pair_names):
                row[offset + self.q + pair_index] = (
                    internal / total_degree
                    if pair_name == "internal"
                    else collision
                )

        left, singular_values, _ = np.linalg.svd(evaluation, full_matrices=False)
        tolerance = max(evaluation.shape) * np.finfo(float).eps * singular_values[0]
        rank = int(np.count_nonzero(singular_values > tolerance))
        basis = left[:, :rank]
        objective_values = np.zeros(len(self.nonempty))
        for a, size in enumerate(self.sizes):
            singleton = tuple(int(b == a) for b in range(self.q))
            objective_values[self.index[singleton]] = size / self.n
        objective = objective_values @ basis

        inequalities = []
        for state in self.transient:
            row = np.zeros(len(self.nonempty))
            rates = []
            for a, size in enumerate(self.sizes):
                weighted_mutants = sum(
                    weights[a, b] * state[b] for b in range(self.q)
                )
                if state[a] < size:
                    x = weighted_mutants / degrees[a]
                    target = list(state)
                    target[a] += 1
                    rates.append((tuple(target), (size - state[a]) * 2 * x / (1 + x)))
                if state[a]:
                    x = (weighted_mutants - weights[a, a]) / degrees[a]
                    target = list(state)
                    target[a] -= 1
                    rates.append((tuple(target), state[a] * (1 - x) / (1 + x)))
            total = sum(rate for _, rate in rates)
            for target, rate in rates:
                if target != self.empty:
                    row[self.index[target]] += rate
                row[self.index[state]] -= rate
            inequalities.append((row / total) @ basis)
        return linprog(
            objective,
            A_ub=np.asarray(inequalities),
            b_ub=np.zeros(len(inequalities)),
            A_eq=basis[self.index[self.full]].reshape(1, -1),
            b_eq=np.ones(1),
            bounds=[(None, None)] * rank,
            method="highs",
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", default="1,2,4,8")
    parser.add_argument("--bound", type=float, default=10)
    parser.add_argument("--iterations", type=int, default=15)
    parser.add_argument("--popsize", type=int, default=5)
    parser.add_argument("--seed", type=int, default=26080821)
    parser.add_argument(
        "--mode", choices=("internal", "collision", "both"), default="both"
    )
    args = parser.parse_args()
    sizes = tuple(int(value) for value in args.sizes.split(","))
    quotient = CombinedQuotient(sizes)
    entries = [(a, b) for a in range(len(sizes)) for b in range(a, len(sizes))]
    best = [-float("inf"), None]
    count = 0

    def objective(logs_tail):
        nonlocal count
        logs = np.concatenate(([0.0], logs_tail))
        weights = np.zeros((len(sizes), len(sizes)))
        for (a, b), value in zip(entries, np.exp(logs)):
            weights[a, b] = weights[b, a] = value
        result = quotient.solve(weights, mode=args.mode)
        count += 1
        if not result.success:
            return 10.0
        gap = result.fun - quotient.baseline
        if gap > best[0]:
            best[:] = [gap, logs.copy()]
            print("best", count, gap, logs.tolist(), flush=True)
        return -gap

    differential_evolution(
        objective,
        [(-args.bound, args.bound)] * (len(entries) - 1),
        seed=args.seed,
        popsize=args.popsize,
        maxiter=args.iterations,
        polish=True,
        updating="immediate",
    )
    print("evaluations", count)
    print("best gap", best[0])
    print("best logs", best[1].tolist())


if __name__ == "__main__":
    main()
