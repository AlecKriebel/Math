#!/usr/bin/env python3
"""Outer hostile optimization of the equitable rank-quadratic LP.

The slice feature space is precomputed once for fixed class sizes.  Edge
weights are then optimized in logarithmic coordinates.  Floating output is
discovery evidence only.
"""

from __future__ import annotations

from itertools import combinations
import argparse

import numpy as np
from scipy.optimize import differential_evolution, linprog

from search_equitable_rank_quadratic import feature_vector, states, transitions


class PreparedLP:
    def __init__(self, sizes):
        self.sizes = tuple(sizes)
        self.q = len(sizes)
        self.n = sum(sizes)
        self.empty = (0,) * self.q
        self.full = self.sizes
        self.nonempty = [s for s in states(self.sizes) if s != self.empty]
        self.transient = [s for s in self.nonempty if s != self.full]
        self.index = {s: i for i, s in enumerate(self.nonempty)}
        evaluation = np.vstack([feature_vector(s, self.n) for s in self.nonempty])
        left, singular_values, _ = np.linalg.svd(evaluation, full_matrices=False)
        tolerance = max(evaluation.shape) * np.finfo(float).eps * singular_values[0]
        rank = int(np.count_nonzero(singular_values > tolerance))
        self.basis = left[:, :rank]
        objective_values = np.zeros(len(self.nonempty))
        for a, size in enumerate(self.sizes):
            singleton = tuple(1 if b == a else 0 for b in range(self.q))
            objective_values[self.index[singleton]] = size / self.n
        self.objective = objective_values @ self.basis
        self.full_row = self.basis[self.index[self.full]].reshape(1, -1)
        self.baseline = (
            (self.n - 1)
            * 2 ** (self.n - 2)
            / (self.n * (2 ** (self.n - 1) - 1))
        )

    def solve(self, weights):
        inequalities = []
        for state in self.transient:
            row = np.zeros(len(self.nonempty))
            rates = transitions(state, self.sizes, weights)
            total = sum(rate for _, rate in rates)
            for target, rate in rates:
                if target != self.empty:
                    row[self.index[target]] += rate
                row[self.index[state]] -= rate
            inequalities.append((row / total) @ self.basis)
        inequalities.extend(-self.basis[self.index[s]] for s in self.transient)
        return linprog(
            self.objective,
            A_ub=np.asarray(inequalities),
            b_ub=np.zeros(len(inequalities)),
            A_eq=self.full_row,
            b_eq=np.ones(1),
            bounds=[(None, None)] * self.basis.shape[1],
            method="highs",
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", default="4,4,4")
    parser.add_argument("--bound", type=float, default=8)
    parser.add_argument("--iterations", type=int, default=60)
    parser.add_argument("--popsize", type=int, default=8)
    parser.add_argument("--seed", type=int, default=26082601)
    args = parser.parse_args()
    sizes = tuple(int(x) for x in args.sizes.split(","))
    prepared = PreparedLP(sizes)
    class_edges = list(combinations(range(len(sizes) + 1), 2))
    # The combinations trick above gives q(q+1)/2 labels after identifying
    # edge (a,b+1) with matrix position (a,b); spell them out explicitly.
    entries = [(a, b) for a in range(len(sizes)) for b in range(a, len(sizes))]
    best = [-float("inf"), None]
    evaluations = 0

    def objective(z):
        nonlocal evaluations
        logs = np.concatenate(([0.0], z))
        weights = [[0.0] * len(sizes) for _ in sizes]
        for (a, b), value in zip(entries, np.exp(logs)):
            weights[a][b] = weights[b][a] = float(value)
        result = prepared.solve(weights)
        evaluations += 1
        if not result.success:
            return 10.0
        gap = result.fun - prepared.baseline
        if gap > best[0]:
            best[:] = [gap, z.copy()]
            print("best", evaluations, gap, flush=True)
        return -gap

    result = differential_evolution(
        objective,
        [(-args.bound, args.bound)] * (len(entries) - 1),
        seed=args.seed,
        popsize=args.popsize,
        maxiter=args.iterations,
        polish=True,
        updating="immediate",
    )
    print("evaluations", evaluations)
    print("best gap", best[0])
    print("best logarithms", best[1])
    print(result.message)


if __name__ == "__main__":
    main()
