#!/usr/bin/env python3
"""Discovery LP for the two-statistic r=2 potential.

At each rank the potential is a linear combination of 1, the total column
temperature of the mutant set, and its internal replacement flow.  These
statistics vanish after centering at the complete graph and have exact
complete-baseline singleton/boundary averages.  Floating output is discovery
evidence only.
"""

from __future__ import annotations

from random import Random
import argparse

import numpy as np
from scipy.optimize import linprog

from search_rank_quadratic_potential import dB_rates, random_graph, complete_baseline


def solve(weights, vertex_mode="temperature"):
    n = len(weights)
    full = (1 << n) - 1
    degree = np.asarray([sum(row) for row in weights], dtype=float)
    p = np.asarray(weights, dtype=float) / degree[:, None]
    temperature = p.sum(axis=0)
    if vertex_mode == "temperature":
        vertex_field = temperature
    elif vertex_mode == "poisson":
        matrix = np.eye(n) - p.T + np.ones((n, n)) / n
        vertex_field = np.linalg.solve(matrix, temperature - 1.0)
    elif vertex_mode == "logdegree":
        vertex_field = np.log(degree)
    else:
        raise ValueError(vertex_mode)
    evaluation = np.zeros((full, 3 * (n + 1)))
    for state in range(1, full + 1):
        k = state.bit_count()
        occupied = [i for i in range(n) if state >> i & 1]
        evaluation[state - 1, 3 * k] = 1.0
        evaluation[state - 1, 3 * k + 1] = vertex_field[occupied].sum()
        evaluation[state - 1, 3 * k + 2] = p[np.ix_(occupied, occupied)].sum()

    left, singular_values, _ = np.linalg.svd(evaluation, full_matrices=False)
    tolerance = max(evaluation.shape) * np.finfo(float).eps * singular_values[0]
    rank = int(np.count_nonzero(singular_values > tolerance))
    basis = left[:, :rank]
    objective_values = np.zeros(full)
    for i in range(n):
        objective_values[(1 << i) - 1] = 1 / n
    inequalities = []
    for state in range(1, full):
        rates = dB_rates(weights, state)
        total = sum(rate for _, rate in rates)
        row = np.zeros(full)
        for target, rate in rates:
            if target:
                row[target - 1] += rate
            row[state - 1] -= rate
        inequalities.append((row / total) @ basis)
    inequalities.extend(-basis[state - 1] for state in range(1, full))
    return linprog(
        objective_values @ basis,
        A_ub=np.asarray(inequalities),
        b_ub=np.zeros(len(inequalities)),
        A_eq=basis[full - 1].reshape(1, -1),
        b_eq=np.ones(1),
        bounds=[(None, None)] * rank,
        method="highs",
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=6)
    parser.add_argument("--trials", type=int, default=100)
    parser.add_argument("--scale", type=float, default=5)
    parser.add_argument("--density", type=float, default=1)
    parser.add_argument("--seed", type=int, default=26082001)
    parser.add_argument("--vertex", choices=["temperature", "poisson", "logdegree"], default="temperature")
    args = parser.parse_args()
    rng = Random(args.seed)
    baseline = complete_baseline(args.n)
    worst = None
    for trial in range(args.trials):
        weights = random_graph(args.n, rng, args.scale, args.density)
        result = solve(weights, vertex_mode=args.vertex)
        if not result.success:
            print("failure", trial, result.message)
            return
        gap = result.fun - baseline
        if worst is None or gap > worst[0]:
            worst = (gap, weights)
    print("largest optimum minus baseline", worst[0])
    for row in worst[1]:
        print(" ".join(f"{value:.17g}" for value in row))


if __name__ == "__main__":
    main()
