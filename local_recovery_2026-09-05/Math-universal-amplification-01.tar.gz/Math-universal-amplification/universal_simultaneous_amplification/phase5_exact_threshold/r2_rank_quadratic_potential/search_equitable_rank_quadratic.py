#!/usr/bin/env python3
"""Discovery LP for class-symmetric rank-quadratic r=2 potentials.

The graph has equitable vertex classes.  Averaging any labelled feasible
potential over within-class permutations shows that this quotient LP is an
exact test of the rank-dependent pair-labelled ansatz on such graphs.
Floating output is discovery evidence only.
"""

from __future__ import annotations

from itertools import product
import argparse

import numpy as np
from scipy.optimize import linprog


def parse_matrix(raw: str) -> list[list[float]]:
    return [[float(x) for x in row.split(",")] for row in raw.split(";")]


def states(sizes: tuple[int, ...]) -> list[tuple[int, ...]]:
    return list(product(*(range(size + 1) for size in sizes)))


def feature_vector(state: tuple[int, ...], n: int) -> np.ndarray:
    q = len(state)
    out = np.zeros((n + 1) * (1 + q + q * (q + 1) // 2))
    k = sum(state)
    if k == 0:
        return out
    block = 1 + q + q * (q + 1) // 2
    offset = k * block
    out[offset] = 1.0
    for a, value in enumerate(state):
        out[offset + 1 + a] = value
    cursor = offset + 1 + q
    for a in range(q):
        for b in range(a, q):
            out[cursor] = state[a] * state[b]
            cursor += 1
    return out


def natural_class_kernels(sizes: tuple[int, ...], weights: list[list[float]]):
    """Return the five graph-natural pair kernels aggregated by classes."""
    labels = []
    for a, size in enumerate(sizes):
        labels.extend([a] * size)
    n = len(labels)
    vertex_weights = np.zeros((n, n))
    for i, a in enumerate(labels):
        for j, b in enumerate(labels):
            if i != j:
                vertex_weights[i, j] = weights[a][b]
    degree = vertex_weights.sum(axis=1)
    p = vertex_weights / degree[:, None]
    stationary = degree / degree.sum()
    matrices = [
        p + p.T,
        p.T @ p,
        p @ p.T,
        stationary[:, None] * p,
        np.outer(p.sum(axis=0) - 1.0, p.sum(axis=0) - 1.0),
    ]
    for matrix in matrices:
        np.fill_diagonal(matrix, 0.0)
    representatives = [sum(sizes[:a]) for a in range(len(sizes))]
    class_kernels = []
    for matrix in matrices:
        kernel = np.zeros((len(sizes), len(sizes)))
        for a, i in enumerate(representatives):
            for b, j0 in enumerate(representatives):
                j = j0 + 1 if a == b else j0
                if a == b and sizes[a] < 2:
                    kernel[a, b] = 0.0
                else:
                    kernel[a, b] = matrix[i, j]
        class_kernels.append(kernel)
    return class_kernels


def natural_feature_vector(
    state: tuple[int, ...], n: int, kernels: list[np.ndarray]
) -> np.ndarray:
    q = len(state)
    block = 1 + q + len(kernels)
    out = np.zeros((n + 1) * block)
    k = sum(state)
    if k == 0:
        return out
    offset = k * block
    out[offset] = 1.0
    for a, value in enumerate(state):
        out[offset + 1 + a] = value
    for j, kernel in enumerate(kernels):
        value = 0.0
        for a in range(q):
            value += state[a] * (state[a] - 1) * kernel[a, a] / 2
            for b in range(a + 1, q):
                value += state[a] * state[b] * kernel[a, b]
        out[offset + 1 + q + j] = value
    return out


def transitions(
    state: tuple[int, ...], sizes: tuple[int, ...], weights: list[list[float]]
) -> list[tuple[tuple[int, ...], float]]:
    q = len(sizes)
    degree = [
        weights[a][a] * (sizes[a] - 1)
        + sum(weights[a][b] * sizes[b] for b in range(q) if b != a)
        for a in range(q)
    ]
    out = []
    for a in range(q):
        if state[a] < sizes[a]:
            mutant_mass = weights[a][a] * state[a] + sum(
                weights[a][b] * state[b] for b in range(q) if b != a
            )
            rate = (sizes[a] - state[a]) * 2 * mutant_mass / (degree[a] + mutant_mass)
            if rate:
                target = list(state)
                target[a] += 1
                out.append((tuple(target), rate))
        if state[a] > 0:
            mutant_mass = weights[a][a] * (state[a] - 1) + sum(
                weights[a][b] * state[b] for b in range(q) if b != a
            )
            resident_mass = degree[a] - mutant_mass
            rate = state[a] * resident_mass / (degree[a] + mutant_mass)
            if rate:
                target = list(state)
                target[a] -= 1
                out.append((tuple(target), rate))
    return out


def solve(sizes: tuple[int, ...], weights: list[list[float]], natural=False, kernel_count=5):
    q = len(sizes)
    assert len(weights) == q and all(len(row) == q for row in weights)
    assert all(abs(weights[a][b] - weights[b][a]) < 1e-12 for a in range(q) for b in range(q))
    n = sum(sizes)
    all_states = states(sizes)
    index = {state: i for i, state in enumerate(all_states)}
    empty = (0,) * q
    full = sizes
    nonempty = [state for state in all_states if state != empty]
    transient = [state for state in nonempty if state != full]

    kernels = natural_class_kernels(sizes, weights)[:kernel_count] if natural else None
    evaluation = np.vstack(
        [
            natural_feature_vector(state, n, kernels)
            if natural
            else feature_vector(state, n)
            for state in nonempty
        ]
    )
    left, singular_values, _ = np.linalg.svd(evaluation, full_matrices=False)
    tolerance = max(evaluation.shape) * np.finfo(float).eps * singular_values[0]
    rank = int(np.count_nonzero(singular_values > tolerance))
    basis = left[:, :rank]
    nonempty_index = {state: i for i, state in enumerate(nonempty)}

    objective_values = np.zeros(len(nonempty))
    for a, size in enumerate(sizes):
        singleton = tuple(1 if b == a else 0 for b in range(q))
        objective_values[nonempty_index[singleton]] = size / n
    objective = objective_values @ basis

    inequalities = []
    for state in transient:
        row = np.zeros(len(nonempty))
        rates = transitions(state, sizes, weights)
        total = sum(rate for _, rate in rates)
        for target, rate in rates:
            if target != empty:
                row[nonempty_index[target]] += rate
            row[nonempty_index[state]] -= rate
        inequalities.append((row / total) @ basis)
    inequalities.extend(-basis[nonempty_index[state]] for state in transient)

    result = linprog(
        objective,
        A_ub=np.asarray(inequalities),
        b_ub=np.zeros(len(inequalities)),
        A_eq=basis[nonempty_index[full]].reshape(1, -1),
        b_eq=np.ones(1),
        bounds=[(None, None)] * rank,
        method="highs",
    )
    baseline = (n - 1) * 2 ** (n - 2) / (n * (2 ** (n - 1) - 1))
    return result, baseline, len(transient), rank


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", default="2,5,10")
    parser.add_argument(
        "--weights",
        default="20000000,15,5;15,9,4500;5,4500,150",
    )
    parser.add_argument("--natural", action="store_true")
    parser.add_argument("--kernels", type=int, default=5)
    args = parser.parse_args()
    sizes = tuple(int(x) for x in args.sizes.split(","))
    weights = parse_matrix(args.weights)
    result, baseline, transient_count, rank = solve(
        sizes, weights, natural=args.natural, kernel_count=args.kernels
    )
    print("states", transient_count, "function-space rank", rank)
    print("status", result.status, result.message)
    if result.success:
        print("optimum", result.fun)
        print("baseline", baseline)
        print("optimum minus baseline", result.fun - baseline)


if __name__ == "__main__":
    main()
