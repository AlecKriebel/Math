#!/usr/bin/env python3
"""Discovery LP for rank-dependent two-marked dB potentials at r=2.

For each rank k the potential has an arbitrary constant, singleton-labelled
terms, and pair-labelled terms.  We minimize its uniform-singleton boundary
value subject to superharmonicity and F(V)=1.  Floating LP output is only
discovery evidence.
"""

from __future__ import annotations

from itertools import combinations
from random import Random
import argparse
import math

import numpy as np
from scipy.optimize import linprog


def feature_keys(n):
    keys = []
    for k in range(1, n + 1):
        keys.append((k, ()))
        keys.extend((k, (i,)) for i in range(n))
        keys.extend((k, pair) for pair in combinations(range(n), 2))
    return keys


def features(state, n, keys, index):
    if state == 0:
        return {}
    k = state.bit_count()
    row = {index[(k, ())]: 1.0}
    occupied = [i for i in range(n) if state >> i & 1]
    for i in occupied:
        row[index[(k, (i,))]] = 1.0
    for pair in combinations(occupied, 2):
        row[index[(k, pair)]] = 1.0
    return row


def dB_rates(weights, state):
    n = len(weights)
    degrees = [sum(row) for row in weights]
    rates = []
    for target in range(n):
        mutant_mass = sum(weights[source][target] for source in range(n) if state >> source & 1)
        resident_mass = degrees[target] - mutant_mass
        denominator = 2.0 * mutant_mass + resident_mass
        if state >> target & 1:
            rate = resident_mass / denominator
        else:
            rate = 2.0 * mutant_mass / denominator
        if rate:
            rates.append((state ^ (1 << target), rate))
    return rates


def solve(weights):
    n = len(weights)
    full = (1 << n) - 1
    keys = feature_keys(n)
    index = {key: j for j, key in enumerate(keys)}
    cache = [features(state, n, keys, index) for state in range(full + 1)]
    variables = len(keys)

    # The labelled monomials have exact linear dependencies at the extreme
    # ranks (for example, at rank one the rank constant is the sum of the
    # singleton indicators).  Work in an orthonormal basis of the actual
    # function space on nonempty states.  This avoids both redundant LP
    # directions and the poor conditioning of an arbitrary pivot-column basis.
    evaluation = np.zeros((full, variables))
    for state in range(1, full + 1):
        for j, value in cache[state].items():
            evaluation[state - 1, j] = value
    left, singular_values, _ = np.linalg.svd(evaluation, full_matrices=False)
    tolerance = max(evaluation.shape) * np.finfo(float).eps * singular_values[0]
    rank = int(np.count_nonzero(singular_values > tolerance))
    value_basis = left[:, :rank]

    objective_values = np.zeros(full)
    for v in range(n):
        objective_values[(1 << v) - 1] += 1.0 / n
    objective = objective_values @ value_basis

    inequalities = []
    for state in range(1, full):
        drift_values = np.zeros(full)
        state_rates = dB_rates(weights, state)
        total_rate = sum(rate for _, rate in state_rates)
        for target, rate in state_rates:
            if target:
                drift_values[target - 1] += rate
            drift_values[state - 1] -= rate
        # Row time changes preserve superharmonicity.  Normalizing the jump
        # rate prevents a nearly disconnected cut from being mistaken for a
        # missing constraint by the floating LP solver.
        inequalities.append((drift_values / total_rate) @ value_basis)

    # Exact maximum-principle redundancy: a superharmonic function with
    # boundary values zero and one is nonnegative on every transient state.
    # Adding this consequence explicitly keeps sparse, multiscale instances
    # away from HiGHS' false unbounded diagnoses.
    inequalities.extend(-value_basis[state - 1] for state in range(1, full))

    full_row = value_basis[full - 1]
    result = linprog(
        objective,
        A_ub=np.asarray(inequalities),
        b_ub=np.zeros(len(inequalities)),
        A_eq=full_row.reshape(1, -1),
        b_eq=np.ones(1),
        bounds=[(None, None)] * rank,
        method="highs",
        options={"dual_feasibility_tolerance": 1e-9, "primal_feasibility_tolerance": 1e-9},
    )
    return result


def complete_baseline(n):
    return (n - 1) * 2 ** (n - 2) / (n * (2 ** (n - 1) - 1))


def random_graph(n, rng, scale, density):
    while True:
        weights = [[0.0] * n for _ in range(n)]
        for u, v in combinations(range(n), 2):
            if rng.random() <= density:
                value = math.exp(rng.uniform(-scale, scale))
                weights[u][v] = weights[v][u] = value
        seen = {0}
        stack = [0]
        while stack:
            u = stack.pop()
            for v, value in enumerate(weights[u]):
                if value and v not in seen:
                    seen.add(v)
                    stack.append(v)
        if len(seen) == n:
            return weights


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=6)
    parser.add_argument("--trials", type=int, default=100)
    parser.add_argument("--scale", type=float, default=8.0)
    parser.add_argument("--density", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=26080871)
    args = parser.parse_args()
    rng = Random(args.seed)
    baseline = complete_baseline(args.n)
    worst = None
    for trial in range(args.trials):
        weights = random_graph(args.n, rng, args.scale, args.density)
        result = solve(weights)
        if not result.success:
            print("LP failure", trial, result.message)
            return
        excess = result.fun - baseline
        if worst is None or excess > worst[0]:
            worst = (excess, result.fun, weights)
    print("largest optimum minus baseline", worst[0])
    print("optimum", worst[1], "baseline", baseline)
    print("weights")
    for row in worst[2]:
        print(" ".join(f"{value:.17g}" for value in row))


if __name__ == "__main__":
    main()
