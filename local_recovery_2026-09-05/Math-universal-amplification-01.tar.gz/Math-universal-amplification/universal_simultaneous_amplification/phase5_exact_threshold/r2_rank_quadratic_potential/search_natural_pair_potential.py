#!/usr/bin/env python3
"""Discovery test for a compressed graph-natural rank/pair potential.

This is deliberately narrower than the full pair-labelled LP.  It retains
arbitrary vertex coefficients at every rank and adds scalar coefficients of
five canonical symmetric pair kernels built from the replacement kernel.
Floating output is discovery evidence only.
"""

from __future__ import annotations

from itertools import combinations
from random import Random
import argparse
import math

import numpy as np
from scipy.optimize import linprog

from search_rank_quadratic_potential import dB_rates, random_graph, complete_baseline


def natural_pair_matrices(weights):
    n = len(weights)
    degree = np.asarray([sum(row) for row in weights], dtype=float)
    p = np.asarray(weights, dtype=float) / degree[:, None]
    stationary = degree / degree.sum()
    conductance = stationary[:, None] * p
    matrices = [
        p + p.T,
        p.T @ p,
        p @ p.T,
        conductance,
        np.outer(p.sum(axis=0) - 1.0, p.sum(axis=0) - 1.0),
    ]
    for matrix in matrices:
        np.fill_diagonal(matrix, 0.0)
    return matrices


def solve(weights, kernel_count=5, kernel_index=None):
    n = len(weights)
    full = (1 << n) - 1
    pairs = list(combinations(range(n), 2))
    all_kernels = natural_pair_matrices(weights)
    kernels = (
        [all_kernels[kernel_index]]
        if kernel_index is not None
        else all_kernels[:kernel_count]
    )
    block = 1 + n + len(kernels)
    columns = (n + 1) * block
    evaluation = np.zeros((full, columns))
    for state in range(1, full + 1):
        k = bin(state).count("1")
        offset = k * block
        evaluation[state - 1, offset] = 1.0
        occupied = [i for i in range(n) if state >> i & 1]
        for i in occupied:
            evaluation[state - 1, offset + 1 + i] = 1.0
        for q, matrix in enumerate(kernels):
            evaluation[state - 1, offset + 1 + n + q] = sum(
                matrix[i, j] for i, j in combinations(occupied, 2)
            )

    left, singular_values, _ = np.linalg.svd(evaluation, full_matrices=False)
    tolerance = max(evaluation.shape) * np.finfo(float).eps * singular_values[0]
    rank = int(np.count_nonzero(singular_values > tolerance))
    basis = left[:, :rank]

    objective_values = np.zeros(full)
    for i in range(n):
        objective_values[(1 << i) - 1] = 1 / n
    objective = objective_values @ basis
    inequalities = []
    for state in range(1, full):
        rates = dB_rates(weights, state)
        total = sum(rate for _, rate in rates)
        row = np.zeros(full)
        for target, rate in rates:
            if target:
                row[target - 1] += rate
            row[state - 1] -= rate
        inequalities.append((row / total) @ basis)
    inequalities.extend(-basis[state - 1] for state in range(1, full))
    return linprog(
        objective,
        A_ub=np.asarray(inequalities),
        b_ub=np.zeros(len(inequalities)),
        A_eq=basis[full - 1].reshape(1, -1),
        b_eq=np.ones(1),
        bounds=[(None, None)] * rank,
        method="highs",
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=6)
    parser.add_argument("--trials", type=int, default=100)
    parser.add_argument("--scale", type=float, default=4)
    parser.add_argument("--density", type=float, default=1)
    parser.add_argument("--seed", type=int, default=26081801)
    parser.add_argument("--kernels", type=int, default=5)
    parser.add_argument("--kernel-index", type=int)
    args = parser.parse_args()
    rng = Random(args.seed)
    baseline = complete_baseline(args.n)
    worst = None
    for trial in range(args.trials):
        weights = random_graph(args.n, rng, args.scale, args.density)
        result = solve(
            weights,
            kernel_count=args.kernels,
            kernel_index=args.kernel_index,
        )
        if not result.success:
            print("failure", trial, result.message)
            return
        gap = result.fun - baseline
        if worst is None or gap > worst[0]:
            worst = (gap, weights)
    print("largest optimum minus baseline", worst[0])
    for row in worst[1]:
        print(" ".join(f"{value:.17g}" for value in row))


if __name__ == "__main__":
    main()
