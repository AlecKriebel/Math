#!/usr/bin/env python3
"""General correlated-cell branching normal form at fitness two.

There are M copies of a labelled cell.  ``A`` is the symmetric order-one
internal matrix and ``W/M`` is the symmetric weight between positions in
distinct cells.  Sending M to infinity yields a genuine branching process
of internally correlated mutant colonies.  This script solves its nonlinear
singleton consistency equations exactly up to floating linear algebra and
searches for a Bd gain with anomalously small dB loss.

This is a discovery implementation, not a proof certificate.
"""

from __future__ import annotations

import argparse
from itertools import combinations
import math

import numpy as np
from scipy.optimize import differential_evolution, root


def colony_survival(A: np.ndarray, W: np.ndarray, rule: str) -> np.ndarray:
    order = len(A)
    degree = A.sum(axis=1) + W.sum(axis=1)
    states = list(range(1, 1 << order))
    index = {mask: row for row, mask in enumerate(states)}

    def linear(singletons: np.ndarray) -> np.ndarray:
        matrix = np.zeros((len(states), len(states)))
        rhs = np.zeros(len(states))
        for mask, row in index.items():
            mutant = np.array([(mask >> i) & 1 for i in range(order)], dtype=float)
            moves: dict[int, float] = {}

            def add(target: int, rate: float) -> None:
                if rate > 0:
                    moves[target] = moves.get(target, 0.0) + rate

            if rule == "Bd":
                for source in range(order):
                    for target in range(order):
                        if source == target or mutant[source] == mutant[target]:
                            continue
                        fitness = 2.0 if mutant[source] else 1.0
                        add(mask ^ (1 << target), fitness * A[source, target] / degree[source])
                incoming = W.T @ (1.0 / degree)
                for target in range(order):
                    if mutant[target]:
                        add(mask ^ (1 << target), incoming[target])
                mark = sum(
                    2.0 * W[source, target] * singletons[target] / degree[source]
                    for source in range(order)
                    if mutant[source]
                    for target in range(order)
                )
            elif rule == "dB":
                external = W.sum(axis=1)
                for target in range(order):
                    mutant_mass = 2.0 * sum(
                        A[source, target]
                        for source in range(order)
                        if mutant[source] and source != target
                    )
                    resident_mass = external[target] + sum(
                        A[source, target]
                        for source in range(order)
                        if not mutant[source] and source != target
                    )
                    denominator = mutant_mass + resident_mass
                    if mutant[target] and resident_mass:
                        add(mask ^ (1 << target), resident_mass / denominator)
                    if not mutant[target] and mutant_mass:
                        add(mask ^ (1 << target), mutant_mass / denominator)
                mark = sum(
                    2.0 * W[source, target] * singletons[target] / degree[target]
                    for source in range(order)
                    if mutant[source]
                    for target in range(order)
                )
            else:
                raise ValueError(rule)
            total = mark + sum(moves.values())
            matrix[row, row] = total
            rhs[row] = mark
            for target, rate in moves.items():
                if target:
                    matrix[row, index[target]] -= rate
        return np.linalg.solve(matrix, rhs)

    def residual(y: np.ndarray) -> np.ndarray:
        # Logistic coordinates keep the solver in (0,1).
        singletons = 1.0 / (1.0 + np.exp(-y))
        values = linear(singletons)
        updated = np.array([values[index[1 << i]] for i in range(order)])
        return updated - singletons

    solution = root(residual, np.zeros(order), method="lm")
    singletons = 1.0 / (1.0 + np.exp(-solution.x))
    error = np.max(np.abs(residual(solution.x)))
    if not solution.success or error > 2e-8 or np.min(singletons) < 1e-8:
        raise FloatingPointError((solution.message, error, singletons))
    return singletons


def decode(order: int, parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    edge_count = order * (order - 1) // 2
    A = np.zeros((order, order))
    cursor = 0
    for i, j in combinations(range(order), 2):
        A[i, j] = A[j, i] = math.exp(float(parameters[cursor]))
        cursor += 1
    W = np.zeros((order, order))
    for i in range(order):
        for j in range(i, order):
            value = math.exp(float(parameters[cursor]))
            cursor += 1
            W[i, j] = W[j, i] = value
    assert cursor == edge_count + order * (order + 1) // 2
    return A, W


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--order", type=int, default=3)
    parser.add_argument("--maxiter", type=int, default=80)
    parser.add_argument("--span", type=float, default=7.0)
    args = parser.parse_args()
    count = args.order * args.order

    def value(parameters: np.ndarray) -> tuple[float, float, float, np.ndarray, np.ndarray]:
        A, W = decode(args.order, parameters)
        b = colony_survival(A, W, "Bd")
        s = colony_survival(A, W, "dB")
        gain = float(np.mean(b) - 0.5)
        loss = float(0.5 - np.mean(s))
        ratio = loss / gain if gain > 1e-8 else 1e4 + abs(gain) * 1e3
        return ratio, gain, loss, b, s

    result = differential_evolution(
        lambda x: value(x)[0],
        [(-args.span, args.span)] * count,
        seed=20260808 + args.order,
        maxiter=args.maxiter,
        popsize=12,
        tol=1e-9,
        polish=True,
        workers=1,
    )
    A, W = decode(args.order, result.x)
    ratio, gain, loss, b, s = value(result.x)
    print(
        {
            "order": args.order,
            "ratio": ratio,
            "gain": gain,
            "loss": loss,
            "b": b.tolist(),
            "s": s.tolist(),
            "A": A.tolist(),
            "W": W.tolist(),
        }
    )


if __name__ == "__main__":
    main()
