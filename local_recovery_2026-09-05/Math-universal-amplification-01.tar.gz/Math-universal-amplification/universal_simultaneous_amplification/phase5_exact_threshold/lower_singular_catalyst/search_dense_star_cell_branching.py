#!/usr/bin/env python3
"""Rare-colony discovery for dense populations of growing star cells.

Each cell contains one hub and ``L`` exchangeable leaves.  Distinct cells
are joined by a uniform complete background normalized to external weighted
degree one at every vertex.  Every hub--leaf edge has weight ``z`` on that
same scale.  The script solves the exact limiting colony branching process,
including all within-cell collisions, and reports uniform-singleton
establishment for Bd and dB.  Floating output is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import brentq, differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def singleton_survival(leaves: int, fitness: float, z: float, rule: str) -> tuple[float, np.ndarray]:
    """Return averaged survival and the two singleton survival values."""
    L = leaves
    dh = 1.0 + L * z
    dl = 1.0 + z
    reciprocal_mean = (1.0 / dh + L / dl) / (L + 1)
    states = [(h, j) for h in (0, 1) for j in range(L + 1) if (h, j) != (0, 0)]
    index = {state: row for row, state in enumerate(states)}

    def solve_at(success: float) -> np.ndarray:
        rows: list[int] = []
        columns: list[int] = []
        entries: list[float] = []
        rhs = np.zeros(len(states))

        for state, row in index.items():
            h, j = state
            moves: dict[tuple[int, int], float] = {}

            def add(target: tuple[int, int], rate: float) -> None:
                if rate > 0:
                    moves[target] = moves.get(target, 0.0) + rate

            if rule == "Bd":
                if h == 0 and j:
                    add((1, j), fitness * j * z / dl)
                if h == 1 and j < L:
                    add((0, j), (L - j) * z / dl)
                if h == 1 and j < L:
                    add((1, j + 1), fitness * (L - j) * z / dh)
                if h == 0 and j:
                    add((0, j - 1), j * z / dh)
                if h:
                    add((0, j), reciprocal_mean)
                if j:
                    add((h, j - 1), j * reciprocal_mean)
                external_birth = fitness * (h / dh + j / dl)
            elif rule == "dB":
                denominator_h = 1.0 + L * z + (fitness - 1.0) * j * z
                if h == 0 and j:
                    add((1, j), fitness * j * z / denominator_h)
                if h == 1:
                    add((0, j), (1.0 + (L - j) * z) / denominator_h)
                if h == 1 and j < L:
                    add((1, j + 1), (L - j) * fitness * z / (1.0 + fitness * z))
                if h == 0 and j:
                    add((0, j - 1), float(j))
                if h == 1 and j:
                    add((1, j - 1), j / (1.0 + fitness * z))
                external_birth = fitness * reciprocal_mean * (h + j)
            else:
                raise ValueError(rule)

            mark = external_birth * success
            total = mark + sum(moves.values())
            rows.append(row)
            columns.append(row)
            entries.append(total)
            rhs[row] = mark
            for target, rate in moves.items():
                if target != (0, 0):
                    rows.append(row)
                    columns.append(index[target])
                    entries.append(-rate)

        matrix = coo_matrix(
            (entries, (rows, columns)), shape=(len(states), len(states))
        ).tocsr()
        values = spsolve(matrix, rhs)
        residual = np.max(np.abs(matrix @ values - rhs))
        if residual > 2e-8:
            raise FloatingPointError(residual)
        return values

    def consistency(success: float) -> float:
        values = solve_at(success)
        hub = values[index[(1, 0)]]
        leaf = values[index[(0, 1)]]
        if rule == "Bd":
            average = (hub + L * leaf) / (L + 1)
        else:
            average = (hub / dh + L * leaf / dl) / ((L + 1) * reciprocal_mean)
        return average - success

    # T=0 is always the extinction solution.  Select the positive root by
    # solving consistency(T)/T=0 away from zero.
    eps = 1e-10
    grid = np.linspace(eps, 1.0 - eps, 500)
    vals = [consistency(float(t)) / t for t in grid]
    roots: list[float] = []
    for left, right, fl, fr in zip(grid[:-1], grid[1:], vals[:-1], vals[1:]):
        if fl * fr < 0:
            roots.append(brentq(lambda t: consistency(t) / t, left, right, xtol=2e-13))
    if not roots:
        raise ArithmeticError((leaves, fitness, z, rule, vals[0], vals[-1]))
    success = max(roots)
    values = solve_at(success)
    singles = np.array([values[index[(1, 0)]], values[index[(0, 1)]]])
    uniform = (singles[0] + L * singles[1]) / (L + 1)
    return float(uniform), singles


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--leaves", type=int, default=20)
    parser.add_argument("--fitness", type=float, default=2.0)
    parser.add_argument("--optimize", action="store_true")
    args = parser.parse_args()
    p = 1.0 - 1.0 / args.fitness

    def evaluate(log_z: float):
        z = math.exp(log_z)
        bd, bd_singles = singleton_survival(args.leaves, args.fitness, z, "Bd")
        db, db_singles = singleton_survival(args.leaves, args.fitness, z, "dB")
        gain = bd - p
        loss = p - db
        return {
            "z": z,
            "Bd": bd,
            "dB": db,
            "gain": gain,
            "loss": loss,
            "loss_over_gain": loss / gain if gain > 0 else math.inf,
            "Bd_singletons": bd_singles.tolist(),
            "dB_singletons": db_singles.tolist(),
        }

    if args.optimize:
        result = differential_evolution(
            lambda x: evaluate(float(x[0]))["loss_over_gain"],
            [(-14.0, 14.0)],
            seed=20260808,
            maxiter=100,
            popsize=20,
            tol=1e-10,
            polish=True,
        )
        print(evaluate(float(result.x[0])))
    else:
        for log_z in np.linspace(-10, 8, 19):
            print(evaluate(float(log_z)))


if __name__ == "__main__":
    main()
