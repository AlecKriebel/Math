#!/usr/bin/env python3
"""Rare-colony search for a metastable gateway aligned with a vanishing mode.

Each of many groups contains L dense-core vertices, a gateway, and a shield
clique of order K.  All core vertices form a uniform dense background of
weighted degree one.  The gateway has total local-core load c and is joined
to every shield vertex with weight B; shield-clique edges have weight A.
External core children enter fresh groups.  The exact limiting orbit state
is (local core mutants, gateway type, shield mutants).

The intended singular regime has K growing logarithmically with L: a rare
core-to-gateway event can nucleate a shield colony whose reciprocal invasion
time is exponential in K.  Floating output is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import brentq, differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def survival(
    L: int, K: int, r: float, c: float, B: float, A: float, rule: str
) -> tuple[float, np.ndarray]:
    w = c / L
    dc = 1.0 + w
    dg = c + K * B
    dr = (K - 1) * A + B
    states = [
        (i, h, j)
        for i in range(L + 1)
        for h in (0, 1)
        for j in range(K + 1)
        if (i, h, j) != (0, 0, 0)
    ]
    index = {q: row for row, q in enumerate(states)}

    def linear(T: float) -> np.ndarray:
        rows: list[int] = []
        columns: list[int] = []
        entries: list[float] = []
        rhs = np.zeros(len(states))
        for (i, h, j), row in index.items():
            moves: dict[tuple[int, int, int], float] = {}

            def add(q: tuple[int, int, int], rate: float) -> None:
                if rate > 0:
                    moves[q] = moves.get(q, 0.0) + rate

            if rule == "Bd":
                # Dense external core and local core--gateway events.
                if i:
                    add((i - 1, h, j), i / dc)
                if h == 0 and i:
                    add((i, 1, j), r * i * w / dc)
                    add((i - 1, 0, j), i * w / dg)
                if h == 1 and i < L:
                    add((i, 0, j), (L - i) * w / dc)
                    add((i + 1, 1, j), r * (L - i) * w / dg)

                # Gateway--shield interface.
                if h == 1 and j < K:
                    add((i, 1, j + 1), r * (K - j) * B / dg)
                    add((i, 0, j), (K - j) * B / dr)
                if h == 0 and j:
                    add((i, 0, j - 1), j * B / dg)
                    add((i, 1, j), r * j * B / dr)

                # Internal shield clique.
                if 0 < j < K:
                    add((i, h, j + 1), r * j * (K - j) * A / dr)
                    add((i, h, j - 1), j * (K - j) * A / dr)
                birth = r * i / dc
            elif rule == "dB":
                # Local core deaths.
                if h == 1 and i < L:
                    add((i + 1, h, j), (L - i) * r * w / (1.0 + r * w))
                if i:
                    loss = 1.0 if h == 0 else 1.0 / (1.0 + r * w)
                    add((i - 1, h, j), i * loss)

                # Gateway death.
                mutant_mass = r * (i * w + j * B)
                resident_mass = (L - i) * w + (K - j) * B
                den_g = mutant_mass + resident_mass
                if h == 0 and mutant_mass:
                    add((i, 1, j), mutant_mass / den_g)
                if h == 1 and resident_mass:
                    add((i, 0, j), resident_mass / den_g)

                # Shield-clique deaths, including the gateway competitor.
                if j < K:
                    mutant = r * (j * A + h * B)
                    resident = (K - j - 1) * A + (1 - h) * B
                    den = mutant + resident
                    if mutant:
                        add((i, h, j + 1), (K - j) * mutant / den)
                if j:
                    mutant = r * ((j - 1) * A + h * B)
                    resident = (K - j) * A + (1 - h) * B
                    den = mutant + resident
                    if resident:
                        add((i, h, j - 1), j * resident / den)
                birth = r * i / dc
            else:
                raise ValueError(rule)

            mark = birth * T
            total = mark + sum(moves.values())
            rows.append(row)
            columns.append(row)
            entries.append(total)
            rhs[row] = mark
            for q, rate in moves.items():
                if q != (0, 0, 0):
                    rows.append(row)
                    columns.append(index[q])
                    entries.append(-rate)
        matrix = coo_matrix((entries, (rows, columns)), shape=(len(states),) * 2).tocsr()
        u = spsolve(matrix, rhs)
        residual = np.max(np.abs(matrix @ u - rhs))
        if residual > 5e-8:
            raise FloatingPointError(residual)
        return u

    def equation(T: float) -> float:
        return linear(T)[index[(1, 0, 0)]] - T

    left, right = 1e-9, 1 - 1e-9
    f_left, f_right = equation(left) / left, equation(right) / right
    if not (f_left > 0 > f_right):
        raise ArithmeticError((L, K, r, c, B, A, rule, f_left, f_right))
    T = brentq(lambda x: equation(x) / x, left, right, xtol=2e-13)
    u = linear(T)
    singles = np.array(
        [u[index[(1, 0, 0)]], u[index[(0, 1, 0)]], u[index[(0, 0, 1)]]]
    )
    uniform = (L * singles[0] + singles[1] + K * singles[2]) / (L + K + 1)
    return float(uniform), singles


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", type=int, default=50)
    parser.add_argument("--shield", type=int, default=5)
    parser.add_argument("--fitness", type=float, default=2.0)
    parser.add_argument("--maxiter", type=int, default=60)
    args = parser.parse_args()
    p = 1 - 1 / args.fitness

    def value(x: np.ndarray) -> dict[str, object]:
        c, B, A = np.exp(x)
        bd, bs = survival(args.core, args.shield, args.fitness, c, B, A, "Bd")
        db, ds = survival(args.core, args.shield, args.fitness, c, B, A, "dB")
        gain, loss = bd - p, p - db
        return {
            "c": float(c),
            "B": float(B),
            "A": float(A),
            "Bd": bd,
            "dB": db,
            "gain": gain,
            "loss": loss,
            "ratio": loss / gain if gain > 1e-10 else math.inf,
            "Bd_singletons": bs.tolist(),
            "dB_singletons": ds.tolist(),
        }

    result = differential_evolution(
        lambda x: value(x)["ratio"],
        [(-10.0, 12.0), (-10.0, 12.0), (-10.0, 12.0)],
        seed=20260808 + args.core + 1000 * args.shield,
        maxiter=args.maxiter,
        popsize=15,
        tol=1e-9,
        polish=True,
    )
    print({"L": args.core, "K": args.shield, **value(result.x)})


if __name__ == "__main__":
    main()
