#!/usr/bin/env python3
"""Rare-colony screen for dense populations of complete-bipartite cells.

Every cell is K_{A,B} with internal edge weight z on the scale where each
vertex has external weighted degree one.  Distinct cells have a uniform
complete background.  The limiting two-count colony chain retains all
within-cell collisions.  Floating output is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import brentq, differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def survival(A: int, B: int, r: float, z: float, rule: str) -> tuple[float, tuple[float, float]]:
    d0, d1 = 1.0 + B * z, 1.0 + A * z
    size = A + B
    t = (A / d0 + B / d1) / size
    states = [(i, j) for i in range(A + 1) for j in range(B + 1) if (i, j) != (0, 0)]
    index = {q: k for k, q in enumerate(states)}

    def linear(T: float) -> np.ndarray:
        rows: list[int] = []
        columns: list[int] = []
        entries: list[float] = []
        rhs = np.zeros(len(states))
        for (i, j), row in index.items():
            moves: dict[tuple[int, int], float] = {}

            def add(q: tuple[int, int], rate: float) -> None:
                if rate > 0:
                    moves[q] = moves.get(q, 0.0) + rate

            if rule == "Bd":
                add((i + 1, j), r * j * (A - i) * z / d1 if i < A else 0.0)
                add((i - 1, j), i * (B - j) * z / d1 if i else 0.0)
                add((i, j + 1), r * i * (B - j) * z / d0 if j < B else 0.0)
                add((i, j - 1), j * (A - i) * z / d0 if j else 0.0)
                add((i - 1, j), i * t if i else 0.0)
                add((i, j - 1), j * t if j else 0.0)
                birth = r * (i / d0 + j / d1)
            elif rule == "dB":
                den0 = 1.0 + z * (B + (r - 1.0) * j)
                add((i + 1, j), (A - i) * r * j * z / den0 if i < A else 0.0)
                add((i - 1, j), i * (1.0 + (B - j) * z) / den0 if i else 0.0)
                den1 = 1.0 + z * (A + (r - 1.0) * i)
                add((i, j + 1), (B - j) * r * i * z / den1 if j < B else 0.0)
                add((i, j - 1), j * (1.0 + (A - i) * z) / den1 if j else 0.0)
                birth = r * t * (i + j)
            else:
                raise ValueError(rule)
            mark = birth * T
            total = mark + sum(moves.values())
            rows.append(row)
            columns.append(row)
            entries.append(total)
            rhs[row] = mark
            for q, rate in moves.items():
                if q != (0, 0):
                    rows.append(row)
                    columns.append(index[q])
                    entries.append(-rate)
        matrix = coo_matrix((entries, (rows, columns)), shape=(len(states),) * 2).tocsr()
        u = spsolve(matrix, rhs)
        if np.max(np.abs(matrix @ u - rhs)) > 2e-8:
            raise FloatingPointError
        return u

    def means(T: float) -> tuple[float, float]:
        u = linear(T)
        u0, u1 = u[index[(1, 0)]], u[index[(0, 1)]]
        uniform = (A * u0 + B * u1) / size
        child = (A * u0 / d0 + B * u1 / d1) / (size * t)
        return uniform, child

    def equation(T: float) -> float:
        uniform, child = means(T)
        return (uniform if rule == "Bd" else child) - T

    grid = np.linspace(1e-10, 1 - 1e-10, 400)
    f = [equation(float(x)) / x for x in grid]
    roots = [
        brentq(lambda x: equation(x) / x, a, b, xtol=2e-13)
        for a, b, fa, fb in zip(grid[:-1], grid[1:], f[:-1], f[1:])
        if fa * fb < 0
    ]
    if not roots:
        raise ArithmeticError((A, B, r, z, rule, f[0], f[-1]))
    T = max(roots)
    uniform, _ = means(T)
    u = linear(T)
    return float(uniform), (float(u[index[(1, 0)]]), float(u[index[(0, 1)]]))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--left", type=int, default=3)
    parser.add_argument("--right", type=int, default=20)
    parser.add_argument("--fitness", type=float, default=2.0)
    parser.add_argument("--maxiter", type=int, default=60)
    args = parser.parse_args()
    p = 1 - 1 / args.fitness

    def value(logz: float) -> dict[str, float | tuple[float, float]]:
        z = math.exp(logz)
        bd, bs = survival(args.left, args.right, args.fitness, z, "Bd")
        db, ds = survival(args.left, args.right, args.fitness, z, "dB")
        gain, loss = bd - p, p - db
        return {
            "z": z,
            "Bd": bd,
            "dB": db,
            "gain": gain,
            "loss": loss,
            "ratio": loss / gain if gain > 1e-12 else math.inf,
            "Bd_singletons": bs,
            "dB_singletons": ds,
        }

    result = differential_evolution(
        lambda x: value(float(x[0]))["ratio"],
        [(-12.0, 14.0)],
        seed=20260808 + args.left + 100 * args.right,
        maxiter=args.maxiter,
        popsize=15,
        tol=1e-10,
        polish=True,
    )
    print({"A": args.left, "B": args.right, **value(float(result.x[0]))})


if __name__ == "__main__":
    main()
