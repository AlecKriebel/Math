#!/usr/bin/env python3
"""Rare-colony search for a correlated gateway--shield cell population.

There are many groups.  Each group has L core vertices, one gateway joined
to all local core vertices with total load c, and one shield joined only to
the gateway with weight W.  All core vertices across all groups form a
uniform dense background of weighted degree one.  The limiting colony state
is (local mutant core count, gateway type, shield type); external core
children enter fresh groups.  This retains the sparse shared gateway edge
below every mutant cutoff and lies outside diffuse clone kernels.

Floating output is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import brentq, differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def survival(L: int, r: float, c: float, W: float, rule: str) -> tuple[float, np.ndarray]:
    w = c / L
    dc = 1.0 + w
    dg = c + W
    states = [(i, h, s) for i in range(L + 1) for h in (0, 1) for s in (0, 1) if (i, h, s) != (0, 0, 0)]
    index = {q: k for k, q in enumerate(states)}

    def linear(T: float) -> np.ndarray:
        rows: list[int] = []
        columns: list[int] = []
        entries: list[float] = []
        rhs = np.zeros(len(states))
        for (i, h, s), row in index.items():
            moves: dict[tuple[int, int, int], float] = {}

            def add(q: tuple[int, int, int], rate: float) -> None:
                if rate > 0:
                    moves[q] = moves.get(q, 0.0) + rate

            if rule == "Bd":
                # Core--gateway events.
                if h == 0 and i:
                    add((i, 1, s), r * i * w / dc)
                    add((i - 1, 0, s), i * w / dg)
                if h == 1 and i < L:
                    add((i, 0, s), (L - i) * w / dc)
                    add((i + 1, 1, s), r * (L - i) * w / dg)
                # External dense-core recovery of local core mutants.
                if i:
                    add((i - 1, h, s), i / dc)
                # Gateway--shield events.  The shield has no other neighbour.
                if h != s:
                    if h:
                        add((i, h, 1), r * W / dg)
                        add((i, 0, s), 1.0)
                    else:
                        add((i, h, 0), W / dg)
                        add((i, 1, s), r)
                birth = r * i / dc
            elif rule == "dB":
                # A local core vertex dies.  Its dense-core neighbour mass is
                # one and the gateway contributes w.
                if h == 1 and i < L:
                    add((i + 1, h, s), (L - i) * r * w / (1.0 + r * w))
                if i:
                    loss_probability = 1.0 if h == 0 else 1.0 / (1.0 + r * w)
                    add((i - 1, h, s), i * loss_probability)

                # The gateway dies and chooses among local cores and shield.
                mutant_mass = r * (i * w + s * W)
                resident_mass = (L - i) * w + (1 - s) * W
                denominator = mutant_mass + resident_mass
                if h == 0 and mutant_mass:
                    add((i, 1, s), mutant_mass / denominator)
                if h == 1 and resident_mass:
                    add((i, 0, s), resident_mass / denominator)

                # The shield dies and copies the gateway deterministically.
                if h != s:
                    add((i, h, h), 1.0)
                birth = r * i / dc
            else:
                raise ValueError(rule)

            mark = birth * T
            total = mark + sum(moves.values())
            rows.append(row)
            columns.append(row)
            entries.append(total)
            rhs[row] = mark
            for q, rate in moves.items():
                if q != (0, 0, 0):
                    rows.append(row)
                    columns.append(index[q])
                    entries.append(-rate)
        matrix = coo_matrix((entries, (rows, columns)), shape=(len(states),) * 2).tocsr()
        u = spsolve(matrix, rhs)
        if np.max(np.abs(matrix @ u - rhs)) > 3e-8:
            raise FloatingPointError
        return u

    def equation(T: float) -> float:
        return linear(T)[index[(1, 0, 0)]] - T

    grid = np.linspace(1e-9, 1 - 1e-9, 400)
    f = [equation(float(x)) / x for x in grid]
    roots = [
        brentq(lambda x: equation(x) / x, a, b, xtol=2e-13)
        for a, b, fa, fb in zip(grid[:-1], grid[1:], f[:-1], f[1:])
        if fa * fb < 0
    ]
    if not roots:
        raise ArithmeticError((L, r, c, W, rule, f[0], f[-1]))
    T = max(roots)
    u = linear(T)
    singles = np.array([u[index[(1, 0, 0)]], u[index[(0, 1, 0)]], u[index[(0, 0, 1)]]])
    uniform = (L * singles[0] + singles[1] + singles[2]) / (L + 2)
    return float(uniform), singles


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", type=int, default=20)
    parser.add_argument("--fitness", type=float, default=2.0)
    parser.add_argument("--maxiter", type=int, default=80)
    args = parser.parse_args()
    p = 1 - 1 / args.fitness

    def value(x: np.ndarray) -> dict[str, object]:
        c, W = np.exp(x)
        bd, bs = survival(args.group, args.fitness, c, W, "Bd")
        db, ds = survival(args.group, args.fitness, c, W, "dB")
        gain, loss = bd - p, p - db
        return {
            "c": float(c),
            "W": float(W),
            "Bd": bd,
            "dB": db,
            "gain": gain,
            "loss": loss,
            "ratio": loss / gain if gain > 1e-11 else math.inf,
            "Bd_singletons": bs.tolist(),
            "dB_singletons": ds.tolist(),
        }

    result = differential_evolution(
        lambda x: value(x)["ratio"],
        [(-12.0, 12.0), (-12.0, 16.0)],
        seed=20260808 + args.group,
        maxiter=args.maxiter,
        popsize=18,
        tol=1e-10,
        polish=True,
    )
    print({"L": args.group, **value(result.x)})


if __name__ == "__main__":
    main()
