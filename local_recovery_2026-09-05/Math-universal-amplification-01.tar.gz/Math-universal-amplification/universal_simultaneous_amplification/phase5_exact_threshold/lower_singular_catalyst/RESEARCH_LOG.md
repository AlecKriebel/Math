# Singular non-diffuse catalyst branch

Date: 2026-08-08 (America/Los_Angeles)

## Objective

Find a growing-rank endpoint catalyst with full response

\[
 B_k/c_k\to b>0,\qquad D_k/c_k\to0,
\]

outside diffuse rank-one, regular quadratic, separated-pair, fixed-order
clone, and previously screened portal--blade normal forms.

## Discovery implementations

All statements in this section are **NUMERICALLY OBSERVED**, not theorems.

1. `search_dense_star_cell_branching.py` derives the exact limiting
   rare-colony equations for a density-one population of star cells over a
   complete external background.  Every within-star collision and every
   uniform singleton is retained.  At `r=2`, Bd gain was always accompanied
   by a larger-order dB loss; the quotient did not decrease with star order.

2. `search_dense_bipartite_cell_branching.py` does the same for arbitrary
   complete-bipartite cells.  Extreme aspect ratios approach the period-two
   response with dB cost approximately twice Bd gain, not zero.

3. `search_grouped_gateway_shield_branching.py` retains an order-one shared
   gateway edge below every mutant cutoff.  Each group has `L` dense-core
   vertices, one gateway, and one shield.  The local orbit is `(i,h,s)` and
   external children enter fresh groups.  The gateway can improve Bd core
   singleton survival, but the exact uniform gateway/shield starts and the
   dB disturbance prevent a catalyst quotient.

4. `search_metastable_gateway_reservoir.py` replaces the shield by a clique
   of order `K`, with the intended singular scaling `K` logarithmic in `L`.
   The local orbit `(i,h,j)` includes the entire metastable episode.  A
   mutant shield can keep the gateway active for an exponentially long
   reciprocal-invasion time, but reciprocity makes the dB loss from the
   `L` core starts grow before the uniform Bd response becomes useful.  No
   positive vanishing-cost ray appeared.

5. `search_correlated_cell_normal_form.py` implements the full fixed-cell
   normal form with an arbitrary symmetric internal matrix `A` and arbitrary
   symmetric intercell matrix `W/M`.  It solves the nonlinear singleton
   consistency vector together with the entire labelled subset trace.  For
   orders two through four, hostile optimization and random screens found

   \[
   \frac{1/2-\bar s_{dB}}{\bar b_{Bd}-1/2}\gtrsim2
   \]

   whenever the denominator was positive.  This suggests an all-cell
   adjoint inequality, but no proof is claimed.

6. `search_integrated_clique_gateway.py` evaluates the exact endpoint M5
   score of a growing shield clique plus one integrated gateway, including
   core marks, recoveries, all singleton starts, and the far-field terms.
   The best quotients approach the portal-free star boundary near one rather
   than zero.  Making the shield genuinely metastable worsens the quotient.

7. `search_integrated_two_gateway_clique.py` adds a second unequal gateway,
   an optional gateway--gateway edge, and independent portal loads.  This is
   the smallest growing-rank module in which two reciprocal dB disturbances
   could cancel while the Bd effects add.  Direct optimization again ran to
   a one-gateway/star boundary; no cancellation ray or positive endpoint dB
   coordinate appeared.

## Structural lesson

The metastable lifetime itself is not the missing leverage.  A core mutant
enters a uniformly shared gateway at rate proportional to its total gateway
load divided by `L`; before the gateway is erased, its chance to nucleate a
shield carries the reciprocal factor.  Increasing the load therefore does
not amplify the uniform entrance mass.  Once a shield is established it can
produce a very long burst, but the burst already saturates at success
probability one, while the same undirected interface continues to perturb
dB core starts.

The remaining constructive exit must therefore avoid a single reciprocal
entrance/output interface.  A credible next candidate needs either:

- two genuinely different correlated interfaces whose dB disturbances
  cancel at the full uniform-start level while their Bd effects add; or
- a nonlocal density interaction in which the first nonzero Bd response is
  generated after colonies overlap, not by a trace-resolved rare-colony
  survival probability.

No exact positive response vector has yet been found on this branch.
