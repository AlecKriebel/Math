#!/usr/bin/env python3
"""Endpoint response of an integrated clique shield plus one gateway.

The gadget consists of a K-clique (edge weight A) and one gateway joined to
every clique vertex (weight B).  Gateway and shield vertices have independent
portal loads x_g and x_s to the large core.  Core marks and core recoveries
remain active in every polymorphic state (gateway bit, shield mutant count).
The reported scores are the full endpoint M5 response, including all uniform
starts and far-field terms.  Floating output is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def singleton_success(
    K: int, fitness: float, rule: str, A: float, B: float, xg: float, xs: float
) -> np.ndarray:
    dg = xg + K * B
    ds = xs + (K - 1) * A + B
    states = [(h, j) for h in (0, 1) for j in range(K + 1) if (h, j) != (0, 0)]
    index = {q: row for row, q in enumerate(states)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))

    for (h, j), row in index.items():
        moves: dict[tuple[int, int], float] = {}

        def add(q: tuple[int, int], rate: float) -> None:
            if rate > 0:
                moves[q] = moves.get(q, 0.0) + rate

        if rule == "Bd":
            if h == 1 and j < K:
                add((1, j + 1), fitness * (K - j) * B / dg)
                add((0, j), (K - j) * B / ds)
            if h == 0 and j:
                add((0, j - 1), j * B / dg)
                add((1, j), fitness * j * B / ds)
            if 0 < j < K:
                add((h, j + 1), fitness * j * (K - j) * A / ds)
                add((h, j - 1), j * (K - j) * A / ds)
            if h:
                add((0, j), xg)
            if j:
                add((h, j - 1), j * xs)
            mark = (fitness - 1) * (h * xg / dg + j * xs / ds)
        elif rule == "dB":
            mutant_g = fitness * j * B
            resident_g = xg + (K - j) * B
            den_g = mutant_g + resident_g
            if h == 0 and mutant_g:
                add((1, j), mutant_g / den_g)
            if h == 1 and resident_g:
                add((0, j), resident_g / den_g)
            if j < K:
                mutant = fitness * (j * A + h * B)
                resident = xs + (K - j - 1) * A + (1 - h) * B
                den = mutant + resident
                if mutant:
                    add((h, j + 1), (K - j) * mutant / den)
            if j:
                mutant = fitness * ((j - 1) * A + h * B)
                resident = xs + (K - j) * A + (1 - h) * B
                den = mutant + resident
                if resident:
                    add((h, j - 1), j * resident / den)
            mark = (fitness - 1) * (h * xg + j * xs)
        else:
            raise ValueError(rule)

        total = mark + sum(moves.values())
        rows.append(row)
        columns.append(row)
        entries.append(total)
        rhs[row] = mark
        for q, rate in moves.items():
            if q != (0, 0):
                rows.append(row)
                columns.append(index[q])
                entries.append(-rate)
    matrix = coo_matrix((entries, (rows, columns)), shape=(len(states),) * 2).tocsr()
    u = spsolve(matrix, rhs)
    if np.max(np.abs(matrix @ u - rhs)) > 3e-8:
        raise FloatingPointError
    return np.array([u[index[(1, 0)]], u[index[(0, 1)]]])


def response(K: int, fitness: float, parameters: np.ndarray) -> tuple[float, ...]:
    A, B, xg, xs = np.exp(parameters)
    dg = xg + K * B
    ds = xs + (K - 1) * A + B
    ub = singleton_success(K, fitness, "Bd", A, B, xg, xs)
    ud = singleton_success(K, fitness, "dB", A, B, xg, xs)
    p = 1 - 1 / fitness
    order = K + 1
    portal_sum = xg + K * xs
    portal_over_degree = xg / dg + K * xs / ds
    source_b = fitness * (xg * ub[0] + K * xs * ub[1]) - (fitness - 1) * portal_over_degree
    source_d = fitness * (xg * ud[0] / dg + K * xs * ud[1] / ds) - (fitness - 1) * (portal_sum + fitness - 1)
    score_b = (ub[0] + K * ub[1]) / p - order + source_b / (fitness - 1) ** 2
    score_d = (ud[0] + K * ud[1]) / p - order + 1 + source_d / (fitness - 1) ** 2
    ratio = -score_d / score_b if score_b > 1e-9 else math.inf
    return float(score_b), float(score_d), float(ratio), A, B, xg, xs, *ub, *ud


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shield", type=int, default=20)
    parser.add_argument("--fitness", type=float, default=2.0)
    parser.add_argument("--balanced", action="store_true")
    parser.add_argument("--maxiter", type=int, default=100)
    parser.add_argument("--span", type=float, default=12.0)
    args = parser.parse_args()

    def objective(x: np.ndarray) -> float:
        B, D, ratio, *_ = response(args.shield, args.fitness, x)
        if args.balanced:
            return -min(D, D + (args.fitness - 1) * B)
        if B <= 1e-8:
            return 1e4 + abs(B)
        # Search the catalyst quotient directly.  Positive dB is accepted as
        # an even stronger witness.
        return ratio

    result = differential_evolution(
        objective,
        [(-args.span, args.span)] * 4,
        seed=20260808 + args.shield,
        maxiter=args.maxiter,
        popsize=18,
        tol=1e-10,
        polish=True,
    )
    print({"K": args.shield, "r": args.fitness, "response": response(args.shield, args.fitness, result.x)})


if __name__ == "__main__":
    main()
