#!/usr/bin/env python3
"""Full endpoint response of a shield clique with two unequal gateways.

This is the smallest growing-rank integrated module with two genuinely
different reciprocal interfaces.  It can in principle cancel their dB
disturbances while adding their Bd effects.  The exact local orbit is
``(gateway_1, gateway_2, shield mutant count)``; all core marks, recoveries,
uniform starts, and far-field response terms are retained.  Floating output
is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def success(K: int, rule: str, parameters: np.ndarray) -> tuple[np.ndarray, tuple[float, ...]]:
    A, B1, B2, C, x1, x2, xs = np.exp(parameters)
    d1 = x1 + K * B1 + C
    d2 = x2 + K * B2 + C
    ds = xs + (K - 1) * A + B1 + B2
    states = [
        (h1, h2, j)
        for h1 in (0, 1)
        for h2 in (0, 1)
        for j in range(K + 1)
        if (h1, h2, j) != (0, 0, 0)
    ]
    index = {q: row for row, q in enumerate(states)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))

    for (h1, h2, j), row in index.items():
        moves: dict[tuple[int, int, int], float] = {}

        def add(q: tuple[int, int, int], rate: float) -> None:
            if rate > 0:
                moves[q] = moves.get(q, 0.0) + rate

        if rule == "Bd":
            if h1 != h2:
                if h1:
                    add((h1, 1, j), 2 * C / d1)
                    add((0, h2, j), C / d2)
                else:
                    add((h1, 0, j), C / d1)
                    add((1, h2, j), 2 * C / d2)
            # Each gateway acts on the common shield population and receives
            # reciprocal replacements from it.
            for which, h, B, dg in ((1, h1, B1, d1), (2, h2, B2, d2)):
                if h and j < K:
                    add((h1, h2, j + 1), 2 * (K - j) * B / dg)
                    q = (0, h2, j) if which == 1 else (h1, 0, j)
                    add(q, (K - j) * B / ds)
                if not h and j:
                    add((h1, h2, j - 1), j * B / dg)
                    q = (1, h2, j) if which == 1 else (h1, 1, j)
                    add(q, 2 * j * B / ds)
            if 0 < j < K:
                add((h1, h2, j + 1), 2 * j * (K - j) * A / ds)
                add((h1, h2, j - 1), j * (K - j) * A / ds)
            if h1:
                add((0, h2, j), x1)
            if h2:
                add((h1, 0, j), x2)
            if j:
                add((h1, h2, j - 1), j * xs)
            mark = h1 * x1 / d1 + h2 * x2 / d2 + j * xs / ds
        elif rule == "dB":
            mutant = 2 * (j * B1 + h2 * C)
            resident = x1 + (K - j) * B1 + (1 - h2) * C
            den = mutant + resident
            if not h1 and mutant:
                add((1, h2, j), mutant / den)
            if h1 and resident:
                add((0, h2, j), resident / den)
            mutant = 2 * (j * B2 + h1 * C)
            resident = x2 + (K - j) * B2 + (1 - h1) * C
            den = mutant + resident
            if not h2 and mutant:
                add((h1, 1, j), mutant / den)
            if h2 and resident:
                add((h1, 0, j), resident / den)
            if j < K:
                mutant = 2 * (j * A + h1 * B1 + h2 * B2)
                resident = xs + (K - j - 1) * A + (1 - h1) * B1 + (1 - h2) * B2
                den = mutant + resident
                if mutant:
                    add((h1, h2, j + 1), (K - j) * mutant / den)
            if j:
                mutant = 2 * ((j - 1) * A + h1 * B1 + h2 * B2)
                resident = xs + (K - j) * A + (1 - h1) * B1 + (1 - h2) * B2
                den = mutant + resident
                if resident:
                    add((h1, h2, j - 1), j * resident / den)
            mark = h1 * x1 + h2 * x2 + j * xs
        else:
            raise ValueError(rule)

        total = mark + sum(moves.values())
        rows.append(row)
        columns.append(row)
        entries.append(total)
        rhs[row] = mark
        for q, rate in moves.items():
            if q != (0, 0, 0):
                rows.append(row)
                columns.append(index[q])
                entries.append(-rate)
    matrix = coo_matrix((entries, (rows, columns)), shape=(len(states),) * 2).tocsr()
    u = spsolve(matrix, rhs)
    if np.max(np.abs(matrix @ u - rhs)) > 3e-8:
        raise FloatingPointError
    singles = np.array(
        [u[index[(1, 0, 0)]], u[index[(0, 1, 0)]], u[index[(0, 0, 1)]]]
    )
    return singles, (A, B1, B2, C, x1, x2, xs, d1, d2, ds)


def response(K: int, parameters: np.ndarray) -> tuple[object, ...]:
    ub, data = success(K, "Bd", parameters)
    ud, _ = success(K, "dB", parameters)
    A, B1, B2, C, x1, x2, xs, d1, d2, ds = data
    B = (
        2 * (1 + x1) * ub[0] - 1 - x1 / d1
        + 2 * (1 + x2) * ub[1] - 1 - x2 / d2
        + K * (2 * (1 + xs) * ub[2] - 1 - xs / ds)
    )
    D = (
        2 * (1 + x1 / d1) * ud[0] - 1 - x1
        + 2 * (1 + x2 / d2) * ud[1] - 1 - x2
        + K * (2 * (1 + xs / ds) * ud[2] - 1 - xs)
    )
    ratio = -D / B if B > 1e-9 else math.inf
    return float(B), float(D), float(ratio), data[:-3], ub, ud


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shield", type=int, default=20)
    parser.add_argument("--maxiter", type=int, default=100)
    parser.add_argument("--span", type=float, default=12)
    args = parser.parse_args()

    def objective(x: np.ndarray) -> float:
        B, _, ratio, *_ = response(args.shield, x)
        return ratio if B > 1e-8 else 1e4 + abs(B)

    result = differential_evolution(
        objective,
        [(-args.span, args.span)] * 7,
        seed=20260808 + args.shield,
        maxiter=args.maxiter,
        popsize=15,
        tol=1e-10,
        polish=True,
    )
    print({"K": args.shield, "response": response(args.shield, result.x)})


if __name__ == "__main__":
    main()
