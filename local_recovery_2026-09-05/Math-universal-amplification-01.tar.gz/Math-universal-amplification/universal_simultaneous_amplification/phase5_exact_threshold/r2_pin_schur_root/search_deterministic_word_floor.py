#!/usr/bin/env python3
"""Hostile screen for a deterministic-word transient floor.

Discovery only.  A loopless deterministic vertex map is a row-extreme
replacement kernel.  The proposed strong lemma is that, from the complete
active law, every time-inhomogeneous word of such maps has inverse-rank
reward at least the complete value.
"""

from __future__ import annotations

from fractions import Fraction as Q
from itertools import product
from functools import lru_cache
from random import Random
import argparse


def states_for(n: int):
    states = [
        (mask, target)
        for target in range(n)
        for mask in range(1, 1 << n)
        if not (mask >> target) & 1
    ]
    return states, {state: index for index, state in enumerate(states)}


def deterministic_operator(mapping, states, index):
    rows = []
    for mask, target in states:
        size = mask.bit_count()
        row = {}

        def add(state, mass):
            j = index[state]
            row[j] = row.get(j, Q(0)) + mass

        sample = mapping[target]
        add((mask | (1 << sample), target), Q(1, 2))
        for new_target in range(len(mapping)):
            if (mask >> new_target) & 1:
                reduced = mask & ~(1 << new_target)
                sample = mapping[new_target]
                add((reduced | (1 << sample), new_target), Q(1, 2 * size))
        assert sum(row.values(), Q(0)) == 1
        rows.append(row)
    return rows


def apply_row(law, operator):
    result = [Q(0) for _ in law]
    for source, mass in enumerate(law):
        if mass:
            for target, probability in operator[source].items():
                result[target] += mass * probability
    return result


def initial_law(n, states):
    denominator = n * (n - 1) * 2 ** (n - 2)
    law = [Q(mask.bit_count(), denominator) for mask, _ in states]
    assert sum(law, Q(0)) == 1
    return law


def reward(law, states):
    return sum(
        (mass / mask.bit_count() for mass, (mask, _) in zip(law, states)),
        Q(0),
    )


def mappings(n):
    choices = [tuple(j for j in range(n) if j != i) for i in range(n)]
    yield from product(*choices)


def exhaustive(n: int, length: int):
    states, index = states_for(n)
    maps = list(mappings(n))
    operators = [deterministic_operator(mapping, states, index) for mapping in maps]
    start = initial_law(n, states)
    baseline = reward(start, states)
    minimum = None
    witness = None

    def visit(depth, law, word):
        nonlocal minimum, witness
        if depth == length:
            gap = reward(law, states) - baseline
            if minimum is None or gap < minimum:
                minimum = gap
                witness = tuple(word)
            return
        for map_index, operator in enumerate(operators):
            visit(depth + 1, apply_row(law, operator), word + [maps[map_index]])

    visit(0, start, [])
    print("exhaustive", n, length, "maps", len(maps), "minimum", minimum)
    print("witness", witness)
    return minimum


def random_screen(n: int, length: int, trials: int, seed: int):
    rng = Random(seed)
    states, index = states_for(n)
    start = initial_law(n, states)
    baseline = reward(start, states)
    cache = {}
    minimum = None
    witness = None
    for _ in range(trials):
        law = start
        word = []
        for _ in range(length):
            mapping = tuple(rng.choice([j for j in range(n) if j != i]) for i in range(n))
            word.append(mapping)
            operator = cache.get(mapping)
            if operator is None:
                operator = deterministic_operator(mapping, states, index)
                cache[mapping] = operator
            law = apply_row(law, operator)
        gap = reward(law, states) - baseline
        if minimum is None or gap < minimum:
            minimum = gap
            witness = tuple(word)
    print("random", n, length, trials, "minimum", minimum, float(minimum))
    print("witness", witness)
    return minimum


def weak_compositions(total, parts, prefix=()):
    if parts == 1:
        yield prefix + (total,)
        return
    for value in range(total + 1):
        yield from weak_compositions(total - value, parts - 1, prefix + (value,))


def symmetrized_multisets(n: int, length: int):
    """Exhaust every map-count vector, averaging over all word orders."""
    states, index = states_for(n)
    maps = list(mappings(n))
    operators = [deterministic_operator(mapping, states, index) for mapping in maps]
    start = tuple(initial_law(n, states))
    baseline = reward(start, states)

    @lru_cache(maxsize=None)
    def control(counts):
        total = sum(counts)
        if total == 0:
            return start
        result = [Q(0) for _ in start]
        for j, count in enumerate(counts):
            if not count:
                continue
            previous = list(counts)
            previous[j] -= 1
            image = apply_row(control(tuple(previous)), operators[j])
            for state, value in enumerate(image):
                result[state] += Q(count, total) * value
        return tuple(result)

    minimum = None
    witness = None
    tested = 0
    for counts in weak_compositions(length, len(maps)):
        gap = reward(control(counts), states) - baseline
        tested += 1
        if minimum is None or gap < minimum:
            minimum = gap
            witness = counts
    print("symmetrized", n, length, "multisets", tested, "minimum", minimum)
    print("count witness", witness)
    if witness is not None:
        print("map witness", [(maps[j], count) for j, count in enumerate(witness) if count])
    return minimum


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=3)
    parser.add_argument("--length", type=int, default=2)
    parser.add_argument("--trials", type=int, default=0)
    parser.add_argument("--seed", type=int, default=26080861)
    parser.add_argument("--symmetrized", action="store_true")
    args = parser.parse_args()
    if args.symmetrized:
        symmetrized_multisets(args.n, args.length)
    elif args.trials:
        random_screen(args.n, args.length, args.trials, args.seed)
    else:
        exhaustive(args.n, args.length)


if __name__ == "__main__":
    main()
