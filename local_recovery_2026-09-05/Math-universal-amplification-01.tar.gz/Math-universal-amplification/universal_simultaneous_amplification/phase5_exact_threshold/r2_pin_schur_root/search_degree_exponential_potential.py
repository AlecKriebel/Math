#!/usr/bin/env python3
"""Hostile screen for the degree-volume exponential dB potential.

Discovery only.  Degrees are normalized to arithmetic mean one and
F(S)=1-2^{-sum_{v in S} d_v}.  We test whether its r=2 dB generator is
nonpositive statewise.
"""

from __future__ import annotations

from itertools import combinations
from random import Random
import argparse
import math


def residuals(weights):
    n = len(weights)
    raw_degrees = [sum(row) for row in weights]
    mean_degree = sum(raw_degrees) / n
    degrees = [degree / mean_degree for degree in raw_degrees]
    P = [
        [weights[v][u] / raw_degrees[v] for u in range(n)]
        for v in range(n)
    ]
    answer = []
    for state in range(1, (1 << n) - 1):
        volume = sum(degrees[v] for v in range(n) if state >> v & 1)
        factor = 2.0 ** (-volume)
        drift = 0.0
        for v in range(n):
            x = sum(P[v][u] for u in range(n) if state >> u & 1)
            if state >> v & 1:
                rate = (1.0 - x) / (1.0 + x)
                drift -= rate * factor * (2.0 ** degrees[v] - 1.0)
            else:
                rate = 2.0 * x / (1.0 + x)
                drift += rate * factor * (1.0 - 2.0 ** (-degrees[v]))
        answer.append((drift, state, volume))
    return answer


def random_graph(n, rng, log_scale):
    weights = [[0.0] * n for _ in range(n)]
    for u, v in combinations(range(n), 2):
        value = math.exp(rng.uniform(-log_scale, log_scale))
        weights[u][v] = weights[v][u] = value
    return weights


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=6)
    parser.add_argument("--trials", type=int, default=10000)
    parser.add_argument("--scale", type=float, default=8.0)
    parser.add_argument("--seed", type=int, default=26080867)
    args = parser.parse_args()
    rng = Random(args.seed)
    maximum = None
    witness = None
    for _ in range(args.trials):
        weights = random_graph(args.n, rng, args.scale)
        candidate = max(residuals(weights))
        if maximum is None or candidate[0] > maximum[0]:
            maximum = candidate
            witness = weights
    print("maximum residual", maximum)
    print("weights")
    for row in witness:
        print(" ".join(f"{value:.17g}" for value in row))


if __name__ == "__main__":
    main()
