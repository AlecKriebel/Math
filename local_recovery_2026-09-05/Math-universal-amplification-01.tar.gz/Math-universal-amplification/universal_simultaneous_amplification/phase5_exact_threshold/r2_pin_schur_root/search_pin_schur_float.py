#!/usr/bin/env python3
"""Hostile floating screen for the multinomial pin-word Schur inequality.

This implementation intentionally differs from the exact discovery verifier:
it stores one full labelled active-state vector for every weak composition at
the current time and uses NumPy scatter sums for the pin operators.  It is a
discovery screen only.  Any negative margin must be reconstructed exactly by
the independent rational implementation in ``r2_determinant``.
"""

from __future__ import annotations

import argparse
from itertools import combinations

import numpy as np


def compositions(total: int, length: int):
    """Yield all weak compositions of ``total`` into ``length`` parts."""

    for bars in combinations(range(total + length - 1), length - 1):
        points = (-1,) + bars + (total + length - 1,)
        yield tuple(points[i + 1] - points[i] - 1 for i in range(length))


def states_for(n: int):
    return [
        (mask, target)
        for target in range(n)
        for mask in range(1, 1 << n)
        if not ((mask >> target) & 1)
    ]


def pin_operator(n: int, pin: int, states, index):
    """Return CSR-like row data for the exact active operator K(Q_pin)."""

    rows = []
    N = n - 1
    for mask, target in states:
        rank = mask.bit_count()
        masses: dict[int, float] = {}

        def add(out_state, mass):
            out = index[out_state]
            masses[out] = masses.get(out, 0.0) + mass

        if target == pin:
            for sampled in range(n):
                if sampled != pin:
                    add((mask | (1 << sampled), target), 1.0 / (2 * N))
        else:
            add((mask | (1 << pin), target), 0.5)

        for removed in range(n):
            if not ((mask >> removed) & 1):
                continue
            cache = mask & ~(1 << removed)
            if removed == pin:
                for sampled in range(n):
                    if sampled != pin:
                        add(
                            (cache | (1 << sampled), removed),
                            1.0 / (2 * rank * N),
                        )
            else:
                add((cache | (1 << pin), removed), 1.0 / (2 * rank))
        assert abs(sum(masses.values()) - 1.0) < 1e-12
        rows.append(
            (
                np.fromiter(masses.keys(), dtype=np.int32),
                np.fromiter(masses.values(), dtype=np.float64),
            )
        )
    return rows


def apply(rows, vector):
    return np.fromiter(
        (np.dot(mass, vector[target]) for target, mass in rows),
        dtype=np.float64,
        count=len(rows),
    )


def run(n: int, final_time: int, stop_margin: float):
    states = states_for(n)
    index = {state: i for i, state in enumerate(states)}
    operators = [pin_operator(n, pin, states, index) for pin in range(n)]
    N = n - 1
    reward = np.array([1.0 / mask.bit_count() for mask, _ in states])
    nu = np.array(
        [mask.bit_count() / (n * N * 2 ** (N - 1)) for mask, _ in states]
    )
    controls = {(0,) * n: reward}
    global_margin = float("inf")
    global_witness = None
    comparisons = 0

    for time in range(1, final_time + 1):
        previous = controls
        controls = {}
        rewards = {}
        for counts in compositions(time, n):
            value = np.zeros(len(states))
            for pin, multiplicity in enumerate(counts):
                if multiplicity:
                    predecessor = list(counts)
                    predecessor[pin] -= 1
                    value += (multiplicity / time) * apply(
                        operators[pin], previous[tuple(predecessor)]
                    )
            controls[counts] = value
            rewards[counts] = float(np.dot(nu, value))

        level_margin = float("inf")
        level_witness = None
        for base in compositions(time - 1, n):
            for i in range(n):
                for j in range(n):
                    # Equal coordinates give equality by label symmetry.  The
                    # strict comparison is the useful hostile quantity and
                    # avoids reporting roundoff-sized signed zeroes.
                    if i == j or base[i] <= base[j]:
                        continue
                    concentrated = list(base)
                    dispersed = list(base)
                    concentrated[i] += 1
                    dispersed[j] += 1
                    margin = rewards[tuple(concentrated)] - rewards[tuple(dispersed)]
                    comparisons += 1
                    if margin < level_margin:
                        level_margin = margin
                        level_witness = (base, i, j, margin)
                    if margin < global_margin:
                        global_margin = margin
                        global_witness = (time, base, i, j, margin)
        print(
            f"n={n} t={time} states={len(states)} comps={len(controls)} "
            f"min={level_margin:.17g} witness={level_witness}",
            flush=True,
        )
        if level_margin < -stop_margin:
            print(f"COUNTEREXAMPLE CANDIDATE: {global_witness}")
            return 1
    print(
        f"NO FLOATING VIOLATION: comparisons={comparisons} "
        f"global_min={global_margin:.17g} witness={global_witness}"
    )
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, required=True)
    parser.add_argument("--time", type=int, required=True)
    parser.add_argument("--stop-margin", type=float, default=1e-11)
    args = parser.parse_args()
    raise SystemExit(run(args.n, args.time, args.stop_margin))


if __name__ == "__main__":
    main()
