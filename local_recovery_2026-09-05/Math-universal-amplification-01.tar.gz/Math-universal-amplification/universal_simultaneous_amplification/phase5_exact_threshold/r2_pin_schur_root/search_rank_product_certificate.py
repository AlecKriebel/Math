#!/usr/bin/env python3
"""Search a rank-times-vertex-product dB optional-stopping certificate.

The candidate is F(S)=a_|S| product_{i in S} z_i.  We impose F(empty)=1,
F(V)=2^(1-n), the complete-graph absorbing value, and require the uniform
singleton mean to be at least (n+1)/(2n).  Nonnegative drift would therefore
prove the exact r=2 complete-graph bound.  Numerical output is discovery
only.
"""

from __future__ import annotations

import argparse

import numpy as np
from scipy.optimize import minimize

from search_product_harmonic_certificate import kernel_from_edges, random_edges


def rows_for(P: np.ndarray):
    n = len(P)
    rows = []
    for mask in range(1, (1 << n) - 1):
        inside = np.array([(mask >> i) & 1 for i in range(n)], dtype=bool)
        x = P[:, inside].sum(axis=1)
        rows.append(
            (
                inside,
                2 * x / (1 + x),
                (1 - x) / (1 + x),
                int(inside.sum()),
            )
        )
    return rows


def unpack(vector: np.ndarray, n: int):
    theta = vector[:n]
    # b_0=0.  The free block supplies b_1,...,b_(n-1); b_n is fixed by
    # the all-mutant boundary value.
    b = np.zeros(n + 1)
    b[1:n] = vector[n:]
    b[n] = (1 - n) * np.log(2.0) - theta.sum()
    return theta, b


def drift(vector: np.ndarray, rows, n: int):
    theta, b = unpack(vector, n)
    answer = []
    for inside, gain, loss, k in rows:
        add_ratio = np.exp(np.clip(b[k + 1] - b[k] + theta, -100, 100))
        remove_ratio = np.exp(np.clip(b[k - 1] - b[k] - theta, -100, 100))
        answer.append(
            np.sum(gain[~inside] * (add_ratio[~inside] - 1))
            + np.sum(loss[inside] * (remove_ratio[inside] - 1))
        )
    return np.asarray(answer)


def singleton_margin(vector: np.ndarray, n: int):
    theta, b = unpack(vector, n)
    return np.exp(b[1]) * np.exp(np.clip(theta, -100, 100)).mean() - (n + 1) / (2 * n)


def complete_start(n: int):
    theta = np.zeros(n)
    b = np.array([-k * np.log(2.0) + np.log1p(k / n) for k in range(1, n)])
    return np.r_[theta, b]


def optimize(P: np.ndarray, restarts: int, seed: int):
    n = len(P)
    rows = rows_for(P)
    rng = np.random.default_rng(seed)
    best = None
    for attempt in range(restarts):
        start = complete_start(n)
        if attempt:
            start = start + rng.normal(0, 1.5, len(start))
        x0 = np.r_[start, min(drift(start, rows, n).min(), singleton_margin(start, n))]
        constraints = [
            {"type": "ineq", "fun": lambda x, row=row: drift(x[:-1], [row], n)[0] - x[-1]}
            for row in rows
        ]
        constraints.append(
            {"type": "ineq", "fun": lambda x: singleton_margin(x[:-1], n) - x[-1]}
        )
        result = minimize(
            lambda x: -x[-1] + 1e-10 * np.dot(x[:-1], x[:-1]),
            x0,
            method="SLSQP",
            constraints=constraints,
            options={"maxiter": 5000, "ftol": 1e-12},
        )
        value = min(drift(result.x[:-1], rows, n).min(), singleton_margin(result.x[:-1], n))
        if best is None or value > best[0]:
            best = (value, result.x[:-1], result.success, result.message)
    return best


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, required=True)
    parser.add_argument("--edges")
    parser.add_argument("--random", type=int, default=0)
    parser.add_argument("--restarts", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260808)
    args = parser.parse_args()
    rng = np.random.default_rng(args.seed)
    cases = []
    if args.edges:
        cases.append([float(part) for part in args.edges.split(",")])
    cases.extend(random_edges(args.n, rng) for _ in range(args.random))
    if not cases:
        cases.append([1.0] * (args.n * (args.n - 1) // 2))
    for case, edges in enumerate(cases):
        P = kernel_from_edges(args.n, edges)
        result = optimize(P, args.restarts, args.seed + case)
        value, vector, success, message = result
        print(
            f"case={case} margin={value:.17g} success={success} "
            f"singleton={singleton_margin(vector, args.n):.17g} "
            f"min_drift={drift(vector, rows_for(P), args.n).min():.17g} "
            f"vector={vector.tolist()} message={message}",
            flush=True,
        )


if __name__ == "__main__":
    main()
