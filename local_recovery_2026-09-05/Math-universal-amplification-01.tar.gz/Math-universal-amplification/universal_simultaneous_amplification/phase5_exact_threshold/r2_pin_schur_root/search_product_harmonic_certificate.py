#!/usr/bin/env python3
"""Hostile screen for a rank-harmonic times vertex-product certificate.

For a graph of order n, test whether there are positive z_i with product one
such that

    F(S)=2^(-|S|) (1+|S|/n) product_{i in S} z_i

is a dB submartingale at fitness two.  If so, optional stopping and AM--GM
give the exact complete-graph singleton bound.  This is discovery code: a
successful numerical solve is not a universal proof, and a failed solve is
restarted before it is classified as a counterexample candidate.
"""

from __future__ import annotations

import argparse
import itertools

import numpy as np
from scipy.optimize import minimize


def kernel_from_edges(n: int, edges: list[float]) -> np.ndarray:
    matrix = np.zeros((n, n), dtype=float)
    at = 0
    for i in range(n):
        for j in range(i + 1, n):
            matrix[i, j] = matrix[j, i] = edges[at]
            at += 1
    degree = matrix.sum(axis=1)
    if np.min(degree) <= 0:
        raise ValueError("every vertex needs positive weighted degree")
    return matrix / degree[:, None]


def drift_rows(P: np.ndarray):
    n = len(P)
    rows = []
    for mask in range(1, (1 << n) - 1):
        inside = np.array([(mask >> i) & 1 for i in range(n)], dtype=bool)
        k = int(inside.sum())
        x = P[:, inside].sum(axis=1)
        gain = 2 * x / (1 + x)
        loss = (1 - x) / (1 + x)
        A = (n + k + 1) / (2 * (n + k))
        B = 2 * (n + k - 1) / (n + k)
        rows.append((inside, gain, loss, A, B))
    return rows


def margins(theta_free: np.ndarray, rows):
    theta = np.r_[theta_free, -theta_free.sum()]
    z = np.exp(np.clip(theta, -100, 100))
    answer = []
    for inside, gain, loss, A, B in rows:
        answer.append(
            np.sum(gain[~inside] * (A * z[~inside] - 1))
            + np.sum(loss[inside] * (B / z[inside] - 1))
        )
    return np.asarray(answer)


def optimize(P: np.ndarray, restarts: int, seed: int):
    rows = drift_rows(P)
    n = len(P)
    rng = np.random.default_rng(seed)
    best = None

    # Smooth minimum followed by an exact max-min SLSQP polish.
    for attempt in range(restarts):
        start = np.zeros(n - 1) if attempt == 0 else rng.normal(0, 2, n - 1)

        def soft_object(theta):
            values = margins(theta, rows)
            scale = 30.0
            floor = values.min()
            soft_min = floor - np.log(np.exp(-scale * (values - floor)).sum()) / scale
            return -soft_min + 1e-8 * np.dot(theta, theta)

        first = minimize(soft_object, start, method="BFGS", options={"maxiter": 1000})
        x0 = np.r_[first.x, margins(first.x, rows).min()]

        def objective(x):
            return -x[-1]

        constraints = [
            {
                "type": "ineq",
                "fun": lambda x, row=row: (
                    margins(x[:-1], [row])[0] - x[-1]
                ),
            }
            for row in rows
        ]
        second = minimize(
            objective,
            x0,
            method="SLSQP",
            constraints=constraints,
            options={"maxiter": 3000, "ftol": 1e-12},
        )
        value = margins(second.x[:-1], rows).min()
        candidate = (value, second.x[:-1], second.success, second.message)
        if best is None or candidate[0] > best[0]:
            best = candidate
    assert best is not None
    theta = np.r_[best[1], -best[1].sum()]
    return best[0], theta, best[2], best[3]


def parse_edges(text: str) -> list[float]:
    return [float(part) for part in text.split(",") if part]


def random_edges(n: int, rng: np.random.Generator):
    return np.exp(rng.uniform(-8, 8, n * (n - 1) // 2)).tolist()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, required=True)
    parser.add_argument("--edges")
    parser.add_argument("--random", type=int, default=0)
    parser.add_argument("--restarts", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20260808)
    args = parser.parse_args()
    rng = np.random.default_rng(args.seed)
    cases = []
    if args.edges:
        cases.append(parse_edges(args.edges))
    for _ in range(args.random):
        cases.append(random_edges(args.n, rng))
    if not cases:
        cases.append([1.0] * (args.n * (args.n - 1) // 2))
    for case, edges in enumerate(cases):
        P = kernel_from_edges(args.n, edges)
        value, theta, success, message = optimize(
            P, args.restarts, args.seed + case
        )
        print(
            f"case={case} min_drift={value:.17g} success={success} "
            f"theta={theta.tolist()} message={message}",
            flush=True,
        )


if __name__ == "__main__":
    main()
