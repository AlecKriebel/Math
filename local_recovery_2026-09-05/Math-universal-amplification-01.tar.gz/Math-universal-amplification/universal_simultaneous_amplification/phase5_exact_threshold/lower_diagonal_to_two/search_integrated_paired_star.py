#!/usr/bin/env python3
"""Integrated-core response of a growing paired-star gadget.

The gadget is a central pair a--h and L peripheral pairs x_j--y_j, with
h--x_j spokes.  Every orbit has its own portal load to every large-core
vertex.  Core marks and recoveries remain active in every polymorphic gadget
state.  The reported M5 response includes all gadget/core singleton and
far-field terms.  Floating optimization is discovery only.
"""
from __future__ import annotations
import argparse,math
import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

TYPES=((0,0),(1,0),(0,1),(1,1))
def states(L):
 return [(a,h,u,v,z) for a in (0,1) for h in (0,1) for u in range(L+1) for v in range(L-u+1) for z in range(L-u-v+1) if (a,h,u,v,z)!=(0,0,0,0,0)]
def counts(L,q):
 a,h,u,v,z=q;return [L-u-v-z,u,v,z]
def move(q,s,t):
 a,h,u,v,z=q;c=[None,u,v,z]
 if s:c[s]-=1
 if t:c[t]+=1
 return (a,h,c[1],c[2],c[3])

def local(L,r,rule,A,C,W,portal):
 sts=states(L);ix={q:i for i,q in enumerate(sts)};ro=[];co=[];da=[];rhs=np.zeros(len(sts));p=1-1/r
 xa,xh,xx,xy=portal;deg=(A+xa,A+L*C+xh,C+W+xx,W+xy)
 for q,row in ix.items():
  a,h,*_=q;cc=counts(L,q);mx=cc[1]+cc[3];my=cc[2]+cc[3];o={}
  def add(t,x):
   if x>0:o[t]=o.get(t,0)+x
  if rule=='Bd':
   if a!=h:
    add((a,a,*q[2:]),(r if a else 1)*A/deg[0]);add((h,h,*q[2:]),(r if h else 1)*A/deg[1])
   for typ,m in enumerate(cc):
    if not m:continue
    x,y=TYPES[typ]
    if h!=x:
     add(move(q,typ,TYPES.index((h,y))),m*(r if h else 1)*C/deg[1])
     add((a,x,*q[2:]),m*(r if x else 1)*C/deg[2])
    if x!=y:
     add(move(q,typ,TYPES.index((x,x))),m*(r if x else 1)*W/deg[2])
     add(move(q,typ,TYPES.index((y,y))),m*(r if y else 1)*W/deg[3])
   if a:add((0,h,*q[2:]),xa)
   if h:add((a,0,*q[2:]),xh)
   for typ,m in enumerate(cc):
    if not m:continue
    x,y=TYPES[typ]
    if x:add(move(q,typ,TYPES.index((0,y))),m*xx)
    if y:add(move(q,typ,TYPES.index((x,0))),m*xy)
   mark=r*p*(a*xa/deg[0]+h*xh/deg[1]+mx*xx/deg[2]+my*xy/deg[3])
  else:
   fa=r if a else 1;fh=r if h else 1
   den=portal[0]+(r if h else 1)*A
   if a!=h:add((h,h,*q[2:]),(r if h else 1)*A/den)
   if a:add((0,h,*q[2:]),xa/den)
   den=portal[1]+fa*A+C*sum(cc[t]*(r if TYPES[t][0] else 1) for t in range(4))
   if a!=h:add((a,a,*q[2:]),fa*A/den)
   if not h and mx:add((a,1,*q[2:]),r*C*mx/den)
   if h and L-mx:add((a,0,*q[2:]),C*(L-mx)/den)
   if h:add((a,0,*q[2:]),xh/den)
   for typ,m in enumerate(cc):
    if not m:continue
    x,y=TYPES[typ];denx=xx+(r if h else 1)*C+(r if y else 1)*W
    if x!=h:add(move(q,typ,TYPES.index((h,y))),m*(r if h else 1)*C/denx)
    if x!=y:add(move(q,typ,TYPES.index((y,y))),m*(r if y else 1)*W/denx)
    if x:add(move(q,typ,TYPES.index((0,y))),m*xx/denx)
    deny=xy+(r if x else 1)*W
    if x!=y:add(move(q,typ,TYPES.index((x,x))),m*(r if x else 1)*W/deny)
    if y:add(move(q,typ,TYPES.index((x,0))),m*xy/deny)
   mark=r*p*(a*xa+h*xh+mx*xx+my*xy)
  total=mark+sum(o.values());ro.append(row);co.append(row);da.append(total);rhs[row]=mark
  for t,x in o.items():
   if t!=(0,0,0,0,0):ro.append(row);co.append(ix[t]);da.append(-x)
 M=coo_matrix((da,(ro,co)),shape=(len(sts),)*2).tocsr();v=spsolve(M,rhs)
 if np.max(np.abs(M@v-rhs))>2e-7:raise FloatingPointError
 return np.array([v[ix[(1,0,0,0,0)]],v[ix[(0,1,0,0,0)]],v[ix[(0,0,1,0,0)]],v[ix[(0,0,0,1,0)]]])

def score(L,r,v):
 A,C,W,*portal=np.exp(v);portal=np.array(portal);mult=np.array([1.,1.,L,L]);s=2+2*L;p=1-1/r;deg=np.array([A+portal[0],A+L*C+portal[1],C+W+portal[2],W+portal[3]])
 ub=local(L,r,'Bd',A,C,W,portal);ud=local(L,r,'dB',A,C,W,portal)
 sb=r*(mult*portal)@ub-(r-1)*np.sum(mult*portal/deg)
 sd=r*(mult*portal/deg)@ud-(r-1)*(mult@portal+r-1)
 B=mult@ub/p-s+sb/(r-1)**2;D=mult@ud/p-s+1+sd/(r-1)**2
 lam=max(0.,(r-1)/r*(D-B));balanced=min(B+lam/(r-1),D-lam)
 return balanced,B,D,lam,(A,C,W),portal,ub,ud

def main():
 a=argparse.ArgumentParser();a.add_argument('--pairs',type=int,default=3);a.add_argument('--fitness',type=float,default=1.9);a.add_argument('--maxiter',type=int,default=160);x=a.parse_args()
 def obj(v):
  try:return -score(x.pairs,x.fitness,v)[0]
  except Exception:return 1e6
 o=differential_evolution(obj,[(-14,14)]*7,seed=20260808,maxiter=x.maxiter,popsize=10,tol=1e-9,polish=True)
 q=score(x.pairs,x.fitness,o.x);print({'L':x.pairs,'r':x.fitness,'balanced':q[0],'B':q[1],'D':q[2],'lambda':q[3],'edges':q[4],'portal':q[5].tolist(),'uB':q[6].tolist(),'uD':q[7].tolist()})
if __name__=='__main__':main()
