#!/usr/bin/env python3
"""Discovery screen for growing-rank integrated K_{a,b} modules.

The exact two-count local chain retains core recovery and successful core
marks in every polymorphic module state.  The reported response is the full
M5 tangent, including uniform starts and the far-field singleton term.
Floating optimization is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def local_success(
    a: int,
    b: int,
    fitness: float,
    rule: str,
    edge: float,
    portal_a: float,
    portal_b: float,
) -> tuple[float, float]:
    empty = (0, 0)
    states = [(i, j) for i in range(a + 1) for j in range(b + 1) if (i, j) != empty]
    index = {state: row for row, state in enumerate(states)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))
    degree_a = b * edge + portal_a
    degree_b = a * edge + portal_b
    p = 1 - 1 / fitness

    for state, row in index.items():
        i, j = state
        moves: dict[tuple[int, int], float] = {}

        def add(target: tuple[int, int], rate: float) -> None:
            if rate > 0:
                moves[target] = moves.get(target, 0.0) + rate

        if rule == "Bd":
            if i < a and j:
                add((i + 1, j), (a - i) * fitness * j * edge / degree_b)
            if i and j < b:
                add((i - 1, j), i * (b - j) * edge / degree_b)
            if j < b and i:
                add((i, j + 1), (b - j) * fitness * i * edge / degree_a)
            if j and i < a:
                add((i, j - 1), j * (a - i) * edge / degree_a)
            if i:
                add((i - 1, j), i * portal_a)
            if j:
                add((i, j - 1), j * portal_b)
            mark = fitness * p * (
                i * portal_a / degree_a + j * portal_b / degree_b
            )
        elif rule == "dB":
            denominator_a = fitness * j * edge + (b - j) * edge + portal_a
            if i < a and j:
                add((i + 1, j), (a - i) * fitness * j * edge / denominator_a)
            if i:
                add(
                    (i - 1, j),
                    i * ((b - j) * edge + portal_a) / denominator_a,
                )
            denominator_b = fitness * i * edge + (a - i) * edge + portal_b
            if j < b and i:
                add((i, j + 1), (b - j) * fitness * i * edge / denominator_b)
            if j:
                add(
                    (i, j - 1),
                    j * ((a - i) * edge + portal_b) / denominator_b,
                )
            mark = fitness * p * (i * portal_a + j * portal_b)
        else:
            raise ValueError(rule)

        total = mark + sum(moves.values())
        if total <= 0:
            raise ArithmeticError((state, rule))
        rows.append(row)
        columns.append(row)
        entries.append(total)
        rhs[row] = mark
        for target, rate in moves.items():
            if target != empty:
                rows.append(row)
                columns.append(index[target])
                entries.append(-rate)

    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(states), len(states))
    ).tocsr()
    solution = spsolve(matrix, rhs)
    if np.max(np.abs(matrix @ solution - rhs)) > 2e-7:
        raise FloatingPointError
    return float(solution[index[(1, 0)]]), float(solution[index[(0, 1)]])


def response(
    a: int,
    b: int,
    fitness: float,
    edge: float,
    portal_a: float,
    portal_b: float,
) -> tuple[float, ...]:
    p = 1 - 1 / fitness
    degree_a = b * edge + portal_a
    degree_b = a * edge + portal_b
    ub_a, ub_b = local_success(a, b, fitness, "Bd", edge, portal_a, portal_b)
    ud_a, ud_b = local_success(a, b, fitness, "dB", edge, portal_a, portal_b)
    source_b = fitness * (a * portal_a * ub_a + b * portal_b * ub_b)
    source_b -= (fitness - 1) * (
        a * portal_a / degree_a + b * portal_b / degree_b
    )
    source_d = fitness * (
        a * portal_a * ud_a / degree_a + b * portal_b * ud_b / degree_b
    )
    source_d -= (fitness - 1) * (
        a * portal_a + b * portal_b + fitness - 1
    )
    order = a + b
    bd = (a * ub_a + b * ub_b) / p - order
    bd += source_b / (fitness - 1) ** 2
    db = (a * ud_a + b * ud_b) / p - order + 1
    db += source_d / (fitness - 1) ** 2
    separator = db + (fitness - 1) * bd
    leaf_density = max(0.0, (fitness - 1) * (db - bd) / fitness)
    balanced = min(bd + leaf_density / (fitness - 1), db - leaf_density)
    return separator, balanced, bd, db, leaf_density, ub_a, ub_b, ud_a, ud_b


def optimize(a: int, b: int, fitness: float, maxiter: int, span: float) -> dict[str, float]:
    def objective(parameters: np.ndarray) -> float:
        try:
            values = response(
                a,
                b,
                fitness,
                *(math.exp(float(value)) for value in parameters),
            )
            return -values[0]
        except (ArithmeticError, FloatingPointError):
            return 1e9

    result = differential_evolution(
        objective,
        [(-span, span)] * 3,
        seed=20260808 + 101 * a + b,
        maxiter=maxiter,
        popsize=12,
        polish=True,
        tol=1e-10,
    )
    edge, portal_a, portal_b = (math.exp(float(value)) for value in result.x)
    values = response(a, b, fitness, edge, portal_a, portal_b)
    return {
        "a": a,
        "b": b,
        "fitness": fitness,
        "edge": edge,
        "portal_a": portal_a,
        "portal_b": portal_b,
        "separator": values[0],
        "balanced": values[1],
        "Bd": values[2],
        "dB": values[3],
        "leaf_density": values[4],
        "uBd_a": values[5],
        "uBd_b": values[6],
        "udB_a": values[7],
        "udB_b": values[8],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--a", type=int, default=4)
    parser.add_argument("--b", type=int, default=12)
    parser.add_argument("--fitness", type=float, default=1.9)
    parser.add_argument("--maxiter", type=int, default=100)
    parser.add_argument("--span", type=float, default=20.0)
    args = parser.parse_args()
    print(optimize(args.a, args.b, args.fitness, args.maxiter, args.span))


if __name__ == "__main__":
    main()
