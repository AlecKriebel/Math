#!/usr/bin/env python3
"""Exact orbit search for exchangeable triggers and one-sided K2 reservoirs.

Q trigger vertices form a weighted clique.  Each of S ordered pairs (P,S)
has internal weight W, and only P joins every trigger with weight one.  The
pair is therefore still exposed to trigger events while discordant.
"""
from __future__ import annotations
import argparse,math
import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

BITS=((0,0),(1,0),(0,1),(1,1))

def states(Q,S):
 return [(p,a,b,c) for p in range(Q+1) for a in range(S+1) for b in range(S-a+1) for c in range(S-a-b+1)]

def trans(q,Q,S,r,rule,aa,W):
 p,np_,ns,n2=q;n0=S-np_-ns-n2;cnt=[n0,np_,ns,n2];out={};dp=(Q-1)*aa+S;dP=W+Q
 def add(t,x):
  if x>0:out[t]=out.get(t,0)+x
 def leaf(k,P=None,T=None):
  x,y=BITS[k];x=x if P is None else P;y=y if T is None else T
  cc=cnt.copy();cc[k]-=1;cc[BITS.index((x,y))]+=1
  return (p,cc[1],cc[2],cc[3])
 if rule=='Bd':
  if p<Q:add((p+1,np_,ns,n2),r*(Q-p)*(p*aa/dp+(np_+n2)/dP))
  if p:add((p-1,np_,ns,n2),p*((Q-p)*aa/dp+(n0+ns)/dP))
  for k,m in enumerate(cnt):
   if not m:continue
   P,T=BITS[k]
   if P!=T:
    if P:
     add(leaf(k,T=1),m*r*W/dP);add(leaf(k,P=0),m)
    else:
     add(leaf(k,T=0),m*W/dP);add(leaf(k,P=1),m*r)
   if P==0 and p:add(leaf(k,P=1),m*r*p/dp)
   elif P==1 and p<Q:add(leaf(k,P=0),m*(Q-p)/dp)
 else:
  if p<Q:
   mm=p*aa+np_+n2;rr=(Q-p-1)*aa+n0+ns
   if mm:add((p+1,np_,ns,n2),(Q-p)*r*mm/(r*mm+rr))
  if p:
   mm=(p-1)*aa+np_+n2;rr=(Q-p)*aa+n0+ns
   if rr:add((p-1,np_,ns,n2),p*rr/(r*mm+rr))
  for k,m in enumerate(cnt):
   if not m:continue
   P,T=BITS[k];mm=r*(W*T+p);rr=W*(1-T)+(Q-p);z=mm+rr
   if P==0 and mm:add(leaf(k,P=1),m*mm/z)
   elif P==1 and rr:add(leaf(k,P=0),m*rr/z)
   if P!=T:add(leaf(k,T=P),m)
 return out

def fix(Q,S,r,rule,aa,W):
 zero=(0,0,0,0);full=(Q,0,0,S);sts=[q for q in states(Q,S) if q not in (zero,full)];ix={q:i for i,q in enumerate(sts)}
 ro=[];co=[];da=[];rhs=np.zeros(len(sts))
 for q,i in ix.items():
  o=trans(q,Q,S,r,rule,aa,W);z=sum(o.values());ro.append(i);co.append(i);da.append(z)
  for t,x in o.items():
   if t==full:rhs[i]+=x
   elif t!=zero:ro.append(i);co.append(ix[t]);da.append(-x)
 A=coo_matrix((da,(ro,co)),shape=(len(sts),)*2).tocsr();v=spsolve(A,rhs)
 if np.max(np.abs(A@v-rhs))>3e-7:raise FloatingPointError
 return float((Q*v[ix[(1,0,0,0)]]+S*(v[ix[(0,1,0,0)]]+v[ix[(0,0,1,0)]]))/(Q+2*S))

def base(n,r,u):return (1-1/r)/(1-r**(-n)) if u=='Bd' else (1-1/r)*(n-1)/(n*(1-r**(1-n)))
def main():
 a=argparse.ArgumentParser();a.add_argument('--portals',type=int,default=2);a.add_argument('--pairs',type=int,default=8);a.add_argument('--fitness',type=float,default=1.9);a.add_argument('--maxiter',type=int,default=100);x=a.parse_args();n=x.portals+2*x.pairs
 def val(z):
  aa,W=np.exp(z);bd=fix(x.portals,x.pairs,x.fitness,'Bd',aa,W);db=fix(x.portals,x.pairs,x.fitness,'dB',aa,W)
  return bd/base(n,x.fitness,'Bd'),db/base(n,x.fitness,'dB'),bd,db
 o=differential_evolution(lambda z:-min(val(z)[:2]),[(-15,15)]*2,seed=20260808,maxiter=x.maxiter,popsize=15,tol=1e-10,polish=True)
 print({'Q':x.portals,'S':x.pairs,'r':x.fitness,'aa':math.exp(float(o.x[0])),'W':math.exp(float(o.x[1])),'values':val(o.x)})
if __name__=='__main__':main()
