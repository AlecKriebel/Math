#!/usr/bin/env python3
"""Discovery search for a singular three-layer Bd catalyst.

Layer sizes are (1,k,k^2).  Complete bipartite edges 0--1 and 1--2 have
weights c01/k and c12/k^2, so the bulk layer is an asymptotic portal clone
while the two vanishing gateway layers retain O(1) loads.  Core portals stay
active throughout the exact three-count local trace.  Floating output is
discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def local_success(
    sizes: tuple[int, int, int],
    edges: np.ndarray,
    portal: np.ndarray,
    fitness: float,
    rule: str,
) -> np.ndarray:
    states = [
        (i, j, ell)
        for i in range(sizes[0] + 1)
        for j in range(sizes[1] + 1)
        for ell in range(sizes[2] + 1)
        if (i, j, ell) != (0, 0, 0)
    ]
    index = {state: row for row, state in enumerate(states)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))
    degrees = portal + edges @ np.array(sizes, dtype=float)
    p = 1 - 1 / fitness

    for state, row in index.items():
        mutant = np.array(state, dtype=int)
        resident = np.array(sizes, dtype=int) - mutant
        moves: dict[tuple[int, int, int], float] = {}

        def add(layer: int, step: int, rate: float) -> None:
            if rate <= 0:
                return
            target = list(state)
            target[layer] += step
            key = tuple(target)
            moves[key] = moves.get(key, 0.0) + rate

        if rule == "Bd":
            for target in range(3):
                growth = fitness * resident[target] * sum(
                    mutant[source] * edges[source, target] / degrees[source]
                    for source in range(3)
                )
                loss = mutant[target] * sum(
                    resident[source] * edges[source, target] / degrees[source]
                    for source in range(3)
                )
                add(target, 1, growth)
                add(target, -1, loss + mutant[target] * portal[target])
            mark = fitness * p * float(np.sum(mutant * portal / degrees))
        elif rule == "dB":
            for target in range(3):
                mutant_mass = fitness * sum(
                    mutant[source] * edges[source, target] for source in range(3)
                )
                resident_mass = portal[target] + sum(
                    resident[source] * edges[source, target] for source in range(3)
                )
                denominator = mutant_mass + resident_mass
                if denominator <= 0:
                    raise ArithmeticError((state, target))
                add(target, 1, resident[target] * mutant_mass / denominator)
                add(target, -1, mutant[target] * resident_mass / denominator)
            mark = fitness * p * float(np.sum(mutant * portal))
        else:
            raise ValueError(rule)

        total = mark + sum(moves.values())
        rows.append(row)
        columns.append(row)
        entries.append(total)
        rhs[row] = mark
        for target, rate in moves.items():
            if target != (0, 0, 0):
                rows.append(row)
                columns.append(index[target])
                entries.append(-rate)

    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(states), len(states))
    ).tocsr()
    solution = spsolve(matrix, rhs)
    residual = float(np.max(np.abs(matrix @ solution - rhs)))
    if residual > 2e-7:
        raise FloatingPointError(residual)
    singleton = []
    for layer in range(3):
        state = [0, 0, 0]
        state[layer] = 1
        singleton.append(solution[index[tuple(state)]])
    return np.array(singleton)


def response(k: int, fitness: float, parameters: np.ndarray) -> tuple[float, ...]:
    c01, c12, x0, x1, x2 = np.exp(parameters)
    sizes = (1, k, k * k)
    edges = np.zeros((3, 3))
    edges[0, 1] = edges[1, 0] = c01 / k
    edges[1, 2] = edges[2, 1] = c12 / (k * k)
    portal = np.array([x0, x1, x2])
    degrees = portal + edges @ np.array(sizes, dtype=float)
    multiplicity = np.array(sizes, dtype=float)
    p = 1 - 1 / fitness
    ub = local_success(sizes, edges, portal, fitness, "Bd")
    ud = local_success(sizes, edges, portal, fitness, "dB")
    source_b = fitness * float((multiplicity * portal) @ ub)
    source_b -= (fitness - 1) * float(np.sum(multiplicity * portal / degrees))
    source_d = fitness * float((multiplicity * portal / degrees) @ ud)
    source_d -= (fitness - 1) * (
        float(multiplicity @ portal) + fitness - 1
    )
    order = sum(sizes)
    bd = float(multiplicity @ ub) / p - order
    bd += source_b / (fitness - 1) ** 2
    db = float(multiplicity @ ud) / p - order + 1
    db += source_d / (fitness - 1) ** 2
    return bd, db, db + (fitness - 1) * bd, c01, c12, x0, x1, x2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rank", type=int, default=5)
    parser.add_argument("--fitness", type=float, default=2.0)
    parser.add_argument("--maxiter", type=int, default=80)
    parser.add_argument("--objective", choices=("separator", "ray"), default="ray")
    args = parser.parse_args()

    def objective(parameters: np.ndarray) -> float:
        try:
            bd, db, separator, *_ = response(args.rank, args.fitness, parameters)
            if args.objective == "separator":
                return -separator
            return -(bd + 0.1 * db) + 1e3 * max(0.0, -bd) ** 2
        except (ArithmeticError, FloatingPointError):
            return 1e9

    result = differential_evolution(
        objective,
        [(-8, 8)] * 5,
        seed=20260808 + args.rank,
        maxiter=args.maxiter,
        popsize=10,
        tol=1e-9,
        polish=True,
    )
    values = response(args.rank, args.fitness, result.x)
    print(
        {
            "rank": args.rank,
            "fitness": args.fitness,
            "objective": args.objective,
            "Bd": values[0],
            "dB": values[1],
            "separator": values[2],
            "cost_ratio": -values[1] / values[0] if values[0] > 0 else None,
            "c01": values[3],
            "c12": values[4],
            "portal": values[5:],
        }
    )


if __name__ == "__main__":
    main()
