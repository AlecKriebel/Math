#!/usr/bin/env python3
"""Discovery screen for a nonseparated portal--pair population.

There are Q exchangeable portals forming a weighted clique and S
exchangeable K2 blades.  Every portal is joined to every blade vertex.
Portal events remain active while a pair is discordant.  The exact orbit
state is (p,u,v): mutant portals, mixed pairs, and mutant pairs.

Floating optimization is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def fixation(Q: int, S: int, r: float, rule: str, aa: float, b: float, w: float) -> float:
    empty = (0, 0, 0)
    full = (Q, 0, S)
    states = [
        (p, u, v)
        for p in range(Q + 1)
        for v in range(S + 1)
        for u in range(S - v + 1)
        if (p, u, v) not in (empty, full)
    ]
    index = {state: row for row, state in enumerate(states)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))
    d_portal = (Q - 1) * aa + 2 * S * b
    d_blade = w + Q * b

    for state, row in index.items():
        p, u, v = state
        n00 = S - u - v
        mutant_blades = u + 2 * v
        resident_blades = 2 * S - mutant_blades
        moves: dict[tuple[int, int, int], float] = {}

        def add(target: tuple[int, int, int], rate: float) -> None:
            if rate > 0:
                moves[target] = moves.get(target, 0.0) + rate

        if rule == "Bd":
            if p < Q:
                incoming = p * aa / d_portal + mutant_blades * b / d_blade
                add((p + 1, u, v), r * (Q - p) * incoming)
            if p:
                incoming = (Q - p) * aa / d_portal + resident_blades * b / d_blade
                add((p - 1, u, v), p * incoming)
            if n00 and p:
                add((p, u + 1, v), 2 * n00 * r * p * b / d_portal)
            if u:
                add((p, u - 1, v + 1), u * r * (w / d_blade + p * b / d_portal))
                add(
                    (p, u - 1, v),
                    u * (w / d_blade + (Q - p) * b / d_portal),
                )
            if v and p < Q:
                add((p, u + 1, v - 1), 2 * v * (Q - p) * b / d_portal)
        elif rule == "dB":
            if p < Q:
                mutant_mass = p * aa + mutant_blades * b
                resident_mass = (Q - p - 1) * aa + resident_blades * b
                if mutant_mass:
                    add(
                        (p + 1, u, v),
                        (Q - p) * r * mutant_mass / (r * mutant_mass + resident_mass),
                    )
            if p:
                mutant_mass = (p - 1) * aa + mutant_blades * b
                resident_mass = (Q - p) * aa + resident_blades * b
                if resident_mass:
                    add(
                        (p - 1, u, v),
                        p * resident_mass / (r * mutant_mass + resident_mass),
                    )
            if n00 and p:
                add(
                    (p, u + 1, v),
                    2 * n00 * r * p * b / (r * p * b + (Q - p) * b + w),
                )
            if u:
                add(
                    (p, u - 1, v + 1),
                    u * r * (w + p * b) / (r * (w + p * b) + (Q - p) * b),
                )
                add(
                    (p, u - 1, v),
                    u * (w + (Q - p) * b) / (r * p * b + w + (Q - p) * b),
                )
            if v and p < Q:
                add(
                    (p, u + 1, v - 1),
                    2 * v * (Q - p) * b / (r * (w + p * b) + (Q - p) * b),
                )
        else:
            raise ValueError(rule)

        total = sum(moves.values())
        if total <= 0:
            raise ArithmeticError((state, rule))
        rows.append(row)
        columns.append(row)
        entries.append(total)
        for target, rate in moves.items():
            if target == full:
                rhs[row] += rate
            elif target != empty:
                rows.append(row)
                columns.append(index[target])
                entries.append(-rate)

    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(states), len(states))
    ).tocsr()
    harmonic = spsolve(matrix, rhs)
    residual = float(np.max(np.abs(matrix @ harmonic - rhs)))
    if residual > 1e-7:
        raise FloatingPointError(residual)
    singleton_sum = Q * harmonic[index[(1, 0, 0)]]
    singleton_sum += 2 * S * harmonic[index[(0, 1, 0)]]
    return float(singleton_sum / (Q + 2 * S))


def baselines(n: int, r: float) -> tuple[float, float]:
    bd = (1 - 1 / r) / (1 - r ** (-n))
    db = (1 - 1 / r) * (n - 1) / (n * (1 - r ** (1 - n)))
    return bd, db


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--portals", type=int, default=3)
    parser.add_argument("--pairs", type=int, default=12)
    parser.add_argument("--fitness", type=float, default=1.9)
    parser.add_argument("--maxiter", type=int, default=160)
    args = parser.parse_args()
    n = args.portals + 2 * args.pairs
    base_b, base_d = baselines(n, args.fitness)

    def score(parameters: np.ndarray) -> tuple[float, float, float, float]:
        aa, w = np.exp(parameters)
        bd = fixation(args.portals, args.pairs, args.fitness, "Bd", aa, 1.0, w)
        db = fixation(args.portals, args.pairs, args.fitness, "dB", aa, 1.0, w)
        return bd / base_b, db / base_d, bd, db

    def objective(parameters: np.ndarray) -> float:
        try:
            return -min(score(parameters)[:2])
        except (ArithmeticError, FloatingPointError):
            return 1e6

    result = differential_evolution(
        objective,
        [(-15, 15), (-15, 15)],
        seed=20260808,
        maxiter=args.maxiter,
        popsize=15,
        tol=1e-10,
        polish=True,
    )
    print(
        {
            "portals": args.portals,
            "pairs": args.pairs,
            "fitness": args.fitness,
            "portal_edge": math.exp(float(result.x[0])),
            "blade_edge": math.exp(float(result.x[1])),
            "score": score(result.x),
            "success": bool(result.success),
        }
    )


if __name__ == "__main__":
    main()
