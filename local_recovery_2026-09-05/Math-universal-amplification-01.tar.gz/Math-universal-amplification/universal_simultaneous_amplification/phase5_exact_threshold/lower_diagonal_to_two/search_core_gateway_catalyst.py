#!/usr/bin/env python3
"""Discovery screen for an o(n) dense gateway attached to a complete core.

The graph has a C-clique and k independent gateway twins, each joined to
every core vertex with weight w.  The exact state is (mutant core count,
mutant gateway count).  This tests core-start effects outside the dilute
uniform-portal M5 normal form.  Floating output is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def fixation(
    core: int,
    gateway: int,
    fitness: float,
    rule: str,
    weight: float,
    gateway_edge: float = 0.0,
) -> float:
    empty = (0, 0)
    full = (core, gateway)
    states = [
        (i, j)
        for i in range(core + 1)
        for j in range(gateway + 1)
        if (i, j) not in (empty, full)
    ]
    index = {state: row for row, state in enumerate(states)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))
    degree_core = core - 1 + gateway * weight
    degree_gateway = core * weight + (gateway - 1) * gateway_edge

    for state, row in index.items():
        i, j = state
        moves: dict[tuple[int, int], float] = {}

        def add(target: tuple[int, int], rate: float) -> None:
            if rate > 0:
                moves[target] = moves.get(target, 0.0) + rate

        if rule == "Bd":
            if i < core:
                add(
                    (i + 1, j),
                    fitness
                    * (core - i)
                    * (i / degree_core + j * weight / degree_gateway),
                )
            if i:
                add(
                    (i - 1, j),
                    i
                    * ((core - i) / degree_core
                       + (gateway - j) * weight / degree_gateway),
                )
            if j < gateway and (i or j):
                add(
                    (i, j + 1),
                    fitness
                    * (gateway - j)
                    * (i * weight / degree_core + j * gateway_edge / degree_gateway),
                )
            if j:
                add(
                    (i, j - 1),
                    j
                    * ((core - i) * weight / degree_core
                       + (gateway - j) * gateway_edge / degree_gateway),
                )
        elif rule == "dB":
            if i < core:
                mutant_mass = i + j * weight
                resident_mass = core - i - 1 + (gateway - j) * weight
                add(
                    (i + 1, j),
                    (core - i)
                    * fitness
                    * mutant_mass
                    / (fitness * mutant_mass + resident_mass),
                )
            if i:
                mutant_mass = i - 1 + j * weight
                resident_mass = core - i + (gateway - j) * weight
                add(
                    (i - 1, j),
                    i * resident_mass / (fitness * mutant_mass + resident_mass),
                )
            if j < gateway and (i or j):
                mutant_mass = i * weight + j * gateway_edge
                resident_mass = (core - i) * weight
                resident_mass += (gateway - j - 1) * gateway_edge
                add(
                    (i, j + 1),
                    (gateway - j)
                    * fitness
                    * mutant_mass
                    / (fitness * mutant_mass + resident_mass),
                )
            if j:
                mutant_mass = i * weight + (j - 1) * gateway_edge
                resident_mass = (core - i) * weight
                resident_mass += (gateway - j) * gateway_edge
                add(
                    (i, j - 1),
                    j * resident_mass / (fitness * mutant_mass + resident_mass),
                )
        else:
            raise ValueError(rule)

        total = sum(moves.values())
        rows.append(row)
        columns.append(row)
        entries.append(total)
        for target, rate in moves.items():
            if target == full:
                rhs[row] += rate
            elif target != empty:
                rows.append(row)
                columns.append(index[target])
                entries.append(-rate)

    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(states), len(states))
    ).tocsr()
    solution = spsolve(matrix, rhs)
    if np.max(np.abs(matrix @ solution - rhs)) > 2e-7:
        raise FloatingPointError
    singleton_sum = core * solution[index[(1, 0)]]
    singleton_sum += gateway * solution[index[(0, 1)]]
    return float(singleton_sum / (core + gateway))


def baseline(size: int, fitness: float, rule: str) -> float:
    if rule == "Bd":
        return (1 - 1 / fitness) / (1 - fitness ** (-size))
    return (
        (1 - 1 / fitness)
        * (size - 1)
        / (size * (1 - fitness ** (1 - size)))
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", type=int, default=100)
    parser.add_argument("--gateway", type=int, default=10)
    parser.add_argument("--fitness", type=float, default=1.99)
    parser.add_argument("--gateway-edge", type=float, default=0.0)
    args = parser.parse_args()
    size = args.core + args.gateway
    base_b = baseline(size, args.fitness, "Bd")
    base_d = baseline(size, args.fitness, "dB")
    for log_weight in np.linspace(-10, 10, 81):
        weight = math.exp(float(log_weight))
        bd = fixation(
            args.core,
            args.gateway,
            args.fitness,
            "Bd",
            weight,
            args.gateway_edge,
        )
        db = fixation(
            args.core,
            args.gateway,
            args.fitness,
            "dB",
            weight,
            args.gateway_edge,
        )
        print(log_weight, weight, bd / base_b, db / base_d, flush=True)


if __name__ == "__main__":
    main()
