#!/usr/bin/env python3
"""Exact-orbit discovery for a one-sided paired star.

The hub H has a twin T of internal weight A.  Each of L leaves is an
ordered pair (P,S) of internal weight W, and H--P has weight C.  Thus a
portal P remains coupled to H while its pair is discordant.  The orbit state
records H,T and the counts of P-only, S-only, and full mutant leaf pairs.

Floating optimization is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


State = tuple[int, int, int, int, int]


def states(L: int) -> list[State]:
    return [
        (h, t, np_, ns, n2)
        for h in (0, 1)
        for t in (0, 1)
        for np_ in range(L + 1)
        for ns in range(L - np_ + 1)
        for n2 in range(L - np_ - ns + 1)
    ]


def moves(
    state: State, L: int, r: float, rule: str, A: float, C: float, W: float
) -> dict[State, float]:
    h, t, np_, ns, n2 = state
    n0 = L - np_ - ns - n2
    counts = [n0, np_, ns, n2]
    # category bits are (portal, shield)
    bits = [(0, 0), (1, 0), (0, 1), (1, 1)]
    out: dict[State, float] = {}

    def add(target: State, rate: float) -> None:
        if rate > 0:
            out[target] = out.get(target, 0.0) + rate

    def leaf_target(category: int, portal: int | None = None, shield: int | None = None) -> State:
        p0, s0 = bits[category]
        p1 = p0 if portal is None else portal
        s1 = s0 if shield is None else shield
        target_category = bits.index((p1, s1))
        new_counts = counts.copy()
        new_counts[category] -= 1
        new_counts[target_category] += 1
        return (h, t, new_counts[1], new_counts[2], new_counts[3])

    d_h = A + L * C
    d_t = A
    d_p = W + C
    d_s = W
    fit = lambda x: r if x else 1.0

    if rule == "Bd":
        # Hub--twin internal edge.
        if h != t:
            if h:
                add((h, h, np_, ns, n2), r * A / d_h)
                add((t, t, np_, ns, n2), A / d_t)
            else:
                add((h, h, np_, ns, n2), A / d_h)
                add((t, t, np_, ns, n2), r * A / d_t)

        # Leaf internal and hub--portal cross edges.
        for category, multiplicity in enumerate(counts):
            if not multiplicity:
                continue
            p, s = bits[category]
            if p != s:
                if p:
                    add(leaf_target(category, shield=1), multiplicity * r * W / d_p)
                    add(leaf_target(category, portal=0), multiplicity * W / d_s)
                else:
                    add(leaf_target(category, shield=0), multiplicity * W / d_p)
                    add(leaf_target(category, portal=1), multiplicity * r * W / d_s)
            if h != p:
                if h:
                    add(leaf_target(category, portal=1), multiplicity * r * C / d_h)
                    add((p, t, np_, ns, n2), multiplicity * C / d_p)
                else:
                    add(leaf_target(category, portal=0), multiplicity * C / d_h)
                    add((p, t, np_, ns, n2), multiplicity * r * C / d_p)

    elif rule == "dB":
        # Death at H and T.
        mutant_mass = r * (A * t + C * (np_ + n2))
        resident_mass = A * (1 - t) + C * (n0 + ns)
        denom = mutant_mass + resident_mass
        if h == 0 and mutant_mass:
            add((1, t, np_, ns, n2), mutant_mass / denom)
        elif h == 1 and resident_mass:
            add((0, t, np_, ns, n2), resident_mass / denom)
        if t != h:
            add((h, h, np_, ns, n2), 1.0)  # T has only H as neighbor.

        # Death at a leaf portal or shield.
        for category, multiplicity in enumerate(counts):
            if not multiplicity:
                continue
            p, s = bits[category]
            mutant_mass = r * (W * s + C * h)
            resident_mass = W * (1 - s) + C * (1 - h)
            denom = mutant_mass + resident_mass
            if p == 0 and mutant_mass:
                add(leaf_target(category, portal=1), multiplicity * mutant_mass / denom)
            elif p == 1 and resident_mass:
                add(leaf_target(category, portal=0), multiplicity * resident_mass / denom)
            if s != p:
                add(leaf_target(category, shield=p), multiplicity * 1.0)
    else:
        raise ValueError(rule)
    return out


def fixation(L: int, r: float, rule: str, A: float, C: float, W: float) -> float:
    empty = (0, 0, 0, 0, 0)
    full = (1, 1, 0, 0, L)
    transient = [state for state in states(L) if state not in (empty, full)]
    index = {state: row for row, state in enumerate(transient)}
    rows: list[int] = []
    cols: list[int] = []
    data: list[float] = []
    rhs = np.zeros(len(transient))
    for state, row in index.items():
        out = moves(state, L, r, rule, A, C, W)
        total = sum(out.values())
        if not total > 0:
            raise ArithmeticError((state, rule))
        rows.append(row)
        cols.append(row)
        data.append(total)
        for target, rate in out.items():
            if target == full:
                rhs[row] += rate
            elif target != empty:
                rows.append(row)
                cols.append(index[target])
                data.append(-rate)
    matrix = coo_matrix((data, (rows, cols)), shape=(len(transient),) * 2).tocsr()
    value = spsolve(matrix, rhs)
    residual = float(np.max(np.abs(matrix @ value - rhs)))
    if residual > 2e-7:
        raise FloatingPointError(residual)
    hub = value[index[(1, 0, 0, 0, 0)]]
    twin = value[index[(0, 1, 0, 0, 0)]]
    portal = value[index[(0, 0, 1, 0, 0)]]
    shield = value[index[(0, 0, 0, 1, 0)]]
    return float((hub + twin + L * (portal + shield)) / (2 * L + 2))


def baseline(n: int, r: float, rule: str) -> float:
    if rule == "Bd":
        return (1 - 1 / r) / (1 - r ** (-n))
    return (1 - 1 / r) * (n - 1) / (n * (1 - r ** (1 - n)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--leaves", type=int, default=8)
    parser.add_argument("--fitness", type=float, default=1.9)
    parser.add_argument("--maxiter", type=int, default=120)
    args = parser.parse_args()
    n = 2 * args.leaves + 2

    def values(z: np.ndarray) -> tuple[float, float, float, float]:
        A, W = np.exp(z)
        bd = fixation(args.leaves, args.fitness, "Bd", A, 1.0, W)
        db = fixation(args.leaves, args.fitness, "dB", A, 1.0, W)
        return bd / baseline(n, args.fitness, "Bd"), db / baseline(n, args.fitness, "dB"), bd, db

    def objective(z: np.ndarray) -> float:
        try:
            return -min(values(z)[:2])
        except (ArithmeticError, FloatingPointError):
            return 1e6

    result = differential_evolution(
        objective,
        [(-14, 14), (-14, 14)],
        seed=20260808,
        maxiter=args.maxiter,
        popsize=15,
        tol=1e-10,
        polish=True,
    )
    print({
        "L": args.leaves,
        "r": args.fitness,
        "A": math.exp(float(result.x[0])),
        "C": 1.0,
        "W": math.exp(float(result.x[1])),
        "values": values(result.x),
        "success": bool(result.success),
    })


if __name__ == "__main__":
    main()
