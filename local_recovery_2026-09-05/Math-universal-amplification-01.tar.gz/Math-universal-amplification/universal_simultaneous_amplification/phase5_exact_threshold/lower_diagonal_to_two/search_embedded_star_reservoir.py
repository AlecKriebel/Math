#!/usr/bin/env python3
"""Exact orbit search for K_C with one hub on L marked clique vertices."""
from __future__ import annotations
import argparse,math
import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

def trans(q,C,L,r,u,w):
 i,j,h=q;A=C-L;da=C-1;db=C-1+w;dh=L*w;o={}
 def add(t,x):
  if x>0:o[t]=o.get(t,0)+x
 if u=='Bd':
  if i<A:add((i+1,j,h),r*(A-i)*(i/da+j/db))
  if i:add((i-1,j,h),i*((A-i)/da+(L-j)/db))
  if j<L:add((i,j+1,h),r*(L-j)*(i/da+j/db+h*w/dh))
  if j:add((i,j-1,h),j*((A-i)/da+(L-j)/db+(1-h)*w/dh))
  if not h and j:add((i,j,1),r*j*w/db)
  if h and j<L:add((i,j,0),(L-j)*w/db)
 else:
  if i<A:
   mm=i+j;rr=A-i-1+L-j
   if mm:add((i+1,j,h),(A-i)*r*mm/(r*mm+rr))
  if i:
   mm=i-1+j;rr=A-i+L-j
   if rr:add((i-1,j,h),i*rr/(r*mm+rr))
  if j<L:
   mm=i+j+h*w;rr=A-i+L-j-1+(1-h)*w
   if mm:add((i,j+1,h),(L-j)*r*mm/(r*mm+rr))
  if j:
   mm=i+j-1+h*w;rr=A-i+L-j+(1-h)*w
   if rr:add((i,j-1,h),j*rr/(r*mm+rr))
  if not h and j:add((i,j,1),r*j/(r*j+L-j))
  if h and j<L:add((i,j,0),(L-j)/(r*j+L-j))
 return o

def fix(C,L,r,u,w):
 A=C-L;z=(0,0,0);f=(A,L,1);sts=[(i,j,h) for i in range(A+1) for j in range(L+1) for h in (0,1) if (i,j,h) not in (z,f)];ix={q:k for k,q in enumerate(sts)};ro=[];co=[];da=[];rhs=np.zeros(len(sts))
 for q,k in ix.items():
  o=trans(q,C,L,r,u,w);s=sum(o.values());ro.append(k);co.append(k);da.append(s)
  for t,x in o.items():
   if t==f:rhs[k]+=x
   elif t!=z:ro.append(k);co.append(ix[t]);da.append(-x)
 M=coo_matrix((da,(ro,co)),shape=(len(sts),)*2).tocsr();v=spsolve(M,rhs)
 if np.max(np.abs(M@v-rhs))>2e-7:raise FloatingPointError
 return float((A*v[ix[(1,0,0)]]+L*v[ix[(0,1,0)]]+v[ix[(0,0,1)]])/(C+1))

def main():
 a=argparse.ArgumentParser();a.add_argument('--core',type=int,default=100);a.add_argument('--marked',type=int,default=10);a.add_argument('--fitness',type=float,default=1.9);a.add_argument('--maxiter',type=int,default=100);x=a.parse_args();p=1-1/x.fitness
 def val(z):
  w=math.exp(float(z[0]));bd=fix(x.core,x.marked,x.fitness,'Bd',w);db=fix(x.core,x.marked,x.fitness,'dB',w)
  return min((bd-p)*x.core,(db-p)*x.core),bd,db,w
 o=differential_evolution(lambda z:-val(z)[0],[(-15,15)],seed=20260808,maxiter=x.maxiter,popsize=20,tol=1e-11,polish=True)
 print({'C':x.core,'L':x.marked,'r':x.fitness,'value':val(o.x)})
if __name__=='__main__':main()
