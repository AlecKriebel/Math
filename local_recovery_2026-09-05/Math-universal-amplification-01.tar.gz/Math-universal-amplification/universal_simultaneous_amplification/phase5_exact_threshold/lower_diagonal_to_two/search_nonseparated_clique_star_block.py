#!/usr/bin/env python3
"""Exact three-count search for a nonseparated clique--star block.

K_C has unit internal weights.  Every one of L star leaves is joined to
every clique vertex with weight e, and to the star hub with weight w.  The
orbit state (i,j,h) records mutant clique vertices, leaves, and hub.
"""
from __future__ import annotations
import argparse,math
import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

def trans(q,C,L,r,u,e,z,w):
 i,j,h=q;dc=C-1+L*e+z;dl=C*e+w;dh=C*z+L*w;out={}
 def add(t,x):
  if x>0:out[t]=out.get(t,0)+x
 if u=='Bd':
  if i<C:add((i+1,j,h),r*(C-i)*(i/dc+j*e/dl+h*z/dh))
  if i:add((i-1,j,h),i*((C-i)/dc+(L-j)*e/dl+(1-h)*z/dh))
  if j<L:add((i,j+1,h),r*(L-j)*(i*e/dc+h*w/dh))
  if j:add((i,j-1,h),j*((C-i)*e/dc+(1-h)*w/dh))
  if not h and (j or i):add((i,j,1),r*(j*w/dl+i*z/dc))
  if h and (j<L or i<C):add((i,j,0),(L-j)*w/dl+(C-i)*z/dc)
 else:
  if i<C:
   mm=i+j*e+h*z;rr=C-i-1+(L-j)*e+(1-h)*z
   if mm:add((i+1,j,h),(C-i)*r*mm/(r*mm+rr))
  if i:
   mm=i-1+j*e+h*z;rr=C-i+(L-j)*e+(1-h)*z
   if rr:add((i-1,j,h),i*rr/(r*mm+rr))
  if j<L:
   mm=i*e+h*w;rr=(C-i)*e+(1-h)*w
   if mm:add((i,j+1,h),(L-j)*r*mm/(r*mm+rr))
  if j:
   mm=i*e+h*w;rr=(C-i)*e+(1-h)*w
   if rr:add((i,j-1,h),j*rr/(r*mm+rr))
  if not h:
   mm=i*z+j*w;rr=(C-i)*z+(L-j)*w
   if mm:add((i,j,1),r*mm/(r*mm+rr))
  if h:
   mm=i*z+j*w;rr=(C-i)*z+(L-j)*w
   if rr:add((i,j,0),rr/(r*mm+rr))
 return out

def fix(C,L,r,u,e,z,w):
 empty=(0,0,0);f=(C,L,1);sts=[(i,j,h) for i in range(C+1) for j in range(L+1) for h in (0,1) if (i,j,h) not in (empty,f)];ix={q:k for k,q in enumerate(sts)}
 ro=[];co=[];da=[];rhs=np.zeros(len(sts))
 for q,k in ix.items():
  o=trans(q,C,L,r,u,e,z,w);s=sum(o.values());ro.append(k);co.append(k);da.append(s)
  for t,x in o.items():
   if t==f:rhs[k]+=x
   elif t!=empty:ro.append(k);co.append(ix[t]);da.append(-x)
 A=coo_matrix((da,(ro,co)),shape=(len(sts),)*2).tocsr();v=spsolve(A,rhs)
 if np.max(np.abs(A@v-rhs))>2e-7:raise FloatingPointError
 return float((C*v[ix[(1,0,0)]]+L*v[ix[(0,1,0)]]+v[ix[(0,0,1)]])/(C+L+1))

def main():
 a=argparse.ArgumentParser();a.add_argument('--core',type=int,default=100);a.add_argument('--leaves',type=int,default=1);a.add_argument('--fitness',type=float,default=1.9);a.add_argument('--maxiter',type=int,default=150);x=a.parse_args();p=1-1/x.fitness
 def val(v):
  # C*e, C*z, and w are the natural antenna-scale coordinates.
  load,target,w=np.exp(v);e=load/x.core;z=target/x.core;bd=fix(x.core,x.leaves,x.fitness,'Bd',e,z,w);db=fix(x.core,x.leaves,x.fitness,'dB',e,z,w)
  return min((bd-p)*x.core,(db-p)*x.core),bd,db,load,target,w
 o=differential_evolution(lambda v:-val(v)[0],[(-15,15)]*3,seed=20260808,maxiter=x.maxiter,popsize=15,tol=1e-10,polish=True)
 print({'C':x.core,'L':x.leaves,'r':x.fitness,'value':val(o.x)})
if __name__=='__main__':main()
