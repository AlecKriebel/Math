#!/usr/bin/env python3
"""Discovery optimizer for non-rank-one integrated path catalyst modules.

The local trace is the exact labelled subset chain at r=2.  Every singleton,
portal mark, core erasure, and endpoint response term is retained.  Floating
output is discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def local_success(edges: np.ndarray, portal: np.ndarray, rule: str) -> np.ndarray:
    order = len(portal)
    degrees = portal + edges.sum(axis=1)
    number = (1 << order) - 1
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(number)

    for mask in range(1, 1 << order):
        row = mask - 1
        moves: dict[int, float] = {}

        def add(target: int, rate: float) -> None:
            if rate > 1e-300:
                moves[target] = moves.get(target, 0.0) + rate

        if rule == "Bd":
            for parent in range(order):
                mutant_parent = (mask >> parent) & 1
                fitness = 2.0 if mutant_parent else 1.0
                for target in np.flatnonzero(edges[parent]):
                    mutant_target = (mask >> target) & 1
                    if mutant_parent != mutant_target:
                        add(mask ^ (1 << target), fitness * edges[parent, target] / degrees[parent])
            for target in range(order):
                if (mask >> target) & 1:
                    add(mask ^ (1 << target), portal[target])
            mark = sum(
                portal[i] / degrees[i]
                for i in range(order)
                if (mask >> i) & 1
            )
        elif rule == "dB":
            for target in range(order):
                mutant_mass = 0.0
                resident_mass = portal[target]
                for parent in np.flatnonzero(edges[target]):
                    if (mask >> parent) & 1:
                        mutant_mass += 2.0 * edges[parent, target]
                    else:
                        resident_mass += edges[parent, target]
                denominator = mutant_mass + resident_mass
                if (mask >> target) & 1:
                    add(mask ^ (1 << target), resident_mass / denominator)
                else:
                    add(mask ^ (1 << target), mutant_mass / denominator)
            mark = sum(portal[i] for i in range(order) if (mask >> i) & 1)
        else:
            raise ValueError(rule)

        total = mark + sum(moves.values())
        if not math.isfinite(total) or total <= 0:
            raise FloatingPointError((mask, total))
        rows.append(row)
        columns.append(row)
        entries.append(total)
        rhs[row] = mark
        for target, rate in moves.items():
            if target:
                rows.append(row)
                columns.append(target - 1)
                entries.append(-rate)

    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(number, number)
    ).tocsr()
    solution = spsolve(matrix, rhs)
    residual = np.max(np.abs(matrix @ solution - rhs))
    if not np.isfinite(residual) or residual > 2e-7:
        raise FloatingPointError(residual)
    return np.array([solution[(1 << i) - 1] for i in range(order)])


def build(order: int, parameters: np.ndarray, profile: str) -> tuple[np.ndarray, np.ndarray]:
    edges = np.zeros((order, order))
    if profile == "geometric":
        log_scale, log_slope, log_portal, log_portal_slope = parameters
        midpoint = (order - 2) / 2
        for i in range(order - 1):
            value = math.exp(log_scale + log_slope * (i - midpoint))
            edges[i, i + 1] = edges[i + 1, i] = value
        center = (order - 1) / 2
        portal = np.exp(log_portal + log_portal_slope * (np.arange(order) - center))
    elif profile == "valley":
        log_scale, log_slope, log_portal, log_portal_slope = parameters
        midpoint = (order - 2) / 2
        for i in range(order - 1):
            value = math.exp(log_scale + log_slope * abs(i - midpoint))
            edges[i, i + 1] = edges[i + 1, i] = value
        center = (order - 1) / 2
        portal = np.exp(log_portal + log_portal_slope * np.abs(np.arange(order) - center))
    else:
        raise ValueError(profile)
    return edges, portal


def response(order: int, parameters: np.ndarray, profile: str) -> tuple[float, ...]:
    edges, portal = build(order, parameters, profile)
    degrees = portal + edges.sum(axis=1)
    ub = local_success(edges, portal, "Bd")
    ud = local_success(edges, portal, "dB")
    bd = float(np.sum(2 * (1 + portal) * ub - 1 - portal / degrees))
    db = float(np.sum(2 * (1 + portal / degrees) * ud - 1 - portal))
    return bd, db, -db / bd if bd > 0 else math.inf, *parameters


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--order", type=int, default=7)
    parser.add_argument("--profile", choices=("geometric", "valley"), default="geometric")
    parser.add_argument("--maxiter", type=int, default=80)
    parser.add_argument("--span", type=float, default=8.0)
    parser.add_argument("--penalty", type=float, default=20.0)
    args = parser.parse_args()

    def objective(parameters: np.ndarray) -> float:
        try:
            bd, db, *_ = response(args.order, parameters, args.profile)
            # Maximize Bd while forcing the dB coordinate into a narrowing
            # neighbourhood of zero.  Positive dB is never penalized.
            return -bd + args.penalty * max(0.0, -db) ** 2 + 0.01 * db**2
        except (ArithmeticError, FloatingPointError, RuntimeWarning):
            return 1e30

    result = differential_evolution(
        objective,
        [(-args.span, args.span)] * 4,
        seed=20260808 + args.order + (1000 if args.profile == "valley" else 0),
        maxiter=args.maxiter,
        popsize=12,
        polish=True,
        tol=1e-9,
        workers=1,
    )
    print(
        {
            "order": args.order,
            "profile": args.profile,
            "response": response(args.order, result.x, args.profile),
            "objective": result.fun,
        }
    )


if __name__ == "__main__":
    main()
