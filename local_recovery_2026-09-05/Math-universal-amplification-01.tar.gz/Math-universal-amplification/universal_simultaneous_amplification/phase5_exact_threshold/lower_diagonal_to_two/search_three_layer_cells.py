#!/usr/bin/env python3
"""Discovery search for positive-density nonseparated three-vertex cells.

There are Q exchangeable labelled cells, each with three coordinates.  The
three coordinates inside a cell form a weighted triangle.  Between distinct
cells, every ordered coordinate pair has an independent symmetric layer
weight.  The orbit records the counts of all eight labelled cell masks, so
every relay start and every discordant episode is retained.  Floating
optimization is discovery only.
"""

from __future__ import annotations

import argparse
import math
from itertools import combinations

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


ORDER = 3
TYPE_COUNT = 1 << ORDER


def compositions(total: int, parts: int):
    if parts == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for tail in compositions(total - first, parts - 1):
            yield (first,) + tail


def transient_states(cell_count: int):
    empty = (cell_count,) + (0,) * (TYPE_COUNT - 1)
    full = (0,) * (TYPE_COUNT - 1) + (cell_count,)
    return [state for state in compositions(cell_count, TYPE_COUNT) if state not in (empty, full)]


def changed_mask(mask: int, coordinate: int, mutant: bool) -> int:
    if mutant:
        return mask | (1 << coordinate)
    return mask & ~(1 << coordinate)


def fixation(
    cell_count: int,
    fitness: float,
    rule: str,
    internal: np.ndarray,
    cross: np.ndarray,
) -> float:
    states = transient_states(cell_count)
    index = {state: row for row, state in enumerate(states)}
    empty = (cell_count,) + (0,) * (TYPE_COUNT - 1)
    full = (0,) * (TYPE_COUNT - 1) + (cell_count,)
    degrees = internal.sum(axis=1) + cross.sum(axis=1)
    cross_edge = cross / (cell_count - 1)
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))

    for state, row in index.items():
        mutant_count = np.array(
            [sum(state[mask] for mask in range(TYPE_COUNT) if mask & (1 << c)) for c in range(ORDER)],
            dtype=float,
        )
        moves: dict[tuple[int, ...], float] = {}

        for mask, multiplicity in enumerate(state):
            if not multiplicity:
                continue
            for target in range(ORDER):
                old_mutant = bool(mask & (1 << target))
                if rule == "Bd":
                    rate = 0.0
                    for parent in range(ORDER):
                        if parent == target:
                            continue
                        parent_mutant = bool(mask & (1 << parent))
                        if parent_mutant != old_mutant:
                            parent_fitness = fitness if parent_mutant else 1.0
                            rate += parent_fitness * internal[parent, target] / degrees[parent]
                    for parent in range(ORDER):
                        parent_mutants = mutant_count[parent] - int(bool(mask & (1 << parent)))
                        parent_residents = cell_count - 1 - parent_mutants
                        opposite_count = parent_mutants if not old_mutant else parent_residents
                        parent_fitness = fitness if not old_mutant else 1.0
                        rate += (
                            parent_fitness
                            * opposite_count
                            * cross_edge[parent, target]
                            / degrees[parent]
                        )
                elif rule == "dB":
                    mutant_mass = 0.0
                    resident_mass = 0.0
                    for parent in range(ORDER):
                        if parent == target:
                            continue
                        if mask & (1 << parent):
                            mutant_mass += internal[target, parent]
                        else:
                            resident_mass += internal[target, parent]
                    for parent in range(ORDER):
                        parent_mutants = mutant_count[parent] - int(bool(mask & (1 << parent)))
                        parent_residents = cell_count - 1 - parent_mutants
                        mutant_mass += parent_mutants * cross_edge[target, parent]
                        resident_mass += parent_residents * cross_edge[target, parent]
                    denominator = fitness * mutant_mass + resident_mass
                    if old_mutant:
                        rate = resident_mass / denominator if resident_mass else 0.0
                    else:
                        rate = fitness * mutant_mass / denominator if mutant_mass else 0.0
                else:
                    raise ValueError(rule)

                if rate <= 0:
                    continue
                next_mask = changed_mask(mask, target, not old_mutant)
                next_state = list(state)
                next_state[mask] -= 1
                next_state[next_mask] += 1
                target_state = tuple(next_state)
                moves[target_state] = moves.get(target_state, 0.0) + multiplicity * rate

        total = sum(moves.values())
        if total <= 0:
            raise ArithmeticError((state, rule))
        rows.append(row)
        columns.append(row)
        entries.append(total)
        for target_state, rate in moves.items():
            if target_state == full:
                rhs[row] += rate
            elif target_state != empty:
                rows.append(row)
                columns.append(index[target_state])
                entries.append(-rate)

    matrix = coo_matrix((entries, (rows, columns)), shape=(len(states), len(states))).tocsr()
    harmonic = spsolve(matrix, rhs)
    residual = float(np.max(np.abs(matrix @ harmonic - rhs)))
    if residual > 2e-7:
        raise FloatingPointError(residual)
    singleton_sum = 0.0
    for coordinate in range(ORDER):
        state = [0] * TYPE_COUNT
        state[0] = cell_count - 1
        state[1 << coordinate] = 1
        singleton_sum += harmonic[index[tuple(state)]]
    return float(singleton_sum / ORDER)


def decode(parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    values = np.exp(parameters)
    internal = np.zeros((ORDER, ORDER))
    internal[0, 1] = internal[1, 0] = 1.0
    internal[0, 2] = internal[2, 0] = values[0]
    internal[1, 2] = internal[2, 1] = values[1]
    cross = np.zeros((ORDER, ORDER))
    cursor = 2
    for left in range(ORDER):
        for right in range(left, ORDER):
            cross[left, right] = cross[right, left] = values[cursor]
            cursor += 1
    return internal, cross


def baseline(size: int, fitness: float, rule: str) -> float:
    if rule == "Bd":
        return (1 - 1 / fitness) / (1 - fitness ** (-size))
    return (1 - 1 / fitness) * (size - 1) / (size * (1 - fitness ** (1 - size)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cells", type=int, default=5)
    parser.add_argument("--fitness", type=float, default=1.9)
    parser.add_argument("--maxiter", type=int, default=80)
    parser.add_argument("--bound", type=float, default=12.0)
    args = parser.parse_args()
    size = ORDER * args.cells
    base_b = baseline(size, args.fitness, "Bd")
    base_d = baseline(size, args.fitness, "dB")

    def score(parameters: np.ndarray):
        internal, cross = decode(parameters)
        bd = fixation(args.cells, args.fitness, "Bd", internal, cross)
        db = fixation(args.cells, args.fitness, "dB", internal, cross)
        return bd / base_b, db / base_d, bd, db

    result = differential_evolution(
        lambda z: -min(score(z)[:2]),
        [(-args.bound, args.bound)] * 8,
        seed=20260808,
        maxiter=args.maxiter,
        popsize=12,
        tol=2e-8,
        polish=True,
        workers=1,
    )
    internal, cross = decode(result.x)
    print(
        {
            "cells": args.cells,
            "fitness": args.fitness,
            "internal": [internal[i, j] for i, j in combinations(range(ORDER), 2)],
            "cross": cross,
            "score": score(result.x),
            "success": bool(result.success),
        }
    )


if __name__ == "__main__":
    main()
