#!/usr/bin/env python3
"""Discovery search for self-dual strong-pair macro amplifiers.

At the rare-coupling pair-module level, Bd conversion uses source activity
and dB conversion uses target activity.  The involution imposed here makes
the two processes conjugate.  This is numerical discovery only.
"""

from __future__ import annotations

import argparse
from itertools import combinations
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def involution(vertex: int, pairs: int) -> int:
    return vertex + pairs if vertex < pairs else vertex - pairs


def parameter_count(pairs: int) -> int:
    order = 2 * pairs
    seen: set[tuple[int, int]] = set()
    edge_orbits = 0
    for i, j in combinations(range(order), 2):
        edge = (i, j)
        if edge in seen:
            continue
        mirror = tuple(sorted((involution(i, pairs), involution(j, pairs))))
        seen.add(edge)
        seen.add(mirror)
        edge_orbits += 1
    return pairs + edge_orbits


def decode(pairs: int, parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    order = 2 * pairs
    left = np.exp(parameters[:pairs])
    activity = np.r_[left, 1 / left]
    edges = np.zeros((order, order))
    seen: set[tuple[int, int]] = set()
    cursor = pairs
    for i, j in combinations(range(order), 2):
        edge = (i, j)
        if edge in seen:
            continue
        mirror = tuple(sorted((involution(i, pairs), involution(j, pairs))))
        value = math.exp(float(parameters[cursor]))
        cursor += 1
        edges[i, j] = edges[j, i] = value
        seen.add(edge)
        if mirror != edge:
            mirror_value = activity[i] * activity[j] * value
            edges[mirror] = edges[mirror[::-1]] = mirror_value
            seen.add(mirror)
    assert cursor == len(parameters)
    assert np.allclose(
        activity[[involution(i, pairs) for i in range(order)]], 1 / activity
    )
    for i, j in combinations(range(order), 2):
        mi, mj = involution(i, pairs), involution(j, pairs)
        assert math.isclose(
            edges[mi, mj], activity[i] * activity[j] * edges[i, j],
            rel_tol=2e-12, abs_tol=1e-14,
        )
    return activity, edges


def fixation(
    activity: np.ndarray,
    edges: np.ndarray,
    bias: float,
    target_activity: bool,
) -> float:
    """Uniform-singleton fixation in the source/target activity chain."""
    order = len(activity)
    full = (1 << order) - 1
    states = list(range(1, full))
    index = {state: row for row, state in enumerate(states)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))
    for state, row in index.items():
        moves: dict[int, float] = {}
        for i, j in combinations(range(order), 2):
            if not edges[i, j] or ((state >> i) & 1) == ((state >> j) & 1):
                continue
            if (state >> i) & 1:
                mutant, resident = i, j
            else:
                mutant, resident = j, i
            gain_activity = activity[resident] if target_activity else activity[mutant]
            loss_activity = activity[mutant] if target_activity else activity[resident]
            gain = state | (1 << resident)
            loss = state & ~(1 << mutant)
            moves[gain] = moves.get(gain, 0.0) + bias * gain_activity * edges[i, j]
            moves[loss] = moves.get(loss, 0.0) + loss_activity * edges[i, j]
        total = sum(moves.values())
        if not total > 0:
            raise ArithmeticError((state, activity, edges))
        rows.append(row); columns.append(row); entries.append(total)
        for destination, rate in moves.items():
            if destination == full:
                rhs[row] += rate
            elif destination:
                rows.append(row); columns.append(index[destination]); entries.append(-rate)
    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(states), len(states))
    ).tocsr()
    values = spsolve(matrix, rhs)
    residual = float(np.max(np.abs(matrix @ values - rhs)))
    if residual > 2e-7 or values.min() < -2e-7 or values.max() > 1 + 2e-7:
        raise FloatingPointError((residual, values.min(), values.max()))
    return float(sum(values[index[1 << vertex]] for vertex in range(order)) / order)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pairs", type=int, default=3)
    parser.add_argument("--bias", type=float, default=4.0)
    parser.add_argument("--bound", type=float, default=9.0)
    parser.add_argument("--maxiter", type=int, default=120)
    parser.add_argument("--popsize", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260808)
    args = parser.parse_args()
    dimension = parameter_count(args.pairs)

    def objective(parameters: np.ndarray) -> float:
        try:
            activity, edges = decode(args.pairs, parameters)
            return -fixation(activity, edges, args.bias, target_activity=False)
        except (ArithmeticError, FloatingPointError, RuntimeError, ValueError):
            return 1e3

    result = differential_evolution(
        objective,
        [(-args.bound, args.bound)] * dimension,
        seed=args.seed,
        popsize=args.popsize,
        maxiter=args.maxiter,
        tol=1e-10,
        polish=True,
        workers=1,
        updating="immediate",
    )
    activity, edges = decode(args.pairs, result.x)
    source = fixation(activity, edges, args.bias, target_activity=False)
    target = fixation(activity, edges, args.bias, target_activity=True)
    order = 2 * args.pairs
    baseline = (1 - 1 / args.bias) / (1 - args.bias ** (-order))
    print({
        "pairs": args.pairs,
        "order": order,
        "bias": args.bias,
        "source": source,
        "target": target,
        "baseline": baseline,
        "gain": source - baseline,
        "conjugacy_error": source - target,
        "activity": activity.tolist(),
        "edges": edges.tolist(),
        "parameters": result.x.tolist(),
        "success": bool(result.success),
        "message": result.message,
    })


if __name__ == "__main__":
    main()
