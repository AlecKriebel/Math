#!/usr/bin/env python3
"""Exact-orbit discovery: one unpaired hub and L one-sided leaf pairs."""

from __future__ import annotations
import argparse, math
import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

BITS=((0,0),(1,0),(0,1),(1,1))

def all_states(L):
    return [(h,np_,ns,n2) for h in (0,1) for np_ in range(L+1)
            for ns in range(L-np_+1) for n2 in range(L-np_-ns+1)]

def transitions(q,L,r,rule,W,C=1.0):
    h,np_,ns,n2=q;n0=L-np_-ns-n2;cnt=[n0,np_,ns,n2];out={}
    def add(t,x):
        if x>0:out[t]=out.get(t,0)+x
    def leaf(k,p=None,s=None):
        a,b=BITS[k];a=a if p is None else p;b=b if s is None else s
        cc=cnt.copy();cc[k]-=1;cc[BITS.index((a,b))]+=1
        return (h,cc[1],cc[2],cc[3])
    if rule=='Bd':
        for k,m in enumerate(cnt):
            if not m:continue
            p,s=BITS[k]
            if p!=s:
                if p:
                    add(leaf(k,s=1),m*r*W/(W+C));add(leaf(k,p=0),m)
                else:
                    add(leaf(k,s=0),m*W/(W+C));add(leaf(k,p=1),m*r)
            if h!=p:
                if h:
                    add(leaf(k,p=1),m*r/L);add((p,np_,ns,n2),m*C/(W+C))
                else:
                    add(leaf(k,p=0),m/L);add((p,np_,ns,n2),m*r*C/(W+C))
    else:
        mm=r*(np_+n2);rr=n0+ns;den=mm+rr
        if h==0 and mm:add((1,np_,ns,n2),mm/den)
        elif h==1 and rr:add((0,np_,ns,n2),rr/den)
        for k,m in enumerate(cnt):
            if not m:continue
            p,s=BITS[k];mm=r*(W*s+C*h);rr=W*(1-s)+C*(1-h);den=mm+rr
            if p==0 and mm:add(leaf(k,p=1),m*mm/den)
            elif p==1 and rr:add(leaf(k,p=0),m*rr/den)
            if p!=s:add(leaf(k,s=p),m)
    return out

def fixation(L,r,rule,W):
    zero=(0,0,0,0);full=(1,0,0,L);sts=[q for q in all_states(L) if q not in (zero,full)];ix={q:i for i,q in enumerate(sts)}
    rows=[];cols=[];dat=[];rhs=np.zeros(len(sts))
    for q,i in ix.items():
        out=transitions(q,L,r,rule,W);z=sum(out.values());rows.append(i);cols.append(i);dat.append(z)
        for t,x in out.items():
            if t==full:rhs[i]+=x
            elif t!=zero:rows.append(i);cols.append(ix[t]);dat.append(-x)
    A=coo_matrix((dat,(rows,cols)),shape=(len(sts),)*2).tocsr();v=spsolve(A,rhs)
    if np.max(np.abs(A@v-rhs))>2e-7:raise FloatingPointError
    return float((v[ix[(1,0,0,0)]]+L*(v[ix[(0,1,0,0)]]+v[ix[(0,0,1,0)]]))/(2*L+1))

def base(n,r,u):
    return (1-1/r)/(1-r**(-n)) if u=='Bd' else (1-1/r)*(n-1)/(n*(1-r**(1-n)))

def main():
    p=argparse.ArgumentParser();p.add_argument('--leaves',type=int,default=8);p.add_argument('--fitness',type=float,default=1.9);p.add_argument('--maxiter',type=int,default=120);a=p.parse_args();n=2*a.leaves+1
    def val(z):
        W=math.exp(float(z[0]));bd=fixation(a.leaves,a.fitness,'Bd',W);db=fixation(a.leaves,a.fitness,'dB',W)
        return bd/base(n,a.fitness,'Bd'),db/base(n,a.fitness,'dB'),bd,db
    o=differential_evolution(lambda z:-min(val(z)[:2]),[(-15,15)],seed=20260808,maxiter=a.maxiter,popsize=20,tol=1e-11,polish=True)
    print({'L':a.leaves,'r':a.fitness,'W':math.exp(float(o.x[0])),'values':val(o.x)})
if __name__=='__main__':main()
