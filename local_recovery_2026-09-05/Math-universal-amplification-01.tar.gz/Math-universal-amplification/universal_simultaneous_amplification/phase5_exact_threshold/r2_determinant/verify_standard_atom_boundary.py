#!/usr/bin/env python3
"""Exact audit of the standard Hausdorff-atom reduction and its sharp boundary.

The all-order positivity of the atom coefficient array remains open.  This
verifier separates three statements:

* an independent labelled-chain check of the reduced recurrence;
* exact finite coefficient and reserve screens;
* an all-N proof that a one-level rank-linear Riccati cone cannot prove the
  desired positivity, because its top diagonal is strictly negative.
"""

from __future__ import annotations

from fractions import Fraction as Q
from math import comb

import sympy as sp

from verify_fixed_count_two_replica import (
    active_operator,
    difference_step,
    dot,
    mat_vec,
    standard_force,
    standard_output,
    standard_step,
)
from verify_standard_pin_bernstein import standard_embedding


def basis(size: int, index: int) -> list[Q]:
    vector = [Q(0)] * size
    vector[index] = Q(1)
    return vector


def reduced_matrices(N: int):
    """Return K,F,D,ell with a_N removed and physical b_N retained."""

    n = N + 1
    # Reachable feature order: a_1,...,a_(N-1),b_1,...,b_N.
    dimension = 2 * N - 1
    K = sp.zeros(dimension)
    for column in range(dimension):
        a = [Q(0)] * (N + 1)
        b = [Q(0)] * (N + 1)
        if column < N - 1:
            a[column + 1] = Q(1)
        else:
            b[column - (N - 1) + 1] = Q(1)
        ap, bp = standard_step(a, b, n)
        values = ap[1:N] + bp[1:]
        for row, value in enumerate(values):
            K[row, column] = sp.Rational(value.numerator, value.denominator)

    F = sp.zeros(dimension, N - 1)
    D = sp.zeros(N - 1)
    for atom in range(1, N):
        h = [Q(0)] * (N + 1)
        for rank in range(1, atom + 1):
            h[rank] = Q(1)
        a, b = standard_force(h, n)
        for row, value in enumerate(a[1:N] + b[1:]):
            F[row, atom - 1] = sp.Rational(value.numerator, value.denominator)

        d = [Q(0)] * (N + 1)
        d[atom] = Q(1)
        next_d = difference_step(d, N)
        for row in range(N - 1):
            D[row, atom - 1] = sp.Rational(
                next_d[row + 1].numerator, next_d[row + 1].denominator
            )

    ell = sp.zeros(1, dimension)
    for rank in range(1, N + 1):
        b = [Q(0)] * (N + 1)
        b[rank] = Q(1)
        value = standard_output(b, n)
        ell[0, N - 1 + rank - 1] = sp.Rational(value.numerator, value.denominator)
    return K, F, D, ell


def coefficient_rows(N: int, max_lag: int):
    K, F, D, ell = reduced_matrices(N)
    state = F
    power = sp.eye(N - 1)
    rows = []
    for lag in range(max_lag + 1):
        if lag:
            power = power * D
            state = K * state + F * power
        rows.append(ell * state)
    return rows


def labelled_reduction_audit() -> None:
    """Compare the quotient against full labelled triangular packets."""

    for N in range(2, 5):
        n = N + 1
        complete_rows = [
            [Q(0) if i == j else Q(1, N) for j in range(n)] for i in range(n)
        ]
        direction_rows = standard_embedding(n, 0)
        states, complete = active_operator(complete_rows)
        direction_states, direction = active_operator(direction_rows)
        assert states == direction_states
        nu = [Q(B.bit_count(), n * N * 2 ** (N - 1)) for B, _ in states]
        reduced = coefficient_rows(N, 4)
        for lag in range(5):
            for atom in range(1, N):
                threshold = [Q(B.bit_count() <= atom) for B, _ in states]
                labelled = Q(0)
                for left_gap in range(lag + 1):
                    value = threshold
                    for _ in range(lag - left_gap):
                        value = mat_vec(complete, value)
                    value = mat_vec(direction, value)
                    for _ in range(left_gap):
                        value = mat_vec(complete, value)
                    value = mat_vec(direction, value)
                    labelled += dot(nu, value)
                expected = sp.Rational(labelled.numerator, labelled.denominator) / (n * N)
                assert expected == reduced[lag][atom - 1]
    print("PASS (EXACT FINITE): full-labelled/reduced atom identity N=2..4, lag<=4")


def finite_atom_screen() -> None:
    """Record exact finite evidence and the three-vertex atom exception."""

    exception = coefficient_rows(2, 5)[5][0]
    assert exception == -sp.Rational(21, 32768)
    for N in range(3, 13):
        K, F, D, ell = reduced_matrices(N)
        state = F
        power = sp.eye(N - 1)
        for lag in range(81):
            if lag:
                power = power * D
                state = K * state + F * power
            beta = state[N - 1 :, :]
            assert all(value >= 0 for value in beta)
            assert all(value > 0 for value in ell * state)

            if N >= 4:
                # Exact finite screen of the strongest clean reserve currently
                # known: a_k + 3 b_(k+1)/(2N) >= 0.
                a = state[: N - 1, :]
                next_beta = beta[1:, :]
                assert all(
                    value >= 0
                    for value in a + sp.Rational(3, 2 * N) * next_beta
                )
    print("EXACT EXCEPTION: N=2, lag=5 atom coefficient = -21/32768")
    print("PASS (EXACT FINITE): beta/output positivity N=3..12, lag<=80")
    print("PASS (EXACT FINITE): 3/(2N) reserve N=4..12, lag<=80")


def block_data(N: int):
    K, F, D, ell = reduced_matrices(N)
    A = K[: N - 1, : N - 1]
    U = -K[: N - 1, N - 1 :]
    C = K[N - 1 :, : N - 1]
    B = K[N - 1 :, N - 1 :]
    M = sp.zeros(N)
    for rank in range(1, N + 1):
        M[rank - 1, rank - 1] = sp.Rational(rank - 1, 2 * N)
        if rank == 1 and N >= 2:
            M[0, 1] = 1
        elif rank < N:
            M[rank - 1, rank] = sp.Rational(
                (N - rank + 1) * (rank + 1), 2 * rank * N
            )
    assert C * A == M * C
    return A, U, C, B, M


def riccati_boundary_obstruction() -> None:
    """Prove that every one-level q=Ca+R beta positivity cone fails."""

    N, x = sp.symbols("N x", integer=True, positive=True)
    top = x * (sp.Rational(1, 2) * (N - 1) / N**2 - x) - sp.Rational(
        1, 4
    ) * (N - 1) / N**3
    maximizer = (N - 1) / (4 * N**2)
    maximum = sp.factor(top.subs(x, maximizer))
    assert sp.factor(maximum + (N - 1) * (3 * N + 1) / (16 * N**4)) == 0

    # Finite matrices independently identify every factor used above.
    for order in range(3, 10):
        A, U, C, B, M = block_data(order)
        assert B[order - 2, order - 1] == 0
        assert B[order - 1, order - 1] - M[order - 1, order - 1] == sp.Rational(
            order - 1, 2 * order**2
        )
        assert (C * U)[order - 1, order - 1] == sp.Rational(
            order - 1, 4 * order**3
        )
    print("PROVED ALL N: one-level rank-linear Riccati cone is impossible")
    print("TOP MAXIMUM: -(N-1)(3N+1)/(16N^4) < 0")


def main() -> None:
    labelled_reduction_audit()
    finite_atom_screen()
    riccati_boundary_obstruction()
    print("OPEN: all-N, all-lag beta/output positivity for N>=3")


if __name__ == "__main__":
    main()
