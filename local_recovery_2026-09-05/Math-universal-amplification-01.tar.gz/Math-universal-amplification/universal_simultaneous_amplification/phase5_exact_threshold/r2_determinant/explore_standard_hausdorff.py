#!/usr/bin/env python3
"""Exact scratch calculations for the standard Hausdorff-atom response.

This file is exploratory: it constructs the forced standard-sector system
directly from ``verify_fixed_count_two_replica`` and searches for an
all-rank positive representation of its monomial coefficient rows.
"""

from __future__ import annotations

from fractions import Fraction as Q
from pathlib import Path
import importlib.util

import sympy as sp


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    "fixed_count", HERE / "verify_fixed_count_two_replica.py"
)
FIXED = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(FIXED)


PIN_SPEC = importlib.util.spec_from_file_location(
    "pin_bernstein", HERE / "verify_standard_pin_bernstein.py"
)
PIN = importlib.util.module_from_spec(PIN_SPEC)
assert PIN_SPEC.loader is not None
PIN_SPEC.loader.exec_module(PIN)


def basis(size: int, index: int) -> list[Q]:
    out = [Q(0)] * size
    out[index] = Q(1)
    return out


def matrices(N: int):
    """Return exact matrices K,F,D and output ell in standard coordinates."""

    n = N + 1
    # State order is a_1,...,a_N,b_1,...,b_N; input d_1,...,d_(N-1).
    Kcols = []
    for j in range(2 * N):
        a = basis(N + 1, j + 1) if j < N else [Q(0)] * (N + 1)
        b = basis(N + 1, j - N + 1) if j >= N else [Q(0)] * (N + 1)
        ap, bp = FIXED.standard_step(a, b, n)
        Kcols.append(ap[1:] + bp[1:])
    K = sp.Matrix(2 * N, 2 * N, lambda i, j: sp.Rational(Kcols[j][i]))

    Fcols = []
    for j in range(1, N):
        h = [Q(0)] * (N + 1)
        # A radial function with exactly d_j=h_j-h_(j+1)=1.
        for k in range(1, j + 1):
            h[k] = Q(1)
        a, b = FIXED.standard_force(h, n)
        Fcols.append(a[1:] + b[1:])
    F = sp.Matrix(2 * N, N - 1, lambda i, j: sp.Rational(Fcols[j][i]))

    Dcols = []
    for j in range(1, N):
        d = [Q(0)] * (N + 1)
        d[j] = Q(1)
        dp = FIXED.difference_step(d, N)
        Dcols.append(dp[1:N])
    D = sp.Matrix(N - 1, N - 1, lambda i, j: sp.Rational(Dcols[j][i]))

    ell = sp.zeros(1, 2 * N)
    for j in range(N):
        b = [Q(0)] * (N + 1)
        b[j + 1] = Q(1)
        ell[0, N + j] = sp.Rational(FIXED.standard_output(b, n))
    return K, F, D, ell


def labelled_atom_audit(max_N: int = 4, max_lag: int = 4):
    """Independently compare every atom coefficient with the labelled chain."""

    for N in range(2, max_N + 1):
        n = N + 1
        complete_rows = [
            [Q(0) if i == j else Q(1, N) for j in range(n)] for i in range(n)
        ]
        direction_rows = PIN.standard_embedding(n, 0)
        states, complete = FIXED.active_operator(complete_rows)
        direction_states, direction = FIXED.active_operator(direction_rows)
        assert states == direction_states
        nu = [Q(B.bit_count(), n * N * 2 ** (N - 1)) for B, _ in states]
        reduced = coefficient_rows(N, max_lag)
        for lag in range(max_lag + 1):
            for atom in range(1, N):
                threshold = [Q(B.bit_count() <= atom) for B, _ in states]
                labelled = Q(0)
                for left_gap in range(lag + 1):
                    value = threshold
                    for _ in range(lag - left_gap):
                        value = FIXED.mat_vec(complete, value)
                    value = FIXED.mat_vec(direction, value)
                    for _ in range(left_gap):
                        value = FIXED.mat_vec(complete, value)
                    value = FIXED.mat_vec(direction, value)
                    labelled += FIXED.dot(nu, value)
                expected = sp.Rational(labelled.numerator, labelled.denominator) / (n * N)
                assert expected == reduced[lag][atom - 1]
    print(
        f"PASS (EXACT FINITE): labelled/reduced atom identity N=2..{max_N}, "
        f"lag<= {max_lag}"
    )


def coefficient_rows(N: int, max_lag: int):
    K, F, D, ell = matrices(N)
    S = F
    power = sp.eye(N - 1)
    rows = []
    for lag in range(max_lag + 1):
        if lag:
            power = power * D
            S = K * S + F * power
        row = ell * S
        rows.append(row)
    return rows


def audit(max_N: int = 16, max_lag: int = 80):
    # N=2 is the already-isolated three-vertex exception: its sole monomial
    # coefficient first turns negative at lag 5, while the cumulative exact
    # generating-function proof remains positive for the physical reward.
    rows_N2 = coefficient_rows(2, 5)
    assert rows_N2[5][0] == sp.Rational(-21, 32768)
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        assert all(sum(D.row(i)) == sp.Rational(N - 1, N) for i in range(N - 1))
        expected = [sp.Rational(N - 1 - j, N) for j in range(N - 1)]
        assert sorted(D.eigenvals(), reverse=True) == sorted(expected, reverse=True)

        S = F
        power = sp.eye(N - 1)
        for lag in range(max_lag + 1):
            if lag:
                power = power * D
                S = K * S + F * power
            row = ell * S
            assert all(value > 0 for value in row), (N, lag, row)
    print(f"PASS (EXACT FINITE): monomial coefficients N=3..{max_N}, lag<= {max_lag}")
    print("EXACT EXCEPTION: N=2, lag=5 coefficient = -21/32768")


def packet_hostile(max_N: int = 10, max_power: int = 40):
    first = None
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        packet = F
        for power in range(max_power + 1):
            row = ell * packet
            if any(value < 0 for value in row) and first is None:
                first = (N, power, row)
            packet = K * packet
    print("FIRST NEGATIVE UNSUMMED PACKET", first)


def reachable_signs(max_N: int = 10, max_lag: int = 100):
    summaries = {}
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        S = F
        power = sp.eye(N - 1)
        first_a = first_b = None
        for lag in range(max_lag + 1):
            if lag:
                power = power * D
                S = K * S + F * power
            if first_a is None:
                for k in range(N - 1):
                    for j in range(N - 1):
                        if S[k, j] < 0:
                            first_a = (lag, k + 1, j + 1, S[k, j])
                            break
                    if first_a:
                        break
            if first_b is None:
                for k in range(N):
                    for j in range(N - 1):
                        if S[N + k, j] < 0:
                            first_b = (lag, k + 1, j + 1, S[N + k, j])
                            break
                    if first_b:
                        break
        summaries[N] = (first_a, first_b)
    print("REACHABLE SIGNS", summaries)


def row_shape_screen(max_N: int = 14, max_lag: int = 80):
    failures = {"logconcave": None, "time_tp2_pos": None, "time_tp2_neg": None}
    for N in range(3, max_N + 1):
        rows = coefficient_rows(N, max_lag)
        for lag, row in enumerate(rows):
            values = list(row)
            for j in range(1, len(values) - 1):
                det = values[j] ** 2 - values[j - 1] * values[j + 1]
                if det < 0 and failures["logconcave"] is None:
                    failures["logconcave"] = (N, lag, j + 1, det)
            if lag:
                prev = list(rows[lag - 1])
                for j in range(len(values) - 1):
                    det = prev[j] * values[j + 1] - prev[j + 1] * values[j]
                    if det < 0 and failures["time_tp2_pos"] is None:
                        failures["time_tp2_pos"] = (N, lag, j + 1, det)
                    if det > 0 and failures["time_tp2_neg"] is None:
                        failures["time_tp2_neg"] = (N, lag, j + 1, det)
    print("ROW SHAPE FAILURES", failures)


def packet_sign_patterns(N: int = 8, max_power: int = 30):
    K, F, D, ell = matrices(N)
    packet = F
    for power in range(max_power + 1):
        row = list(ell * packet)
        signs = "".join("+" if x > 0 else "-" if x < 0 else "0" for x in row)
        print(power, signs, row)
        packet = K * packet


def gamma_ratio_screen(max_N: int = 14, max_lag: int = 200, reserve=sp.Rational(1)):
    worst = None
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        S = F
        power = sp.eye(N - 1)
        for lag in range(max_lag + 1):
            if lag:
                power = power * D
                S = K * S + F * power
            for k in range(N - 1):
                for j in range(N - 1):
                    a = S[k, j]
                    bnext = S[N + k + 1, j]
                    assert a + reserve * bnext >= 0, (
                        N, lag, k + 1, j + 1, a, bnext, reserve
                    )
                    if a < 0:
                        ratio = -a / bnext
                        if worst is None or ratio > worst[0]:
                            worst = (ratio, N, lag, k + 1, j + 1)
    print("GAMMA WORST", worst, float(worst[0]) if worst else None)


def gamma_min_by_rank(max_N: int = 10, max_lag: int = 100):
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        S = F
        power = sp.eye(N - 1)
        minima = [None] * (N - 1)
        where = [None] * (N - 1)
        for lag in range(max_lag + 1):
            if lag:
                power = power * D
                S = K * S + F * power
            for k in range(N - 1):
                for j in range(N - 1):
                    if S[N + k + 1, j] == 0:
                        continue
                    ratio = (S[k, j] + S[N + k + 1, j]) / S[N + k + 1, j]
                    if minima[k] is None or ratio < minima[k]:
                        minima[k] = ratio
                        where[k] = (lag, j + 1)
        print("MIN GAMMA/B N", N, [(float(x), w) for x, w in zip(minima, where)])


def beta_shape_screen(max_N: int = 14, max_lag: int = 100):
    failures = {"rank_logconcave": None, "rank_unimodal": None, "column_logconcave": None}
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        S = F
        power = sp.eye(N - 1)
        for lag in range(max_lag + 1):
            if lag:
                power = power * D
                S = K * S + F * power
            beta = S[N:, :]
            for j in range(N - 1):
                col = list(beta[:, j])
                signs = [col[k + 1] - col[k] for k in range(N - 1)]
                changes = sum(
                    bool(signs[k] * signs[k + 1] < 0)
                    for k in range(len(signs) - 1)
                )
                if changes > 1 and failures["rank_unimodal"] is None:
                    failures["rank_unimodal"] = (N, lag, j + 1, col)
                for k in range(1, N - 1):
                    det = col[k] ** 2 - col[k - 1] * col[k + 1]
                    if det < 0 and failures["rank_logconcave"] is None:
                        failures["rank_logconcave"] = (N, lag, j + 1, k + 1, det)
            for k in range(N):
                row = list(beta[k, :])
                for j in range(1, N - 2):
                    det = row[j] ** 2 - row[j - 1] * row[j + 1]
                    if det < 0 and failures["column_logconcave"] is None:
                        failures["column_logconcave"] = (N, lag, k + 1, j + 1, det)
    print("BETA SHAPE", failures)


def spectra(max_N: int = 8):
    for N in range(2, max_N + 1):
        K, F, D, ell = matrices(N)
        z = sp.symbols("z")
        char_K = sp.factor(K.charpoly(z).as_expr())
        char_D = sp.factor(D.charpoly(z).as_expr())
        print("N", N, "K", char_K, "D", char_D)


def transfer_functions(max_N: int = 6):
    z = sp.symbols("z")
    for N in range(2, max_N + 1):
        K, F, D, ell = matrices(N)
        transfer = ell * (sp.eye(2 * N) - z * K).inv() * F * (
            sp.eye(N - 1) - z * D
        ).inv()
        print("TRANSFER N", N)
        for j, value in enumerate(transfer, 1):
            print(j, sp.factor(value))


def adjoint_rows(N: int = 5):
    K, F, D, ell = matrices(N)
    A = K[:N - 1, :N - 1]
    U = -K[:N - 1, N :]
    C = K[N:, :N - 1]
    B = K[N:, N:]
    # a_N is identically zero; remove it from the exact reachable quotient.
    l = ell[:, N:]
    print("ADJOINT N", N)
    for name, row in (("l", l), ("lB", l * B), ("lC", l * C)):
        print(name, list(row))
    print("A", A)
    print("U", U)
    print("C", C)


def sylvester_screen(max_N: int = 9):
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        entries = sp.symbols(f"x0:{2*N*(N-1)}")
        X = sp.Matrix(2 * N, N - 1, entries)
        equations = list(X * D - K * X - F)
        sol = sp.linsolve(equations, entries)
        if sol is sp.EmptySet:
            print("SYLVESTER N", N, "NO SOLUTION")
            continue
        tup = next(iter(sol))
        free = sorted(set().union(*(value.free_symbols for value in tup)), key=str)
        X0 = sp.Matrix(2 * N, N - 1, [value.subs({s: 0 for s in free}) for value in tup])
        row = ell * X0
        print(
            "SYLVESTER N", N, "free", len(free),
            "ellX signs", "".join("+" if v > 0 else "-" if v < 0 else "0" for v in row),
            "X signs", sum(bool(v > 0) for v in X0), sum(bool(v < 0) for v in X0),
        )


def reduced_blocks(N: int):
    """Reachable a/b blocks (a_N is identically zero)."""
    K, F, D, ell = matrices(N)
    inds = list(range(N - 1)) + list(range(N, 2 * N))
    Kr = K.extract(inds, inds)
    Fr = F.extract(inds, range(N - 1))
    A = Kr[: N - 1, : N - 1]
    U = -Kr[: N - 1, N - 1 :]
    C = Kr[N - 1 :, : N - 1]
    B = Kr[N - 1 :, N - 1 :]
    Fa = Fr[: N - 1, :]
    G = Fr[N - 1 :, :]
    return A, U, C, B, Fa, G, D


def intertwiner(N: int):
    A, U, C, B, Fa, G, D = reduced_blocks(N)
    M = sp.zeros(N)
    for k in range(1, N + 1):
        M[k - 1, k - 1] = sp.Rational(k - 1, 2 * N)
        if k == 1 and N >= 2:
            M[0, 1] = 1
        elif 2 <= k < N:
            M[k - 1, k] = sp.Rational((N - k + 1) * (k + 1), 2 * k * N)
    assert C * A == M * C
    return M, A, U, C, B, Fa, G, D


def block_patterns(N: int = 7):
    M, A, U, C, B, Fa, G, D = intertwiner(N)
    P = M + B
    Qm = M * B + C * U
    RHS0 = G
    RHS1 = C * Fa - M * G
    for name, matrix in (("P", P), ("Q", Qm), ("G", G), ("CF-MG", RHS1)):
        print(name)
        for row in matrix.tolist():
            print(" ".join("+" if x > 0 else "-" if x < 0 else "." for x in row))


def dominant_response(max_N: int = 9):
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        lam = sp.Rational(N - 1, N)
        w = sp.simplify(lam * (lam * sp.eye(2 * N) - K).inv() * F * sp.ones(N - 1, 1))
        print("DOM N", N)
        print("a", [sp.factor(x) for x in w[:N, :]])
        print("b", [sp.factor(x) for x in w[N:, :]])


def affine_graph_search(max_N: int = 8):
    """Seek A_L=S B_L+T D^L on the entire source-reachable subspace."""
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        Svars = sp.symbols(f"s0:{(N-1)*N}")
        Tvars = sp.symbols(f"t0:{(N-1)*(N-1)}")
        Sm = sp.Matrix(N - 1, N, Svars)
        Tm = sp.Matrix(N - 1, N - 1, Tvars)
        state = F
        power = sp.eye(N - 1)
        equations = []
        for lag in range(3 * N + 2):
            if lag:
                power = power * D
                state = K * state + F * power
            equations.extend(list(state[: N - 1, :] - Sm * state[N:, :] - Tm * power))
        solution = sp.linsolve(equations, Svars + Tvars)
        if solution is sp.EmptySet:
            print("AFFINE GRAPH N", N, "NONE")
        else:
            tup = next(iter(solution))
            free = set().union(*(v.free_symbols for v in tup))
            print("AFFINE GRAPH N", N, "free", len(free))


def time_monotonicity_screen(max_N: int = 14, max_lag: int = 100):
    failures = {"raw_inc": None, "lambda_scaled_inc": None, "source_reserve": None}
    for N in range(3, max_N + 1):
        K, F, D, ell = matrices(N)
        lam = sp.Rational(N - 1, N)
        state = F
        power = sp.eye(N - 1)
        previous = None
        for lag in range(max_lag + 1):
            if lag:
                power = power * D
                state = K * state + F * power
            beta = state[N:, :]
            if previous is not None:
                if failures["raw_inc"] is None:
                    for pos, value in enumerate(beta - previous):
                        if value < 0:
                            failures["raw_inc"] = (N, lag, pos, value)
                            break
                if failures["lambda_scaled_inc"] is None:
                    for pos, value in enumerate(beta - lam * previous):
                        if value < 0:
                            failures["lambda_scaled_inc"] = (N, lag, pos, value)
                            break
            # G d_lag is exactly the current forcing beta source.
            G = F[N:, :]
            if failures["source_reserve"] is None:
                for pos, value in enumerate(beta - G * power):
                    if value < 0:
                        failures["source_reserve"] = (N, lag, pos, value)
                        break
            previous = beta
    print("TIME MONOTONICITY", failures)


def reserve_ratios(max_N: int = 10, max_lag: int = 100):
    for N in range(4, max_N + 1):
        K, F, D, ell = matrices(N)
        G = F[N:, :]
        state = F
        power = sp.eye(N - 1)
        minima = None
        for lag in range(1, max_lag + 1):
            power = power * D
            state = K * state + F * power
            beta = state[N:, :]
            p = beta - G * power
            previous_beta = None
            # Compare p to the current source and total beta where defined.
            for row in range(N):
                for col in range(N - 1):
                    if beta[row, col] > 0:
                        ratio = p[row, col] / beta[row, col]
                        if minima is None or ratio < minima[0]:
                            minima = (ratio, lag, row + 1, col + 1)
        print("P/BETA N", N, minima, float(minima[0]))


def beta_neighbor_ratios(max_N: int = 12, max_lag: int = 100):
    worst = None
    for N in range(4, max_N + 1):
        K, F, D, ell = matrices(N)
        state = F
        power = sp.eye(N - 1)
        for lag in range(max_lag + 1):
            if lag:
                power = power * D
                state = K * state + F * power
            beta = state[N:, :]
            for k in range(1, N - 1):
                for j in range(N - 1):
                    denom = beta[k - 1, j] + beta[k + 1, j]
                    if denom:
                        ratio = beta[k, j] / denom
                        if worst is None or ratio > worst[0]:
                            worst = (ratio, N, lag, k + 1, j + 1)
    print("BETA LOCAL PEAK", worst, float(worst[0]))


def adjoint_cumulative_cones(max_N: int = 20, max_lag: int = 200):
    failures = {"x": None, "z_bulk": None, "s": None, "top_target": None}
    for N in range(2, max_N + 1):
        K, F, D, ell = matrices(N)
        y = ell
        for lag in range(max_lag + 1):
            x = list(y[:, : N - 1])
            z = list(y[:, N:])
            if failures["x"] is None and any(value < 0 for value in x):
                failures["x"] = (N, lag, min(x))
            if failures["z_bulk"] is None and any(value < 0 for value in z[:-1]):
                failures["z_bulk"] = (N, lag, min(z[:-1]))
            for j in range(1, N):
                sval = sp.Rational(N - j + 1, j) * z[j - 1]
                sval += sp.Rational(j, j + 1) * z[j]
                if sval < 0 and failures["s"] is None:
                    failures["s"] = (N, lag, j, sval)
            top = sp.Rational(1, 2 * (N + 1)) * x[N - 2]
            top += sp.Rational(N, 2 * (N + 1) * (N - 1)) * z[N - 2]
            top += sp.Rational(1, 2 * N) * z[N - 1]
            if top < 0 and failures["top_target"] is None:
                failures["top_target"] = (N, lag, top)
            y = ell + y * K
    print("ADJOINT CUMULATIVE CONES", failures)


if __name__ == "__main__":
    audit()
    packet_hostile()
    reachable_signs()
    spectra()
    transfer_functions()
    adjoint_rows()
