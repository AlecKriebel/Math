#!/usr/bin/env python3
"""Exact scratch model for the cumulative two-label standard discrepancy.

This is deliberately an exploratory file.  It records the signed quotient of
the complete active chain under the transposition of two marked labels.  The
positive orientation channels are

    P_k: target=x, neither x nor y is cached,
    Q_k: target=x, y is cached,
    R_k: target is ordinary, x is cached and y is not.

The negative orientations are obtained by swapping x and y.  Matrix entries
are positive-orientation transition mass minus negative-orientation mass.
"""

from __future__ import annotations

from fractions import Fraction as Q
from math import comb

from verify_fixed_count_two_replica import active_operator


State = tuple[str, int]


def quotient(N: int) -> tuple[list[State], list[list[Q]], list[Q]]:
    states = (
        [("P", k) for k in range(1, N)]
        + [("Q", k) for k in range(1, N + 1)]
        + [("R", k) for k in range(1, N)]
    )
    index = {state: position for position, state in enumerate(states)}
    matrix = [[Q(0) for _ in states] for _ in states]

    def add(source: State, target: State, mass: Q) -> None:
        if mass and target in index:
            matrix[index[source]][index[target]] += mass

    for k in range(1, N):
        source = ("P", k)
        add(source, ("P", k), Q(k, 2 * N))
        add(source, ("P", k + 1), Q(N - k - 1, 2 * N))
        add(source, ("Q", k + 1), Q(1, 2 * N))

    for k in range(1, N + 1):
        source = ("Q", k)
        add(source, ("Q", k), Q(k * k - 1, 2 * k * N))
        add(source, ("Q", k + 1), Q(N - k, 2 * N))
        add(source, ("P", k - 1), -Q(k - 1, 2 * k * N))
        add(source, ("P", k), -Q(N - k, 2 * k * N))
        add(source, ("R", k - 1), -Q((k - 1) ** 2, 2 * k * N))
        add(source, ("R", k), -Q((k - 1) * (N - k), 2 * k * N))

    for k in range(1, N):
        source = ("R", k)
        add(
            source,
            ("R", k),
            Q(k, 2 * N) + Q((k - 1) * (N - k), 2 * k * N),
        )
        add(source, ("R", k + 1), Q(N - k - 1, 2 * N))
        add(source, ("R", k - 1), Q((k - 1) ** 2, 2 * k * N))
        add(source, ("Q", k), Q(1, 2 * k * N))
        add(source, ("P", k - 1), Q(k - 1, 2 * k * N))
        add(source, ("P", k), Q(N - k, 2 * k * N))

    source = [Q(0) for _ in states]
    for k in range(1, N):
        source[index[("R", k)]] = Q(comb(N - 2, k - 1), 2 ** (N - 2))
    return states, matrix, source


def row_times(row: list[Q], matrix: list[list[Q]]) -> list[Q]:
    return [
        sum((row[i] * matrix[i][j] for i in range(len(row))), Q(0))
        for j in range(len(row))
    ]


def labelled_audit(max_N: int = 5) -> None:
    """Compare every signed quotient row with the full labelled chain."""

    def category(B: int, v: int) -> tuple[int, int, int, str]:
        target = "X" if v == 0 else "Y" if v == 1 else "O"
        return B.bit_count(), (B >> 0) & 1, (B >> 1) & 1, target

    def swapped(state: tuple[int, int, int, str]):
        rank, x_in, y_in, target = state
        return rank, y_in, x_in, {"X": "Y", "Y": "X", "O": "O"}[target]

    def positive_channel(state: tuple[int, int, int, str]) -> State | None:
        rank, x_in, y_in, target = state
        if target == "X":
            return ("Q" if y_in else "P"), rank
        if target == "O" and x_in and not y_in:
            return "R", rank
        return None

    for N in range(2, max_N + 1):
        n = N + 1
        replacement = [
            [Q(0) if i == j else Q(1, N) for j in range(n)]
            for i in range(n)
        ]
        labelled_states, labelled = active_operator(replacement)
        orbit_states = sorted(
            {category(B, v) for B, v in labelled_states}, key=repr
        )
        orbit_index = {state: i for i, state in enumerate(orbit_states)}
        representatives: dict[tuple[int, int, int, str], list[int]] = {
            state: [] for state in orbit_states
        }
        for i, (B, v) in enumerate(labelled_states):
            representatives[category(B, v)].append(i)
        aggregate: list[list[Q]] = []
        for state in orbit_states:
            candidate_rows = []
            for source in representatives[state]:
                row = [Q(0)] * len(orbit_states)
                for target, mass in enumerate(labelled[source]):
                    if mass:
                        row[orbit_index[category(*labelled_states[target])]] += mass
                candidate_rows.append(row)
            assert all(row == candidate_rows[0] for row in candidate_rows)
            aggregate.append(candidate_rows[0])

        signed_states, signed, _source = quotient(N)
        signed_index = {state: i for i, state in enumerate(signed_states)}
        for state in orbit_states:
            channel = positive_channel(state)
            if channel is None:
                continue
            source = orbit_index[state]
            for target_channel in signed_states:
                # Recover the positive orbit and its swapped negative orbit.
                kind, rank = target_channel
                positive = next(
                    orbit
                    for orbit in orbit_states
                    if positive_channel(orbit) == target_channel
                )
                expected = aggregate[source][orbit_index[positive]]
                expected -= aggregate[source][orbit_index[swapped(positive)]]
                assert signed[signed_index[channel]][signed_index[target_channel]] == expected
    print(f"PASS (EXACT FINITE): labelled two-label quotient N=2..{max_N}")


def screen(max_N: int = 20, max_lag: int = 300) -> None:
    failures = {
        "P": None,
        "Q": None,
        "R": None,
        "R-4Q": None,
        "P-Qnext": None,
        "Qtop-ratio": None,
        "atom": None,
    }
    for N in range(2, max_N + 1):
        states, matrix, source = quotient(N)
        index = {state: position for position, state in enumerate(states)}
        cumulative = [Q(0) for _ in states]
        current = source
        for lag in range(max_lag + 1):
            cumulative = [x + y for x, y in zip(cumulative, current)]
            P = [cumulative[index[("P", k)]] for k in range(1, N)]
            Z = [cumulative[index[("Q", k)]] for k in range(1, N + 1)]
            R = [cumulative[index[("R", k)]] for k in range(1, N)]
            for key, values in (("P", P), ("Q", Z), ("R", R)):
                if failures[key] is None and any(value < 0 for value in values):
                    failures[key] = (N, lag, min(values))
            reserve = [R[k] - 4 * Z[k] for k in range(N - 1)]
            if failures["R-4Q"] is None and any(value < 0 for value in reserve):
                failures["R-4Q"] = (N, lag, min(reserve))
            reserve = [P[k] - Z[k + 1] for k in range(N - 1)]
            if failures["P-Qnext"] is None and any(value < 0 for value in reserve):
                failures["P-Qnext"] = (N, lag, min(reserve))
            top_ratio = (4 * N - 1) * Z[N - 2] - Q(N - 1, N) * Z[N - 1]
            if failures["Qtop-ratio"] is None and top_ratio < 0:
                failures["Qtop-ratio"] = (N, lag, top_ratio)
            for j in range(1, N):
                atom = P[j - 1] + Z[j - 1]
                atom += Q(N, j) * (R[j - 1] - Z[j - 1])
                if j < N - 1:
                    atom += Q(N + 1, j + 1) * (R[j] - Z[j])
                else:
                    atom -= Q(N + 1, N) * Z[j]
                if failures["atom"] is None and atom < 0:
                    failures["atom"] = (N, lag, j, atom)
            current = row_times(current, matrix)
    print(failures)


if __name__ == "__main__":
    labelled_audit()
    screen()
