#!/usr/bin/env python3
"""Search the smallest positive two-ground equilibrium circuits directly.

For n=4 the complete looped graph has ten undirected edge variables.  A
generic positive circuit has nine edges and an 8-by-9 equilibrium matrix.
The labels (a,q,h) are optimized directly; the unique stress is obtained
from the numerical null vector.  Any all-positive null vector is itself a
reversible kernel with q and h as its two endpoint ground states.

Discovery only: floating output is not a certificate.
"""

from __future__ import annotations

import argparse
from itertools import combinations_with_replacement

import numpy as np
from scipy.optimize import differential_evolution


N = 4
PAIRS = list(combinations_with_replacement(range(N), 2))


def labels(parameters):
    q = 1.0 / (1.0 + np.exp(-parameters[:N]))
    h = 1.0 / (1.0 + np.exp(-parameters[N : 2 * N]))
    a = np.exp(np.r_[parameters[2 * N :], 0.0])
    return a, q, h


def circuit(parameters, deleted_edge):
    a, q, h = labels(parameters)
    b = 1.0 - q
    s = 1.0 - h
    z = 2.0 * q - 1.0
    C = (4.0 - q) * z * z / (4.0 * q)
    A = z / 2.0 - z * z * (1.0 + h) / (8.0 * h)

    support = [edge for edge in PAIRS if edge != deleted_edge]
    equilibrium = []
    target = []
    for i, j in support:
        column = np.zeros(2 * N)
        column[i] += b[i] * a[j] - 2.0 * a[i] * q[i] * b[j]
        column[j] += b[j] * a[i] - 2.0 * a[j] * q[j] * b[i]
        column[N + i] += a[i] * s[i] - 2.0 * h[i] * a[j] * s[j]
        column[N + j] += a[j] * s[j] - 2.0 * h[j] * a[i] * s[i]
        equilibrium.append(column)
        target.append(a[j] * C[i] + a[i] * A[i] + a[i] * C[j] + a[j] * A[j])
    equilibrium = np.array(equilibrium).T
    target = np.array(target)

    row_scale = np.maximum(np.max(abs(equilibrium), axis=1), 1e-300)
    _, singular_values, vh = np.linalg.svd(
        equilibrium / row_scale[:, None], full_matrices=True
    )
    stress = vh[-1]
    if stress.sum() < 0:
        stress = -stress
    stress /= np.sum(abs(stress))
    defect = target @ stress
    scale = np.dot(abs(target), abs(stress)) + 1e-300
    return defect / scale, defect, stress, singular_values, (a, q, h, target, support)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--deleted", type=int, default=0, choices=range(len(PAIRS)))
    parser.add_argument("--span", type=float, default=12.0)
    parser.add_argument("--iterations", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--min-stress", type=float, default=1e-5)
    parser.add_argument(
        "--objective",
        choices=("signed-l1", "ground-energy", "smallest-edge", "feasibility"),
        default="ground-energy",
        help=(
            "signed-l1 is the old sign-only ratio and is flat when every "
            "edge target has one sign; ground-energy uses a positive label "
            "scale; smallest-edge searches for mixed-sign target columns"
        ),
    )
    args = parser.parse_args()
    deleted_edge = PAIRS[args.deleted]

    def objective(parameters):
        ratio, defect, stress, _, data = circuit(parameters, deleted_edge)
        if args.objective == "feasibility":
            return -stress.min()
        if stress.min() < args.min_stress:
            # Keep the optimizer inside the positive-stress chamber.  A
            # unit penalty is not enough because the natural ground-energy
            # normalization can itself be larger than one.
            return 100.0 + 1.0e4 * (args.min_stress - stress.min())
        if args.objective == "signed-l1":
            return ratio
        a, q, h, target, support = data
        if args.objective == "smallest-edge":
            scale = np.max(abs(target)) + 1e-300
            return np.min(target) / scale
        z = 2.0 * q - 1.0
        node_scale = z * z * (1.0 + 1.0 / q + 1.0 / h) + 1e-4
        edge_scale = np.array(
            [a[j] * node_scale[i] + a[i] * node_scale[j] for i, j in support]
        )
        scale = np.dot(stress, edge_scale) + 1e-300
        return defect / scale

    dimension = 3 * N - 1
    result = differential_evolution(
        objective,
        [(-args.span, args.span)] * dimension,
        seed=args.seed,
        maxiter=args.iterations,
        popsize=15,
        tol=1e-10,
        polish=True,
        workers=1,
        updating="immediate",
    )
    ratio, defect, stress, singular_values, data = circuit(result.x, deleted_edge)
    a, q, h, target, support = data
    print("deleted edge", deleted_edge)
    print("optimizer", result.fun, result.success, result.message)
    print("target ratio", ratio, "raw defect", defect)
    print("minimum stress", stress.min())
    print("stress", repr(stress), "support", support)
    print("singular values", repr(singular_values))
    print("a", repr(a))
    print("q", repr(q))
    print("h", repr(h))
    print("target", repr(target))


if __name__ == "__main__":
    main()
