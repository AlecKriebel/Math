#!/usr/bin/env python3
"""Search K and its Jensen marginal on a fixed sparse conductance support.

Unlike ``search_positive_ground_circuits.py``, this discovery parameterization
uses positive conductances and solves the two ground equations.  Positivity is
therefore exact at floating level and there is no SVD sign chamber to cross.
For four labels the complete looped graph with one deleted edge has nine
conductances, the generic size of a two-ground equilibrium circuit.

Floating output is not a certificate.
"""

from __future__ import annotations

import argparse
from itertools import combinations_with_replacement

import numpy as np
from scipy.optimize import differential_evolution


def solve_grounds(a: np.ndarray, conductance: np.ndarray):
    pi = conductance.sum(axis=1)
    if np.any(pi <= 0):
        return None
    P = conductance / pi[:, None]
    t = P @ a / a
    q = np.zeros_like(a)
    h = np.zeros_like(a)
    for _ in range(50000):
        q1 = t / (t + 2.0 * (P @ (1.0 - q)))
        h1 = 1.0 / (1.0 + 2.0 * (P @ (a * (1.0 - h))) / a)
        error = max(np.max(abs(q1 - q)), np.max(abs(h1 - h)))
        q, h = q1, h1
        if error < 2e-13:
            break
    else:
        return None
    if np.any(q <= 0) or np.any(q >= 1) or np.any(h <= 0) or np.any(h >= 1):
        return None
    return pi, P, t, q, h


def unpack(x: np.ndarray, deleted: tuple[int, int], n: int = 4):
    pairs = list(combinations_with_replacement(range(n), 2))
    support = [edge for edge in pairs if edge != deleted]
    a = np.exp(np.r_[x[: n - 1], 0.0])
    weights = np.exp(np.r_[x[n - 1 :], 0.0])
    conductance = np.zeros((n, n))
    for weight, (i, j) in zip(weights, support):
        conductance[i, j] = conductance[j, i] = weight
    return a, conductance, support


def defects(x: np.ndarray, deleted: tuple[int, int], n: int = 4):
    a, conductance, support = unpack(x, deleted, n)
    solved = solve_grounds(a, conductance)
    if solved is None:
        return None
    pi, P, t, q, h = solved
    p = pi * a
    v = 0.5 - q
    lhs = np.dot(p, h * (P @ v - v / h) ** 2)
    rhs = 4.0 * np.dot(p, t * v * v / q)
    k_defect = rhs - lhs
    z = 2.0 * q - 1.0
    C = (4.0 - q) * z * z / (4.0 * q)
    A = z / 2.0 - z * z * (1.0 + h) / (8.0 * h)
    marginal = np.dot(p, t * C + A)
    endpoint = np.dot(p, q + h - 1.0)
    scale = np.dot(p, z * z * (1.0 + 1.0 / q + 1.0 / h))
    return k_defect, marginal, endpoint, scale, (a, conductance, pi, P, t, q, h, support)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--deleted", type=int, default=0, choices=range(10))
    parser.add_argument("--objective", choices=("k", "marginal", "endpoint"), default="marginal")
    parser.add_argument("--span", type=float, default=10.0)
    parser.add_argument("--iterations", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=1)
    args = parser.parse_args()
    pairs = list(combinations_with_replacement(range(4), 2))
    deleted = pairs[args.deleted]
    dimension = 3 + 8

    def objective(x):
        result = defects(x, deleted)
        if result is None:
            return 1e6
        index = {"k": 0, "marginal": 1, "endpoint": 2}[args.objective]
        return result[index] / (result[3] + 1e-20)

    result = differential_evolution(
        objective,
        [(-args.span, args.span)] * dimension,
        maxiter=args.iterations,
        popsize=14,
        seed=args.seed,
        tol=1e-10,
        polish=True,
        workers=1,
        updating="immediate",
    )
    values = defects(result.x, deleted)
    assert values is not None
    k_defect, marginal, endpoint, scale, data = values
    a, conductance, pi, P, t, q, h, support = data
    print("deleted", deleted, "support", support)
    print("optimizer", result.fun, result.success, result.message)
    print("K defect", k_defect, "marginal", marginal, "endpoint", endpoint, "scale", scale)
    print("parameters", repr(result.x))
    print("a", repr(a))
    print("conductance", repr(conductance))
    print("pi", repr(pi))
    print("t", repr(t))
    print("q", repr(q))
    print("h", repr(h))
    print("P", repr(P))


if __name__ == "__main__":
    main()
