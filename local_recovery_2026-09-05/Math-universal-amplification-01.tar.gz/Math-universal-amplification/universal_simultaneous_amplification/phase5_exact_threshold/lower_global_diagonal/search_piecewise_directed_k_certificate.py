#!/usr/bin/env python3
"""Search a piecewise-bilinear directed-flow certificate for the K marginal.

Discovery only.  The unknown numerators of alpha(q,h) and gamma(q,h) are
bilinear on each cell.  After multiplying the directed edge slack by
q_x h_x q_y h_y, every tensor Bernstein coefficient is linear in the grid
node values.  This script imposes all such coefficients simultaneously.
"""

from __future__ import annotations

import argparse
from itertools import product
from math import comb

import numpy as np
from scipy.optimize import linprog


DEGREES = (3, 2, 3, 2)


def scalar_constant(value: float):
    return {(0, 0, 0, 0): value}


def scalar_linear(axis: int, lower: float, upper: float):
    zero = (0, 0, 0, 0)
    unit = [0, 0, 0, 0]
    unit[axis] = 1
    return {zero: lower, tuple(unit): upper - lower}


def add(*polynomials):
    result = {}
    for polynomial in polynomials:
        for power, coefficient in polynomial.items():
            if power in result:
                result[power] = result[power] + coefficient
            else:
                result[power] = coefficient.copy() if isinstance(coefficient, np.ndarray) else coefficient
    return result


def scale(polynomial, value):
    return {power: value * coefficient for power, coefficient in polynomial.items()}


def multiply_scalar(left, right):
    result = {}
    for p, a in left.items():
        for q, b in right.items():
            power = tuple(p[k] + q[k] for k in range(4))
            result[power] = result.get(power, 0.0) + a * b
    return result


def multiply_affine_scalar(affine, scalar):
    result = {}
    for p, a in affine.items():
        for q, b in scalar.items():
            power = tuple(p[k] + q[k] for k in range(4))
            if power in result:
                result[power] = result[power] + b * a
            else:
                result[power] = b * a
    return result


def one_minus(polynomial):
    return add(scalar_constant(1.0), scale(polynomial, -1.0))


def bilinear_potential(
    iq: int,
    ih: int,
    q_axis: int,
    h_axis: int,
    offset: int,
    node_count: int,
    variable_count: int,
):
    result = {}

    def add_corner(dq, dh, terms):
        index = offset + (iq + dq) * node_count + ih + dh
        for power, coefficient in terms.items():
            if power not in result:
                result[power] = np.zeros(variable_count)
            result[power][index] += coefficient

    zero = (0, 0, 0, 0)
    uq = [0, 0, 0, 0]
    uh = [0, 0, 0, 0]
    uquh = [0, 0, 0, 0]
    uq[q_axis] = 1
    uh[h_axis] = 1
    uquh[q_axis] = uquh[h_axis] = 1
    uq, uh, uquh = tuple(uq), tuple(uh), tuple(uquh)
    add_corner(0, 0, {zero: 1.0, uq: -1.0, uh: -1.0, uquh: 1.0})
    add_corner(1, 0, {uq: 1.0, uquh: -1.0})
    add_corner(0, 1, {uh: 1.0, uquh: -1.0})
    add_corner(1, 1, {uquh: 1.0})
    return result


def bernstein_rows(polynomial, variable_count):
    rows = []
    for index in product(*[range(degree + 1) for degree in DEGREES]):
        coefficient = np.zeros(variable_count)
        for power, value in polynomial.items():
            if all(power[k] <= index[k] for k in range(4)):
                multiplier = 1.0
                for k in range(4):
                    multiplier *= comb(index[k], power[k]) / comb(DEGREES[k], power[k])
                coefficient += multiplier * value
        rows.append(coefficient)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--subdivisions", type=int, default=4)
    parser.add_argument("--skip-central", action="store_true")
    args = parser.parse_args()
    grid = np.linspace(0.0, 1.0, args.subdivisions + 1)
    node_count = len(grid)
    potential_count = node_count * node_count
    # Last coordinate is the common L-infinity bound on potential numerator
    # node values.  Coordinate zero in each affine vector is the constant.
    unknown_count = 2 * potential_count
    affine_count = 1 + unknown_count
    rows = []

    for iq, ih, jq, jh in product(range(node_count - 1), repeat=4):
        if args.skip_central:
            central = {
                k
                for k in range(node_count - 1)
                if grid[k] <= 0.5 <= grid[k + 1]
            }
            if iq in central and ih in central and jq in central and jh in central:
                continue
        q = scalar_linear(0, grid[iq], grid[iq + 1])
        h = scalar_linear(1, grid[ih], grid[ih + 1])
        Q = scalar_linear(2, grid[jq], grid[jq + 1])
        H = scalar_linear(3, grid[jh], grid[jh + 1])
        one_q = one_minus(q)
        one_h = one_minus(h)
        one_Q = one_minus(Q)

        z = add(scale(q, 2.0), scalar_constant(-1.0))
        Z = add(scale(Q, 2.0), scalar_constant(-1.0))

        # Cleared target q*h*Q*H [C(Q)+A(q,h)].
        target_c = scale(
            multiply_scalar(
                multiply_scalar(multiply_scalar(q, h), H),
                multiply_scalar(add(scalar_constant(4.0), scale(Q, -1.0)), multiply_scalar(Z, Z)),
            ),
            0.25,
        )
        bracket_a = add(
            scale(multiply_scalar(h, z), 0.5),
            scale(multiply_scalar(multiply_scalar(z, z), add(scalar_constant(1.0), h)), -0.125),
        )
        target_a = multiply_scalar(multiply_scalar(multiply_scalar(q, Q), H), bracket_a)

        alpha_x = bilinear_potential(iq, ih, 0, 1, 1, node_count, affine_count)
        alpha_y = bilinear_potential(jq, jh, 2, 3, 1, node_count, affine_count)
        gamma_x = bilinear_potential(
            iq, ih, 0, 1, 1 + potential_count, node_count, affine_count
        )
        gamma_y = bilinear_potential(
            jq, jh, 2, 3, 1 + potential_count, node_count, affine_count
        )

        # Cleared Bd and dB null-Lagrangian terms.
        term_alpha_y = multiply_affine_scalar(alpha_y, multiply_scalar(multiply_scalar(q, h), one_Q))
        term_alpha_x = scale(
            multiply_affine_scalar(
                alpha_x,
                multiply_scalar(multiply_scalar(multiply_scalar(q, Q), H), one_Q),
            ),
            -2.0,
        )
        term_gamma_x = multiply_affine_scalar(
            gamma_x, multiply_scalar(multiply_scalar(one_h, Q), H)
        )
        term_gamma_y = scale(
            multiply_affine_scalar(
                gamma_y,
                multiply_scalar(multiply_scalar(multiply_scalar(H, one_h), q), h),
            ),
            -2.0,
        )

        constant_affine = {}
        for power, value in add(target_c, target_a).items():
            vector = np.zeros(affine_count)
            vector[0] = value
            constant_affine[power] = vector
        numerator = add(
            constant_affine,
            term_alpha_y,
            term_alpha_x,
            term_gamma_x,
            term_gamma_y,
        )
        rows.extend(bernstein_rows(numerator, affine_count))

    # b_0 + sum b_i x_i >= 0 for every Bernstein coefficient.
    matrix = np.array([-row[1:] for row in rows])
    rhs = np.array([row[0] for row in rows])

    # Add |x_i| <= L.
    total_variables = unknown_count + 1
    augmented = np.zeros((len(rows) + 2 * unknown_count, total_variables))
    augmented[: len(rows), :unknown_count] = matrix
    augmented_rhs = np.r_[rhs, np.zeros(2 * unknown_count)]
    cursor = len(rows)
    for i in range(unknown_count):
        augmented[cursor, i] = 1.0
        augmented[cursor, -1] = -1.0
        cursor += 1
        augmented[cursor, i] = -1.0
        augmented[cursor, -1] = -1.0
        cursor += 1

    objective = np.zeros(total_variables)
    objective[-1] = 1.0
    result = linprog(
        objective,
        A_ub=augmented,
        b_ub=augmented_rhs,
        bounds=[(None, None)] * unknown_count + [(0.0, None)],
        method="highs",
    )
    print(result.success, result.message)
    if result.success:
        print("minimum numerator-node L-infinity norm", result.fun)
        print("alpha numerator nodes")
        print(result.x[:potential_count].reshape(node_count, node_count))
        print("gamma numerator nodes")
        print(result.x[potential_count:unknown_count].reshape(node_count, node_count))


if __name__ == "__main__":
    main()
