#!/usr/bin/env python3
"""Discovery: exact-lumped dense two-class graphs near fitness two.

This is a numerical search tool only.  It solves the full count-state
absorbing chain for a complete two-class weighted graph and reports the
Bd-gain / dB-loss response ratio.  No establishment approximation is used.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution


def baseline(n: int, r: float, rule: str) -> float:
    if rule == "Bd":
        return (1.0 - 1.0 / r) / (1.0 - r ** (-n))
    return ((n - 1.0) / n) * (1.0 - 1.0 / r) / (1.0 - r ** (-(n - 1)))


def fixation(a: int, b: int, r: float, rule: str,
             waa: float, wbb: float, wab: float) -> float:
    """Uniform-singleton fixation in the full two-count quotient."""
    n = a + b
    d_a = (a - 1) * waa + b * wab
    d_b = (b - 1) * wbb + a * wab
    states = [
        (i, j) for i in range(a + 1) for j in range(b + 1)
        if (i, j) not in ((0, 0), (a, b))
    ]
    index = {state: row for row, state in enumerate(states)}
    # Delete self loops: the harmonic row is total-changing-rate on the
    # diagonal minus each changing transition rate off the diagonal.
    matrix = np.zeros((len(states), len(states)))
    rhs = np.zeros(len(states))

    for state, row in index.items():
        i, j = state
        k = i + j
        rates: dict[tuple[int, int], float] = {}

        def add(target: tuple[int, int], rate: float) -> None:
            if rate:
                rates[target] = rates.get(target, 0.0) + rate

        if rule == "Bd":
            total_fitness = r * k + n - k
            if i:
                reproduce = r * i / total_fitness
                add((i + 1, j), reproduce * (a - i) * waa / d_a)
                add((i, j + 1), reproduce * (b - j) * wab / d_a)
            if j:
                reproduce = r * j / total_fitness
                add((i + 1, j), reproduce * (a - i) * wab / d_b)
                add((i, j + 1), reproduce * (b - j) * wbb / d_b)
            if a - i:
                reproduce = (a - i) / total_fitness
                add((i - 1, j), reproduce * i * waa / d_a)
                add((i, j - 1), reproduce * j * wab / d_a)
            if b - j:
                reproduce = (b - j) / total_fitness
                add((i - 1, j), reproduce * i * wab / d_b)
                add((i, j - 1), reproduce * j * wbb / d_b)
        elif rule == "dB":
            if a - i:
                denominator = r * (i * waa + j * wab) + (
                    (a - i - 1) * waa + (b - j) * wab
                )
                add((i + 1, j), (a - i) / n * r *
                    (i * waa + j * wab) / denominator)
            if i:
                denominator = r * ((i - 1) * waa + j * wab) + (
                    (a - i) * waa + (b - j) * wab
                )
                add((i - 1, j), i / n *
                    ((a - i) * waa + (b - j) * wab) / denominator)
            if b - j:
                denominator = r * (i * wab + j * wbb) + (
                    (a - i) * wab + (b - j - 1) * wbb
                )
                add((i, j + 1), (b - j) / n * r *
                    (i * wab + j * wbb) / denominator)
            if j:
                denominator = r * (i * wab + (j - 1) * wbb) + (
                    (a - i) * wab + (b - j) * wbb
                )
                add((i, j - 1), j / n *
                    ((a - i) * wab + (b - j) * wbb) / denominator)
        else:
            raise ValueError(rule)

        matrix[row, row] = sum(rates.values())
        for target, probability in rates.items():
            if target == (a, b):
                rhs[row] += probability
            elif target != (0, 0):
                matrix[row, index[target]] -= probability

    solution = np.linalg.solve(matrix, rhs)
    return (
        a * solution[index[(1, 0)]]
        + b * solution[index[(0, 1)]]
    ) / n


def ratios(a: int, b: int, r: float, logs: np.ndarray) -> tuple[float, float]:
    waa, wbb, wab = np.exp(logs)
    n = a + b
    return tuple(
        fixation(a, b, r, rule, waa, wbb, wab) / baseline(n, r, rule)
        for rule in ("Bd", "dB")
    )  # type: ignore[return-value]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--a", type=int, default=2)
    parser.add_argument("--b", type=int, default=30)
    parser.add_argument("--r", type=float, default=1.9)
    parser.add_argument("--seed", type=int, default=20260808)
    args = parser.parse_args()

    # Fix the irrelevant global scale by setting wbb=1 in the objective.
    def objective(point: np.ndarray) -> float:
        x, y = ratios(args.a, args.b, args.r,
                      np.array([point[0], 0.0, point[1]]))
        gain = x - 1.0
        loss = max(1.0 - y, 1.0e-12)
        # First favor an actual Bd amplifier, then its gain/loss ratio.
        if gain <= 0:
            return 10.0 - gain
        return -math.log1p(gain / loss)

    result = differential_evolution(
        objective,
        [(-12.0, 12.0), (-12.0, 12.0)],
        seed=args.seed,
        popsize=20,
        maxiter=160,
        polish=True,
        workers=1,
        updating="immediate",
    )
    logs = np.array([result.x[0], 0.0, result.x[1]])
    x, y = ratios(args.a, args.b, args.r, logs)
    print(f"a={args.a} b={args.b} r={args.r}")
    print("weights", np.exp(logs))
    print("Bd ratio", x, "dB ratio", y)
    print("gain/loss", (x - 1.0) / max(1.0 - y, 1.0e-300))


if __name__ == "__main__":
    main()
