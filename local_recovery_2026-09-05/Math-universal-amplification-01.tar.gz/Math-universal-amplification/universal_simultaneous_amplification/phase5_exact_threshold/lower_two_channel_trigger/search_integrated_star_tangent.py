#!/usr/bin/env python3
"""Exact-orbit discovery search for a growing integrated star tangent."""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def local_success(
    leaves: int,
    fitness: float,
    rule: str,
    internal_weight: float,
    hub_portal: float,
    leaf_portal: float,
) -> tuple[float, float]:
    states = [(hub, count) for hub in (0, 1) for count in range(leaves + 1)]
    empty = (0, 0)
    active = [state for state in states if state != empty]
    index = {state: row for row, state in enumerate(active)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(active))
    degree_hub = leaves * internal_weight + hub_portal
    degree_leaf = internal_weight + leaf_portal
    p = 1 - 1 / fitness

    for state, row in index.items():
        hub, count = state
        moves: dict[tuple[int, int], float] = {}

        def add(target: tuple[int, int], rate: float) -> None:
            if rate > 0:
                moves[target] = moves.get(target, 0.0) + rate

        if rule == "Bd":
            if not hub and count:
                add((1, count), fitness * count * internal_weight / degree_leaf)
            if hub and count < leaves:
                add((0, count), (leaves - count) * internal_weight / degree_leaf)
            if hub and count < leaves:
                add(
                    (1, count + 1),
                    fitness * (leaves - count) * internal_weight / degree_hub,
                )
            if not hub and count:
                add((0, count - 1), count * internal_weight / degree_hub)
            if hub:
                add((0, count), hub_portal)
            if count:
                add((hub, count - 1), count * leaf_portal)
            mark = fitness * p * (
                hub * hub_portal / degree_hub
                + count * leaf_portal / degree_leaf
            )
        elif rule == "dB":
            mutant_mass = count * internal_weight
            resident_mass = (leaves - count) * internal_weight + hub_portal
            denominator = fitness * mutant_mass + resident_mass
            if not hub and mutant_mass:
                add((1, count), fitness * mutant_mass / denominator)
            if hub and resident_mass:
                add((0, count), resident_mass / denominator)

            if hub and count < leaves:
                add(
                    (1, count + 1),
                    (leaves - count)
                    * fitness
                    * internal_weight
                    / (fitness * internal_weight + leaf_portal),
                )
            if count:
                if hub:
                    recovery = leaf_portal / (
                        fitness * internal_weight + leaf_portal
                    )
                else:
                    recovery = 1.0
                add((hub, count - 1), count * recovery)
            mark = fitness * p * (hub * hub_portal + count * leaf_portal)
        else:
            raise ValueError(rule)

        total = mark + sum(moves.values())
        rows.append(row)
        columns.append(row)
        entries.append(total)
        rhs[row] = mark
        for target, rate in moves.items():
            if target != empty:
                rows.append(row)
                columns.append(index[target])
                entries.append(-rate)

    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(active), len(active))
    ).tocsr()
    solution = spsolve(matrix, rhs)
    if np.max(np.abs(matrix @ solution - rhs)) > 2e-8:
        raise FloatingPointError
    return float(solution[index[(1, 0)]]), float(solution[index[(0, 1)]])


def response(
    leaves: int,
    fitness: float,
    internal_weight: float,
    hub_portal: float,
    leaf_portal: float,
) -> tuple[float, ...]:
    p = 1 - 1 / fitness
    degree_hub = leaves * internal_weight + hub_portal
    degree_leaf = internal_weight + leaf_portal
    ub_h, ub_l = local_success(
        leaves, fitness, "Bd", internal_weight, hub_portal, leaf_portal
    )
    ud_h, ud_l = local_success(
        leaves, fitness, "dB", internal_weight, hub_portal, leaf_portal
    )
    source_b = fitness * (hub_portal * ub_h + leaves * leaf_portal * ub_l)
    source_b -= (fitness - 1) * (
        hub_portal / degree_hub + leaves * leaf_portal / degree_leaf
    )
    source_d = fitness * (
        hub_portal * ud_h / degree_hub
        + leaves * leaf_portal * ud_l / degree_leaf
    )
    source_d -= (fitness - 1) * (
        hub_portal + leaves * leaf_portal + fitness - 1
    )
    order = leaves + 1
    bd = (ub_h + leaves * ub_l) / p - order
    bd += source_b / (fitness - 1) ** 2
    db = (ud_h + leaves * ud_l) / p - order + 1
    db += source_d / (fitness - 1) ** 2
    separator = db + (fitness - 1) * bd
    leaf_ratio = max(0.0, (fitness - 1) * (db - bd) / fitness)
    balanced = min(bd + leaf_ratio / (fitness - 1), db - leaf_ratio)
    return separator, balanced, bd, db, leaf_ratio, ub_h, ub_l, ud_h, ud_l


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--leaves", type=int, default=20)
    parser.add_argument("--fitness", type=float, default=1.9)
    parser.add_argument("--maxiter", type=int, default=100)
    parser.add_argument("--span", type=float, default=28.0)
    args = parser.parse_args()

    def objective(parameters: np.ndarray) -> float:
        try:
            return -response(
                args.leaves,
                args.fitness,
                math.exp(float(parameters[0])),
                math.exp(float(parameters[1])),
                math.exp(float(parameters[2])),
            )[0]
        except (FloatingPointError, ArithmeticError):
            return 1e9

    result = differential_evolution(
        objective,
        [(-args.span, args.span)] * 3,
        seed=20260808 + args.leaves,
        maxiter=args.maxiter,
        popsize=16,
        polish=True,
        tol=1e-11,
    )
    internal_weight, hub_portal, leaf_portal = np.exp(result.x)
    values = response(
        args.leaves, args.fitness, internal_weight, hub_portal, leaf_portal
    )
    print(
        {
            "leaves": args.leaves,
            "fitness": args.fitness,
            "internal_weight": float(internal_weight),
            "hub_portal": float(hub_portal),
            "leaf_portal": float(leaf_portal),
            "separator": values[0],
            "balanced": values[1],
            "Bd": values[2],
            "dB": values[3],
            "local": values[5:],
        }
    )


if __name__ == "__main__":
    main()
