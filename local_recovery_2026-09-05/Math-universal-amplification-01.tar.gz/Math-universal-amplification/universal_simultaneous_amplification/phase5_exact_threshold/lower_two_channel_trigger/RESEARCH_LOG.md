# Two-channel trigger research log

## 2026-08-08

- Opened a dedicated full-chain screen for a population of paired trigger
  vertices whose two roots communicate through distinct dense layers.
- The orbit state `(n10,n01,n11)` retains pair discordance and both channel
  dynamics; no separated-establishment approximation is used.
- Numerical optimization is discovery only.  Any positive lead must be
  independently aggregated from the labelled chain and exactified before it
  can support a claim.
- The first full-chain optimization at fitness `1.55,1.70,1.90,1.99` and
  `Q=7,8,10` found no lead.  Every run collapsed to the equal-layer line,
  where Bd is neutral to floating precision and dB is strictly suppressing
  (normalized dB about `0.972--0.982`).  This is evidence only, but it rules
  out the simplest two-layer prism as the immediate realization of the
  opposite-root trigger idea.
- Opened a separate singular-growing-rank screen for path relays with
  endpoint-only core portals and geometrically graded internal weights.  Its
  objective is the exact full integrated-gadget separator, including local
  absorption, both singleton classes, core recovery/marking, reciprocal
  invasion, and the ordinary-core Poisson term.
- Added an exact orbit implementation of the corresponding growing star
  tangent, with independent hub and leaf portal loads.  This specifically
  tests whether the proved same-direction star diode can survive the full
  uniform-start and far-field correction when it is integrated rather than
  resolved as a separated antenna.
