#!/usr/bin/env python3
"""Discovery search for a fully nonseparated two-layer pair population.

There are Q labelled pairs (A_i,B_i).  The A vertices form a weighted
complete graph of total incident weight x, the B vertices form one of total
incident weight y, and A_i--B_i has weight a.  Pair resolution and both
layer channels compete at every polymorphic state.  The exact orbit state is
(n10,n01,n11), so this is a full fixation calculation, not an establishment
approximation.  Floating optimization is for discovery only.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


TYPES = ((0, 0), (1, 0), (0, 1), (1, 1))


def states(order: int) -> list[tuple[int, int, int]]:
    return [
        (n10, n01, n11)
        for n10 in range(order + 1)
        for n01 in range(order - n10 + 1)
        for n11 in range(order - n10 - n01 + 1)
        if (n10, n01, n11) not in ((0, 0, 0), (0, 0, order))
    ]


def transition_state(
    state: tuple[int, int, int], source_type: int, target_type: int
) -> tuple[int, int, int]:
    counts = [None, state[0], state[1], state[2]]
    if source_type:
        counts[source_type] -= 1
    if target_type:
        counts[target_type] += 1
    return counts[1], counts[2], counts[3]


def fixation(order: int, fitness: float, rule: str, a: float, x: float, y: float) -> float:
    transient = states(order)
    index = {state: row for row, state in enumerate(transient)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(transient))
    empty = (0, 0, 0)
    full = (0, 0, order)
    degree_a = a + x
    degree_b = a + y
    layer_a = x / (order - 1)
    layer_b = y / (order - 1)

    for state, row in index.items():
        counts = [order - sum(state), state[0], state[1], state[2]]
        mutant_a = counts[1] + counts[3]
        mutant_b = counts[2] + counts[3]
        moves: dict[tuple[int, int, int], float] = {}

        def add(source_type: int, target_type: int, rate: float) -> None:
            if rate <= 0:
                return
            target = transition_state(state, source_type, target_type)
            moves[target] = moves.get(target, 0.0) + rate

        for type_index, multiplicity in enumerate(counts):
            if not multiplicity:
                continue
            bit_a, bit_b = TYPES[type_index]

            if rule == "Bd":
                if not bit_a:
                    rate = fitness * (
                        bit_b * a / degree_b
                        + mutant_a * layer_a / degree_a
                    )
                    add(type_index, TYPES.index((1, bit_b)), multiplicity * rate)
                else:
                    rate = (1 - bit_b) * a / degree_b
                    rate += (order - mutant_a) * layer_a / degree_a
                    add(type_index, TYPES.index((0, bit_b)), multiplicity * rate)

                if not bit_b:
                    rate = fitness * (
                        bit_a * a / degree_a
                        + mutant_b * layer_b / degree_b
                    )
                    add(type_index, TYPES.index((bit_a, 1)), multiplicity * rate)
                else:
                    rate = (1 - bit_a) * a / degree_a
                    rate += (order - mutant_b) * layer_b / degree_b
                    add(type_index, TYPES.index((bit_a, 0)), multiplicity * rate)

            elif rule == "dB":
                mutant_mass = bit_b * a + (mutant_a - bit_a) * layer_a
                resident_mass = (1 - bit_b) * a
                resident_mass += (order - mutant_a - (1 - bit_a)) * layer_a
                denominator = fitness * mutant_mass + resident_mass
                if not bit_a and mutant_mass:
                    add(
                        type_index,
                        TYPES.index((1, bit_b)),
                        multiplicity * fitness * mutant_mass / denominator,
                    )
                elif bit_a and resident_mass:
                    add(
                        type_index,
                        TYPES.index((0, bit_b)),
                        multiplicity * resident_mass / denominator,
                    )

                mutant_mass = bit_a * a + (mutant_b - bit_b) * layer_b
                resident_mass = (1 - bit_a) * a
                resident_mass += (order - mutant_b - (1 - bit_b)) * layer_b
                denominator = fitness * mutant_mass + resident_mass
                if not bit_b and mutant_mass:
                    add(
                        type_index,
                        TYPES.index((bit_a, 1)),
                        multiplicity * fitness * mutant_mass / denominator,
                    )
                elif bit_b and resident_mass:
                    add(
                        type_index,
                        TYPES.index((bit_a, 0)),
                        multiplicity * resident_mass / denominator,
                    )
            else:
                raise ValueError(rule)

        total = sum(moves.values())
        if total <= 0:
            raise ArithmeticError((state, rule))
        rows.append(row)
        columns.append(row)
        entries.append(total)
        for target, rate in moves.items():
            if target == full:
                rhs[row] += rate
            elif target != empty:
                rows.append(row)
                columns.append(index[target])
                entries.append(-rate)

    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(transient), len(transient))
    ).tocsr()
    harmonic = spsolve(matrix, rhs)
    residual = float(np.max(np.abs(matrix @ harmonic - rhs)))
    if residual > 2e-7:
        raise FloatingPointError(residual)
    singleton_a = harmonic[index[(1, 0, 0)]]
    singleton_b = harmonic[index[(0, 1, 0)]]
    return float((singleton_a + singleton_b) / 2)


def baseline(size: int, fitness: float, rule: str) -> float:
    if rule == "Bd":
        return (1 - 1 / fitness) / (1 - fitness ** (-size))
    return (
        (1 - 1 / fitness)
        * (size - 1)
        / (size * (1 - fitness ** (1 - size)))
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pairs", type=int, default=10)
    parser.add_argument("--fitness", type=float, default=1.9)
    parser.add_argument("--maxiter", type=int, default=100)
    args = parser.parse_args()
    size = 2 * args.pairs
    base_b = baseline(size, args.fitness, "Bd")
    base_d = baseline(size, args.fitness, "dB")

    def score(parameters: np.ndarray) -> tuple[float, float]:
        x, y = np.exp(parameters)
        bd = fixation(args.pairs, args.fitness, "Bd", 1.0, x, y)
        db = fixation(args.pairs, args.fitness, "dB", 1.0, x, y)
        return bd / base_b, db / base_d

    def objective(parameters: np.ndarray) -> float:
        try:
            return -min(score(parameters))
        except (ArithmeticError, FloatingPointError):
            return 1e6

    result = differential_evolution(
        objective,
        [(-16, 16), (-16, 16)],
        seed=20260808,
        maxiter=args.maxiter,
        popsize=12,
        tol=1e-9,
        polish=True,
    )
    print(
        {
            "pairs": args.pairs,
            "fitness": args.fitness,
            "x": math.exp(float(result.x[0])),
            "y": math.exp(float(result.x[1])),
            "ratios": score(result.x),
            "objective": -float(result.fun),
        }
    )


if __name__ == "__main__":
    main()
