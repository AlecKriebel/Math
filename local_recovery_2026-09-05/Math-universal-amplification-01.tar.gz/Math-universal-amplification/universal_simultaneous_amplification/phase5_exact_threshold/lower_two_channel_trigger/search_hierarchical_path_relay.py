#!/usr/bin/env python3
"""Discovery search for a singular growing path relay in the dilute tangent.

The gadget is a path of ``s`` vertices.  Only its two endpoints have portal
load to the large clique.  Internal edge weights form a geometric profile.
The full nonempty subset chain is solved, including core recovery, marking,
uniform singleton starts, reciprocal invasion, and the ordinary-core
far-field term through the exact integrated-gadget tangent formula.

This is floating discovery code.  It makes no theorem claim.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def local_success(
    internal: np.ndarray, portal: np.ndarray, fitness: float, rule: str
) -> np.ndarray:
    order = len(portal)
    degrees = portal + internal.sum(axis=1)
    full = (1 << order) - 1
    states = list(range(1, full + 1))
    index = {mask: row for row, mask in enumerate(states)}
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    rhs = np.zeros(len(states))
    p = 1 - 1 / fitness

    for mask, row in index.items():
        mutant = np.array([(mask >> vertex) & 1 for vertex in range(order)])
        moves: dict[int, float] = {}

        def add(target: int, rate: float) -> None:
            if rate > 0:
                moves[target] = moves.get(target, 0.0) + rate

        if rule == "Bd":
            for parent in range(order):
                parent_fitness = fitness if mutant[parent] else 1.0
                for target in np.flatnonzero(internal[parent]):
                    if mutant[parent] != mutant[target]:
                        add(
                            mask ^ (1 << int(target)),
                            parent_fitness * internal[parent, target] / degrees[parent],
                        )
            for target in np.flatnonzero(mutant):
                add(mask ^ (1 << int(target)), portal[target])
            mark = fitness * p * float(
                np.sum(portal[mutant == 1] / degrees[mutant == 1])
            )
        elif rule == "dB":
            vertex_fitness = np.where(mutant, fitness, 1.0)
            for target in range(order):
                denominator = portal[target] + float(internal[target] @ vertex_fitness)
                if mutant[target]:
                    recovery = portal[target] + float(
                        np.sum(internal[target, mutant == 0])
                    )
                    add(mask ^ (1 << target), recovery / denominator)
                else:
                    invasion = fitness * float(
                        np.sum(internal[target, mutant == 1])
                    )
                    add(mask ^ (1 << target), invasion / denominator)
            mark = fitness * p * float(np.sum(portal[mutant == 1]))
        else:
            raise ValueError(rule)

        exit_rate = mark + sum(moves.values())
        rows.append(row)
        columns.append(row)
        entries.append(exit_rate)
        rhs[row] = mark
        for target, rate in moves.items():
            if target:
                rows.append(row)
                columns.append(index[target])
                entries.append(-rate)

    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(states), len(states))
    ).tocsr()
    solution = spsolve(matrix, rhs)
    residual = float(np.max(np.abs(matrix @ solution - rhs)))
    if residual > 2e-7 or np.min(solution) < -2e-7 or np.max(solution) > 1 + 2e-7:
        raise FloatingPointError(residual)
    return np.array([solution[index[1 << vertex]] for vertex in range(order)])


def decode(order: int, parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    edge_scale, edge_slope, right_portal = parameters
    internal = np.zeros((order, order))
    center = (order - 2) / 2
    for left in range(order - 1):
        value = math.exp(edge_scale + edge_slope * (left - center))
        internal[left, left + 1] = internal[left + 1, left] = value
    portal = np.zeros(order)
    portal[0] = 1.0
    portal[-1] = math.exp(right_portal)
    return internal, portal


def response(order: int, fitness: float, parameters: np.ndarray) -> tuple[float, ...]:
    internal, portal = decode(order, parameters)
    degrees = portal + internal.sum(axis=1)
    p = 1 - 1 / fitness
    bd_local = local_success(internal, portal, fitness, "Bd")
    db_local = local_success(internal, portal, fitness, "dB")
    source_bd = fitness * float(portal @ bd_local)
    source_bd -= (fitness - 1) * float(np.sum(portal / degrees))
    source_db = fitness * float((portal / degrees) @ db_local)
    source_db -= (fitness - 1) * (float(np.sum(portal)) + fitness - 1)
    bd = float(np.sum(bd_local)) / p - order
    bd += source_bd / (fitness - 1) ** 2
    db = float(np.sum(db_local)) / p - order + 1
    db += source_db / (fitness - 1) ** 2
    separator = db + (fitness - 1) * bd
    leaf_ratio = max(0.0, (fitness - 1) * (db - bd) / fitness)
    balanced = min(bd + leaf_ratio / (fitness - 1), db - leaf_ratio)
    return separator, balanced, bd, db, leaf_ratio, *parameters


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--order", type=int, default=7)
    parser.add_argument("--fitness", type=float, default=1.9)
    parser.add_argument("--maxiter", type=int, default=120)
    parser.add_argument("--span", type=float, default=25.0)
    args = parser.parse_args()

    def objective(parameters: np.ndarray) -> float:
        try:
            return -response(args.order, args.fitness, parameters)[0]
        except (FloatingPointError, ArithmeticError, ValueError):
            return 1e9

    result = differential_evolution(
        objective,
        [(-args.span, args.span)] * 3,
        seed=20260808 + args.order,
        maxiter=args.maxiter,
        popsize=12,
        polish=True,
        tol=1e-10,
    )
    values = response(args.order, args.fitness, result.x)
    print(
        {
            "order": args.order,
            "fitness": args.fitness,
            "separator": values[0],
            "balanced": values[1],
            "Bd": values[2],
            "dB": values[3],
            "leaf_ratio": values[4],
            "edge_scale": values[5],
            "edge_slope": values[6],
            "right_portal_log": values[7],
        }
    )


if __name__ == "__main__":
    main()
