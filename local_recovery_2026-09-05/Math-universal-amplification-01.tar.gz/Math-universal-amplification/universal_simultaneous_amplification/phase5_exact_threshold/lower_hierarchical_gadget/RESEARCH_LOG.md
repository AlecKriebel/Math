# Hierarchical separated-gadget search

Date opened: 2026-08-08 (America/Los_Angeles).

This branch tests one proof-relevant surviving mechanism: a finite satellite
that shares one portal gate between a dB-favourable heavy pair and a
Bd-favourable star.  The leaf orbit is lumped exactly, so the isolated
fixation vectors use `8(L+1)-2` states rather than a sampled or branching
approximation.  Numerical optimization is discovery only; any positive
separator must be reconstructed exactly before it becomes a claim.

## First bounded screen

The quotient was independently checked against the full labelled subset
chain for one through three leaves under both update rules (maximum floating
discrepancy below `5e-15`).  Differential-evolution screens with arbitrary
orbit portal loads found no positive leaf-eliminated separator.  At fitness
`1.9`, the four-leaf gadget optimized to `-2.0597...`; at fitness `1.55`,
the two-, three-, five-, and eight-leaf variants were all strictly negative.
The optimizer runs to singular portal boundaries rather than revealing a
shared-gate improvement.  This is numerical route triage only.  The branch
is frozen unless a new analytic mechanism changes the parameterization.
# Growing complete-bipartite module screen

Added `search_growing_bipartite.py`, an exact two-count-chain/numerical
response-cone discovery screen for separated `K_{a,b}` satellites with two
independently scaled portal-load classes.  This regime has both class sizes
free to diverge and is therefore outside the fixed-order Taylor obstruction.
All reported signs remain discovery-only until independently exactified.

## Hierarchical pair-star screen

Added `search_pair_of_pairs_star.py`.  Its exact quotient retains the two
central vertex types and the counts of all four peripheral-pair types.  This
tests a growing hierarchy of `K_2` primitives rather than another fixed
bounded gadget.  The outer parameter optimization is numerical discovery;
the chain rows and response include reciprocal invasion and the full
separated macro gate.
