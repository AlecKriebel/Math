#!/usr/bin/env python3
"""Discovery search for a growing star of internally strong pairs.

The connected separated satellite consists of a central edge ``a--h`` and
``L`` identical peripheral edges ``x_j--y_j``; every ``x_j`` is also joined
to ``h``.  Peripheral pair configurations are lumped by their four type
counts, so the quotient is exact.  Numerical optimization is discovery only.
"""

from __future__ import annotations

import argparse
import math
from itertools import product

import numpy as np
from scipy.optimize import differential_evolution, minimize_scalar
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


PAIR_TYPES = ((0, 0), (1, 0), (0, 1), (1, 1))


def all_states(L: int):
    states = []
    for a, h in product((0, 1), repeat=2):
        for n10 in range(L + 1):
            for n01 in range(L - n10 + 1):
                for n11 in range(L - n10 - n01 + 1):
                    state = (a, h, n10, n01, n11)
                    if state not in ((0, 0, 0, 0, 0), (1, 1, 0, 0, L)):
                        states.append(state)
    return states


def counts(L: int, state):
    a, h, n10, n01, n11 = state
    return [L - n10 - n01 - n11, n10, n01, n11]


def replace_pair(state, source_type: int, target_type: int):
    a, h, n10, n01, n11 = state
    c = [None, n10, n01, n11]
    if source_type:
        c[source_type] -= 1
    if target_type:
        c[target_type] += 1
    return (a, h, c[1], c[2], c[3])


def fixation_orbits(L: int, r: float, rule: str, A: float, C: float, W: float):
    empty = (0, 0, 0, 0, 0)
    full = (1, 1, 0, 0, L)
    states = all_states(L)
    index = {s: i for i, s in enumerate(states)}
    rows, cols, data = [], [], []
    rhs = np.zeros(len(states))
    d_a, d_h, d_x, d_y = A, A + L * C, C + W, W

    for state, row in index.items():
        a, h, *_ = state
        cc = counts(L, state)
        fa, fh = (r if a else 1.0), (r if h else 1.0)
        moves = {}

        def add(target, rate):
            if rate:
                moves[target] = moves.get(target, 0.0) + rate

        if rule == "Bd":
            if a != h:
                add((a, a, *state[2:]), fa * A / d_a)
                add((h, h, *state[2:]), fh * A / d_h)
            for typ, (x, y) in enumerate(PAIR_TYPES):
                mult = cc[typ]
                if not mult:
                    continue
                fx, fy = (r if x else 1.0), (r if y else 1.0)
                if h != x:
                    # h -> x changes one peripheral pair.
                    new_type = PAIR_TYPES.index((h, y))
                    add(replace_pair(state, typ, new_type), mult * fh * C / d_h)
                    # x -> h changes the unique hub.
                    add((a, x, *state[2:]), mult * fx * C / d_x)
                if x != y:
                    add(replace_pair(state, typ, PAIR_TYPES.index((x, x))),
                        mult * fx * W / d_x)
                    add(replace_pair(state, typ, PAIR_TYPES.index((y, y))),
                        mult * fy * W / d_y)
        elif rule == "dB":
            if a != h:
                add((h, h, *state[2:]), 1.0)

            mutant_x = sum(cc[t] * PAIR_TYPES[t][0] for t in range(4))
            hub_mutant_mass = A * a + C * mutant_x
            hub_total_fit_mass = A * fa + C * sum(
                cc[t] * (r if PAIR_TYPES[t][0] else 1.0) for t in range(4)
            )
            if h == 0 and hub_mutant_mass:
                add((a, 1, *state[2:]), r * hub_mutant_mass / hub_total_fit_mass)
            if h == 1:
                resident_mass = A * (1 - a) + C * (L - mutant_x)
                if resident_mass:
                    add((a, 0, *state[2:]), resident_mass / hub_total_fit_mass)

            for typ, (x, y) in enumerate(PAIR_TYPES):
                mult = cc[typ]
                if not mult:
                    continue
                fh_local, fy = (r if h else 1.0), (r if y else 1.0)
                den_x = C * fh_local + W * fy
                if x == 0:
                    mut = C * h + W * y
                    if mut:
                        add(replace_pair(state, typ, PAIR_TYPES.index((1, y))),
                            mult * r * mut / den_x)
                else:
                    res = C * (1 - h) + W * (1 - y)
                    if res:
                        add(replace_pair(state, typ, PAIR_TYPES.index((0, y))),
                            mult * res / den_x)
                if x != y:
                    add(replace_pair(state, typ, PAIR_TYPES.index((x, x))), mult)
        else:
            raise ValueError(rule)

        mass = sum(moves.values())
        if mass <= 0:
            raise ArithmeticError((rule, state))
        rows.append(row); cols.append(row); data.append(mass)
        for target, rate in moves.items():
            if target == full:
                rhs[row] += rate
            elif target != empty:
                rows.append(row); cols.append(index[target]); data.append(-rate)

    matrix = coo_matrix((data, (rows, cols)), shape=(len(states), len(states))).tocsr()
    sol = spsolve(matrix, rhs)
    singleton_states = [
        (1, 0, 0, 0, 0),
        (0, 1, 0, 0, 0),
        (0, 0, 1, 0, 0),
        (0, 0, 0, 1, 0),
    ]
    return np.array([sol[index[s]] for s in singleton_states])


def decode(params):
    logs = np.r_[0.0, params]
    edge = logs[:3] - np.mean(logs[:3])
    portal = logs[3:] - np.mean(logs[3:])
    return *np.exp(edge), np.exp(portal)


def score(L: int, r: float, params):
    A, C, W, portals = decode(params)
    bp = fixation_orbits(L, r, "Bd", A, C, W)
    dp = fixation_orbits(L, r, "dB", A, C, W)
    bm = fixation_orbits(L, 1 / r, "Bd", A, C, W)
    dm = fixation_orbits(L, 1 / r, "dB", A, C, W)
    mult = np.array((1.0, 1.0, float(L), float(L)))
    s = 2 + 2 * L
    p = 1 - 1 / r
    aB = float(mult @ bp / (s * p))
    aD = float(mult @ dp / (s * p))
    deg = np.array((A, A + L * C, C + W, W))
    S0 = float(mult @ (portals / deg))
    PP = float(mult @ portals)
    SB = float(mult @ (portals * bm))
    SD = float(mult @ (portals * dm / deg))
    K = r * (r - 1) ** 2 * S0 * PP / (SB * SD)

    def sep(logz):
        z = math.exp(logz)
        return aD * K / (K + z) + (r - 1) * aB * z / (1 + z) - r

    opt = minimize_scalar(lambda z: -sep(z), bounds=(-50, 50), method="bounded")
    zs = [(-50, sep(-50)), (50, sep(50)), (opt.x, -opt.fun)]
    logz, per = max(zs, key=lambda q: q[1])
    z = math.exp(logz)
    B = s * (aB * z / (1 + z) - 1)
    D = s * (aD * K / (K + z) - 1)
    return dict(separator=s * per, B=B, D=D, aB=aB, aD=aD, K=K,
                z=z, edges=(A, C, W), portals=portals)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", type=int, default=3)
    ap.add_argument("--fitness", type=float, default=1.9)
    ap.add_argument("--bound", type=float, default=12)
    ap.add_argument("--maxiter", type=int, default=100)
    ap.add_argument("--seed", type=int, default=811)
    args = ap.parse_args()
    def objective(x):
        try:
            return -score(args.pairs, args.fitness, x)["separator"]
        except Exception:
            return 1e6
    opt = differential_evolution(objective, [(-args.bound, args.bound)] * 6,
                                 seed=args.seed, maxiter=args.maxiter, popsize=10,
                                 tol=1e-9, polish=True, workers=1,
                                 updating="immediate")
    ans = score(args.pairs, args.fitness, opt.x)
    ans["portals"] = ans["portals"].tolist()
    print(ans)
    print({"success": opt.success, "parameters": opt.x.tolist()})


if __name__ == "__main__":
    main()
