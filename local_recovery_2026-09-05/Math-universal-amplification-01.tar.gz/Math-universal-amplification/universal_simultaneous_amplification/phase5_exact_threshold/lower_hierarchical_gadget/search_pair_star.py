#!/usr/bin/env python3
"""Search an exactly lumped pair--star satellite in the separated cone.

The gadget has vertices a,b,h and L interchangeable leaves.  Its edges are
a--b of weight A, b--h of weight C, and h--leaf of weight W.  Portal loads
may differ on the four vertex orbits.  The optimizer reports the full
leaf-eliminated separator, including reciprocal invasion and the subtraction
of the same number of complete-core vertices.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution, minimize_scalar
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def states(leaves: int) -> list[tuple[int, int, int, int]]:
    empty = (0, 0, 0, 0)
    full = (1, 1, 1, leaves)
    return [
        (a, b, h, j)
        for a in (0, 1)
        for b in (0, 1)
        for h in (0, 1)
        for j in range(leaves + 1)
        if (a, b, h, j) not in (empty, full)
    ]


def fixation_orbits(
    leaves: int,
    fitness: float,
    rule: str,
    pair_weight: float,
    bridge_weight: float,
    leaf_weight: float,
) -> np.ndarray:
    """Return singleton fixation from a,b,h,leaf using the exact quotient."""
    empty = (0, 0, 0, 0)
    full = (1, 1, 1, leaves)
    transient = states(leaves)
    index = {state: row for row, state in enumerate(transient)}
    rows: list[int] = []
    cols: list[int] = []
    data: list[float] = []
    rhs = np.zeros(len(transient))

    A = pair_weight
    C = bridge_weight
    W = leaf_weight
    degrees = (A, A + C, C + leaves * W, W)

    for state, row in index.items():
        a, b, h, j = state
        types = (a, b, h)
        fits = tuple(fitness if value else 1.0 for value in types)
        leaf_mut_fit = fitness
        leaf_res_fit = 1.0
        moves: dict[tuple[int, int, int, int], float] = {}

        def add(target: tuple[int, int, int, int], rate: float) -> None:
            if rate > 0:
                moves[target] = moves.get(target, 0.0) + rate

        if rule == "Bd":
            # a--b
            if a != b:
                add((b, b, h, j), fits[1] * A / degrees[1])
                add((a, a, h, j), fits[0] * A / degrees[0])
            # b--h
            if b != h:
                add((a, h, h, j), fits[2] * C / degrees[2])
                add((a, b, b, j), fits[1] * C / degrees[1])
            # h--leaves
            if h == 1 and j < leaves:
                add((a, b, h, j + 1), fitness * (leaves - j) * W / degrees[2])
            if h == 0 and j > 0:
                add((a, b, h, j - 1), j * W / degrees[2])
            if h == 0 and j > 0:
                add((a, b, 1, j), leaf_mut_fit * j)
            if h == 1 and j < leaves:
                add((a, b, 0, j), leaf_res_fit * (leaves - j))
        elif rule == "dB":
            # Target a has only neighbour b.
            if a != b:
                add((b, b, h, j), 1.0)

            # Target b competes between a and h.
            denom_b = fits[0] * A + fits[2] * C
            if a != b:
                add((a, a, h, j), fits[0] * A / denom_b)
            if h != b:
                add((a, h, h, j), fits[2] * C / denom_b)

            # Target h competes between b and all leaves.
            denom_h = fits[1] * C + (fitness * j + leaves - j) * W
            if b != h:
                add((a, b, b, j), fits[1] * C / denom_h)
            if h == 0 and j > 0:
                add((a, b, 1, j), fitness * j * W / denom_h)
            if h == 1 and j < leaves:
                add((a, b, 0, j), (leaves - j) * W / denom_h)

            # A leaf target has only neighbour h; multiplicity is its count.
            if h == 1 and j < leaves:
                add((a, b, h, j + 1), leaves - j)
            if h == 0 and j > 0:
                add((a, b, h, j - 1), j)
        else:
            raise ValueError(rule)

        exit_rate = sum(moves.values())
        if not exit_rate:
            raise ArithmeticError((rule, state, moves))
        rows.append(row)
        cols.append(row)
        data.append(exit_rate)
        for target, rate in moves.items():
            if target == full:
                rhs[row] += rate
            elif target != empty:
                rows.append(row)
                cols.append(index[target])
                data.append(-rate)

    matrix = coo_matrix((data, (rows, cols)), shape=(len(transient), len(transient))).tocsr()
    harmonic = spsolve(matrix, rhs)
    return np.array(
        [
            harmonic[index[(1, 0, 0, 0)]],
            harmonic[index[(0, 1, 0, 0)]],
            harmonic[index[(0, 0, 1, 0)]],
            harmonic[index[(0, 0, 0, 1)]],
        ]
    )


def maximize_separator(a_bd: float, a_db: float, gate_product: float, r: float) -> tuple[float, float]:
    def value(log_z: float) -> float:
        z = math.exp(log_z)
        return a_db * gate_product / (gate_product + z) + (r - 1) * a_bd * z / (1 + z) - r

    fit = minimize_scalar(lambda x: -value(x), bounds=(-45, 45), method="bounded")
    candidates = [(-45.0, value(-45.0)), (45.0, value(45.0)), (fit.x, -fit.fun)]
    log_z, best = max(candidates, key=lambda item: item[1])
    return best, math.exp(log_z)


def decode(params: np.ndarray) -> tuple[float, float, float, np.ndarray]:
    logs = np.r_[0.0, params]
    # First three entries are A,C,W; final four are portal loads.
    edge_logs = logs[:3] - np.mean(logs[:3])
    portal_logs = logs[3:] - np.mean(logs[3:])
    return (*np.exp(edge_logs), np.exp(portal_logs))


def score(leaves: int, r: float, params: np.ndarray) -> dict[str, object]:
    A, C, W, portals = decode(params)
    plus_b = fixation_orbits(leaves, r, "Bd", A, C, W)
    plus_d = fixation_orbits(leaves, r, "dB", A, C, W)
    minus_b = fixation_orbits(leaves, 1 / r, "Bd", A, C, W)
    minus_d = fixation_orbits(leaves, 1 / r, "dB", A, C, W)
    multiplicity = np.array([1.0, 1.0, 1.0, float(leaves)])
    order = leaves + 3
    p = 1 - 1 / r
    a_bd = float(np.dot(multiplicity, plus_b) / (order * p))
    a_db = float(np.dot(multiplicity, plus_d) / (order * p))
    degrees = np.array([A, A + C, C + leaves * W, W])
    S0 = float(np.dot(multiplicity, portals / degrees))
    total = float(np.dot(multiplicity, portals))
    SB = float(np.dot(multiplicity, portals * minus_b))
    SD = float(np.dot(multiplicity, portals * minus_d / degrees))
    gate = r * (r - 1) ** 2 * S0 * total / (SB * SD)
    sep, z = maximize_separator(a_bd, a_db, gate, r)
    return {
        "separator": order * sep,
        "per_vertex": sep,
        "A_Bd": a_bd,
        "A_dB": a_db,
        "K": gate,
        "Z_Bd": z,
        "edges": [A, C, W],
        "portals": portals.tolist(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--leaves", type=int, default=4)
    parser.add_argument("--fitness", type=float, default=1.9)
    parser.add_argument("--bound", type=float, default=10.0)
    parser.add_argument("--maxiter", type=int, default=120)
    parser.add_argument("--seed", type=int, default=20260808)
    args = parser.parse_args()

    # decode prepends one fixed log, so there are six free scale-free logs.
    def objective(params: np.ndarray) -> float:
        try:
            return -float(score(args.leaves, args.fitness, params)["separator"])
        except (ArithmeticError, FloatingPointError, np.linalg.LinAlgError, ValueError):
            return 1e6

    result = differential_evolution(
        objective,
        [(-args.bound, args.bound)] * 6,
        seed=args.seed,
        maxiter=args.maxiter,
        popsize=10,
        tol=1e-10,
        polish=True,
        workers=1,
        updating="immediate",
    )
    print(score(args.leaves, args.fitness, result.x))
    print({"success": bool(result.success), "message": result.message, "parameters": result.x.tolist()})


if __name__ == "__main__":
    main()
