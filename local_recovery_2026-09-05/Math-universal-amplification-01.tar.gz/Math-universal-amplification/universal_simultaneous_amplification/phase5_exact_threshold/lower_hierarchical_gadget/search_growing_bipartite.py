#!/usr/bin/env python3
"""Discovery screen for separated complete-bipartite satellite responses.

This is numerical discovery code.  It solves the exact two-count absorbing
chain for K_{a,b}, evaluates the separated normal form, and optimizes the
portal-load ratio and the free gate.  Any positive output must be exactified
independently before it can support a claim.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import differential_evolution, minimize_scalar
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import spsolve


def fixation(a: int, b: int, r: float, rule: str) -> tuple[float, float, float]:
    states = [(i, j) for i in range(a + 1) for j in range(b + 1)
              if (i, j) not in ((0, 0), (a, b))]
    index = {x: k for k, x in enumerate(states)}
    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    rhs = np.zeros(len(states))

    for x, (i, j) in enumerate(states):
        moves: dict[tuple[int, int], float] = {}
        if rule == "Bd":
            fit = r * (i + j) + (a + b - i - j)
            if i and j < b:
                moves[i, j + 1] = moves.get((i, j + 1), 0.0) + r * i / fit * (b - j) / b
            if j and i < a:
                moves[i + 1, j] = moves.get((i + 1, j), 0.0) + r * j / fit * (a - i) / a
            if i < a and j:
                moves[i, j - 1] = moves.get((i, j - 1), 0.0) + (a - i) / fit * j / b
            if j < b and i:
                moves[i - 1, j] = moves.get((i - 1, j), 0.0) + (b - j) / fit * i / a
        elif rule == "dB":
            den_b = r * j + (b - j)
            den_a = r * i + (a - i)
            if i < a and j:
                moves[i + 1, j] = moves.get((i + 1, j), 0.0) + (a - i) / (a + b) * r * j / den_b
            if i and j < b:
                moves[i - 1, j] = moves.get((i - 1, j), 0.0) + i / (a + b) * (b - j) / den_b
            if j < b and i:
                moves[i, j + 1] = moves.get((i, j + 1), 0.0) + (b - j) / (a + b) * r * i / den_a
            if j and i < a:
                moves[i, j - 1] = moves.get((i, j - 1), 0.0) + j / (a + b) * (a - i) / den_a
        else:
            raise ValueError(rule)

        change = sum(moves.values())
        rows.append(x); cols.append(x); vals.append(change)
        for ystate, prob in moves.items():
            if ystate == (a, b):
                rhs[x] += prob
            elif ystate != (0, 0):
                rows.append(x); cols.append(index[ystate]); vals.append(-prob)

    mat = csr_matrix((vals, (rows, cols)), shape=(len(states), len(states)))
    h = spsolve(mat, rhs)
    h_a = float(h[index[1, 0]])
    h_b = float(h[index[0, 1]])
    avg = (a * h_a + b * h_b) / (a + b)
    return h_a, h_b, avg


def best_response(a: int, b: int, r: float) -> dict[str, float]:
    hp = {u: fixation(a, b, r, u) for u in ("Bd", "dB")}
    hm = {u: fixation(a, b, 1 / r, u) for u in ("Bd", "dB")}
    p = 1 - 1 / r
    s = a + b

    def quantities(logx: float, logz: float) -> tuple[float, float, float]:
        xa, xb = math.exp(logx), 1.0
        s0 = a * xa / b + b * xb / a
        sb = a * xa * hm["Bd"][0] + b * xb * hm["Bd"][1]
        sd = a * xa / b * hm["dB"][0] + b * xb / a * hm["dB"][1]
        pp = a * xa + b * xb
        K = r * (r - 1) ** 2 * s0 * pp / (sb * sd)
        z = math.exp(logz)
        B = s * (hp["Bd"][2] * z / (p * (1 + z)) - 1)
        D = s * (hp["dB"][2] * K / (p * (K + z)) - 1)
        return B, D, K

    # Maximize the leaf-eliminated separator subject to D>0.  A smooth
    # penalty is adequate for discovery; exact certification comes later.
    def objective(v: np.ndarray) -> float:
        B, D, _ = quantities(float(v[0]), float(v[1]))
        sep = D + (r - 1) * B
        return -sep + 1e3 * max(0.0, -D) ** 2

    opt = differential_evolution(objective, [(-12, 12), (-12, 16)],
                                 tol=1e-10, polish=True, seed=1234,
                                 workers=1, updating="immediate")
    B, D, K = quantities(float(opt.x[0]), float(opt.x[1]))
    return dict(a=a, b=b, r=r, B=B, D=D, sep=D + (r - 1) * B,
                xratio=math.exp(float(opt.x[0])), z=math.exp(float(opt.x[1])), K=K,
                AB=hp["Bd"][2], AD=hp["dB"][2])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--r", type=float, default=1.9)
    ap.add_argument("--max", type=int, default=30)
    args = ap.parse_args()
    pairs = {(a, b) for a in range(1, args.max + 1) for b in range(a, args.max + 1)
             if a in {1, 2, 3, 5, 8, 13, 21, args.max} or b in {a, 2*a, 3*a, args.max}}
    out = []
    for a, b in sorted(pairs, key=lambda t: (t[0] + t[1], t)):
        try:
            q = best_response(a, b, args.r)
        except Exception as exc:
            print("FAIL", a, b, exc)
            continue
        out.append(q)
        print("a=%3d b=%3d sep=% .8g D=% .8g B=% .8g x=% .4g z=% .4g" %
              (a, b, q["sep"], q["D"], q["B"], q["xratio"], q["z"]))
    print("BEST")
    for q in sorted(out, key=lambda x: x["sep"], reverse=True)[:12]:
        print(q)


if __name__ == "__main__":
    main()
