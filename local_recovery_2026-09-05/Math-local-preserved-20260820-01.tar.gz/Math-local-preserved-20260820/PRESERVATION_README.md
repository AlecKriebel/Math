# Math local preservation — 2026-08-20

This folder preserves local-only material that was moved out of the primary
Math checkout so `/Users/alec/Documents/Math` could safely return to a clean,
up-to-date `main` branch.

## Preserved directories

- `exceptional_ybe_d4_v1_2_private/`: private release and submission working
  material. It was not committed or pushed.
- `k2p_level2_identifiability_closure/`: a complete pre-switch copy including
  the local virtual environment and resumable four-port run records. The 78
  nonignored source files matched `origin/main` byte for byte before the move.
- `noncommutative_comparative_statics/`: the local project copy and build
  products.
- `ramsey55/`: ignored Ramsey certificates, datasets, and result directories
  that became untracked when the root checkout changed branches.

## K2P run note

The active four-port sweep was resumed after the branch switch. All six source
lanes report complete manifests and were reusable. The final manifest merge
then stopped on the committed package's input-lock check for
`resumable_four_port_driver.py`; the lane records remain preserved both here
and under the ignored `runs/four_port_full/` directory in the main checkout.

Nothing in this preservation folder is part of Git's `main` worktree.
