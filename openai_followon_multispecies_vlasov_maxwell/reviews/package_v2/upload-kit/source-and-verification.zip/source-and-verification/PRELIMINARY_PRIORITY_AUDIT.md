# Preliminary independent primary-source priority audit

Checkpoint: 2026-10-06 21:27:46 America/Los_Angeles (2026-10-07 04:27:46 UTC). Revised after full-text acquisition of Glassey–Schaeffer 1988.

This is an early literature and attribution audit, not a mathematical certification or a final novelty clearance. No unconditional multispecies theorem has been proved by this audit. For the original research objective, mathematical resolution is estimated at 0% and publication-package completion at 0%; this agent's preliminary literature reconnaissance is about 85% complete. Percentages are planning estimates, not evidence.

## Findings that change the research plan

1. Actual finite-mass, signed multispecies relativistic Vlasov–Maxwell formulations and conditional continuation are established machinery. Glassey's book explicitly treats different masses and charges; Luk–Strain explicitly notes its continuation criterion extends to multispecies. Credit those authors for these ingredients.
2. Family 362 explicitly restricts its claimed unconditional result to one species. The common-field, opposite-charge extension is not stated in its theorem. A successful new paper would need to prove the species-dependent estimates, not advertise the underlying one-species breakthrough as independently ours.
3. Glassey's exact Chapter 5 theorem has a neutrality condition in its stated initial constraints. Therefore it cannot, without a separately verified extension, certify the intended nonneutral finite-energy field class.
4. Important prior global multispecies results exist for nearly neutral or perturbative data. Any priority statement must exclude these restrictions precisely. “Multispecies global existence was previously unknown” would be inaccurate without qualifiers. The 1988 theorem controls a signed **phase-space density** in a \(C^1\) norm; scalar integrated neutrality alone is not its smallness hypothesis.
5. Current repository history has one observed commit and no later correction on its current main history. The manuscript date September 23 is not evidence of a September public disclosure.

## Scope actually checked

The primary material reviewed here is the exact pinned upstream README, family README and BibTeX, family 362 introduction/theorem, setup and beginning of continuation section, its scope document, and a corpus-wide source-title/text search for companions. I read the complete statements and adjoining remarks of Luk–Strain's 2014 continuation theorems; Glassey Chapter 5 pp.140 and 159 were also visually inspected because OCR omits formulas. I read Wang's 2026 Part I Theorem 1.1 and adjoining remarks, Part II title/abstract and section structure, and Bigorgne's full Theorem 2.10 and introductory multispecies statement. Glassey–Schaeffer 1988 was obtained from the primary Project Euclid archive; its exact theorem/definition (p.355), normalization (p.354), fixed-parameter constants (p.356), and adjoining outline were read, including visual formula inspection. No full proof of these literature inputs or Lean build was independently certified by this agent.

### Upstream OpenAI input

Pinned source: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Family directory:

`preprints/Global-classical-solutions-of-the-three-dimensional-relativistic-Vlasov-Maxwell-system-September-23-2026`.

The displayed theorem takes nonnegative \(f_0\in C_c^\infty(\mathbb R^6)\), \(E_0,B_0\in C_b^\infty\cap L^2\), Gauss constraints, \(m=e=c=1\), no background charge, and claims global smooth uniqueness with compact phase support on finite intervals. The source explicitly calls this a one-species model. It does not impose neutrality. Its source catalogue supplies only one manuscript in family 362. A search of all pinned manuscript `.tex` files containing Vlasov–Maxwell found no distinct multispecies companion; this finite corpus search is evidence about this snapshot, not evidence about all public literature.

The repository README warns that verification status is mixed. A scope document or comparator statement is not proof. This audit makes no formalization claim. Cite OpenAI as supplied in the manuscript-specific BibTeX, with the pinned source URL for reproducibility: [family README](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Global-classical-solutions-of-the-three-dimensional-relativistic-Vlasov-Maxwell-system-September-23-2026/README.md).

### Glassey, The Cauchy Problem in Kinetic Theory (1996)

Printed p.140, system (5.3), uses physical momentum \(p\), velocities

\[
\widehat p_a=p/\sqrt{m_a^2+|p|^2/c^2},\qquad
\dot p=e_a(E+c^{-1}\widehat p_a\times B),
\]

and signed sources \(\rho=4\pi\sum_a e_a\int f_a\,dp\), \(j=4\pi\sum_a e_a\int\widehat p_af_a\,dp\). Theorem 5.2.1 assumes nonnegative \(C_c^1\) distributions, \(C^2\) fields, Gauss constraints **and** \(\int\rho_0dx=0\), and a continuous common momentum-support bound. It then gives unique global \(C^1\) solutions. Printed p.159 adapts the representation proof by species-dependent transport operators, signed source sums and separate iterate-difference estimates. Chapter 6 gives a small-data theorem for several species. These are conditional or perturbative inputs, not the new unrestricted a priori estimate. [Publisher chapter](https://epubs.siam.org/doi/10.1137/1.9781611971477.ch5).

### Luk–Strain 2014 continuation

[arXiv:1406.0165v1](https://arxiv.org/abs/1406.0165v1), submitted June 1, 2014; published as *Communications in Mathematical Physics* **331** (2014), 1005–1027, DOI [10.1007/s00220-014-2108-8](https://doi.org/10.1007/s00220-014-2108-8).

Their Theorem 1.1 states bounded-full-momentum continuation for nonnegative phase-compact \(f_0\in H^5\), \(E_0,B_0\in H^5\) and Gauss constraints. A footnote distinguishes the original Glassey–Strauss iterate-support hypothesis and lower regularity. Theorem 1.2 needs bounded momentum projection onto a fixed two-plane. Theorem 1.3 replaces that bound by a time/angular integrability condition. Remark 1.2 explicitly states an analogous multispecies continuation criterion follows, with details omitted. These remarks support attribution and a continuation strategy, not automatic satisfaction of their \(H^5\) field hypothesis by \(C_b^\infty\cap L^2\) data. No neutrality assumption appears in the displayed statements.

### Luk–Strain 2014/2016 moment continuation

[arXiv:1406.0169v1](https://arxiv.org/abs/1406.0169v1), submitted June 1, 2014; combined published version *Archive for Rational Mechanics and Analysis* **219** (2016), 445–552, DOI [10.1007/s00205-015-0899-1](https://doi.org/10.1007/s00205-015-0899-1).

Theorem 1.1 explicitly includes bounded support for every approximation, and Theorem 1.2 is the corresponding continuation statement. Later results permit noncompact momentum support subject to weighted regularity and additional bounds, including a field integral along characteristics. These do not supply an unconditional estimate for our compact large-data target. This distinction matters when citing a continuation theorem: the exact version and its iterate, regularity and solution hypotheses must be stated.

### Glassey–Schaeffer 1988 nearly neutral data

Primary publisher record: *Communications in Mathematical Physics* **119** (1988), 353–384, DOI [10.1007/BF01218078](https://link.springer.com/article/10.1007/BF01218078). Received September 8, 1987; revised April 19, 1988; issue September 1988.

[Primary archived article](https://projecteuclid.org/journals/communications-in-mathematical-physics/volume-119/issue-3/Global-existence-for-the-relativistic-Vlasov-Maxwell-system-with-nearly/cmp/1104162494.full), printed pp.354–356, proves the following for fixed finite species parameters. Put \(g_a^0(x,u)=f_a^0(x,m_au)\). Require nonnegative \(g_a^0\in C_c^2\), all supported in \(|x|,|u|<k\); \(E^0,B^0\in C_c^2\), supported in \(|x|<k\); Maxwell divergence constraints; and

\[
\sum_a\|g_a^0\|_{C^2}<M,\qquad
\left\|\sum_a e_am_a^3g_a^0\right\|_{C^1}
  +\|E^0\|_{C^2}+\|B^0\|_{C^2}<\varepsilon(k,M).
\]

For sufficiently small positive \(\varepsilon(k,M)\), there is a unique global \(C^1\) solution. Constants may depend on the specified charges and masses. This is phase-space cancellation and field smallness, not an arbitrary finite-energy theorem. Their mass normalization/common velocity and \(m_a^3\) signed-source Jacobian are already printed on p.354 and must be attributed as known reductions. Compact field support plus Gauss's law enforces integrated neutrality, which is also narrower than our intended field class.

### Bigorgne small-distribution theorem

[arXiv:2208.08360v2](https://arxiv.org/abs/2208.08360v2), first submitted August 17, 2022, revised August 31, 2023; published *Analysis & PDE* **18** (2025), 629–714, DOI [10.2140/apde.2025.18.629](https://doi.org/10.2140/apde.2025.18.629).

Theorem 2.10 assumes \(N\ge3\), weighted \(C^N\) distribution derivatives bounded by a small parameter and weighted field derivatives bounded by \(\Lambda\); the decisive smallness has an exponential dependence on \(\Lambda\). Its exponents include \(N_v\ge15\), \(N_x>7\). It permits a large Maxwell field, but the distribution still must be small. The introduction explicitly states extension to different charges and positive masses. Thus it is established perturbative multispecies scope, not duplicate unrestricted large-data scope. The 2020 sharp-asymptotic paper also has a small-data hypothesis and permits nonneutral data.

### Wang 2026 cylindrical symmetry

[arXiv:2203.01199v2](https://arxiv.org/abs/2203.01199v2), first submitted March 2, 2022, revised July 16, 2026, pairs with [arXiv:2607.14685v1](https://arxiv.org/abs/2607.14685v1), submitted July 16, 2026. Part I Theorem 1.1 is for one-species data invariant under simultaneous rotations around an axis, \(s\ge6\), Sobolev fields and a strong weighted distribution condition (the displayed \(N_0=10^{10}\)). Part I expressly states cylindrical symmetry is crucial and discusses the unrestricted problem separately. Part II provides pointwise estimates for that mechanism. This is a substantial large-data result under symmetry; it does not resolve arbitrary nonsymmetric data or the new signed species-pair estimate.

## Public-disclosure and correction evidence

The read-only GitHub API retrieval on this checkpoint gives repository `created_at=2026-10-06T21:47:02Z` and one main commit, `adc7f124...`, whose recorded committer time is `2026-10-06T21:58:50Z` (14:58:50 America/Los_Angeles). The file-path commit history also returns that one commit. The current family README equals the pinned README byte-for-byte. The API evidence is saved locally; its hashes are in the source manifest.

These observations show the source is public at our access time and that no later main correction was found. Author/committer dates can be chosen and are not independently decisive dates of public availability. No earlier public disclosure of this manuscript was established in this audit. Use “OpenAI's October 2026 public repository release, manuscript dated September 23” rather than assert public priority on September 23.

## What may be new, conditional on proof and later audit

The intended extension removes the single-species restriction from an unrestricted nonsymmetric, nonperturbative 3D result while allowing fixed positive masses and signed charges. Its potential new content is a verified cross-species impulse/occupation mechanism and coupled common-field momentum bootstrap. Momentum normalization, energy and charge conservation, finite propagation, signed Maxwell source sums, local theory, and continuation machinery are inherited or direct algebraic reductions and should be credited accordingly.

There is presently **no cleared priority claim**. No exact unrestricted multispecies theorem was found in the primary sources inspected, but absent search hits never prove novelty. Once a complete candidate exists, repeat the audit against its exact final hypotheses, citation chains, current versions, public companions and equivalent formulations. Check whether the claimed new pairwise argument is already explicitly available in an upstream correction. The full 1988 theorem has now been inspected and does not duplicate the proposed arbitrary-data conclusion.

## Remaining gaps and publication disposition

* Complete mathematical proof, pivotal upstream validation, and actual species-pair estimates are outside this preliminary audit and remain requirements.
* The subscribed Springer preview did not supply the 1988 theorem, but the full Project Euclid archive did. Its exact class has now been inspected; its proof was not independently revalidated.
* This was not an exhaustive search of every thesis, proceedings item, non-English source, or new release. No assertion of firstness is supported.
* The book's neutrality hypothesis and the Sobolev-field hypotheses of the continuation literature must be reconciled with the new theorem, explicitly.
* Third-party PDFs, OCR text and page images saved under `sources/priority_primary` are private working copies, not authorized supplemental uploads. Their redistribution rights were not established. Publish the derived notes, references and hashes only unless separately justified.

This report does not establish publication readiness. A sound new full theorem and the user-required final package/priority reviews are still necessary.
