# Theorem dependency graph

```mermaid
flowchart TD
  A[Positive mass-action equilibrium] --> B[Flux/equilibrium parameterization]
  B --> C[Reduced Hurwitz inequalities on S]
  B --> D[Principal-minor flux polynomials tau_I]
  E[All-mobile fixed-J theorem] --> D
  C --> F[Exact semialgebraic iff formula]
  D --> F
  F --> G[Boolean selector + arithmetic-circuit encoding]
  G --> H[Membership in existential theory of the reals]
  F --> I[Real algebraic YES samples]
  F --> J[Real Nullstellensatz NO identities]
  I --> K[Complete finite certificate theorem]
  J --> K
  L[Positive flux cone K] --> M[Projected Jacobian cone P]
  M --> N[Fixed-species polynomial-time algorithm]
  N --> O[Complete n <= 3 classifications]

  P[PARTITION] --> Q[Open-cube interval Hurwitz family]
  Q --> R[Row-splitting lift]
  R --> S[Eliminate arbitrary positive right scaling]
  S --> T[Mass-action row-segment realization]
  T --> U[NP-hardness]

  H --> V[T-ALG closure]
  K --> V
  O --> V
  U --> V

  W[Same Gamma, different Y counterexample] --> X[Level 4 insufficient]
  F --> Y[Level 5 sufficient]
  X --> Z[Level 5 weakest among specified levels]
  Y --> Z
  Z --> V
```

## File map

* `fixed_jacobian/stationary_diagonal_damping.tex` proves the all-mobile matrix theorem.
* `fixed_jacobian/mobile_set_extension.tex` proves the positive-spectral-parameter mobile theorem and preserves the refuted zero-parameter proposal.
* `mass_action/equilibrium_flux_parameterization.tex`, `jacobian_factorization.tex`, and `principal_minor_expansion.tex` produce the exact mass-action reduction.
* `topology/exact_characterization.tex` gives the iff formula and polynomial-size selector/circuit encoding.
* `mass_action/row_segment_realization.tex` and `topology/np_hardness_reduction.tex` prove the complexity lower bound.
* `topology/certificate_completeness.tex` gives the complete finite YES/NO certificate theorem.
* `topology/fixed_species_algorithm.tex` gives the fixed-`n` polynomial-time algorithm.
* `definitions/topology_levels.tex` and
  `benchmarks/coarse_topology_counterexamples.tex` prove that Level 4 is
  insufficient and Level 5 is the weakest sufficient parameter-independent
  reaction-network input among the specified presentations; Level 3 is
  parameter-dependent rather than a network invariant.
* `topology/complexity_boundary.tex` assembles the formal T-ALG outcome.

The unrestricted positive diagonal-stabilization problem is not solved. It is bypassed in the hardness reduction by a special scaling-elimination lemma and handled in the general iff theorem by exact Routh--Hurwitz feasibility.