# Assumption audit

* **Classical mass action only:** every Jacobian formula uses integer source complexes and monomial rates.
* **Strictly positive declared rates:** every positive witness lists positive rational rates; no reaction is deleted by setting its rate to zero.
* **Strictly positive equilibrium:** the characterization uses `h_i=1/x_i^*>0`; every constructive witness reconstructs `x^*=h^{-1}` and positive rates. The benchmark and hardness certificates use `x^*=1`.
* **Positive steady flux:** every branch contains exact equations enforcing `Gamma v=0` and strict positivity of every flux coordinate. The reduction family has a direct-product positive flux cone; no reaction is suppressed at an endpoint.
* **Relative stability:** conservative systems are tested on `S`, not by demanding the full Jacobian be Hurwitz.
* **Nonzero spatial mode:** domain normalization uses the first Neumann mode on `(0,pi)`.
* **All-mobile core:** positive certificates use strictly positive diffusion for every species.
* **Stationary scope:** acceptance requires a positive real eigenvalue or a negative characteristic constant with the accompanying intermediate-value proof.
* **No nonlinear claim:** no stable stripe, spot, or nonlinear branch is inferred.
* **No topology inflation:** the final condition uses the indexed pair `(Gamma,Y)`. An exact same-`Gamma` pair proves that `Gamma` alone is insufficient.
* **No tautological certificate:** strict inequalities are converted to polynomial equations; Boolean principal-set selectors and arithmetic circuits give a polynomial-size existential-real formula. Network-bound verifiers regenerate those equations from the reaction list instead of trusting certificate-supplied surrogates.
* **Two-sided exactness:** a YES is a checked real-algebraic sample point. A NO is an exhaustive bundle of checked Real-Nullstellensatz identities, one for every nonempty principal branch.
* **Complexity scope:** the reduction proves ordinary NP-hardness only. It does not claim strong NP-hardness, existential-real hardness or completeness, or polynomial certificate size.
* **Stable-realization scope:** unrestricted positive diagonal stabilizability remains open. The hardness proof uses a specially constructed row-splitting family for which arbitrary positive right scalings are eliminated by an exact determinant argument; it does not assume a general stabilizability theorem.
* **Software versus theorem:** the release proves a terminating quantifier-elimination/certificate-enumeration algorithm. The bundled lightweight classifier may still return `UNRESOLVED` on an uncertified raw network because no general CAD implementation is shipped.
