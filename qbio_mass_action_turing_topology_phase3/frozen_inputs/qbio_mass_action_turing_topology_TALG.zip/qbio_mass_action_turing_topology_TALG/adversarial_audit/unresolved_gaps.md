# Remaining limitations after T-ALG closure

These are deliberately outside the proved outcome. None invalidates the exact stationary T-ALG theorem.

1. **No compact motif theorem.** The arbitrary-size criterion is semialgebraic and certificate-complete, not a finite list of forbidden or required reaction motifs.
2. **No unrestricted diagonal-stabilization theorem.** The general matrix problem remains open. It is retained explicitly in `mass_action/stable_realization.tex` rather than being hidden.
3. **No stronger lower bound.** The package proves ordinary NP-hardness from `PARTITION`, not strong NP-hardness, `exists-R`-hardness, or `exists-R`-completeness.
4. **No polynomial certificate-size bound.** Real algebraic samples and Real Nullstellensatz identities are finite and exactly checkable, but may be very large.
5. **No primary-crossing theorem.** A positive real spatial eigenvalue exists, but a wave crossing may occur earlier along a chosen diffusion path.
6. **No arbitrary-dimensional wave classification.** Turing--Hopf instability still requires full Hurwitz-determinant data and is not characterized reaction-hypergraphically here.
7. **No robust-bifurcation equivalence.** Weak stationary admissibility is not proved equivalent to a simple transverse zero-eigenvalue crossing with every other mode stable.
8. **No nonlinear pattern theorem.** The result does not establish a nonconstant steady state, stable stripe or spot, persistence, or global attraction.
9. **No bundled general CAD engine.** The lightweight classifier verifies certificates and emits the canonical formula but may return `UNRESOLVED` on an uncertified raw positive-flux network. The terminating exact algorithm is proved, not shipped as a high-performance quantifier-elimination implementation.
10. **Priority remains externally auditable.** The dated literature search found no prior combined theorem, but this is not a formal proof of novelty.