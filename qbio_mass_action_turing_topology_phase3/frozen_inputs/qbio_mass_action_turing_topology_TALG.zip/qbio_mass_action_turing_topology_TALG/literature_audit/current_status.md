# Current-literature audit

**Audit date:** 2026-08-13  
**Scope:** stationary diffusion-driven instability, classical mass action, full reaction-hypergraph data, matrix diagonal destabilization, real-algebraic decision methods, and complexity.

## Scope crosswalk

| Work stream | Kinetic/data level | Exact scope | Relation to this package |
|---|---|---|---|
| Turing (1952) | Specific smooth two-species reaction--diffusion model | Foundational diffusion-driven mechanism | Historical origin, not a reaction-hypergraph decision theorem. |
| Satnoianu, Menzinger & Maini (2000); Wang & Li (2001); Satnoianu & van den Driessche (2005); Villar-Sepúlveda & Champneys (2023) | Fixed numerical Jacobian or general smooth kinetics at an equilibrium | Necessary/sufficient matrix conditions for stationary and/or wave instability | Closest antecedents to the fixed-J portion. The principal-minor matrix theorem is not claimed as new. |
| Mincheva & Roussel (2006); Mincheva & Craciun (2013) | Classical mass-action species--reaction graphs | Graph-theoretic necessary conditions and sufficient constructions for zero-eigenvalue Turing instability | Important reaction-network structure, but not an arbitrary-size iff algorithm with flux, stability, conservation, and complete NO certificates. |
| Marcon et al. (2016); Diego et al. (2018); Scholes et al. (2019) | Signed interaction networks and parameter-rich regulatory kinetics, often bounded atlases | Topological design principles, computational atlases, robustness | Their “topology” is coarser than the indexed classical-mass-action pair `(Gamma,Y)`. |
| Paul et al. (2024), *Widespread biochemical reaction networks enable Turing patterns* | Twenty-three elementary biochemical mass-action model families | Exact/numerical study of small biologically motivated schemes; ten pattern-capable families | Strong benchmark evidence that reaction-hypergraph structure matters, not an arbitrary-network iff or complexity classification. |
| Piskovsky (2024) | General fixed three-species Jacobian | Exact three-species stationary and Turing--Hopf inequalities | Recovered at the fixed-J layer; this package additionally eliminates into positive steady-flux geometry and gives an arbitrary reaction-list polynomial algorithm for fixed `n`. |
| Vassena (2023/2025); Vassena & Stadler (2024) | Parameter-rich kinetics, generalized mass action, and child selections | Structural sufficient conditions, unstable cores, symbolic bifurcation criteria | Classical mass action couples derivative symbols through one steady flux and one concentration scaling; the T-ALG formula retains those dependencies exactly. |
| Krause et al. (2024) | General nonlinear reaction--diffusion systems | Linear Turing instability need not yield a persistent nonlinear pattern | Supports the package’s explicit linear/nonlinear boundary. |
| Conradi, Mincheva & Uecker (2026), arXiv:2605.16049 | Classical mass-action networks with monomial positive-steady-state parametrization | Sufficient polynomial conditions for spatial instability in a special class | Closest current mass-action paper located; it states sufficient conditions for a restricted parametrizable class, not the arbitrary-network iff, certificate, and complexity theorem here. |
| Blondel & Tsitsiklis (1997) | Rational interval/rank-one affine matrix families | NP-hardness of deciding whether a family contains a Hurwitz matrix | Supplies the source family. The new required steps are the row-splitting lift, elimination of arbitrary positive right scalings, and exact realization by a classical mass-action hypergraph. |
| Renegar (1992); Basu, Pollack & Roy (2006) | First-order theory of the reals | General exact decision and fixed-variable polynomial-time bounds | Supplies the real-algebraic algorithmic layer, not the reaction-network reduction. |
| Bochnak, Coste & Roy (1998) | Real algebraic geometry | Transfer, Real Nullstellensatz, real-root isolation foundations | Supplies the complete finite certificate theorem. |
| Sun (2023) and matrix-stability reviews | General real matrices | Reviews diagonal stability/stabilizability; full compact diagonal-stabilizability characterization remains open | The package does not claim to solve this general matrix problem. The NP-hardness family has a separate exact scaling-elimination lemma. |

## Audit conclusions

1. The fixed-J principal-minor theorem has clear antecedents and is used as an exact self-contained reduction, not advertised as a new matrix theorem.
2. Existing reaction-network “topology” results located in the audit concern coarser signed graphs, parameter-rich kinetics, bounded model families, necessary conditions, or sufficient constructions.
3. The 2026 monomial-parametrization paper is close in subject but explicitly treats a restricted network class and sufficient inequalities.
4. The interval-stability NP-hardness theorem is prior. The potentially new content is the exact polynomial reduction from that family to strictly positive classical mass-action stationary-Turing admissibility while neutralizing every positive equilibrium/right-diagonal scaling.
5. Exact real quantifier elimination and Real Nullstellensatz certificates are standard general machinery. Their role here is to complete the reaction-hypergraph decision theorem and provide two-sided finite certificates.
6. Searches performed through 2026-08-13 did not locate a prior theorem combining all of the following: arbitrary classical-mass-action `(Gamma,Y)` input, stationary positive-real diffusion destabilization, conservation laws, a polynomial-size existential-real iff encoding, NP-hardness, complete finite YES/NO certificates, and polynomial-time algorithms for every fixed species count.

## Search limitations

This is a good-faith current-priority audit, not a proof of global novelty. Searches covered the works mandated by the directive, their citation chains and terminology, matrix interval stability, diagonal stabilization, mass-action Turing criteria, reaction-network topology, and complexity formulations. Before circulation, an expert should search MathSciNet, zbMATH, Scopus, Web of Science, and older chemical-kinetics literature under alternate terms such as `excitable matrices`, `zero-eigenvalue Turing bifurcation`, `additive D-instability`, `S-stability`, `unstable subsystems`, and `diffusion-driven instability of reaction graphs`.