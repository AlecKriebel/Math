# Terminology and data-level crosswalk

The word **topology** is overloaded in the Turing and reaction-network literature. This project uses it only with an explicit level.

| Level | Data retained | What it can and cannot determine here |
|---|---|---|
| 1. Unsigned species-interaction graph | Whether an interaction is present | An exact fixed-row mass-action pair has the same graph for every positive realization but opposite network-wide Turing answers. |
| 2. Signed species-interaction graph | Sign of each possible Jacobian entry | The same pair has the complete all-negative signed graph for every positive realization, while only one network is admissible. |
| 3. Coates graph of a chosen Jacobian | Numerical or symbolic Jacobian entries at one selected equilibrium | Sufficient for the corresponding fixed-J matrix question, but parameter-dependent and therefore not a parameter-free input for network-wide existence over all mass-action realizations. |
| 4. Stoichiometric matrix `Gamma` | Reaction vectors `y'_r-y_r` | Does not determine source monomials or the Jacobian; the same `Gamma` with different source complexes can change `Y` and all Jacobian minors. |
| 5. Pair `(Gamma,Y)` | Stoichiometric changes and source complexes, reaction by reaction | Exactly determines the classical mass-action family up to positive rate constants; this is the algebraic data used by the reduction. |
| 6. Directed complex graph with labels | Source/target complexes, parallel-reaction identities, linkage classes | Equivalent to Level 5 once reaction columns and parallel reactions are retained; useful for graph-theoretic certificates and operations. |

Accordingly, “weakest level” in the final theorem means the weakest sufficient
**parameter-independent reaction-network input** among these choices.  Levels 1
and 2 fail by an exact fixed-row mass-action pair with opposite network-wide
answers; Level 4 fails by an exact same-`Gamma` pair; and Level 3 is a selected
realization rather than a network invariant.  Level 5 is sufficient, while
Level 6 is an equivalent labeled presentation.

## Related terms

**Fixed-J Turing admissibility** asks whether a given stable numerical Jacobian can be destabilized by diagonal diffusion. It is a matrix question.

**Reaction-hypergraph admissibility** asks whether some positive rates and positive equilibrium of a declared reaction network produce such a Jacobian. It is a realization question over the positive steady-flux cone.

**Signed `P_0` condition** in this package means

```text
(-1)^|I| det(J_I) >= 0 for every principal set I,
```

or equivalently that `-J` is a `P_0` matrix. It exactly excludes a positive real eigenvalue under all-mobile positive diagonal subtraction. It does not by itself exclude wave instability.

**Additive D-stability** requires `J-D` to remain Hurwitz for every nonnegative diagonal `D`. It is stronger than the absence of positive real eigenvalues because a complex pair can destabilize while all positive-real tests remain negative.

**Zero-eigenvalue Turing instability**, **stationary Turing instability**, and **real-mode diffusion-driven instability** are used in neighboring literatures. Here the proved general theorem is labeled **weak stationary**: some nonzero spatial matrix has a strictly positive real eigenvalue. A **primary stationary bifurcation** additionally requires that a simple zero crossing occurs before any wave instability and that the remaining spectrum is stable.

**Wave** or **Turing-Hopf instability** means a nonreal conjugate pair crosses the imaginary axis at nonzero wavenumber. It is not characterized by the principal-minor theorem.

**Relative homogeneous stability** means Hurwitz stability of `J|_S`, where `S=im Gamma`. Conservation-induced transverse zero eigenvalues are not counted as instability of the well-mixed compatibility class.

**Positive steady flux** means `v>0` and `Gamma v=0`. It is necessary and sufficient for the declared reaction list to admit some strictly positive mass-action equilibrium after rates are reconstructed.

**Classical mass action** uses integer source complexes and rates `k_r x^{y_r}`. Generalized mass action, Hill kinetics, Michaelis-Menten kinetics, and freely specified positive derivative symbols are not silently substituted for it.
