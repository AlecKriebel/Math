# Priority and novelty audit

## Claims that must not be presented as new

* the fixed-numerical-Jacobian principal-subsystem/signed-minor criterion for stationary diffusion destabilization;
* classical two-species activator--inhibitor inequalities and fixed-J three-species criteria;
* Cauchy--Binet/child-selection expansions of reaction-network Jacobian minors;
* NP-hardness of finding a Hurwitz matrix in a rational interval or rank-one affine family;
* decidability of real polynomial feasibility, fixed-variable real-algebraic complexity bounds, and the Real Nullstellensatz;
* the fact that linear Turing instability need not imply a stable nonlinear pattern.

## Exact contributions of this package

Publication priority remains subject to expert audit, but the package independently proves and verifies:

1. a conservative classical-mass-action iff reduction using the full species-space spatial matrix and relative homogeneous stability;
2. the corrected designated-mobile condition with a positive spectral parameter and an exact rational counterexample to the proposed zero-parameter condition;
3. a polynomial-size selector/circuit encoding of stationary-Turing admissibility from the indexed pair `(Gamma,Y)`;
4. a row-segment mass-action realization theorem producing exactly `R L(q)` for independent open-interval row parameters;
5. a row-splitting lift whose determinant path eliminates arbitrary positive right-diagonal scalings for the Blondel--Tsitsiklis partition family;
6. NP-hardness of arbitrary-network classical-mass-action stationary-Turing admissibility under strict positivity of all rates and equilibrium coordinates;
7. complete finite network-bound YES and NO certificates using real algebraic samples and exhaustive Real Nullstellensatz identities;
8. a polynomial-time algorithm for every fixed species count through the projected positive-flux cone, including complete arbitrary-reaction-list classifications for `n<=3`;
9. an exact same-`Gamma` pair proving Level 4 insufficient, with Level 5
   `(Gamma,Y)` the weakest sufficient parameter-independent reaction-network
   input among the listed presentations; Level 3 is a selected realization,
   not a network invariant.

## Strongest supportable claim

Subject to external review, the package supports a paper centered on:

> An exact semialgebraic and certificate-complete characterization of stationary diffusion-driven instability in arbitrary classical mass-action reaction networks, together with an NP-hardness boundary and polynomial-time algorithms for every fixed species count.

This is a **T-ALG** result. It is not a finite forbidden-motif theorem, does not solve unrestricted positive diagonal stabilizability, and does not classify nonlinear pattern formation.

## Closest current work and exact distinction

* Fixed-J Turing/wave theory supplies the matrix criterion but does not decide realizability by a given mass-action hypergraph.
* Graph-theoretic mass-action papers supply necessary conditions and sufficient constructions but not the complete arbitrary-size two-sided certificate theorem.
* Child-selection/unstable-core papers use parameter-rich derivative symbols and do not impose the same positive steady-flux/concentration coupling as classical mass action.
* The 2026 monomial-steady-state paper supplies sufficient conditions in a restricted parametrizable class.
* Blondel--Tsitsiklis supplies interval-stability NP-hardness, but not the mass-action row realization or the proof that positive equilibrium scaling cannot create false YES instances.

## Required external audit before circulation

1. Have a matrix-stability expert check Lemma `right-scaling-elimination`, especially the signed-determinant path and open-cube strictness.
2. Have a reaction-network theorist check the row-segment realization converse for every positive steady flux and arbitrary positive equilibrium.
3. Have a real-algebraic geometer check the network-level certificate completeness theorem and the algebraic-coefficient Real Nullstellensatz representation.
4. Have a computational-geometry/complexity expert check the fixed-`n` projected-cone and V-to-H polynomial-time argument.
5. Perform database-level priority searches under alternate matrix and chemical-kinetics terminology.

Until those audits are complete, describe the theorem as a rigorously verified author-audit package rather than an unquestionable priority claim.