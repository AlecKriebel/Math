#!/usr/bin/env python3
"""Exact verifier for a YES witness produced by the PARTITION reduction."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "computation"
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))

from exact_linear_algebra import exact_vector, matrix_to_strings  # noqa: E402
from hurwitz import is_hurwitz  # noqa: E402
from network_parser import (  # noqa: E402
    direct_mass_action_jacobian,
    jacobian_from_flux,
    parse_network,
    reaction_flux,
)
from partition_reduction import (  # noqa: E402
    blondel_family,
    blondel_matrix,
    interior_parameters,
    lifted_family,
    lifted_matrix,
    triangularizing_matrix,
)


class CertificateError(ValueError):
    pass


def verify(data: dict[str, Any]) -> dict[str, Any]:
    metadata = data.get("reduction_metadata")
    if not isinstance(metadata, dict) or metadata.get("source_problem") != "PARTITION":
        raise CertificateError("missing PARTITION reduction metadata")
    values = metadata.get("partition_values")
    signs = metadata.get("partition_signs")
    if not isinstance(values, list) or not isinstance(signs, list):
        raise CertificateError("partition values and signs are required")
    values = [int(item) for item in values]
    signs = [int(item) for item in signs]
    if len(values) != len(signs) or any(sign not in (-1, 1) for sign in signs):
        raise CertificateError("invalid partition sign vector")
    if sum(a * t for a, t in zip(values, signs)) != 0:
        raise CertificateError("partition signs do not sum to zero")

    family = blondel_family(values)
    lift = lifted_family(family)
    q_expected = interior_parameters(family, signs)
    q_raw = metadata.get("witness_q")
    if not isinstance(q_raw, list):
        raise CertificateError("witness_q is required")
    q = tuple(sp.Rational(item) for item in q_raw)
    if q != q_expected:
        raise CertificateError("witness_q is not the canonical exact interior witness")
    if any(not (-1 < item < 1) for item in q):
        raise CertificateError("witness_q is not in the open cube")

    bmat = blondel_matrix(family, q)
    lmat = lifted_matrix(lift, q)
    tmat = triangularizing_matrix(lift, q)
    n0 = family.base_dimension
    d = family.parameter_dimension
    expected_block = bmat.row_join(family.U1).col_join(
        sp.zeros(d, n0).row_join(-lift.alpha * sp.eye(d))
    )
    if sp.simplify(tmat.inv() * lmat * tmat - expected_block) != sp.zeros(lift.dimension):
        raise CertificateError("row-splitting similarity identity failed")
    if not is_hurwitz(bmat) or not is_hurwitz(lmat):
        raise CertificateError("canonical Blondel/lifted matrix is not Hurwitz")

    network = parse_network(data)
    if network.n != lift.dimension:
        raise CertificateError("network has the wrong species count")
    x_star = exact_vector(data.get("x_star", []))
    if x_star != sp.ones(network.n, 1):
        raise CertificateError("this certificate requires x_star=1")
    flux = reaction_flux(network, x_star)
    if any(item <= 0 for item in flux):
        raise CertificateError("all reaction fluxes must be strictly positive")
    gamma = network.stoichiometric_matrix()
    if gamma.rank() != network.n:
        raise CertificateError("the reduction network must have full stoichiometric rank")
    if gamma * flux != sp.zeros(network.n, 1):
        raise CertificateError("the certified flux is not steady")
    j_factorized = jacobian_from_flux(network, x_star, flux)
    j_direct = direct_mass_action_jacobian(network, x_star)
    if sp.simplify(j_factorized - j_direct) != sp.zeros(network.n):
        raise CertificateError("the two Jacobian computations disagree")
    if sp.simplify(j_factorized - lmat) != sp.zeros(network.n):
        raise CertificateError("mass-action Jacobian is not the lifted matrix")

    positive_index = family.m
    if j_factorized[positive_index, positive_index] != family.k * family.beta:
        raise CertificateError("the protected positive diagonal entry changed")
    diffusion = exact_vector(data.get("diffusion", []))
    if diffusion.rows != network.n or any(item <= 0 for item in diffusion):
        raise CertificateError("diffusion must be strictly positive")
    dmat = sp.diag(*list(diffusion))
    determinant = sp.factor((dmat - j_factorized).det())
    if determinant >= 0:
        raise CertificateError("det(D-J)<0 was not verified")

    return {
        "status": "YES",
        "scope": "PARTITION reduction instance and all-mobile weak stationary Turing witness",
        "partition_values": values,
        "partition_signs": signs,
        "species": network.n,
        "reactions": network.m,
        "Gamma_rank": gamma.rank(),
        "beta": str(family.beta),
        "positive_diagonal_index_zero_based": positive_index,
        "det_D_minus_J": str(determinant),
        "Jacobian": matrix_to_strings(j_factorized),
        "proof": "The exact lifted Jacobian is Hurwitz, has a positive diagonal entry, and det(D-J)<0 certifies a positive real spatial eigenvalue.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    try:
        data = json.loads(args.certificate.read_text())
        if not isinstance(data, dict):
            raise CertificateError("top-level JSON must be an object")
        report = verify(data)
    except Exception as exc:
        print(json.dumps({"status": "INVALID", "error": str(exc)}, indent=2))
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
