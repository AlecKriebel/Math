#!/usr/bin/env python3
"""Exact checker for equation-system YES and real-Nullstellensatz NO certificates.

Strict polynomial inequalities are first encoded as equations in the standard
way, e.g. g>0 becomes g*z^2-1=0.  A YES certificate gives a real algebraic
sample point.  A NO certificate gives

    -1 = sum_i s_i^2 + sum_j q_j F_j.

The coefficient field may be Q or a simple real algebraic extension Q(alpha)
specified by an irreducible polynomial and a rational isolating interval.
"""
from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path
from typing import Any, Iterable

import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "computation"
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))

from exact_characterization import canonical_branch_system  # noqa: E402
from network_parser import parse_network  # noqa: E402


class CertificateError(ValueError):
    pass


def _symbols(names: list[str]) -> tuple[sp.Symbol, ...]:
    if not names or len(set(names)) != len(names):
        raise CertificateError("variables must be a nonempty list of distinct names")
    if any(not name.isidentifier() for name in names):
        raise CertificateError("variable names must be identifiers")
    return tuple(sp.Symbol(name) for name in names)


def _parse_rational(value: Any) -> sp.Rational:
    if isinstance(value, float):
        raise CertificateError("floating-point certificate data are forbidden")
    return sp.Rational(value)


class CoefficientField:
    def __init__(self, raw: dict[str, Any], variables: tuple[sp.Symbol, ...]):
        kind = raw.get("type", "rational")
        self.kind = kind
        self.alpha: sp.Symbol | None = None
        self.minpoly: sp.Poly | None = None
        self.locals = {str(var): var for var in variables}
        self.interval: tuple[sp.Rational, sp.Rational] | None = None
        if kind == "rational":
            return
        if kind != "real_algebraic":
            raise CertificateError("coefficient_field.type must be rational or real_algebraic")
        name = raw.get("symbol", "alpha")
        if not isinstance(name, str) or not name.isidentifier() or name in self.locals:
            raise CertificateError("invalid primitive-element symbol")
        alpha = sp.Symbol(name)
        self.alpha = alpha
        self.locals[name] = alpha
        try:
            minpoly_expr = sp.sympify(raw["minimal_polynomial"], locals=self.locals)
            minpoly = sp.Poly(minpoly_expr, alpha, domain=sp.QQ)
        except Exception as exc:
            raise CertificateError(f"invalid minimal polynomial: {exc}") from exc
        if minpoly.degree() < 1 or not minpoly.is_irreducible:
            raise CertificateError("minimal polynomial must be irreducible over Q")
        interval_raw = raw.get("isolating_interval")
        if not isinstance(interval_raw, list) or len(interval_raw) != 2:
            raise CertificateError("real algebraic field requires a rational isolating interval")
        lo, hi = map(_parse_rational, interval_raw)
        if not lo < hi:
            raise CertificateError("isolating interval must be increasing")
        if minpoly.eval(lo) == 0 or minpoly.eval(hi) == 0:
            raise CertificateError("isolating interval endpoints cannot be roots")
        if int(minpoly.count_roots(lo, hi)) != 1:
            raise CertificateError("interval does not isolate exactly one real root")
        self.minpoly = minpoly
        self.interval = (lo, hi)

    def parse(self, text: Any) -> sp.Expr:
        if isinstance(text, float):
            raise CertificateError("floating-point expressions are forbidden")
        try:
            expr = sp.cancel(sp.sympify(str(text), locals=self.locals))
        except Exception as exc:
            raise CertificateError(f"cannot parse expression {text!r}: {exc}") from exc
        allowed = set(self.locals.values())
        if not expr.free_symbols <= allowed:
            raise CertificateError(f"expression uses undeclared symbols: {expr.free_symbols - allowed}")
        numerator, denominator = sp.fraction(expr)
        if self.alpha is None:
            if sp.Poly(denominator, *allowed, domain=sp.QQ).total_degree() != 0:
                raise CertificateError("only rational scalar denominators are allowed")
            return sp.expand(expr)
        # Denominators depending on variables are disallowed.  Algebraic scalar
        # inverses may be reduced to polynomial representatives by the author.
        variable_symbols = allowed - {self.alpha}
        if denominator.free_symbols & variable_symbols:
            raise CertificateError("certificate expressions cannot divide by variables")
        if denominator.free_symbols:
            raise CertificateError("represent algebraic coefficients polynomially in the primitive element")
        return sp.expand(expr)

    def coefficient_is_zero(self, coefficient: sp.Expr) -> bool:
        coefficient = sp.expand(coefficient)
        if self.alpha is None:
            return sp.factor(coefficient) == 0
        assert self.minpoly is not None and self.alpha is not None
        try:
            poly = sp.Poly(coefficient, self.alpha, domain=sp.QQ)
        except Exception as exc:
            raise CertificateError(f"coefficient is not polynomial over Q(alpha): {coefficient}") from exc
        return poly.rem(self.minpoly).is_zero

    def polynomial_is_zero(self, expression: sp.Expr, variables: tuple[sp.Symbol, ...]) -> bool:
        expression = sp.expand(expression)
        try:
            poly = sp.Poly(expression, *variables)
        except Exception as exc:
            raise CertificateError(f"expression is not polynomial in declared variables: {exc}") from exc
        return all(self.coefficient_is_zero(coefficient) for coefficient in poly.coeffs())


def _load_system(data: dict[str, Any]) -> tuple[tuple[sp.Symbol, ...], CoefficientField, list[sp.Expr]]:
    names = data.get("variables")
    if not isinstance(names, list) or any(not isinstance(name, str) for name in names):
        raise CertificateError("variables must be a list of names")
    variables = _symbols(names)
    raw_field = data.get("coefficient_field", {"type": "rational"})
    if not isinstance(raw_field, dict):
        raise CertificateError("coefficient_field must be an object")
    field = CoefficientField(raw_field, variables)
    raw_equations = data.get("equations")
    if not isinstance(raw_equations, list) or not raw_equations:
        raise CertificateError("equations must be a nonempty list")
    equations = [field.parse(item) for item in raw_equations]
    for equation in equations:
        try:
            sp.Poly(equation, *variables)
        except Exception as exc:
            raise CertificateError(f"non-polynomial equation {equation}: {exc}") from exc
    return variables, field, equations


def _check_yes_system(
    variables: tuple[sp.Symbol, ...],
    field: CoefficientField,
    equations: list[sp.Expr],
    raw_values: Any,
) -> dict[str, Any]:
    if not isinstance(raw_values, list) or len(raw_values) != len(variables):
        raise CertificateError("values must give one coordinate per variable")
    values = [field.parse(item) for item in raw_values]
    coefficient_symbols = set() if field.alpha is None else {field.alpha}
    for value in values:
        if not value.free_symbols <= coefficient_symbols:
            raise CertificateError(
                "sample-point coordinates must be ground algebraic numbers, "
                "not expressions in the system variables"
            )
    substitutions = dict(zip(variables, values))
    residuals = [sp.expand(equation.subs(substitutions)) for equation in equations]
    if not all(field.coefficient_is_zero(residual) for residual in residuals):
        raise CertificateError(f"sample point does not satisfy all equations: {residuals}")
    return {
        "equation_count": len(equations),
        "variable_count": len(variables),
        "proof": "Every defining polynomial vanishes at the certified real algebraic sample point.",
    }


def _check_no_system(
    variables: tuple[sp.Symbol, ...],
    field: CoefficientField,
    equations: list[sp.Expr],
    raw_sos: Any,
    raw_multipliers: Any,
) -> dict[str, Any]:
    if not isinstance(raw_sos, list):
        raise CertificateError("sum_of_squares must be a list")
    if not isinstance(raw_multipliers, list) or len(raw_multipliers) != len(equations):
        raise CertificateError("multipliers must match the equation list")
    sos = [field.parse(item) for item in raw_sos]
    multipliers = [field.parse(item) for item in raw_multipliers]
    identity = sp.Integer(1)
    identity += sum((term**2 for term in sos), sp.Integer(0))
    identity += sum(
        (multiplier * equation for multiplier, equation in zip(multipliers, equations)),
        sp.Integer(0),
    )
    if not field.polynomial_is_zero(identity, variables):
        raise CertificateError(f"claimed Real Nullstellensatz identity is nonzero: {sp.expand(identity)}")
    return {
        "equation_count": len(equations),
        "variable_count": len(variables),
        "squares": len(sos),
        "proof": "The checked identity -1=sum(s_i^2)+sum(q_j F_j) forbids a common real zero.",
    }


def verify_yes(data: dict[str, Any]) -> dict[str, Any]:
    variables, field, equations = _load_system(data)
    report = _check_yes_system(variables, field, equations, data.get("values"))
    return {
        "status": "YES",
        "scope": "exact equation-system feasibility over the reals",
        **report,
    }


def verify_no(data: dict[str, Any]) -> dict[str, Any]:
    variables, field, equations = _load_system(data)
    report = _check_no_system(
        variables,
        field,
        equations,
        data.get("sum_of_squares", []),
        data.get("multipliers"),
    )
    return {
        "status": "NO",
        "scope": "exact equation-system infeasibility over the reals",
        **report,
    }


def _principal_index(raw: Any, n: int) -> tuple[int, ...]:
    if not isinstance(raw, list):
        raise CertificateError("principal_species_zero_based must be a list")
    index = tuple(int(item) for item in raw)
    if not index or tuple(sorted(set(index))) != index or any(item < 0 or item >= n for item in index):
        raise CertificateError("principal species must be a nonempty sorted subset")
    return index


def verify_network_yes(data: dict[str, Any]) -> dict[str, Any]:
    network = parse_network(data)
    index = _principal_index(data.get("principal_species_zero_based"), network.n)
    variables, equations, metadata = canonical_branch_system(
        network.stoichiometric_matrix(),
        network.source_matrix(),
        index,
    )
    raw_field = data.get("coefficient_field", {"type": "rational"})
    if not isinstance(raw_field, dict):
        raise CertificateError("coefficient_field must be an object")
    field = CoefficientField(raw_field, variables)
    report = _check_yes_system(variables, field, equations, data.get("values"))
    return {
        "status": "YES",
        "scope": "network-bound exact all-mobile stationary-Turing semialgebraic certificate",
        "species": network.n,
        "reactions": network.m,
        **metadata,
        **report,
    }


def verify_network_no(data: dict[str, Any]) -> dict[str, Any]:
    network = parse_network(data)
    raw_branches = data.get("branch_certificates")
    if not isinstance(raw_branches, list):
        raise CertificateError("branch_certificates must be a list")
    expected = {
        index
        for size in range(1, network.n + 1)
        for index in itertools.combinations(range(network.n), size)
    }
    supplied: dict[tuple[int, ...], dict[str, Any]] = {}
    for raw in raw_branches:
        if not isinstance(raw, dict):
            raise CertificateError("each branch certificate must be an object")
        index = _principal_index(raw.get("principal_species_zero_based"), network.n)
        if index in supplied:
            raise CertificateError(f"duplicate branch certificate for {index}")
        supplied[index] = raw
    if set(supplied) != expected:
        missing = sorted(expected - set(supplied))
        extra = sorted(set(supplied) - expected)
        raise CertificateError(f"branch bundle is not exhaustive; missing={missing}, extra={extra}")

    branch_reports: list[dict[str, Any]] = []
    for index in sorted(expected, key=lambda item: (len(item), item)):
        raw = supplied[index]
        variables, equations, metadata = canonical_branch_system(
            network.stoichiometric_matrix(),
            network.source_matrix(),
            index,
        )
        raw_field = raw.get("coefficient_field", {"type": "rational"})
        if not isinstance(raw_field, dict):
            raise CertificateError("coefficient_field must be an object")
        field = CoefficientField(raw_field, variables)
        report = _check_no_system(
            variables,
            field,
            equations,
            raw.get("sum_of_squares", []),
            raw.get("multipliers"),
        )
        branch_reports.append({**metadata, **report})

    return {
        "status": "NO",
        "scope": "network-bound exhaustive all-mobile stationary-Turing infeasibility certificate",
        "species": network.n,
        "reactions": network.m,
        "branch_count": len(branch_reports),
        "branches": branch_reports,
        "proof": "Every nonempty principal-minor branch has an exact Real Nullstellensatz certificate.",
    }


def verify(data: dict[str, Any]) -> dict[str, Any]:
    kind = data.get("certificate_type")
    if kind == "real_algebraic_sample_yes":
        return verify_yes(data)
    if kind == "real_nullstellensatz_no":
        return verify_no(data)
    if kind == "mass_action_semialgebraic_yes":
        return verify_network_yes(data)
    if kind == "mass_action_semialgebraic_no":
        return verify_network_no(data)
    raise CertificateError("unsupported certificate_type")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    try:
        raw = json.loads(args.certificate.read_text())
        if not isinstance(raw, dict):
            raise CertificateError("top-level certificate must be an object")
        report = verify(raw)
    except Exception as exc:
        print(json.dumps({"status": "INVALID", "error": str(exc)}, indent=2))
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
