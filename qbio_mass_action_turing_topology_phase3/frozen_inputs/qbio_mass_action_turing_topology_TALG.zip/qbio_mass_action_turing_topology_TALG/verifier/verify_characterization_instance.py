#!/usr/bin/env python3
"""Certificate-aware classifier front end.

It returns YES/NO only when an exact independently checked certificate supports
that answer.  For an uncertified raw network it performs inexpensive exact
preprocessing but does not pretend to be a bundled CAD implementation; it
returns UNRESOLVED together with the canonical-formula command.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "computation"
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))

from flux_cone import gordan_no_positive_flux_certificate, positive_flux_witness  # noqa: E402
from network_parser import parse_network  # noqa: E402
from verify_negative_certificate import verify_certificate as verify_no  # noqa: E402
from verify_positive_witness import verify_certificate as verify_yes  # noqa: E402
from verify_semialgebraic_certificate import verify as verify_semialgebraic  # noqa: E402


def classify(data: dict[str, Any]) -> dict[str, Any]:
    kind = data.get("certificate_type")
    if kind == "mass_action_stationary_yes":
        return verify_yes(data)
    if kind in {"fixed_j_stationary_no", "no_positive_flux"}:
        return verify_no(data)
    if kind in {"mass_action_semialgebraic_yes", "mass_action_semialgebraic_no"}:
        return verify_semialgebraic(data)
    if kind == "mobile_proposal_counterexample":
        return {
            "status": "OUTSIDE_ASSUMPTIONS",
            "reason": "This file audits a proposed theorem rather than classifying a reaction network.",
        }

    # Raw network data: exact NO is available when positive steady flux is impossible.
    try:
        network = parse_network(data)
    except Exception as exc:
        return {"status": "OUTSIDE_ASSUMPTIONS", "reason": str(exc)}
    gamma = network.stoichiometric_matrix()
    flux = positive_flux_witness(gamma)
    if flux is None:
        certificate = gordan_no_positive_flux_certificate(gamma)
        if certificate is None:
            return {"status": "UNRESOLVED", "reason": "positive-flux LP was infeasible but no exact separator was produced"}
        y, z = certificate
        return {
            "status": "NO",
            "scope": "no strictly positive steady flux",
            "separator_y": [str(x) for x in y],
            "Gamma_transpose_y": [str(x) for x in z],
        }
    return {
        "status": "UNRESOLVED",
        "reason": (
            "A positive steady flux exists.  The T-ALG theorem gives a terminating exact "
            "real-algebraic decision procedure, but this lightweight command has not run "
            "quantifier elimination or a complete certificate search."
        ),
        "positive_flux_witness": [str(x) for x in flux],
        "canonical_formula_command": "python computation/exact_characterization.py network.json",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("instance", type=Path)
    args = parser.parse_args()
    try:
        data = json.loads(args.instance.read_text())
        result = classify(data)
    except Exception as exc:
        result = {"status": "OUTSIDE_ASSUMPTIONS", "reason": str(exc)}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result.get("status") in {"YES", "NO", "OUTSIDE_ASSUMPTIONS", "UNRESOLVED"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
