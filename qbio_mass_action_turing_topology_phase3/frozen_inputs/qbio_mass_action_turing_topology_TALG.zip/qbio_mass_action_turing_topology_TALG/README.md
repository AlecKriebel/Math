# Mass-action stationary Turing topology project

This package gives the formal **T-ALG** outcome for the problem of deciding,
from a finite classical mass-action reaction hypergraph, whether some strictly
positive realization has a homogeneous equilibrium that is asymptotically
stable on its stoichiometric compatibility class but has a nonzero spatial mode
with a strictly positive real eigenvalue after positive diagonal diffusion is
added.

The earlier STOP package remains frozen in its separately distributed archive
`qbio_mass_action_turing_topology.zip`. This T-ALG release does not overwrite
that historical tree or silently replace its failed arguments.

## Final outcome

For the indexed source/stoichiometric data `(Gamma,Y)`, the package proves:

1. an exact existential-real characterization eliminating the original rate
   constants, equilibrium concentrations, diffusion coefficients, domain
   length, and wave number;
2. a polynomial-size selector/circuit encoding, hence membership in the
   existential theory of the reals;
3. NP-hardness under polynomial-time many-one reductions from `PARTITION`, even
   for full-rank networks whose stoichiometric columns are signed unit vectors;
4. a terminating exact decision algorithm;
5. complete finite independently checkable YES and NO certificates;
6. polynomial-time classification for every fixed number of species, including
   arbitrary one-, two-, and three-species reaction lists;
7. Level 5, the indexed pair `(Gamma,Y)`, as the weakest sufficient
   parameter-independent reaction-network level among the six presentations
   specified in the directive;
8. the corrected designated-mobile theorem, exact conservation-law treatment,
   and a sharp separation between stationary and wave instability.

The general positive diagonal-stabilization problem remains open as a matrix
problem. The package does not claim to solve it. Instead, the NP-hardness
reduction uses a specially lifted interval family for which arbitrary positive
right scalings are eliminated exactly by a determinant argument.

## Core theorem

Every positive-equilibrium mass-action Jacobian is

```text
J(v,h) = Gamma diag(v) Y^T diag(h),
v > 0,  Gamma v = 0,  h > 0.
```

The network is weakly all-mobile stationary-Turing-admissible exactly when the
reduced matrix `J(v,h)|_S` is Hurwitz and one signed principal-minor polynomial

```text
tau_I(v) = (-1)^|I| det(Gamma diag(v) Y^T)_{I,I}
```

is negative. Boolean selector variables encode the existence of such an `I`
in polynomial size.

## Reproduce

```bash
cd /mnt/data/qbio_mass_action_turing_topology_TALG
bash release/one_command_verification.sh
```

The command recompiles the manuscript and runs 28 exact unit/regression tests,
nine JSON-schema checks, direct witness verifiers, network-bound
Real-Nullstellensatz certificates, the exact `PARTITION` reduction witness,
formula generation, adversarial regressions, a 65-file required-tree audit,
LaTeX/reference checks, and SHA-256 manifest generation.

Useful commands:

```bash
python computation/exact_characterization.py network.json
python classify_network.py certificate_or_network.json
python verifier/verify_semialgebraic_certificate.py certificate.json
python computation/partition_reduction.py 1 1 --with-witness
```

`classify_network.py` returns `YES` or `NO` only after checking an exact
certificate. For a raw positive-flux network it may return `UNRESOLVED`
because the release does not bundle a general-purpose CAD engine; this is a
software limitation, not a gap in the proved terminating algorithm.

The author-audit manuscript is `manuscript/main.pdf`. The mandated final
report is `FINAL_REPORT.md`, and machine-readable verification outputs are in
`release/verification_outputs/`.