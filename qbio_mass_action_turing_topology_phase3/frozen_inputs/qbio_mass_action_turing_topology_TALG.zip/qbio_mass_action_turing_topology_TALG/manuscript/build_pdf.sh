#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

# Some minimal TeX installations expose bibtex.original while the bibtex
# alternatives link is missing.  Prefer the normal command and fall back only
# when necessary.
TMP_BIN=""
cleanup() {
  if [[ -n "$TMP_BIN" ]]; then
    rm -rf "$TMP_BIN"
  fi
}
trap cleanup EXIT

if ! command -v bibtex >/dev/null 2>&1; then
  ALT_BIBTEX="$(command -v bibtex.original || true)"
  if [[ -z "$ALT_BIBTEX" ]]; then
    printf 'ERROR: neither bibtex nor bibtex.original is available\n' >&2
    exit 2
  fi
  TMP_BIN="$(mktemp -d)"
  ln -s "$ALT_BIBTEX" "$TMP_BIN/bibtex"
  export PATH="$TMP_BIN:$PATH"
fi

latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error supplement.tex

# Audit the final converged logs before cleanup.  First-pass undefined-reference
# warnings can legitimately appear in latexmk's transcript, so only the last
# generated log files are authoritative.
for log in main.log supplement.log; do
  if grep -Eq 'There were undefined references|Citation .* undefined|Reference .* undefined|Overfull \hbox|Underfull \hbox|Overfull \vbox|Underfull \vbox' "$log"; then
    printf 'ERROR: final LaTeX audit failed for %s\n' "$log" >&2
    grep -nE 'There were undefined references|Citation .* undefined|Reference .* undefined|Overfull|Underfull' "$log" >&2 || true
    exit 3
  fi
done
printf 'FINAL_LATEX_LAYOUT_AND_REFERENCE_AUDIT_OK\n'

latexmk -c main.tex
latexmk -c supplement.tex
printf '%s\n' "$HERE/main.pdf" "$HERE/supplement.pdf"
