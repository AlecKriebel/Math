# Project state

## Status

Completed under **OUTCOME T-ALG** on 2026-08-13.

The earlier formal STOP package remains frozen in its separately distributed
archive `qbio_mass_action_turing_topology.zip`. The present continuation adds a
proved complexity boundary, complete exact certificates, and fixed-species
algorithms; it does not erase the earlier failed structural approaches.

## Proved statements

### Matrix and spatial closure

1. **All-mobile fixed-J theorem.** For every real square matrix `J`, some
   positive diagonal `D` makes `J-D` have a strictly positive real eigenvalue
   exactly when one signed principal minor
   `(-1)^|I| det J_{I,I}` is negative.
2. **Correct designated-mobile theorem.** For mobile set `M`, under
   `det(lambda I-J)>0` for all positive `lambda`, partial diffusion creates a
   positive real eigenvalue exactly when some `lambda>0` and
   `I superset M^c` satisfy
   `det(lambda I_|I|-J_{I,I})<0`.
3. **Counterexample to the zero-spectral-parameter proposal.** The exact
   rational 3-by-3 certificate in
   `verifier/test_certificates/mobile_proposal_counterexample.json` refutes the
   proposed determinant-at-zero mobile criterion.
4. **Conservative extension.** If `J|_S` is Hurwitz, then
   `R^n=S direct-sum ker J`, the conservation zeros are semisimple, and
   `det(lambda I-J)>0` for every positive `lambda`. Nonzero Neumann modes must
   be tested on the full species space.
5. **Domain normalization.** The nonzero wave-number factor is absorbed into
   the freely chosen positive diffusion matrix.

### Classical mass action

6. **Flux/equilibrium parameterization.** Every positive-equilibrium Jacobian
   is
   `J(v,h)=Gamma diag(v)Y^T diag(h)` with `v>0`, `Gamma v=0`, and `h>0`, and
   every such pair reconstructs positive rates and a positive equilibrium.
7. **Principal-minor expansion.** Every signed principal minor factors as a
   positive monomial in `h` times the exact flux polynomial `tau_I(v)`.
8. **Arbitrary rational-Jacobian realization.** Every rational square matrix is
   a full-rank classical mass-action Jacobian at `x*=1` with strictly positive
   rational rates and pairwise-balanced positive flux.
9. **Independent row-segment realization.** A family with fixed rows and one
   open-interval affine parameter per variable row is realized exactly as
   `R L(q)`, with `R>0` diagonal and `q` in the open cube.

### T-ALG characterization and complexity

10. **Exact semialgebraic iff theorem.** A network is weakly all-mobile
    stationary-Turing-admissible exactly when some positive steady flux and
    positive inverse-equilibrium scaling make the reduced Jacobian Hurwitz and
    some `tau_I(v)` negative.
11. **Polynomial-size existential-real encoding.** Boolean selectors encode the
    principal subset through
    `det(I-S-S A(v)S)<0`; determinant and Hurwitz computations are encoded by
    polynomial-size arithmetic circuits. Hence the decision problem belongs to
    the existential theory of the reals.
12. **NP-hardness.** A polynomial-time many-one reduction from `PARTITION`
    produces a full-rank network with `3m+1` species and `8m+2` reactions,
    signed-unit stoichiometric columns, and a direct-product positive flux cone.
    The network is stationary-Turing-admissible exactly when the partition
    instance is YES.
13. **Scaling elimination for the reduction family.** The row-splitting lift
    satisfies
    `exists q,D>0: L(q)D Hurwitz` exactly when the original interval family
    contains a Hurwitz matrix; arbitrary positive equilibrium scaling cannot
    create a false YES.
14. **Complete finite certificates.** Every feasible branch has a real
    algebraic sample certificate. Every infeasible branch has a Real
    Nullstellensatz identity. A network-level NO certificate consists of an
    exhaustive identity bundle over every nonempty principal branch.
15. **Terminating exact algorithm.** Exact real quantifier elimination decides
    feasibility; real-algebraic sample extraction and exhaustive identity
    enumeration produce independently checkable certificates.
16. **Fixed-species polynomial time.** For every fixed `n`, positive steady
    fluxes project to the relative interior of a rational cone in the fixed
    `n^2`-dimensional matrix space. Circuit enumeration, fixed-dimensional
    polyhedral conversion, and fixed-variable real-algebraic decision give a
    polynomial-time algorithm.
17. **Complete `n<=3` calibration.** One species is always NO; two species have
    the exact projected-cone determinant/opposite-diagonal criterion; three
    species have the complete projected-cone reduced-Hurwitz and singleton/
    two-by-two-minor disjunction.
18. **Weakest parameter-independent network level.** An exact fixed-row
    mass-action pair has the same unsigned and complete all-negative signed
    interaction graphs for every positive realization but opposite
    network-wide answers, so Levels 1 and 2 fail. Level 3 is a selected,
    parameter-dependent realization rather than a finite invariant of the
    declared network. Level 4 (`Gamma` alone) is refuted by an exact
    same-`Gamma` two-network pair with opposite answers. Level 5, the indexed
    pair `(Gamma,Y)`, supports the iff theorem, algorithm, and certificates;
    Level 6 is an equivalent labeled presentation.

### Stationary/wave boundary

19. The principal-minor theorem characterizes positive **real** spatial
    eigenvalues, not complex wave crossings.
20. For fixed numerical Jacobians of dimension at most three, signed-`P_0`
    plus Hurwitz stability excludes all diagonal diffusion destabilization.
    Dimension four is the first fixed-J dimension in which wave-only
    destabilization can occur.

## Exact dependency graph

```text
mass-action equilibrium
  -> positive flux v and inverse equilibrium h
  -> reduced Hurwitz inequalities
  -> negative signed principal-minor polynomial
  -> exact existential-real formula
      -> selector/circuit encoding -> membership in ETR
      -> Real Nullstellensatz -> complete NO certificates
      -> projected flux cone -> fixed-n polynomial time

PARTITION
  -> open-cube interval Hurwitz family
  -> row-splitting lift
  -> arbitrary-right-scaling elimination
  -> mass-action row-segment realization
  -> NP-hard stationary-Turing admissibility
```

## Failed approaches preserved

1. The determinant-at-zero designated-mobile proposal remains preserved and
   explicitly refuted in `fixed_jacobian/mobile_set_extension.tex`.
2. The earlier attempt to obtain a compact arbitrary-dimensional positive
   diagonal-stabilization theorem remains marked as unresolved in
   `mass_action/stable_realization.tex`.
3. `topology/turing_core_definition.tex` records why the T-ALG result is not a
   finite forbidden-motif theorem.
4. `adversarial_audit/stationary_vs_wave.md` preserves the failed implication
   from a stationary witness to a primary stationary bifurcation.
5. The complete Phase-I STOP tree remains byte-separate from this continuation.

## Numerical observations

No theorem, hardness implication, YES certificate, or NO certificate depends on
floating-point evidence. Numerical search files are discovery-only.

## Remaining limitations, not blockers to T-ALG

1. no compact forbidden-motif, oriented-matroid, or minimal-core
   characterization for arbitrary network size;
2. no `exists-R`-hardness or completeness result, no strong NP-hardness, and no
   polynomial certificate-size bound;
3. no proof that the real stationary crossing is the first instability along a
   diffusion path;
4. no arbitrary-dimensional reaction-hypergraph characterization of wave
   instability;
5. no nonlinear patterned-state existence, stability, or persistence theorem;
6. no bundled general-purpose quantifier-elimination engine in the lightweight
   CLI, although the exact terminating algorithm is proved.

## Landmark outcome complete?

**Yes: T-ALG.** The stronger motif-style T-CHAR outcome is not claimed.

## Verification status

The one-command release verification currently passes:

* 28 exact unit/regression tests;
* nine formal JSON-schema checks;
* direct rational YES/NO witnesses;
* network-bound semialgebraic YES and exhaustive NO certificates;
* the exact `PARTITION` reduction witness;
* canonical selector-form generation;
* all machine-readable status assertions;
* a 65-file required-tree audit;
* LaTeX citation, input, label, brace, and compiled-PDF checks.

The manuscript PDF is rebuilt by the verification command and separately
rendered for visual inspection. Machine-readable outputs are in
`release/verification_outputs/`; hashes are in `release/sha256_manifest.txt`.