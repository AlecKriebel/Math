#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/release/verification_outputs"
mkdir -p "$OUT"
rm -f "$OUT"/*.json "$OUT"/*.txt

export PYTHONPATH="$ROOT/computation${PYTHONPATH:+:$PYTHONPATH}"

printf '[1/12] Compiling Python sources...\n'
python -m compileall -q "$ROOT/computation" "$ROOT/verifier" "$ROOT/adversarial_audit" "$ROOT/classify_network.py"

printf '[2/12] Validating certificate schemas...\n'
python - "$ROOT" <<'PY' > "$OUT/schema_validation.txt"
import json
import sys
from pathlib import Path
import jsonschema

root = Path(sys.argv[1])
schema = json.loads((root / 'verifier/certificate_schema.json').read_text())
files = [
    'positive_two_species.json',
    'fixed_j_p0_no.json',
    'no_positive_flux.json',
    'mobile_proposal_counterexample.json',
    'network_semialgebraic_yes.json',
    'network_semialgebraic_no.json',
    'real_sample_yes.json',
    'real_sample_algebraic_yes.json',
    'real_nullstellensatz_no.json',
]
for name in files:
    data = json.loads((root / 'verifier/test_certificates' / name).read_text())
    jsonschema.validate(data, schema)
    print(f'{name}: SCHEMA_OK')
PY
cat "$OUT/schema_validation.txt"

printf '[3/12] Running unit tests...\n'
python -m unittest discover -s "$ROOT/computation/tests" -v 2>&1 | tee "$OUT/unit_tests.txt"

printf '[4/12] Verifying direct exact YES/NO certificates...\n'
python "$ROOT/verifier/verify_positive_witness.py" \
  "$ROOT/verifier/test_certificates/positive_two_species.json" \
  > "$OUT/positive_two_species.json"
python "$ROOT/verifier/verify_negative_certificate.py" \
  "$ROOT/verifier/test_certificates/fixed_j_p0_no.json" \
  > "$OUT/fixed_j_p0_no.json"
python "$ROOT/verifier/verify_negative_certificate.py" \
  "$ROOT/verifier/test_certificates/no_positive_flux.json" \
  > "$OUT/no_positive_flux.json"
python "$ROOT/verifier/verify_mobile_counterexample.py" \
  "$ROOT/verifier/test_certificates/mobile_proposal_counterexample.json" \
  > "$OUT/mobile_counterexample.json"

printf '[5/12] Verifying complete T-ALG certificates and reduction witness...\n'
python "$ROOT/verifier/verify_semialgebraic_certificate.py" \
  "$ROOT/verifier/test_certificates/network_semialgebraic_yes.json" \
  > "$OUT/network_semialgebraic_yes.json"
python "$ROOT/verifier/verify_semialgebraic_certificate.py" \
  "$ROOT/verifier/test_certificates/network_semialgebraic_no.json" \
  > "$OUT/network_semialgebraic_no.json"
python "$ROOT/verifier/verify_partition_reduction.py" \
  "$ROOT/verifier/test_certificates/partition_reduction_yes_1_1.json" \
  > "$OUT/partition_reduction_yes.json"
python "$ROOT/verifier/verify_semialgebraic_certificate.py" \
  "$ROOT/verifier/test_certificates/real_sample_algebraic_yes.json" \
  > "$OUT/real_sample_algebraic_yes.json"
python "$ROOT/verifier/verify_semialgebraic_certificate.py" \
  "$ROOT/verifier/test_certificates/real_nullstellensatz_no.json" \
  > "$OUT/real_nullstellensatz_no.json"

printf '[6/12] Generating the canonical reaction-hypergraph formula...\n'
python "$ROOT/computation/exact_characterization.py" \
  "$ROOT/verifier/test_certificates/raw_unresolved_positive_flux.json" \
  --output "$OUT/canonical_formula.json"
python - "$OUT/canonical_formula.json" <<'PY'
import json
import sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
if 'polynomial_size_selector_encoding' not in data:
    raise SystemExit('selector encoding missing from canonical formula')
if not data.get('branches'):
    raise SystemExit('canonical branch list is empty')
print(f"FORMULA_OK species={data['species_count']} reactions={data['reaction_count']} branches={len(data['branches'])}")
PY

printf '[7/12] Checking certificate-aware classifier behavior...\n'
python "$ROOT/classify_network.py" \
  "$ROOT/verifier/test_certificates/raw_unresolved_positive_flux.json" \
  > "$OUT/raw_unresolved.json"
python "$ROOT/classify_network.py" \
  "$ROOT/verifier/test_certificates/network_semialgebraic_yes.json" \
  > "$OUT/classifier_semialgebraic_yes.json"
python "$ROOT/classify_network.py" \
  "$ROOT/verifier/test_certificates/network_semialgebraic_no.json" \
  > "$OUT/classifier_semialgebraic_no.json"

printf '[8/12] Running exact adversarial regressions...\n'
python "$ROOT/adversarial_audit/counterexample_search.py" > "$OUT/counterexample_regressions.json"

printf '[9/12] Asserting machine-readable statuses...\n'
python - "$OUT" <<'PY'
import json
import sys
from pathlib import Path
out = Path(sys.argv[1])
expected = {
    'positive_two_species.json': 'YES',
    'fixed_j_p0_no.json': 'NO',
    'no_positive_flux.json': 'NO',
    'mobile_counterexample.json': 'REFUTES_PROPOSED_MOBILE_CRITERION',
    'network_semialgebraic_yes.json': 'YES',
    'network_semialgebraic_no.json': 'NO',
    'partition_reduction_yes.json': 'YES',
    'real_sample_algebraic_yes.json': 'YES',
    'real_nullstellensatz_no.json': 'NO',
    'classifier_semialgebraic_yes.json': 'YES',
    'classifier_semialgebraic_no.json': 'NO',
    'raw_unresolved.json': 'UNRESOLVED',
}
for name, status in expected.items():
    value = json.loads((out / name).read_text()).get('status')
    if value != status:
        raise SystemExit(f'{name}: expected {status}, got {value}')
    print(f'{name}: {value}')
PY

printf '[10/12] Auditing mandatory project files...\n'
python - "$ROOT" <<'PY' > "$OUT/required_files.txt"
import sys
from pathlib import Path
root = Path(sys.argv[1])
required = '''
STATE.md
README.md
theorem_dependency_graph.md
literature_audit/current_status.md
literature_audit/terminology_crosswalk.md
literature_audit/priority_audit.md
definitions/reaction_network_conventions.tex
definitions/turing_definitions.tex
definitions/conservation_laws.tex
definitions/topology_levels.tex
fixed_jacobian/domain_mode_reduction.tex
fixed_jacobian/stationary_diagonal_damping.tex
fixed_jacobian/mobile_set_extension.tex
fixed_jacobian/turing_hopf_boundary.tex
fixed_jacobian/additive_D_stability_audit.tex
mass_action/equilibrium_flux_parameterization.tex
mass_action/jacobian_factorization.tex
mass_action/principal_minor_expansion.tex
mass_action/stable_realization.tex
mass_action/conservative_networks.tex
mass_action/row_segment_realization.tex
topology/turing_core_definition.tex
topology/necessity.tex
topology/sufficiency.tex
topology/lifting_and_reduction.tex
topology/exact_characterization.tex
topology/complexity_boundary.tex
topology/np_hardness_reduction.tex
topology/certificate_completeness.tex
topology/fixed_species_algorithm.tex
low_dimension/one_species.tex
low_dimension/two_species.tex
low_dimension/three_species.tex
low_dimension/comparison_with_known_criteria.tex
benchmarks/classical_positive_examples.tex
benchmarks/structural_negative_classes.tex
benchmarks/coarse_topology_counterexamples.tex
benchmarks/benchmark_table.csv
computation/network_format.md
computation/network_parser.py
computation/exact_linear_algebra.py
computation/flux_cone.py
computation/principal_minors.py
computation/hurwitz.py
computation/search_small_networks.py
computation/discover_witnesses.py
computation/exact_characterization.py
computation/partition_reduction.py
verifier/verify_positive_witness.py
verifier/verify_negative_certificate.py
verifier/verify_characterization_instance.py
verifier/verify_partition_reduction.py
verifier/verify_semialgebraic_certificate.py
verifier/certificate_schema.json
adversarial_audit/assumption_audit.md
adversarial_audit/conservation_audit.md
adversarial_audit/stationary_vs_wave.md
adversarial_audit/nonlinear_claims_audit.md
adversarial_audit/counterexample_search.py
adversarial_audit/unresolved_gaps.md
manuscript/main.tex
manuscript/supplement.tex
manuscript/references.bib
release/reproducibility.md
release/one_command_verification.sh
'''.strip().splitlines()
missing = [rel for rel in required if not (root / rel).is_file()]
if missing:
    raise SystemExit('Missing required files:\n' + '\n'.join(missing))
for rel in required:
    print(f'OK {rel}')
print(f'TOTAL_OK {len(required)}')
PY
cat "$OUT/required_files.txt"

printf '[11/12] Rebuilding and auditing the manuscript...\n'
bash "$ROOT/manuscript/build_pdf.sh" > "$OUT/manuscript_build.txt"
python - "$ROOT" <<'PY' > "$OUT/latex_source_audit.txt"
import re
import sys
from pathlib import Path

root = Path(sys.argv[1])
tex_files = sorted(root.rglob('*.tex'))
all_text = '\n'.join(path.read_text() for path in tex_files)
main = (root / 'manuscript/main.tex').read_text()
supplement_source = (root / 'manuscript/supplement.tex').read_text()
bib = (root / 'manuscript/references.bib').read_text()

cites = set()
for match in re.finditer(r'\\cite\w*\{([^}]*)\}', all_text):
    cites.update(key.strip() for key in match.group(1).split(',') if key.strip())
bib_keys = set(re.findall(r'@\w+\{\s*([^,\s]+)', bib))
missing_bib = sorted(cites - bib_keys)
if missing_bib:
    raise SystemExit('Missing bibliography keys: ' + ', '.join(missing_bib))

input_values = re.findall(r'\\input\{([^}]+)\}', main + '\n' + supplement_source)
missing_inputs = []
for value in input_values:
    path = root / 'manuscript' / value
    if not path.suffix:
        path = path.with_suffix('.tex')
    if not path.is_file():
        missing_inputs.append(str(path))
if missing_inputs:
    raise SystemExit('Missing input files:\n' + '\n'.join(missing_inputs))

labels = set(re.findall(r'\\label\{([^}]+)\}', all_text))
refs = set(re.findall(r'\\(?:ref|eqref|autoref)\{([^}]+)\}', all_text))
missing_labels = sorted(refs - labels)
if missing_labels:
    raise SystemExit('Missing labels: ' + ', '.join(missing_labels))

for path in tex_files:
    text = '\n'.join(line.split('%', 1)[0] for line in path.read_text().splitlines())
    text = re.sub(r'\\[{}]', '', text)
    balance = 0
    for char in text:
        if char == '{':
            balance += 1
        elif char == '}':
            balance -= 1
        if balance < 0:
            raise SystemExit(f'Negative brace balance in {path}')
    if balance:
        raise SystemExit(f'Unbalanced braces in {path}: {balance}')

pdf = root / 'manuscript/main.pdf'
if not pdf.is_file() or pdf.stat().st_size == 0:
    raise SystemExit('Compiled manuscript/main.pdf is missing or empty')
supplement = root / 'manuscript/supplement.pdf'
if not supplement.is_file() or supplement.stat().st_size == 0:
    raise SystemExit('Compiled manuscript/supplement.pdf is missing or empty')

print(f'TEX_FILES {len(tex_files)}')
print(f'CITATION_KEYS {len(cites)}')
print(f'INPUTS {len(input_values)}')
print(f'COMPILED_PDF_BYTES {pdf.stat().st_size}')
print(f'COMPILED_SUPPLEMENT_PDF_BYTES {supplement.stat().st_size}')
print('LATEX_SOURCE_AUDIT_OK')
PY
cat "$OUT/latex_source_audit.txt"

printf '[12/12] Regenerating SHA-256 manifest...\n'
python - "$ROOT" <<'PY'
import hashlib
import sys
from pathlib import Path
root = Path(sys.argv[1])
manifest = root / 'release/sha256_manifest.txt'
entries = []
for path in sorted(root.rglob('*')):
    if not path.is_file():
        continue
    rel = path.relative_to(root).as_posix()
    if rel == 'release/sha256_manifest.txt' or '__pycache__' in path.parts or path.suffix == '.pyc':
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    entries.append(f'{digest}  {rel}')
manifest.write_text('\n'.join(entries) + '\n')
print(f'wrote {manifest} with {len(entries)} entries')
PY

printf 'ALL EXACT VERIFICATION GATES PASSED\n'
