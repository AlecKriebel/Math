# Reproducibility guide

## Environment used

The release was verified on 2026-08-13 with:

```text
Python 3.13.5
SymPy 1.14.0
jsonschema 4.26.0
```

No floating-point eigenvalue is accepted as proof. Certificate scalars are JSON integers or exact rational strings. The verifiers reject binary floating-point values on every exact path.

## One-command verification

```bash
cd /mnt/data/qbio_mass_action_turing_topology_TALG
bash release/one_command_verification.sh
```

The command performs:

1. Python byte-code compilation;
2. JSON-schema validation of nine formal certificate files;
3. the complete exact unit/regression suite;
4. independent verification of the direct positive and negative certificates;
5. independent verification of the network-bound semialgebraic YES and
   exhaustive Real-Nullstellensatz NO certificates, the `PARTITION` reduction
   witness, and generic real-algebraic certificate regressions;
6. generation and validation of the canonical reaction-hypergraph formula,
   including its polynomial-size selector encoding;
7. certificate-aware classifier checks;
8. exact adversarial regressions;
9. machine-readable status assertions;
10. a 65-file mandatory-tree audit;
11. manuscript rebuild plus LaTeX citation/input/reference and PDF audit;
12. regeneration of `release/sha256_manifest.txt`.

Expected high-level statuses are:

```text
positive_two_species: YES
fixed_j_p0_no: NO
no_positive_flux: NO
mobile_proposal_counterexample: REFUTES_PROPOSED_MOBILE_CRITERION
network_semialgebraic_yes: YES
network_semialgebraic_no: NO
partition_reduction_yes: YES
real_sample_algebraic_yes: YES
real_nullstellensatz_no: NO
raw_positive_flux_network: UNRESOLVED
```

Detailed machine-readable outputs are written to `release/verification_outputs/`.

## Individual commands

```bash
python verifier/verify_positive_witness.py \
  verifier/test_certificates/positive_two_species.json

python verifier/verify_negative_certificate.py \
  verifier/test_certificates/fixed_j_p0_no.json

python verifier/verify_negative_certificate.py \
  verifier/test_certificates/no_positive_flux.json

python verifier/verify_mobile_counterexample.py \
  verifier/test_certificates/mobile_proposal_counterexample.json

python verifier/verify_semialgebraic_certificate.py \
  verifier/test_certificates/network_semialgebraic_yes.json

python verifier/verify_semialgebraic_certificate.py \
  verifier/test_certificates/network_semialgebraic_no.json

python verifier/verify_partition_reduction.py \
  verifier/test_certificates/partition_reduction_yes_1_1.json

python computation/exact_characterization.py \
  verifier/test_certificates/raw_unresolved_positive_flux.json

python computation/partition_reduction.py 1 1 --with-witness

python classify_network.py \
  verifier/test_certificates/raw_unresolved_positive_flux.json
```

## Discovery versus verification

`computation/discover_witnesses.py` and `computation/search_small_networks.py`
are discovery/reconnaissance utilities.  Their failure to find a witness never
yields `NO`.  A complete network-level NO certificate is instead an exhaustive
bundle of Real-Nullstellensatz identities whose branch equations are regenerated
from the supplied reaction hypergraph by the independent verifier.

## Manuscript source and PDF

The manuscript and supplement are LaTeX sources in `manuscript/`. Rebuild both
included author-audit PDFs with:

```bash
bash manuscript/build_pdf.sh
```

The build script uses `latexmk` and includes a fallback for installations that
expose `bibtex.original` but have a broken `bibtex` alternatives link.  The
release audit verifies citation keys, `\input` paths, cross-reference labels,
basic brace balance, and a nonempty compiled PDF.  The frozen release PDF is
also rendered page-by-page and visually inspected; PDF compilation remains
independent of the mathematical certificate checks.

## Algorithm/software distinction

The theorem supplies a terminating exact decision-and-certificate procedure:
real quantifier elimination decides each branch, and exact certificate
enumeration terminates by certificate completeness.  The release intentionally
does not vendor a general-purpose CAD or quantifier-elimination engine.
Accordingly, `classify_network.py` returns `UNRESOLVED` for a raw positive-flux
network with no attached certificate.  It does return `YES` or `NO` after
checking the corresponding network-bound exact certificate.  This is a
limitation of the bundled front end, not a retreat from the proved T-ALG
decision theorem.
