# Final report

## OUTCOME

**T-ALG — exact algorithmic characterization plus a proved complexity
boundary.**

The earlier STOP package is preserved separately. The continuation closes the
previous stable-realization gate without claiming a compact motif theorem: it
gives a polynomial-size existential-real characterization, an explicit
NP-hardness reduction, a terminating exact decision procedure, complete finite
YES and NO certificates, and polynomial-time algorithms for every fixed number
of species.

## MAIN THEOREM

Let a rationally encoded finite classical mass-action network have indexed
source matrix `Y`, stoichiometric matrix `Gamma`, and stoichiometric subspace
`S=im Gamma`. Choose a rational basis matrix `B` for `S` and a rational left
inverse `C`. Put

```text
A(v)   = Gamma diag(v) Y^T,
J(v,h) = A(v) diag(h),
R(v,h) = C J(v,h) B.
```

For each principal species set `I`, define

```text
tau_I(v) = (-1)^|I| det A(v)_{I,I}.
```

Then the network is weakly all-mobile stationary-Turing-admissible exactly
when there exist

```text
v > 0,       Gamma v = 0,
h > 0,
all Routh-Hurwitz determinants of R(v,h) positive,
tau_I(v) < 0 for at least one nonempty I.
```

Equivalently, introduce Boolean selectors `b_i`, set `S_b=diag(b)`, and impose

```text
b_i^2-b_i = 0,
det(I-S_b-S_b A(v) S_b) < 0.
```

For a Boolean selector this determinant is exactly
`(-1)^|I| det A(v)_{I,I}`. Determinants, characteristic coefficients, and
Hurwitz determinants have polynomial-size arithmetic circuits, so gate
variables convert the criterion into a polynomial-size existential-real
formula computed solely from `(Gamma,Y)`.

This characterization eliminates the original rate constants, equilibrium
concentrations, diffusion coefficients, spatial domain length, and wave number.
Feasible `v,h` reconstruct them constructively:

```text
x* = h^{-1},
k_r = v_r/(x*)^{y_r},
```

and the negative signed principal minor gives a terminating exact multiscale
construction of a strictly positive diagonal diffusion matrix.

### Complexity theorem

The arbitrary-network decision problem is NP-hard under polynomial-time
many-one reductions from `PARTITION`. For an input containing `ell` integers, choose
`m=k^2>ell`. The reduction constructs a full-rank classical mass-action
network with

```text
3m+1 species,
8m+2 reactions,
every stoichiometric column in {+e_i,-e_i},
a direct-product positive steady-flux cone.
```

The network is stationary-Turing-admissible exactly when the partition
instance is YES. The decisive row-splitting lemma proves that arbitrary
positive equilibrium/right-diagonal scaling cannot turn a NO interval family
into a stable mass-action Jacobian.

The problem therefore belongs to the existential theory of the reals and is
NP-hard. No claim of strong NP-hardness, existential-real hardness, or
existential-real completeness is made.

### Exact algorithm and bounded dimension

Exact real quantifier elimination decides the finite formula. Feasible
branches have real-algebraic sample points; infeasible branches have Real
Nullstellensatz identities. Exhaustive exact certificate enumeration therefore
turns the decision route into a terminating proof-producing algorithm.

For every fixed species count `n`, the nonnegative steady-flux cone can be
projected into the fixed `n^2`-dimensional matrix space. Its extreme rays have
support at most `n+1`, so they can be enumerated in polynomial time for fixed
`n`; fixed-dimensional polyhedral conversion and fixed-variable real-algebraic
decision then give polynomial bit complexity. This includes arbitrary reaction
lists for one, two, and three species.

### Designated mobile species

For a specified mobile set `M`, retain the positive-flux and homogeneous
Hurwitz conditions and introduce `lambda>0`. The exact stationary condition is

```text
det(lambda I_|I| - J(v,h)_{I,I}) < 0
```

for some `I` containing every immobile species. A Boolean selector gives a
polynomial-size formula. The previously proposed determinant-at-zero rule is
false; the package preserves an exact rational counterexample.

## TOPOLOGY LEVEL

The weakest sufficient **parameter-independent reaction-network input** among
the levels in the mission is **Level 5**, the indexed pair `(Gamma,Y)`.

* Levels 1 and 2 are refuted network-wide by an exact fixed-row mass-action
  pair with the same complete all-negative interaction graph for every positive
  realization and opposite admissibility answers.
* Level 3 is a selected, parameter-dependent Jacobian/Coates graph rather than
  a finite invariant of the declared network.
* Level 4 is refuted by an exact two-network pair with the same ordered
  `Gamma=[e1,-e1,e2,-e2]`: one is stationary-Turing-admissible and the other has
  `A(v)=0` for every positive steady flux.
* Level 5 determines the exact formula, algorithm, and certificates.
* Level 6 is an equivalent labeled presentation because targets satisfy
  `y'_r=y_r+gamma_r` once indexed reactions are retained.

Parallel identical reactions remain separate indexed columns. They may be
merged or split only by aggregating or partitioning their positive fluxes.

## STATIONARY OR WAVE

The theorem characterizes **weak stationary diffusion-driven instability**:
some nonzero spatial mode has a strictly positive **real** eigenvalue.

It does not assert that the real crossing is the first instability along a
diffusion path, that the zero crossing is simple and transverse, or that no
complex conjugate pair crosses earlier. Stationary and Turing-Hopf/wave
instability remain separate. For fixed numerical Jacobians of dimension at
most three, Hurwitz stability plus the signed-`P_0` condition excludes all
diagonal-diffusion destabilization; wave-only behavior first becomes possible
in dimension four at the fixed-J level.

## CONSERVATION LAWS

Homogeneous stability is assessed on `S=im Gamma`. If `J|_S` is Hurwitz, then

```text
R^n = S direct-sum ker J,
```

and the conservation-induced zero eigenvalues are semisimple. Hence
`det(lambda I-J)>0` for every `lambda>0`.

A nonzero Neumann eigenfunction has zero spatial mean. Therefore every species
amplitude preserves the integrated conservation laws, and the spatial matrix
must be tested on the full species space. Restricting `J-q^2D` to `S` would in
general be wrong because unequal diagonal diffusion need not preserve `S`.

## CERTIFICATE

Every arbitrary-network answer has a finite independently checkable exact
certificate; no polynomial size bound is claimed.

### YES certificate

A network-level YES file contains the reaction hypergraph, a selected
principal branch, and a real-algebraic sample point for the canonical
equation-only system. All coordinates lie in one specified field `Q(alpha)`,
represented by an irreducible minimal polynomial, a rational isolating interval
for the intended real root, and polynomial representatives. Strict inequalities
are encoded by equations such as

```text
g>0  iff  g z^2-1=0.
```

The verifier reconstructs every equation from `(Gamma,Y)` and checks exact
vanishing in `Q(alpha)`.

### NO certificate

For each nonempty principal branch with canonical equations `F_j=0`, a NO file
supplies an exact identity

```text
-1 = sum_i s_i^2 + sum_j q_j F_j.
```

A network-level NO certificate is an exhaustive bundle containing exactly one
checked identity for every branch. Evaluation at a hypothetical real common
zero would give `-1>=0`, proving infeasibility.

The package also retains compact direct certificates for a complete rational
mass-action witness, absence of positive steady flux, a fixed-J signed-`P_0`
NO instance, and the designated-mobile counterexample.

## SOFTWARE

From the frozen project root run:

```bash
bash release/one_command_verification.sh
```

Principal entry points are:

```bash
python computation/exact_characterization.py network.json
python computation/partition_reduction.py 1 1 --with-witness
python verifier/verify_semialgebraic_certificate.py certificate.json
python verifier/verify_partition_reduction.py certificate.json
python classify_network.py certificate_or_network.json
```

The release script compiles the Python sources, validates all schemas, runs the
exact unit and adversarial regression suite, verifies direct and network-bound
YES/NO certificates, replays the `PARTITION` reduction witness, regenerates the
canonical formula, checks classifier statuses, audits the mandatory tree,
rebuilds and audits the manuscript, and regenerates the SHA-256 manifest.

The proved algorithm is complete, but the lightweight bundled classifier does
not vendor a general-purpose CAD/quantifier-elimination engine. It therefore
returns `UNRESOLVED` for a raw positive-flux network without an attached exact
certificate; it never converts failed numerical search into `NO`.

## NOVELTY

The all-mobile fixed-J principal-minor criterion has matrix-theory antecedents
and is not claimed as new. The NP-hardness source family is adapted from the
interval-matrix stability construction of Blondel and Tsitsiklis. The package
adds the classical-mass-action row-segment realization and an exact
right-scaling-elimination lift needed to make that reduction survive arbitrary
positive equilibria.

The dated literature audit did not locate a prior theorem combining, for
arbitrary classical mass-action reaction hypergraphs, the exact `(Gamma,Y)`
existential-real characterization, the restricted-family NP-hardness proof,
complete two-sided real-algebraic certificates, and polynomial-time algorithms
for every fixed species count. This is a search result, not a formal proof of
priority.

The parts most requiring independent expert audit are:

1. the open-cube-to-row-splitting scaling-elimination argument;
2. the row-segment mass-action realization and polynomial bit-size accounting;
3. the complete Real-Nullstellensatz certificate theorem as bound to canonical
   network equations;
4. the projected-cone fixed-species polynomial-time proof;
5. the corrected designated-mobile theorem and exact counterexample.

The package should be treated as a new proof package prepared for expert audit,
not as peer-reviewed confirmation or a settled priority claim.

## LIMITATIONS

* No compact forbidden-motif, child-selection-only, or oriented-matroid
  characterization is proved.
* The unrestricted positive diagonal-stabilization problem remains open; only
  the reduction family receives a special exact scaling-elimination theorem.
* No existential-real hardness/completeness, strong NP-hardness, or polynomial
  certificate-size bound is proved.
* The release does not bundle a complete CAD implementation, despite proving a
  terminating exact algorithm.
* No arbitrary-dimensional wave-instability classification is proved.
* Weak stationary admissibility is not upgraded to a primary simple stationary
  bifurcation.
* No nonlinear nonconstant steady state, persistent pattern, stability,
  supercriticality, or global behavior is inferred.
* The literature audit and novelty assessment require external specialist
  confirmation.

## FILES

```text
/mnt/data/qbio_mass_action_turing_topology_TALG/README.md
/mnt/data/qbio_mass_action_turing_topology_TALG/STATE.md
/mnt/data/qbio_mass_action_turing_topology_TALG/FINAL_REPORT.md
/mnt/data/qbio_mass_action_turing_topology_TALG/theorem_dependency_graph.md
/mnt/data/qbio_mass_action_turing_topology_TALG/literature_audit/
/mnt/data/qbio_mass_action_turing_topology_TALG/definitions/
/mnt/data/qbio_mass_action_turing_topology_TALG/fixed_jacobian/
/mnt/data/qbio_mass_action_turing_topology_TALG/mass_action/
/mnt/data/qbio_mass_action_turing_topology_TALG/topology/
/mnt/data/qbio_mass_action_turing_topology_TALG/low_dimension/
/mnt/data/qbio_mass_action_turing_topology_TALG/benchmarks/
/mnt/data/qbio_mass_action_turing_topology_TALG/computation/
/mnt/data/qbio_mass_action_turing_topology_TALG/verifier/
/mnt/data/qbio_mass_action_turing_topology_TALG/adversarial_audit/
/mnt/data/qbio_mass_action_turing_topology_TALG/manuscript/main.pdf
/mnt/data/qbio_mass_action_turing_topology_TALG/manuscript/
/mnt/data/qbio_mass_action_turing_topology_TALG/release/
```