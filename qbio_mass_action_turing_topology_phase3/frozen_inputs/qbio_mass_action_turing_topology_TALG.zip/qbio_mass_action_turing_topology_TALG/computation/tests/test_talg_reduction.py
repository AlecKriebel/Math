from __future__ import annotations

import itertools
import json
import sys
import unittest
from pathlib import Path

import sympy as sp

ROOT = Path(__file__).resolve().parents[2]
COMP = ROOT / "computation"
VERIFIER = ROOT / "verifier"
for path in (COMP, VERIFIER):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from exact_characterization import canonical_branch_system, characterization_data
from hurwitz import is_hurwitz
from network_parser import direct_mass_action_jacobian, jacobian_from_flux, parse_network, reaction_flux
from partition_reduction import (
    blondel_family,
    blondel_matrix,
    build_reduction,
    interior_parameters,
    lifted_family,
    lifted_matrix,
    partition_sign,
    realize_lifted_family,
    triangularizing_matrix,
)
from verify_partition_reduction import verify as verify_partition_reduction
from verify_semialgebraic_certificate import CertificateError, verify as verify_semialgebraic


class TAlgReductionTests(unittest.TestCase):
    def test_canonical_interior_witness(self) -> None:
        family = blondel_family([1, 1])
        signs = partition_sign([1, 1])
        self.assertIsNotNone(signs)
        assert signs is not None
        q = interior_parameters(family, signs)
        self.assertTrue(all(-1 < value < 1 for value in q))
        bmat = blondel_matrix(family, q)
        self.assertTrue(is_hurwitz(bmat))
        self.assertEqual(
            sp.factor(bmat.charpoly().as_expr()),
            sp.factor((sp.Symbol("lambda") + 2) ** 2 * (sp.Symbol("lambda") + 6) * (24 * sp.Symbol("lambda") + 1) ** 2 / 576),
        )

    def test_no_partition_open_cube_gap(self) -> None:
        family = blondel_family([1, 2])
        self.assertIsNone(partition_sign([1, 2]))
        signs = list(itertools.product((-1, 1), repeat=family.m))
        minimum_square = min(int((family.padded_a.T * sp.Matrix(sign))[0]) ** 2 for sign in signs)
        self.assertEqual(minimum_square, 1)
        cube_maximum = family.m - sp.Rational(minimum_square, 1 + family.gamma)
        self.assertLess(cube_maximum, family.m * family.beta)

    def test_row_splitting_similarity(self) -> None:
        family = blondel_family([1, 1])
        q = interior_parameters(family, (-1, 1))
        lift = lifted_family(family)
        lmat = lifted_matrix(lift, q)
        tmat = triangularizing_matrix(lift, q)
        bmat = blondel_matrix(family, q)
        n0 = family.base_dimension
        d = family.parameter_dimension
        expected = bmat.row_join(family.U1).col_join(
            sp.zeros(d, n0).row_join(-sp.eye(d))
        )
        self.assertEqual(sp.simplify(tmat.inv() * lmat * tmat), expected)
        self.assertEqual(sp.factor(lmat.det()), sp.factor((-1) ** d * bmat.det()))
        self.assertTrue(is_hurwitz(lmat))

    def test_mass_action_row_segment_realization(self) -> None:
        family = blondel_family([1, 1])
        q = interior_parameters(family, (-1, 1))
        lift = lifted_family(family)
        raw = realize_lifted_family(lift, q).network
        network = parse_network(raw)
        x = sp.ones(network.n, 1)
        flux = reaction_flux(network, x)
        gamma = network.stoichiometric_matrix()
        lmat = lifted_matrix(lift, q)
        self.assertEqual(gamma.rank(), network.n)
        self.assertTrue(all(value > 0 for value in flux))
        self.assertEqual(gamma * flux, sp.zeros(network.n, 1))
        self.assertEqual(jacobian_from_flux(network, x, flux), lmat)
        self.assertEqual(direct_mass_action_jacobian(network, x), lmat)

    def test_complete_reduction_certificate(self) -> None:
        raw = build_reduction([1, 1], include_witness=True)
        report = verify_partition_reduction(raw)
        self.assertEqual(report["status"], "YES")
        self.assertEqual(report["species"], 13)
        self.assertEqual(report["reactions"], 34)
        self.assertLess(sp.Rational(report["det_D_minus_J"]), 0)

    def test_semialgebraic_formula_generation(self) -> None:
        raw = {
            "species": ["X1", "X2"],
            "reactions": [
                {"source": [2, 0], "target": [3, 0]},
                {"source": [1, 0], "target": [0, 0]},
                {"source": [1, 1], "target": [1, 2]},
                {"source": [0, 1], "target": [0, 0]},
            ],
        }
        network = parse_network(raw)
        data = characterization_data(network.stoichiometric_matrix(), network.source_matrix())
        self.assertEqual(data["species_count"], 2)
        self.assertEqual(data["reaction_count"], 4)
        self.assertEqual(len(data["branches"]), 3)
        self.assertTrue(data["strict_hurwitz_inequalities"])
        self.assertIn("polynomial_size_selector_encoding", data)

    def test_boolean_selector_principal_minor_identity(self) -> None:
        entries = sp.symbols("a0:9")
        amat = sp.Matrix(3, 3, entries)
        for mask in range(8):
            bits = [(mask >> i) & 1 for i in range(3)]
            selector = sp.diag(*bits)
            lhs = sp.expand((sp.eye(3) - selector - selector * amat * selector).det())
            index = [i for i, bit in enumerate(bits) if bit]
            expected = sp.Integer(1) if not index else (-1) ** len(index) * amat.extract(index, index).det()
            self.assertEqual(sp.expand(lhs - expected), 0)

    def test_canonical_branch_system_is_network_bound(self) -> None:
        raw = json.loads((ROOT / "verifier/test_certificates/network_semialgebraic_yes.json").read_text())
        network = parse_network(raw)
        variables, equations, metadata = canonical_branch_system(
            network.stoichiometric_matrix(),
            network.source_matrix(),
            (0,),
        )
        self.assertEqual(len(variables), 15)
        self.assertEqual(len(equations), 11)
        self.assertEqual(metadata["tau"], "-2*v0 + v1")

    def test_general_equation_certificates(self) -> None:
        yes = json.loads((ROOT / "verifier/test_certificates/real_sample_algebraic_yes.json").read_text())
        no = json.loads((ROOT / "verifier/test_certificates/real_nullstellensatz_no.json").read_text())
        self.assertEqual(verify_semialgebraic(yes)["status"], "YES")
        self.assertEqual(verify_semialgebraic(no)["status"], "NO")

    def test_yes_certificate_rejects_symbolic_coordinates(self) -> None:
        forged = {
            "certificate_type": "real_algebraic_sample_yes",
            "variables": ["x", "y"],
            "equations": ["x-y"],
            "coefficient_field": {"type": "rational"},
            "values": ["y", "y"],
        }
        with self.assertRaises(CertificateError):
            verify_semialgebraic(forged)

    def test_network_bound_equation_certificates(self) -> None:
        yes = json.loads((ROOT / "verifier/test_certificates/network_semialgebraic_yes.json").read_text())
        no = json.loads((ROOT / "verifier/test_certificates/network_semialgebraic_no.json").read_text())
        self.assertEqual(verify_semialgebraic(yes)["status"], "YES")
        self.assertEqual(verify_semialgebraic(no)["status"], "NO")

    def test_network_bound_certificate_rejects_reaction_tampering(self) -> None:
        raw = json.loads((ROOT / "verifier/test_certificates/network_semialgebraic_yes.json").read_text())
        raw["reactions"][0]["source"][1] += 1
        with self.assertRaises(CertificateError):
            verify_semialgebraic(raw)

    def test_level_four_same_gamma_counterexample(self) -> None:
        # Both networks have ordered Gamma columns (+e1,-e1,+e2,-e2).
        yes = {
            "species": ["X1", "X2"],
            "reactions": [
                {"source": [2, 0], "target": [3, 0], "k": "1"},
                {"source": [1, 2], "target": [0, 2], "k": "1"},
                {"source": [2, 0], "target": [2, 1], "k": "1"},
                {"source": [0, 3], "target": [0, 2], "k": "1"},
            ],
        }
        no = {
            "species": ["X1", "X2"],
            "reactions": [
                {"source": [1, 0], "target": [2, 0], "k": "1"},
                {"source": [1, 0], "target": [0, 0], "k": "1"},
                {"source": [0, 1], "target": [0, 2], "k": "1"},
                {"source": [0, 1], "target": [0, 0], "k": "1"},
            ],
        }
        net_yes = parse_network(yes)
        net_no = parse_network(no)
        self.assertEqual(net_yes.stoichiometric_matrix(), net_no.stoichiometric_matrix())
        x = sp.ones(2, 1)
        j_yes = jacobian_from_flux(net_yes, x, reaction_flux(net_yes, x))
        j_no = jacobian_from_flux(net_no, x, reaction_flux(net_no, x))
        self.assertEqual(j_yes, sp.Matrix([[1, -2], [2, -3]]))
        self.assertTrue(is_hurwitz(j_yes))
        self.assertEqual(j_no, sp.zeros(2))


if __name__ == "__main__":
    unittest.main()
