# Exact network and certificate format

All accepted numbers are JSON integers or strings representing exact rational numbers, such as `"17/23"`. Binary floating-point JSON numbers are rejected by the exact verifier.

A network object has:

```json
{
  "species": ["X1", "X2"],
  "reactions": [
    {"source": [1, 0], "target": [0, 1], "k": "3/2"}
  ]
}
```

The source and target arrays are nonnegative integer stoichiometric vectors in the listed species order. A positive YES certificate additionally supplies `x_star`, positive all-species `diffusion`, a positive squared wave number `q2` (default `1`), and optionally a zero-based `responsible_species` principal set.

The verifier recomputes, rather than trusts, the source matrix `Y`, stoichiometric matrix `Gamma`, flux vector, equilibrium equation, mass-action Jacobian by two independent formulas, stoichiometric reduction, Routh--Hurwitz determinants, spatial determinant, and all principal-minor/flux-polynomial identities.

A network-level NO certificate has two exact forms.

1. `no_positive_flux`: a Gordan separator `separator_y` satisfying `Gamma^T separator_y >= 0` componentwise and nonzero.
2. `mass_action_semialgebraic_no`: an exhaustive bundle containing one Real Nullstellensatz identity for every nonempty principal-species branch of the canonical T-ALG equation system.

A `fixed_j_stationary_no` certificate is a matrix-level certificate only and must not be described as a universal NO certificate for a reaction hypergraph.

## Network-bound T-ALG certificates

The verifier regenerates the canonical branch equations from the supplied reaction list. It does not trust certificate-supplied equations.

A network-level semialgebraic YES certificate has the form

```json
{
  "certificate_type": "mass_action_semialgebraic_yes",
  "species": ["X1", "X2"],
  "reactions": [
    {"source": [2, 0], "target": [3, 0]}
  ],
  "principal_species_zero_based": [0],
  "coefficient_field": {"type": "rational"},
  "values": ["..."]
}
```

The `values` array follows the deterministic variable order produced by `canonical_branch_system` in `computation/exact_characterization.py`:

```text
v, h, positive-flux slacks, positive-h slacks,
Hurwitz slacks, negative-minor slack.
```

For real algebraic coordinates, use

```json
{
  "type": "real_algebraic",
  "symbol": "alpha",
  "minimal_polynomial": "alpha**2-2",
  "isolating_interval": ["1", "2"]
}
```

and represent every coordinate as a polynomial in `alpha`.

A network-level semialgebraic NO certificate has `certificate_type` equal to `mass_action_semialgebraic_no` and a `branch_certificates` array. Each branch supplies its principal set, coefficient field, sum-of-squares polynomials, and one ideal multiplier per canonical equation. The verifier rejects duplicate, missing, or extra branches.

The generic `real_algebraic_sample_yes` and `real_nullstellensatz_no` formats test the algebraic checker itself. They do not classify a reaction network unless the equations are regenerated and bound through one of the network-level formats above.
