#!/usr/bin/env python3
"""Exact PARTITION-to-mass-action reduction used in the T-ALG theorem.

The construction has three layers.

1.  Blondel--Tsitsiklis' interval family B(x,y).
2.  A row-splitting lift L(q) similar to diag(B(q), -I).
3.  A classical mass-action realization whose positive steady-flux Jacobians
    are exactly R L(q), with R positive diagonal and q in the open cube.

All arithmetic is exact.  The module is a constructor and a regression aid;
the mathematical converse, including arbitrary positive right diagonal
scalings, is proved in topology/np_hardness_reduction.tex.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import sympy as sp


def _rational_string(value: sp.Expr) -> str:
    value = sp.factor(value)
    if not value.is_Rational:
        raise ValueError(f"expected a rational number, got {value}")
    return str(value)


def _vector_strings(values: Iterable[sp.Expr]) -> list[str]:
    return [_rational_string(value) for value in values]


def _matrix_strings(matrix: sp.Matrix) -> list[list[str]]:
    return [[_rational_string(matrix[i, j]) for j in range(matrix.cols)] for i in range(matrix.rows)]


def next_strict_square(length: int) -> tuple[int, int]:
    """Return (k,m) with m=k^2 the least square strictly larger than length."""
    if length < 1:
        raise ValueError("PARTITION instances must contain at least one integer")
    k = math.isqrt(length)
    if k * k <= length:
        k += 1
    return k, k * k


@dataclass(frozen=True)
class BlondelFamily:
    values: tuple[int, ...]
    padded_a: sp.Matrix
    k: int
    m: int
    gamma: int
    beta: sp.Rational
    B0: sp.Matrix
    U1: sp.Matrix
    W: sp.Matrix

    @property
    def base_dimension(self) -> int:
        return self.m + 1

    @property
    def parameter_dimension(self) -> int:
        return 2 * self.m


def blondel_family(values: Sequence[int]) -> BlondelFamily:
    """Construct the rational open-cube stability family for PARTITION."""
    cleaned = tuple(int(value) for value in values)
    if not cleaned or any(value <= 0 for value in cleaned):
        raise ValueError("the reduction expects a nonempty list of positive integers")
    k, m = next_strict_square(len(cleaned))
    padded = sp.Matrix(list(cleaned) + [0] * (m - len(cleaned)))
    gamma = int((padded.T * padded)[0])
    beta = sp.Rational(1) - sp.Rational(1, 2 * m * (1 + gamma))
    qmat = sp.eye(m) + padded * padded.T
    B0 = sp.diag(*([-k] * m + [k * beta]))
    B0[:m, :m] = -k * qmat

    n0 = m + 1
    d = 2 * m
    columns: list[sp.Matrix] = []
    rows: list[sp.Matrix] = []

    # First m variables are y_i, appearing in entry (i,bottom).
    for i in range(m):
        u = sp.zeros(n0, 1)
        u[i] = 1
        w = sp.zeros(1, n0)
        w[0, m] = 1
        columns.append(u)
        rows.append(w)

    # Last m variables are x_i, appearing in entry (bottom,i).
    for i in range(m):
        u = sp.zeros(n0, 1)
        u[m] = 1
        w = sp.zeros(1, n0)
        w[0, i] = 1
        columns.append(u)
        rows.append(w)

    U1 = sp.Matrix.hstack(*columns)
    W = sp.Matrix.vstack(*rows)
    assert U1.shape == (n0, d)
    assert W.shape == (d, n0)
    return BlondelFamily(cleaned, padded, k, m, gamma, beta, B0, U1, W)


def blondel_matrix(family: BlondelFamily, q: Sequence[sp.Expr]) -> sp.Matrix:
    """Evaluate B(q), with q=(y_1,...,y_m,x_1,...,x_m)."""
    if len(q) != family.parameter_dimension:
        raise ValueError("wrong parameter dimension")
    qvec = sp.Matrix([sp.Rational(value) for value in q])
    return sp.simplify(family.B0 + family.U1 * sp.diag(*list(qvec)) * family.W)


@dataclass(frozen=True)
class LiftedFamily:
    blondel: BlondelFamily
    alpha: sp.Rational
    fixed_rows: tuple[sp.Matrix, ...]
    variable_rows: tuple[tuple[sp.Matrix, sp.Matrix], ...]

    @property
    def dimension(self) -> int:
        return self.blondel.base_dimension + self.blondel.parameter_dimension

    @property
    def parameter_dimension(self) -> int:
        return self.blondel.parameter_dimension


def lifted_family(family: BlondelFamily, alpha: sp.Rational = sp.Rational(1)) -> LiftedFamily:
    """Construct fixed rows and one-parameter row segments for L(q)."""
    alpha = sp.Rational(alpha)
    if alpha <= 0:
        raise ValueError("alpha must be positive")
    n0 = family.base_dimension
    d = family.parameter_dimension
    p = n0 + d

    top = family.B0.row_join(family.U1)
    fixed_rows = tuple(sp.Matrix(1, p, list(top.row(i))) for i in range(n0))

    variable_rows: list[tuple[sp.Matrix, sp.Matrix]] = []
    for ell in range(d):
        base = sp.zeros(1, p)
        base[0, n0 + ell] = -alpha
        w = family.W.row(ell)
        direction = (w * (family.B0 + alpha * sp.eye(n0))).row_join(w * family.U1)
        variable_rows.append((base, direction))
    return LiftedFamily(family, alpha, fixed_rows, tuple(variable_rows))


def lifted_matrix(lift: LiftedFamily, q: Sequence[sp.Expr]) -> sp.Matrix:
    if len(q) != lift.parameter_dimension:
        raise ValueError("wrong parameter dimension")
    rows = list(lift.fixed_rows)
    for value, (base, direction) in zip(q, lift.variable_rows):
        rows.append(sp.simplify(base + sp.Rational(value) * direction))
    return sp.Matrix.vstack(*rows)


def triangularizing_matrix(lift: LiftedFamily, q: Sequence[sp.Expr]) -> sp.Matrix:
    """Return T(q) satisfying T^-1 L(q) T = [[B(q),U1],[0,-alpha I]]."""
    family = lift.blondel
    qvec = sp.Matrix([sp.Rational(value) for value in q])
    X = sp.diag(*list(qvec)) * family.W
    n0 = family.base_dimension
    d = family.parameter_dimension
    return sp.eye(n0).row_join(sp.zeros(n0, d)).col_join(X.row_join(sp.eye(d)))


def partition_sign(values: Sequence[int]) -> tuple[int, ...] | None:
    """Brute-force helper for small regression instances, not part of the reduction."""
    for signs in itertools.product((-1, 1), repeat=len(values)):
        if sum(a * t for a, t in zip(values, signs)) == 0:
            return tuple(signs)
    return None


def interior_parameters(family: BlondelFamily, signs: Sequence[int]) -> tuple[sp.Rational, ...]:
    """Give the explicit interior stable parameter from a partition sign vector."""
    if len(signs) != len(family.values) or any(sign not in (-1, 1) for sign in signs):
        raise ValueError("sign vector has the wrong form")
    if sum(a * t for a, t in zip(family.values, signs)) != 0:
        raise ValueError("the supplied signs do not solve PARTITION")
    padded_signs = tuple(int(value) for value in signs) + (1,) * (family.m - len(signs))
    r = sp.factor((1 + family.beta) / 2)
    y = tuple(-r * value for value in padded_signs)
    x = tuple(r * value for value in padded_signs)
    return y + x


def _integer_scale(row: sp.Matrix) -> int:
    denominators = [int(sp.denom(sp.Rational(value))) for value in row]
    return int(sp.ilcm(*denominators)) if denominators else 1


def _base_complex(*deltas: Sequence[int], row_index: int, dimension: int) -> list[int]:
    base: list[int] = []
    for j in range(dimension):
        lower = max([0] + [-int(delta[j]) for delta in deltas])
        base.append(lower)
    base[row_index] = max(base[row_index], 1)
    return base


def _add_unit(vector: Sequence[int], index: int, sign: int) -> list[int]:
    result = list(vector)
    result[index] += sign
    if result[index] < 0:
        raise ValueError("negative target complex")
    return result


def _add_vectors(left: Sequence[int], right: Sequence[int]) -> list[int]:
    return [int(a) + int(b) for a, b in zip(left, right)]


@dataclass(frozen=True)
class ReductionNetwork:
    network: dict
    row_scales: tuple[int, ...]
    parameter_rows: tuple[int, ...]


def realize_lifted_family(
    lift: LiftedFamily,
    witness_q: Sequence[sp.Expr] | None = None,
) -> ReductionNetwork:
    """Realize all positive-flux Jacobians as R L(q), q in the open cube.

    If witness_q is supplied, rates at x*=1 are added with row scale R=I.
    """
    p = lift.dimension
    if witness_q is not None and len(witness_q) != lift.parameter_dimension:
        raise ValueError("wrong witness parameter dimension")
    reactions: list[dict] = []
    row_scales: list[int] = []
    parameter_rows: list[int] = []

    def append_reaction(source: list[int], target: list[int], rate: sp.Expr | None) -> None:
        item: dict[str, object] = {"source": source, "target": target}
        if rate is not None:
            item["k"] = _rational_string(rate)
        reactions.append(item)

    # Fixed rows: equal flux on +e_i and -e_i reactions.
    for i, row in enumerate(lift.fixed_rows):
        c = _integer_scale(row)
        delta = [int(c * sp.Rational(value)) for value in row]
        base = _base_complex(delta, row_index=i, dimension=p)
        plus_source = _add_vectors(base, delta)
        rate = sp.Rational(1, c) if witness_q is not None else None
        append_reaction(plus_source, _add_unit(plus_source, i, 1), rate)
        append_reaction(base, _add_unit(base, i, -1), rate)
        row_scales.append(c)

    # Variable rows: two +e_i sources and one balancing -e_i source.
    n0 = len(lift.fixed_rows)
    for ell, (base_row, direction) in enumerate(lift.variable_rows):
        i = n0 + ell
        plus_row = base_row + direction
        minus_row = base_row - direction
        c = _integer_scale(plus_row.row_join(minus_row))
        delta_plus = [int(c * sp.Rational(value)) for value in plus_row]
        delta_minus = [int(c * sp.Rational(value)) for value in minus_row]
        base = _base_complex(delta_plus, delta_minus, row_index=i, dimension=p)
        source_plus = _add_vectors(base, delta_plus)
        source_minus = _add_vectors(base, delta_minus)
        if witness_q is None:
            u = w = z = None
        else:
            q_value = sp.Rational(witness_q[ell])
            if not (-1 < q_value < 1):
                raise ValueError("witness parameters must lie in the open unit cube")
            u = sp.factor((1 + q_value) / (2 * c))
            w = sp.factor((1 - q_value) / (2 * c))
            z = sp.Rational(1, c)
        append_reaction(source_plus, _add_unit(source_plus, i, 1), u)
        append_reaction(source_minus, _add_unit(source_minus, i, 1), w)
        append_reaction(base, _add_unit(base, i, -1), z)
        row_scales.append(c)
        parameter_rows.append(i)

    family = lift.blondel
    raw = {
        "species": [f"X{i + 1}" for i in range(p)],
        "reactions": reactions,
        "reduction_metadata": {
            "source_problem": "PARTITION",
            "partition_values": list(family.values),
            "padded_dimension_m": family.m,
            "square_root_k": family.k,
            "gamma": family.gamma,
            "beta": _rational_string(family.beta),
            "base_matrix_B0": _matrix_strings(family.B0),
            "lift_dimension": p,
            "parameter_dimension": lift.parameter_dimension,
            "parameter_order": "y_1,...,y_m,x_1,...,x_m",
            "row_scales_used_to_clear_denominators": row_scales,
            "theorem": "positive steady-flux Jacobians are exactly R*L(q), R>0 diagonal, q in (-1,1)^(2m)",
        },
    }
    if witness_q is not None:
        raw["x_star"] = ["1"] * p
        raw["reduction_metadata"]["witness_q"] = _vector_strings(witness_q)
    return ReductionNetwork(raw, tuple(row_scales), tuple(parameter_rows))


def diffusion_from_positive_diagonal(jacobian: sp.Matrix, index: int) -> sp.Matrix:
    """Construct exact positive D with det(D-J)<0 from J[index,index]>0."""
    p = jacobian.rows
    if jacobian.cols != p or jacobian[index, index] <= 0:
        raise ValueError("the selected diagonal entry must be positive")
    epsilon = sp.factor(jacobian[index, index] / 2)
    t = sp.Integer(1)
    # The singleton-coefficient isolation theorem guarantees that doubling
    # eventually succeeds; do not turn a theorem-backed construction into a
    # heuristic by imposing an arbitrary iteration cap.
    while True:
        entries = [t] * p
        entries[index] = epsilon
        dmat = sp.diag(*entries)
        if sp.factor((dmat - jacobian).det()) < 0:
            return sp.Matrix(entries)
        t *= 2


def build_reduction(values: Sequence[int], include_witness: bool = False) -> dict:
    family = blondel_family(values)
    lift = lifted_family(family)
    q_values: tuple[sp.Rational, ...] | None = None
    signs: tuple[int, ...] | None = None
    if include_witness:
        signs = partition_sign(values)
        if signs is None:
            raise ValueError("include_witness was requested for a NO PARTITION instance")
        q_values = interior_parameters(family, signs)
    reduction = realize_lifted_family(lift, q_values)
    raw = reduction.network
    if q_values is not None:
        L = lifted_matrix(lift, q_values)
        positive_index = family.m
        diffusion = diffusion_from_positive_diagonal(L, positive_index)
        raw["certificate_type"] = "mass_action_stationary_yes"
        raw["diffusion"] = _vector_strings(diffusion)
        raw["q2"] = "1"
        raw["responsible_species"] = [positive_index]
        raw["reduction_metadata"]["partition_signs"] = list(signs or ())
        raw["reduction_metadata"]["lifted_jacobian"] = _matrix_strings(L)
        raw["reduction_metadata"]["det_D_minus_J"] = _rational_string(
            (sp.diag(*list(diffusion)) - L).det()
        )
    return raw


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("values", nargs="+", type=int, help="positive PARTITION integers")
    parser.add_argument("--with-witness", action="store_true", help="brute-force a sign witness and emit a YES certificate")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    raw = build_reduction(args.values, include_witness=args.with_witness)
    text = json.dumps(raw, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text)
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
