# Benchmark coverage audit

The directive requested a broad benchmark suite.  The final outcome is
`T-ALG`, so this audit separates theorem-critical exact regressions from
illustrative named models that are not needed for the characterization or the
complexity proof.

## Theorem-critical exact regressions

| Benchmark | Status | Artifact |
|---|---|---|
| Classical two-species activator-inhibitor mass-action witness | Exact `YES` | `positive_two_species.json` and independent verifier |
| Network without positive steady flux | Exact network-level `NO` | `no_positive_flux.json` |
| Hurwitz signed-`P_0` fixed Jacobian | Exact fixed-J `NO` for positive-real modes | `fixed_j_p0_no.json` |
| Same signed Jacobian graph, opposite fixed-J stationary behavior | Exact coarse-graph counterexample | `coarse_topology_counterexamples.tex` |
| Designated mobile-set determinant-at-zero proposal | Exact rational refutation | `mobile_proposal_counterexample.json` |
| Complex-balanced equilibrium | Structural exclusion for all positive diagonal diffusion | `structural_negative_classes.tex` |
| Conservation-law treatment | Exact full-space nonzero-mode reduction | `conservation_audit.md` |
| Network-bound semialgebraic branch | Exact algebraic `YES` | `network_semialgebraic_yes.json` |
| Exhaustive network-level infeasibility | Exact Real-Nullstellensatz `NO` | `network_semialgebraic_no.json` |
| Polynomial reduction from `PARTITION` | Exact reduction witness for `[1,1]` | `partition_reduction_yes_1_1.json` |
| Same ordered `Gamma`, opposite network answers | Exact Level-4 failure | unit test and `definitions/topology_levels.tex` |
| Irrational real-algebraic sample | Exact field/root-isolation `YES` | `real_sample_algebraic_yes.json` |
| Generic empty real variety | Exact Real-Nullstellensatz `NO` | `real_nullstellensatz_no.json` |

## Covered analytically but not instantiated as separate named models

* one-species impossibility;
* complete two-species full-rank and rank-one projected-cone criteria;
* complete three-species projected-cone stationary criterion;
* polynomial-time classification for every fixed species count;
* equal diffusion as a special case of the complex-balanced Lyapunov argument when applicable;
* parallel-reaction aggregation and splitting;
* an arbitrary rational Jacobian realization gadget;
* the row-segment realization and right-scaling elimination used by the
  NP-hardness reduction;
* polynomial-size Boolean selection of a negative principal minor.

## Illustrative models not separately packaged

The release does not include separate certificates for every named model or
boundary case in the directive, including dedicated Schnakenberg and
Brusselator parameterizations, an immobile-binding model beyond the exact
fixed-J mobile counterexample, a detailed-balanced example distinct from the
general complex-balanced proof, a classical-mass-action wave-only example, or
an explicit linearly unstable system with a separately proved absence of a
stable nonlinear pattern.

None of those omissions is used as evidence.  The T-ALG theorem rests on the
exact equivalence, complete certificate theorem, fixed-species algorithms, and
the explicit reduction family above.  The omitted named models remain useful
external validation targets rather than acceptance gates for the proved
algorithmic characterization.
