# Priority and novelty audit

## Claims that must not be presented as new

* The fixed-numerical-Jacobian principal-subsystem/signed-minor criterion for stationary Turing destabilization has established antecedents in the general Turing matrix literature.
* Two-species activator-inhibitor inequalities and fixed-J three-species criteria are established.
* Child-selection/Cauchy-Binet expansions of reaction-network Jacobian coefficients have substantial prior literature.
* Linear Turing instability does not by itself establish a stable nonlinear pattern.

## Contributions independently derived in this package

The following are exact outputs of this project, but publication priority has not been established merely by derivation:

1. a short self-contained multiscale proof of the all-mobile fixed-J positive-real criterion;
2. the corrected designated-mobile-set criterion using `det(lambda I-J_I)` for positive `lambda`;
3. an exact rational 3-by-3 counterexample to the proposed determinant-at-zero mobile-set criterion;
4. a clean conservative-network reduction showing why nonzero spatial modes act on the full species space and why the transverse zero eigenvalues are semisimple under relative stability;
5. a unified classical mass-action flux/concentration reduction with exact principal-minor polynomials `tau_I(v)`;
6. an explicit construction realizing every rational matrix as a full-rank classical mass-action Jacobian at a positive equilibrium with positive pairwise-balanced flux;
7. exact witness and obstruction verifiers that return `UNRESOLVED` instead of converting search failure into `NO`.

## Strongest publishable statement presently supported

A methodological/reduction paper could be supportable after expert audit, centered on:

> exact matrix reductions for weak stationary diffusion destabilization in conservative mass-action networks, a correction for partially mobile systems, and the identification of positive diagonal stable realization as the remaining arbitrary-network obstruction.

It should **not** be titled or advertised as a necessary-and-sufficient reaction-hypergraph characterization. The landmark theorem requested by the directive is not complete.

## Closest current work

The closest streams are:

* general fixed-J Turing/wave theory;
* graph-theoretic zero-eigenvalue Turing conditions for mass-action networks;
* child-selection and unstable-core theory under parameter-rich kinetics;
* the 2026 monomial-steady-state-parametrization approach giving sufficient mass-action conditions;
* general matrix diagonal-stabilization theory.

The exact distinction must be explained in any abstract and introduction: this package retains classical mass-action dependencies and conservation laws, but stops at the unresolved simultaneous flux/stable-scaling feasibility problem.

## Required external audit before circulation

1. Ask an expert in reaction-network theory to inspect the arbitrary-Jacobian realization construction and the claim that it embeds unrestricted right-diagonal stabilization.
2. Ask an expert in matrix stability/Turing theory to verify that the designated-mobile-set theorem and counterexample are not already standard in the same form.
3. Search MathSciNet, zbMATH, Scopus, and citation chains for alternate terminology such as `S-stability`, `D-instability`, `excitable matrices`, `unstable subsystems`, and `zero-eigenvalue Turing bifurcation`.
4. Keep the outcome labeled `STOP` until the stable-realization gate is either solved or a sharp complexity theorem is proved.
