# Current literature audit

**Audit date:** 2026-08-12  
**Question audited:** whether the literature already gives a finite necessary-and-sufficient criterion, from the full directed classical mass-action reaction hypergraph (with integer stoichiometric labels and an optional mobile set), for existence of a strictly positive equilibrium that is stable on its stoichiometric class and has a nonzero spatial mode with a positive real eigenvalue after diagonal diffusion is added.

## Scope matrix

| Work | Kinetic/network data actually treated | Result type relevant here | Why it does not already close this project |
|---|---|---|---|
| Turing (1952), *The Chemical Basis of Morphogenesis* | Specific reaction-diffusion models and linearized kinetics | Foundational mechanism and examples | Not an arbitrary reaction-hypergraph decision theorem. |
| Satnoianu, Menzinger & Maini (2000), *Turing Instabilities in General Systems* | A fixed stable numerical Jacobian with diagonal diffusion | General matrix-level necessary/sufficient conditions | Does not eliminate a mass-action equilibrium Jacobian into the pair `(Gamma,Y)` and its positive steady-flux constraints. |
| Wang & Li (2001), *Diffusion-Driven Instability in Reaction-Diffusion Systems* | Fixed numerical Jacobian / general smooth kinetics | Matrix stability and diffusion criteria | Not a classical mass-action topology characterization. |
| Satnoianu & van den Driessche (2005), *Some Remarks on Matrix Stability with Application to Turing Instability* | Fixed numerical Jacobian | Signed-principal-minor / subsystem matrix theory | This is the closest antecedent to the all-mobile fixed-J theorem reproved here; that theorem is therefore not claimed as new. |
| Mincheva & Roussel (2006); Mincheva & Craciun (2013) | Classical mass-action reaction networks represented by species-reaction graphs | Graph-theoretic necessary conditions and sufficient constructions for zero-eigenvalue Turing instability | Important structural results, but not a complete iff criterion for every reaction hypergraph with positive steady-flux and stable-realization constraints eliminated. |
| Ge & Arcak (2009) | Fixed Jacobian classes, especially cyclic structures | Sufficient compound-matrix condition for additive `D`-stability | An exclusion theorem for subclasses, not a complete admissibility criterion. |
| Marcon et al. (2016) | Enumerated small interaction networks with parameterized regulatory kinetics | High-throughput identification of Turing-capable topologies, including equal diffusion in modeled settings | The interaction functions are parameter-rich and the analysis is not an iff theorem for arbitrary classical mass-action hypergraphs. |
| Diego et al. (2018) | Signed interaction-network/Jacobian topology with sampled or parameterized kinetics | Design principles and topology-level features | “Topology” is not the full mass-action pair `(Gamma,Y)`; mass-action derivative dependencies and positive steady-flux feasibility are not the final decision variables of an arbitrary-network iff theorem. |
| Scholes et al. (2019) | Census of two- and three-node regulatory-network models | Computational atlas and robustness analysis | Bounded model atlas, not arbitrary-size exact reaction-hypergraph classification. |
| Villar-Sepúlveda & Champneys (2023) | General `C^1` reaction kinetics linearized at a fixed equilibrium | Necessary/sufficient fixed-J conditions for Turing or wave instability and constructive diffusion choices | Solves the matrix/dispersion problem, not realization by a given classical mass-action reaction hypergraph. |
| Piskovsky (2024) | General three-species fixed-equilibrium Jacobian | Exact three-species Turing and Turing-Hopf inequalities | Does not eliminate the Jacobian into arbitrary `(Gamma,Y)` data. |
| Vassena (2023/2025), *Symbolic Hunt...* | Parameter-rich kinetics in which nonzero rate derivatives are independent positive symbols; Michaelis-Menten realization results | Child-selection expansions and structural sufficient conditions for instability/Hopf behavior | Classical mass action couples derivative symbols through a common flux and concentration scaling; those dependencies are precisely the unresolved gate here. |
| Vassena & Stadler (2024), *Unstable Cores...* | Parameter-rich kinetics including generalized mass action and Michaelis-Menten | Sufficient unstable-core constructions and sign classification | Not an iff theorem for classical mass-action stationary diffusion destabilization with flux balance and stable completion. |
| Krause et al. (2024) | General reaction-diffusion systems and nonlinear examples | Shows linear Turing instability need not yield a stable nonlinear pattern | Supports the package’s strict separation between the linear result and nonlinear pattern formation. |
| Conradi, Mincheva & Uecker (2026), arXiv:2605.16049 | Mass-action networks admitting a monomial steady-state parametrization | Sufficient polynomial inequalities for a Turing-like instability on suitable domains | A special network class and a sufficient condition, not the arbitrary-network iff theorem requested here. |
| Sun (2023), diagonal-stability/stabilizability review | General real matrices | Reviews sufficient diagonal-stabilization criteria and states that a full necessary-and-sufficient characterization remains open | The mass-action fixed-flux stable-realization gate contains this unrestricted positive diagonal stabilization problem. |

## Conclusions of the audit

1. The all-mobile principal-minor criterion belongs to established fixed-J matrix theory. This package provides a self-contained proof and exact implementation, but makes no priority claim for that theorem.
2. Existing “network topology” papers generally use signed interaction graphs, parameter-rich kinetics, bounded atlases, or fixed numerical Jacobians. None located in this audit supplies the requested arbitrary classical mass-action reaction-hypergraph iff theorem.
3. Classical mass action introduces two coupled constraints that fixed-J and parameter-rich results do not remove: a strictly positive steady flux `v` in `ker Gamma`, and a positive concentration scaling `h` making `Gamma diag(v) Y^T diag(h)` Hurwitz on the stoichiometric subspace.
4. The 2026 monomial-parametrization paper is especially close in subject matter, but explicitly gives sufficient conditions for a special steady-state-parametrizable class.
5. Because a general matrix review describes positive diagonal stabilizability as lacking a full characterization, the residual stable-realization gate must be stated as unresolved rather than hidden behind “topology.”

## Search limitations

The audit covered the named literature in the directive, its cited matrix/reaction-network antecedents, and searches through 2026-08-12 for new mass-action Turing criteria. It is a good-faith priority audit, not a formal proof that no uncatalogued or differently worded result exists. Any publication based on this package should undergo expert bibliographic review.
