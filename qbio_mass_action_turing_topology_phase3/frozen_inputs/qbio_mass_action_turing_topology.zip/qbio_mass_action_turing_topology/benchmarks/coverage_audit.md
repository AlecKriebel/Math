# Benchmark coverage audit

The directive requested a broad benchmark suite. Because the final outcome is `STOP`, this package distinguishes benchmarks that were exactly closed from those not completed.

## Exactly closed

| Benchmark | Status | Artifact |
|---|---|---|
| Classical two-species activator-inhibitor mass-action witness | Exact `YES` | `positive_two_species.json` and independent verifier |
| Network without positive steady flux | Exact network-level `NO` | `no_positive_flux.json` |
| Hurwitz signed-`P_0` fixed Jacobian | Exact fixed-J `NO` for positive-real modes | `fixed_j_p0_no.json` |
| Same signed Jacobian graph, opposite fixed-J stationary behavior | Exact coarse-graph counterexample | `coarse_topology_counterexamples.tex` |
| Designated mobile-set determinant-at-zero proposal | Exact rational refutation | `mobile_proposal_counterexample.json` |
| Complex-balanced equilibrium | Structural exclusion for all positive diagonal diffusion | `structural_negative_classes.tex` |
| Conservation-law treatment | Exact full-space nonzero-mode reduction | `conservation_audit.md` |

## Covered analytically but not instantiated as separate named models

* one-species impossibility;
* two-species full-rank and rank-one criteria;
* fixed-J three-species stationary criterion;
* equal diffusion as a special case of the complex-balanced Lyapunov argument when applicable;
* parallel-reaction aggregation and splitting;
* an arbitrary rational Jacobian realization gadget.

## Not completed in this STOP package

The release does not claim separate exact benchmark certificates for every named model or boundary case in the directive, including Schnakenberg and Brusselator parameterizations, an immobile-binding example, a detailed-balanced example distinct from the general complex-balanced proof, a mass-action wave-only example satisfying the stationary signed-`P_0` condition, or an explicit linearly unstable model with a rigorously excluded stable nonlinear pattern.

Their absence is not used as evidence for any theorem. The benchmark census remains validation work for a future phase after the stable-realization gate is resolved.
