# Theorem dependency graph

```mermaid
graph TD
  A[Reaction hypergraph Gamma,Y] --> B[Positive flux cone C_N]
  B --> C[Flux/equilibrium reconstruction]
  C --> D[Jacobian J(v,h)=Gamma diag(v) Y^T H]
  D --> E[Relative Hurwitz stability on S]
  D --> F[Principal-minor polynomials tau_I(v)]
  F --> G[All-mobile fixed-J stationary criterion]
  E --> H[Exact semialgebraic network reduction]
  G --> H
  H --> I{Eliminate v,h structurally?}
  I -->|not achieved| STOP[STOP outcome]

  J[Conservation laws] --> K[Semisimple transverse zero modes]
  K --> L[Full-space nonzero-mode test]
  L --> G

  M[Specified mobile set] --> N[lambda-dependent principal-block criterion]
  N --> O[Counterexample to determinant-at-zero proposal]
```

## Dependency details

* `fixed_jacobian/domain_mode_reduction.tex` and `mass_action/conservative_networks.tex` justify the full-space spatial test.
* `fixed_jacobian/stationary_diagonal_damping.tex` proves the all-mobile matrix theorem.
* `fixed_jacobian/mobile_set_extension.tex` proves the corrected mobile-set theorem.
* `mass_action/equilibrium_flux_parameterization.tex`, `jacobian_factorization.tex`, and `principal_minor_expansion.tex` eliminate `k`, `x*`, `D`, and the wave number from the all-mobile condition.
* `mass_action/stable_realization.tex` identifies the unresolved right-diagonal stabilization gate and proves arbitrary rational matrices occur at a positive mass-action equilibrium.
* `topology/exact_characterization.tex` states the strongest exact reduction actually proved.
