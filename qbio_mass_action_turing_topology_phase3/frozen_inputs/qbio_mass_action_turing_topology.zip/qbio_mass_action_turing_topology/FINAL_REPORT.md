# Final report

## OUTCOME

**STOP**

The requested arbitrary-network reaction-hypergraph characterization was not proved. The package does not upgrade an exact existential reduction, numerical evidence, or agreement between agents into `T-CHAR`, `T-ALG`, or `T-TOPOLOGY-CORRECTION`.

## MAIN THEOREM

### Exact all-mobile mass-action reduction

Let a finite classical mass-action network have source matrix `Y`, stoichiometric matrix `Gamma`, and stoichiometric subspace `S=im Gamma`. For `v>0` with `Gamma v=0` and `h>0`, define

```text
J(v,h) = Gamma diag(v) Y^T diag(h).
```

The network is **weakly stationary-Turing-admissible**—there exist strictly positive rates, a strictly positive equilibrium that is Hurwitz on `S`, positive diffusion for every species, and a nonzero spatial mode whose full linearization has a strictly positive real eigenvalue—if and only if there exist `v,h` such that

```text
v > 0,
Gamma v = 0,
J(v,h)|_S is Hurwitz,
tau_I(v) < 0 for at least one principal species set I,
```

where, for `p=|I|`,

```text
tau_I(v) = (-1)^p sum_{R subset reactions, |R|=p}
             det(Gamma_{I,R}) det(Y_{I,R}) product_{r in R} v_r.
```

Equivalently,

```text
(-1)^p det J(v,h)_{I,I} = (product_{i in I} h_i) tau_I(v).
```

This theorem eliminates the original rate constants, equilibrium concentrations, diffusion coefficients, domain length, and wave number. It does **not** eliminate the positive steady-flux variable `v` or the positive right-diagonal stabilizer `h`; the directive expressly identifies that residual stable-realization problem as insufficient for the landmark endpoint.

### Fixed-J theorem

For any real square matrix `J`, there exists a positive diagonal `D` such that `J-D` has a strictly positive real eigenvalue if and only if

```text
(-1)^|I| det(J_I) < 0
```

for some principal set `I`. For Hurwitz `J`, the witness is automatically nonempty and proper.

### Correct designated-mobile theorem

Let `M` be the mobile set, with diffusion positive on `M` and zero on `M^c`, and assume `det(lambda I-J)>0` for every `lambda>0`. Then a positive real spatial eigenvalue exists if and only if there are `lambda>0` and `I` containing `M^c` such that

```text
det(lambda I_|I| - J_I) < 0.
```

The determinant-at-zero proposal in the directive is false. The package gives an exact rational 3-by-3 counterexample and an independent verifier.

## TOPOLOGY LEVEL

The exact mass-action reduction requires at least **Level 5**, the indexed pair `(Gamma,Y)`, equivalently the fully labeled directed reaction hypergraph with parallel reactions retained.

No weakest data level supporting a complete arbitrary-network iff criterion was proved. A signed species-interaction graph is already too coarse for the fixed-J problem. The package does not overstate that fixed-J counterexample as a minimal reaction-hypergraph theorem.

## STATIONARY OR WAVE

The exact theorem concerns **weak stationary** instability: some nonzero spatial matrix has a strictly positive real eigenvalue.

It does not prove that this real branch is the first loss of stability along a diffusion path. A complex conjugate pair may cross earlier. Primary simple stationary crossing and arbitrary-dimensional Turing-Hopf admissibility remain separate unresolved gates.

## CONSERVATION LAWS

Homogeneous stability is assessed on `S=im Gamma`. If `J|_S` is Hurwitz, then

```text
R^n = S direct-sum ker J,
```

and the transverse conservation zeros are semisimple. For nonzero Neumann modes, the eigenfunctions have zero spatial mean, so every species-amplitude vector preserves the integrated conservation laws. The spatial matrix must therefore be tested on the full species space; restricting `J-D` to `S` would generally be incorrect because unequal diagonal diffusion need not preserve `S`.

## CERTIFICATE

Supported exact certificate scopes are:

* **YES, arbitrary declared mass-action instance:** complete rational rates, positive equilibrium, positive flux, positive all-species diffusion, mode factor, exact reduced Hurwitz determinants, exact spatial determinant sign, and all principal-minor/`tau_I` identities.
* **NO, fixed numerical Jacobian:** Hurwitz `J` plus nonnegative signed principal minors for every principal set.
* **NO, reaction network:** a Gordan separator `y` with `Gamma^T y >= 0` componentwise and nonzero, proving no strictly positive steady flux exists.
* **Counterexample certificate:** exact Hurwitz matrix, designated mobile set, nonnegative determinant-at-zero candidates, positive eigenpair after partial diffusion, and a negative positive-`lambda` principal-block determinant.

There is no universal arbitrary-network `NO` certificate once positive steady flux exists. The classifier returns `UNRESOLVED` in that case unless a complete YES witness is supplied.

## SOFTWARE

From the project root:

```bash
bash release/one_command_verification.sh
python classify_network.py network.json
```

The release command runs schema validation, unit tests, exact verifiers, adversarial regressions, required-file checks, a LaTeX source/compiled-manuscript audit, and SHA-256 manifest generation. Detailed outputs are in `release/verification_outputs/`. The manuscript PDF is rebuilt with `bash manuscript/build_pdf.sh`.

## NOVELTY

The fixed-J principal-minor theorem has established matrix-theory antecedents and is not claimed as new. The literature audit through 2026-08-12 did not locate a complete arbitrary classical mass-action reaction-hypergraph iff theorem eliminating positive steady flux and stable realization.

Potentially distinct outputs requiring expert priority audit are the positive-`lambda` designated-mobile correction and its rational counterexample, the conservative full-space mode treatment in this formulation, the exact arbitrary-rational-Jacobian classical mass-action realization construction, and the assembled mass-action reduction/verifier package.

## LIMITATIONS

* No complete reaction-hypergraph characterization.
* No matching complexity-hardness theorem.
* No arbitrary-network finite NO certificate beyond recognized exact obstructions.
* No proof that weak stationary admissibility implies a primary simple stationary bifurcation.
* No arbitrary-dimensional wave classification.
* No nonlinear patterned-state existence or stability theorem.
* No claim that the literature audit is a formal proof of priority.

## FILES

```text
/mnt/data/qbio_mass_action_turing_topology/README.md
/mnt/data/qbio_mass_action_turing_topology/STATE.md
/mnt/data/qbio_mass_action_turing_topology/FINAL_REPORT.md
/mnt/data/qbio_mass_action_turing_topology/theorem_dependency_graph.md
/mnt/data/qbio_mass_action_turing_topology/literature_audit/
/mnt/data/qbio_mass_action_turing_topology/definitions/
/mnt/data/qbio_mass_action_turing_topology/fixed_jacobian/
/mnt/data/qbio_mass_action_turing_topology/mass_action/
/mnt/data/qbio_mass_action_turing_topology/topology/
/mnt/data/qbio_mass_action_turing_topology/low_dimension/
/mnt/data/qbio_mass_action_turing_topology/benchmarks/
/mnt/data/qbio_mass_action_turing_topology/computation/
/mnt/data/qbio_mass_action_turing_topology/verifier/
/mnt/data/qbio_mass_action_turing_topology/adversarial_audit/
/mnt/data/qbio_mass_action_turing_topology/manuscript/main.pdf
/mnt/data/qbio_mass_action_turing_topology/manuscript/
/mnt/data/qbio_mass_action_turing_topology/release/
```
