#!/usr/bin/env python3
"""Independent exact verifier for the mobile-set counterexample certificate."""
from __future__ import annotations

import argparse
import json
import sys
from itertools import combinations
from pathlib import Path
from typing import Any

import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "computation"
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))

from exact_linear_algebra import exact_matrix, exact_vector, q, signed_principal_minor  # noqa: E402
from hurwitz import characteristic_coefficients, hurwitz_determinants, is_hurwitz  # noqa: E402


class CertificateError(ValueError):
    pass


def verify_certificate(data: dict[str, Any]) -> dict[str, Any]:
    if data.get("certificate_type") != "mobile_proposal_counterexample":
        raise CertificateError("wrong certificate_type")
    j = exact_matrix(data.get("J", []))
    if j.rows == 0 or j.rows != j.cols:
        raise CertificateError("J must be nonempty and square")
    n = j.rows
    mobile = tuple(sorted({int(i) for i in data.get("mobile_species_zero_based", [])}))
    if not mobile or any(i < 0 or i >= n for i in mobile):
        raise CertificateError("mobile set must be a nonempty subset of the species")
    diffusion = exact_vector(data.get("diffusion", []))
    if diffusion.rows != n:
        raise CertificateError("diffusion has the wrong length")
    mobile_set = set(mobile)
    for i, value in enumerate(diffusion):
        if i in mobile_set and value <= 0:
            raise CertificateError("mobile diffusion entries must be positive")
        if i not in mobile_set and value != 0:
            raise CertificateError("immobile diffusion entries must be zero")
    lam = q(data.get("lambda"))
    vector = exact_vector(data.get("eigenvector", []))
    if lam <= 0 or vector.rows != n or vector == sp.zeros(n, 1):
        raise CertificateError("invalid positive eigenpair")
    if not is_hurwitz(j):
        raise CertificateError("J is not Hurwitz")

    immobile = set(range(n)) - mobile_set
    tested: dict[str, str] = {}
    for size in range(len(immobile), n + 1):
        for idx in combinations(range(n), size):
            if immobile.issubset(idx):
                value = sp.factor(signed_principal_minor(j, idx))
                tested[",".join(map(str, idx))] = str(value)
                if value < 0:
                    raise CertificateError("the proposed determinant-at-zero criterion is actually satisfied")

    dmat = sp.diag(*list(diffusion))
    if sp.simplify((j - dmat) * vector - lam * vector) != sp.zeros(n, 1):
        raise CertificateError("the supplied positive eigenpair is false")

    lambda_blocks: dict[str, str] = {}
    negative_lambda_block = False
    for size in range(len(immobile), n + 1):
        for idx in combinations(range(n), size):
            if immobile.issubset(idx):
                block = j.extract(idx, idx)
                value = sp.factor((lam * sp.eye(size) - block).det())
                lambda_blocks[",".join(map(str, idx))] = str(value)
                negative_lambda_block |= value < 0
    if not negative_lambda_block:
        raise CertificateError("no negative lambda-dependent principal block was found")

    return {
        "status": "REFUTES_PROPOSED_MOBILE_CRITERION",
        "characteristic_coefficients": [str(x) for x in characteristic_coefficients(j)],
        "Hurwitz_determinants": [str(x) for x in hurwitz_determinants(j)],
        "mobile_species_zero_based": list(mobile),
        "signed_principal_minors_containing_immobile_set": tested,
        "lambda": str(lam),
        "lambda_dependent_principal_determinants": lambda_blocks,
        "verified_eigenpair": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    try:
        result = verify_certificate(json.loads(args.certificate.read_text()))
    except Exception as exc:
        print(json.dumps({"status": "INVALID", "error": str(exc)}, indent=2))
        return 1
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
