#!/usr/bin/env python3
"""Independent exact verifier for all-mobile mass-action YES certificates."""
from __future__ import annotations

import argparse
import json
import sys
from itertools import combinations
from pathlib import Path
from typing import Any

import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "computation"
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))

from exact_linear_algebra import (  # noqa: E402
    exact_vector,
    matrix_to_strings,
    reduced_restriction,
    signed_principal_minor,
    vector_to_strings,
)
from hurwitz import characteristic_coefficients, hurwitz_determinants, is_hurwitz  # noqa: E402
from network_parser import (  # noqa: E402
    direct_mass_action_jacobian,
    jacobian_from_flux,
    parse_network,
    reaction_flux,
)
from principal_minors import tau_value  # noqa: E402


class CertificateError(ValueError):
    pass


def verify_certificate(data: dict[str, Any]) -> dict[str, Any]:
    if data.get("certificate_type") != "mass_action_stationary_yes":
        raise CertificateError("wrong certificate_type")
    network = parse_network(data)
    x_star = exact_vector(data.get("x_star", []))
    if x_star.rows != network.n or any(x <= 0 for x in x_star):
        raise CertificateError("x_star must have one strictly positive exact entry per species")
    diffusion = exact_vector(data.get("diffusion", []))
    if diffusion.rows != network.n or any(d <= 0 for d in diffusion):
        raise CertificateError("all diffusion coefficients must be strictly positive")
    q2_raw = data.get("q2", "1")
    from exact_linear_algebra import q

    q2 = q(q2_raw)
    if q2 <= 0:
        raise CertificateError("q2 must be strictly positive")

    gamma = network.stoichiometric_matrix()
    y = network.source_matrix()
    rates = network.rates()
    flux = reaction_flux(network, x_star, rates)
    if any(v <= 0 for v in flux):
        raise CertificateError("reaction flux is not strictly positive")
    residual = sp.simplify(gamma * flux)
    if residual != sp.zeros(network.n, 1):
        raise CertificateError(f"Gamma*v is nonzero: {list(residual)}")

    jacobian = jacobian_from_flux(network, x_star, flux)
    direct = direct_mass_action_jacobian(network, x_star, rates)
    if sp.simplify(jacobian - direct) != sp.zeros(network.n):
        raise CertificateError("factorized and directly differentiated Jacobians disagree")

    reduced, basis = reduced_restriction(jacobian, gamma)
    if not is_hurwitz(reduced):
        raise CertificateError("J restricted to the stoichiometric subspace is not Hurwitz")

    dmat = sp.diag(*list(diffusion))
    spatial = sp.simplify(jacobian - q2 * dmat)
    constant_term = sp.factor((q2 * dmat - jacobian).det())
    if constant_term >= 0:
        raise CertificateError(
            "this verifier requires det(q2*D-J)<0 as an exact positive-real-root certificate"
        )

    negative_sets: list[tuple[int, ...]] = []
    tau_values: dict[str, str] = {}
    for size in range(1, network.n + 1):
        for idx in combinations(range(network.n), size):
            signed = sp.factor(signed_principal_minor(jacobian, idx))
            tau = sp.factor(tau_value(gamma, y, flux, idx))
            h_product = sp.prod(1 / x_star[i] for i in idx)
            if sp.simplify(signed - h_product * tau) != 0:
                raise CertificateError(f"principal-minor formula failed on {idx}")
            tau_values[",".join(str(i) for i in idx)] = str(tau)
            if signed < 0:
                negative_sets.append(idx)
    if not negative_sets:
        raise CertificateError("no negative signed principal minor was found")

    requested = data.get("responsible_species")
    if requested is not None:
        requested_tuple = tuple(int(i) for i in requested)
        if requested_tuple not in negative_sets:
            raise CertificateError("responsible_species does not identify a negative signed minor")

    coeffs = characteristic_coefficients(reduced)
    deltas = hurwitz_determinants(reduced)
    return {
        "status": "YES",
        "scope": "all-mobile weak stationary mass-action Turing admissibility",
        "species": list(network.species),
        "Gamma": matrix_to_strings(gamma),
        "Y": matrix_to_strings(y),
        "x_star": vector_to_strings(x_star),
        "rates": vector_to_strings(rates),
        "flux": vector_to_strings(flux),
        "Gamma_v": vector_to_strings(residual),
        "Jacobian": matrix_to_strings(jacobian),
        "stoichiometric_basis": matrix_to_strings(basis),
        "reduced_Jacobian": matrix_to_strings(reduced),
        "reduced_characteristic_coefficients": [str(sp.factor(c)) for c in coeffs],
        "reduced_Hurwitz_determinants": [str(sp.factor(d)) for d in deltas],
        "diffusion": vector_to_strings(diffusion),
        "q2": str(q2),
        "spatial_matrix": matrix_to_strings(spatial),
        "det_q2D_minus_J": str(constant_term),
        "negative_signed_principal_sets_zero_based": [list(idx) for idx in negative_sets],
        "tau_values": tau_values,
        "proof": "The reduced homogeneous Jacobian is Hurwitz. det(q2*D-J)<0 is the constant term of the monic spatial characteristic polynomial, so it has a positive real root.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    try:
        data = json.loads(args.certificate.read_text())
        report = verify_certificate(data)
    except Exception as exc:  # verifier CLI reports a clean failure
        print(json.dumps({"status": "INVALID", "error": str(exc)}, indent=2))
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
