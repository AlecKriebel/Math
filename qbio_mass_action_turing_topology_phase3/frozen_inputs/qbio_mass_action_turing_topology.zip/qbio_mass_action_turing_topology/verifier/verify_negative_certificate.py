#!/usr/bin/env python3
"""Exact verifier for supported NO certificates.

Supported scopes:
* fixed numerical Jacobian, all species mobile, no positive-real stationary mode;
* reaction network with no strictly positive steady-flux vector.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "computation"
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))

from exact_linear_algebra import (  # noqa: E402
    exact_matrix,
    exact_vector,
    matrix_to_strings,
    signed_principal_minors,
    vector_to_strings,
)
from flux_cone import verify_gordan_certificate  # noqa: E402
from hurwitz import characteristic_coefficients, hurwitz_determinants, is_hurwitz  # noqa: E402
from network_parser import parse_network  # noqa: E402


class CertificateError(ValueError):
    pass


def verify_fixed_j(data: dict[str, Any]) -> dict[str, Any]:
    j = exact_matrix(data.get("J", []))
    if j.rows == 0 or j.rows != j.cols:
        raise CertificateError("J must be a nonempty square matrix")
    if not is_hurwitz(j):
        raise CertificateError("J is not Hurwitz")
    minors = signed_principal_minors(j)
    negative = {idx: value for idx, value in minors.items() if value < 0}
    if negative:
        raise CertificateError(f"negative signed principal minors exist: {negative}")
    return {
        "status": "NO",
        "scope": "fixed numerical Jacobian; all-mobile positive-real stationary destabilization",
        "J": matrix_to_strings(j),
        "characteristic_coefficients": [str(c) for c in characteristic_coefficients(j)],
        "Hurwitz_determinants": [str(d) for d in hurwitz_determinants(j)],
        "signed_principal_minors": {
            ",".join(str(i) for i in idx): str(sp.factor(value))
            for idx, value in minors.items()
        },
        "proof": "Every coefficient in det(D-J)=sum_I (-1)^|I|det(J_I) prod_{j notin I}d_j is nonnegative; replacing d by d+lambda keeps the determinant positive for every D>0 and lambda>0.",
    }


def verify_no_positive_flux(data: dict[str, Any]) -> dict[str, Any]:
    network = parse_network(data)
    gamma = network.stoichiometric_matrix()
    separator = exact_vector(data.get("separator_y", []))
    if not verify_gordan_certificate(gamma, separator):
        raise CertificateError("separator_y is not a valid Gordan certificate")
    z = sp.simplify(gamma.T * separator)
    return {
        "status": "NO",
        "scope": "reaction network: no strictly positive mass-action equilibrium flux",
        "species": list(network.species),
        "Gamma": matrix_to_strings(gamma),
        "separator_y": vector_to_strings(separator),
        "Gamma_transpose_y": vector_to_strings(z),
        "proof": "Gamma^T y is componentwise nonnegative and nonzero. For every v>0, y^T Gamma v=(Gamma^T y)^T v>0, so Gamma v=0 is impossible.",
    }


def verify_certificate(data: dict[str, Any]) -> dict[str, Any]:
    kind = data.get("certificate_type")
    if kind == "fixed_j_stationary_no":
        return verify_fixed_j(data)
    if kind == "no_positive_flux":
        return verify_no_positive_flux(data)
    raise CertificateError("unsupported certificate_type")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    try:
        report = verify_certificate(json.loads(args.certificate.read_text()))
    except Exception as exc:
        print(json.dumps({"status": "INVALID", "error": str(exc)}, indent=2))
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
