#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

# Some minimal TeX installations expose bibtex.original while the bibtex
# alternatives link is missing.  Prefer the normal command and fall back only
# when necessary.
TMP_BIN=""
cleanup() {
  if [[ -n "$TMP_BIN" ]]; then
    rm -rf "$TMP_BIN"
  fi
}
trap cleanup EXIT

if ! command -v bibtex >/dev/null 2>&1; then
  ALT_BIBTEX="$(command -v bibtex.original || true)"
  if [[ -z "$ALT_BIBTEX" ]]; then
    printf 'ERROR: neither bibtex nor bibtex.original is available\n' >&2
    exit 2
  fi
  TMP_BIN="$(mktemp -d)"
  ln -s "$ALT_BIBTEX" "$TMP_BIN/bibtex"
  export PATH="$TMP_BIN:$PATH"
fi

latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
latexmk -c main.tex
printf '%s\n' "$HERE/main.pdf"
