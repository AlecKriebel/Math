#!/usr/bin/env python3
"""Exact positive steady-flux feasibility and Gordan certificates."""
from __future__ import annotations

import sympy as sp
from sympy.solvers.simplex import InfeasibleLPError, lpmin


def positive_flux_witness(gamma: sp.Matrix) -> sp.Matrix | None:
    """Find v>0 with Gamma v=0 exactly, or return None.

    Homogeneity makes v>0 equivalent to a feasible scaling v_i>=1.
    """
    m = gamma.cols
    if m == 0:
        return sp.zeros(0, 1)
    variables = sp.symbols(f"v0:{m}", real=True)
    constraints = [sp.Eq(sum(gamma[i, j] * variables[j] for j in range(m)), 0) for i in range(gamma.rows)]
    constraints.extend(variable >= 1 for variable in variables)
    try:
        _, solution = lpmin(sp.Integer(0), constraints)
    except InfeasibleLPError:
        return None
    return sp.Matrix([sp.factor(solution.get(variable, variable)) for variable in variables])


def gordan_no_positive_flux_certificate(gamma: sp.Matrix) -> tuple[sp.Matrix, sp.Matrix] | None:
    """Find y with z=Gamma^T y>=0 and sum(z)>=1.

    Such a vector is a finite Gordan/Farkas certificate excluding every v>0 in
    ker(Gamma).  Returns (y,z), or None if a positive flux may exist.
    """
    n, m = gamma.rows, gamma.cols
    if m == 0:
        return None
    variables = sp.symbols(f"y0:{n}", real=True)
    z = [sum(gamma[i, j] * variables[i] for i in range(n)) for j in range(m)]
    constraints = [entry >= 0 for entry in z]
    constraints.append(sum(z) >= 1)
    try:
        _, solution = lpmin(sp.Integer(0), constraints)
    except InfeasibleLPError:
        return None
    y = sp.Matrix([sp.factor(solution.get(variable, variable)) for variable in variables])
    zz = sp.simplify(gamma.T * y)
    if not all(entry >= 0 for entry in zz) or sum(zz) < 1:
        raise AssertionError("simplex returned an invalid separation certificate")
    return y, zz


def verify_gordan_certificate(gamma: sp.Matrix, y: sp.Matrix) -> bool:
    if y.rows != gamma.rows or y.cols != 1:
        return False
    z = gamma.T * y
    return all(entry >= 0 for entry in z) and any(entry > 0 for entry in z)
