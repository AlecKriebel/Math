#!/usr/bin/env python3
"""Bounded exact reconnaissance scaffold.

The program deliberately does not treat absence of a witness as a NO result.
It checks supplied JSON networks, reports exact flux feasibility, and labels all
remaining cases UNRESOLVED.  This keeps enumeration subordinate to the proved
structural reductions.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from flux_cone import gordan_no_positive_flux_certificate, positive_flux_witness  # noqa: E402
from network_parser import load_network  # noqa: E402


def inspect(path: Path) -> dict[str, object]:
    network, _ = load_network(path)
    gamma = network.stoichiometric_matrix()
    witness = positive_flux_witness(gamma)
    if witness is None:
        separator = gordan_no_positive_flux_certificate(gamma)
        return {
            "file": str(path),
            "status": "NO",
            "reason": "no positive steady flux",
            "separator_y": None if separator is None else [str(x) for x in separator[0]],
        }
    return {
        "file": str(path),
        "status": "UNRESOLVED",
        "positive_flux_witness": [str(x) for x in witness],
        "reason": "stable realization and negative-minor compatibility not supplied",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("networks", nargs="+", type=Path)
    parser.add_argument("--max-species", type=int, default=3)
    parser.add_argument("--max-reactions", type=int, default=8)
    args = parser.parse_args()
    reports = []
    for path in args.networks:
        network, _ = load_network(path)
        if network.n > args.max_species or network.m > args.max_reactions:
            reports.append({"file": str(path), "status": "OUTSIDE_ASSUMPTIONS"})
        else:
            reports.append(inspect(path))
    print(json.dumps(reports, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
