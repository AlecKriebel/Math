from __future__ import annotations

import sys
import unittest
from itertools import combinations
from pathlib import Path

import sympy as sp

COMP = Path(__file__).resolve().parents[1]
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))

from exact_linear_algebra import construct_multiscale_diffusion, signed_principal_minor
from hurwitz import characteristic_coefficients, hurwitz_determinants, is_hurwitz


class FixedJacobianTests(unittest.TestCase):
    def test_hurwitz_cubic(self) -> None:
        j = sp.Matrix([[-10, 20, -50], [1, 1, 0], [1, 0, 2]])
        self.assertEqual(characteristic_coefficients(j), [1, 7, 2, 10])
        self.assertEqual(hurwitz_determinants(j), [7, 4, 40])
        self.assertTrue(is_hurwitz(j))

    def test_multiscale_construction(self) -> None:
        j = sp.Matrix([[1, -2], [3, -4]])
        self.assertLess(signed_principal_minor(j, (0,)), 0)
        d = construct_multiscale_diffusion(j, (0,))
        self.assertTrue(all(d[i, i] > 0 for i in range(2)))
        self.assertLess((d - j).det(), 0)

    def test_mobile_counterexample(self) -> None:
        j = sp.Matrix([[-10, 20, -50], [1, 1, 0], [1, 0, 2]])
        d = sp.diag(sp.Rational(257, 2), 0, 0)
        lam = sp.Rational(3, 2)
        v = sp.Matrix([sp.Rational(-1, 2), -1, 1])
        self.assertTrue(is_hurwitz(j))
        for size in (2, 3):
            for idx in combinations(range(3), size):
                if {1, 2}.issubset(idx):
                    self.assertGreaterEqual(signed_principal_minor(j, idx), 0)
        self.assertEqual((j - d) * v, lam * v)

    def test_same_sign_pattern_pair(self) -> None:
        j0 = sp.Matrix([[-7, -5, -4], [-7, -7, -5], [-3, -4, -6]])
        j1 = sp.Matrix([[-7, -1, -2], [-7, -4, -4], [-3, -7, -6]])
        self.assertTrue(is_hurwitz(j0) and is_hurwitz(j1))
        self.assertTrue(all(sp.sign(j0[i, k]) == sp.sign(j1[i, k]) for i in range(3) for k in range(3)))
        self.assertTrue(all(signed_principal_minor(j0, idx) >= 0 for r in range(1, 4) for idx in combinations(range(3), r)))
        self.assertLess(signed_principal_minor(j1, (1, 2)), 0)


if __name__ == "__main__":
    unittest.main()
