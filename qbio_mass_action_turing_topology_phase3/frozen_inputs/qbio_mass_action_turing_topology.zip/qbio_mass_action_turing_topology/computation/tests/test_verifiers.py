from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PYTHON = sys.executable


class VerifierCliTests(unittest.TestCase):
    def run_json(self, script: str, certificate: str) -> dict[str, object]:
        proc = subprocess.run(
            [PYTHON, str(ROOT / script), str(ROOT / "verifier" / "test_certificates" / certificate)],
            check=True,
            capture_output=True,
            text=True,
        )
        return json.loads(proc.stdout)

    def test_positive(self) -> None:
        result = self.run_json("verifier/verify_positive_witness.py", "positive_two_species.json")
        self.assertEqual(result["status"], "YES")
        self.assertEqual(result["det_q2D_minus_J"], "-33/5")

    def test_fixed_j_no(self) -> None:
        result = self.run_json("verifier/verify_negative_certificate.py", "fixed_j_p0_no.json")
        self.assertEqual(result["status"], "NO")

    def test_no_flux(self) -> None:
        result = self.run_json("verifier/verify_negative_certificate.py", "no_positive_flux.json")
        self.assertEqual(result["status"], "NO")

    def test_unresolved_is_not_no(self) -> None:
        result = self.run_json("verifier/verify_characterization_instance.py", "raw_unresolved_positive_flux.json")
        self.assertEqual(result["status"], "UNRESOLVED")

    def test_mobile_counterexample(self) -> None:
        result = self.run_json("verifier/verify_mobile_counterexample.py", "mobile_proposal_counterexample.json")
        self.assertEqual(result["status"], "REFUTES_PROPOSED_MOBILE_CRITERION")
        self.assertTrue(result["verified_eigenpair"])

    def test_root_classifier_command(self) -> None:
        result = self.run_json("classify_network.py", "raw_unresolved_positive_flux.json")
        self.assertEqual(result["status"], "UNRESOLVED")


if __name__ == "__main__":
    unittest.main()
