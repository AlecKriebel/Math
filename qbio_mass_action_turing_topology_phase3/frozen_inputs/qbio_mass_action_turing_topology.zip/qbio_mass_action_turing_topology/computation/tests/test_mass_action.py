from __future__ import annotations

import json
import sys
import unittest
from itertools import combinations
from pathlib import Path

import sympy as sp

ROOT = Path(__file__).resolve().parents[2]
COMP = ROOT / "computation"
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))

from exact_linear_algebra import exact_vector, reduced_restriction, signed_principal_minor
from flux_cone import gordan_no_positive_flux_certificate, positive_flux_witness, verify_gordan_certificate
from hurwitz import is_hurwitz
from network_parser import direct_mass_action_jacobian, jacobian_from_flux, parse_network, reaction_flux, reconstruct_rates
from principal_minors import tau_value, verify_principal_minor_formula
from realize_matrix import realize_matrix


class MassActionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        path = ROOT / "verifier" / "test_certificates" / "positive_two_species.json"
        cls.raw = json.loads(path.read_text())
        cls.network = parse_network(cls.raw)
        cls.x = exact_vector(cls.raw["x_star"])

    def test_flux_and_jacobian(self) -> None:
        gamma = self.network.stoichiometric_matrix()
        flux = reaction_flux(self.network, self.x)
        self.assertEqual(gamma * flux, sp.zeros(2, 1))
        j1 = jacobian_from_flux(self.network, self.x, flux)
        j2 = direct_mass_action_jacobian(self.network, self.x)
        self.assertEqual(j1, sp.Matrix([[1, -2], [3, -4]]))
        self.assertEqual(j1, j2)
        reduced, _ = reduced_restriction(j1, gamma)
        self.assertTrue(is_hurwitz(reduced))

    def test_reconstruction(self) -> None:
        flux = reaction_flux(self.network, self.x)
        self.assertEqual(reconstruct_rates(self.network, self.x, flux), self.network.rates())

    def test_cauchy_binet_formula(self) -> None:
        gamma = self.network.stoichiometric_matrix()
        y = self.network.source_matrix()
        flux = reaction_flux(self.network, self.x)
        h = sp.Matrix([1, 1])
        j = jacobian_from_flux(self.network, self.x, flux)
        for size in range(1, 3):
            for idx in combinations(range(2), size):
                self.assertTrue(verify_principal_minor_formula(gamma, y, flux, h, idx))
                self.assertEqual(signed_principal_minor(j, idx), tau_value(gamma, y, flux, idx))

    def test_flux_cone_exact_lp(self) -> None:
        gamma = sp.Matrix([[1, -1]])
        self.assertEqual(positive_flux_witness(gamma), sp.Matrix([1, 1]))
        impossible = sp.Matrix([[1, 1]])
        self.assertIsNone(positive_flux_witness(impossible))
        cert = gordan_no_positive_flux_certificate(impossible)
        self.assertIsNotNone(cert)
        assert cert is not None
        self.assertTrue(verify_gordan_certificate(impossible, cert[0]))

    def test_arbitrary_rational_matrix_realization(self) -> None:
        target = sp.Matrix([[sp.Rational(1, 2), -3, 0], [4, 0, 5], [0, 0, 0]])
        raw = realize_matrix(target)
        network = parse_network(raw)
        x = exact_vector(raw["x_star"])
        flux = reaction_flux(network, x)
        gamma = network.stoichiometric_matrix()
        self.assertEqual(gamma.rank(), 3)
        self.assertTrue(all(value > 0 for value in flux))
        self.assertEqual(gamma * flux, sp.zeros(3, 1))
        self.assertEqual(jacobian_from_flux(network, x, flux), target)
        self.assertEqual(direct_mass_action_jacobian(network, x), target)


if __name__ == "__main__":
    unittest.main()
