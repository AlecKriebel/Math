#!/usr/bin/env python3
"""Exact linear-algebra helpers for stationary Turing certificates.

All accepted certificate paths use SymPy rationals.  Python floats are rejected
rather than silently rationalized.
"""
from __future__ import annotations

from itertools import combinations
from typing import Iterable, Iterator, Sequence

import sympy as sp


def q(value: object) -> sp.Rational:
    """Parse an exact rational value, rejecting binary floating point."""
    if isinstance(value, float):
        raise TypeError("floating-point values are forbidden in exact certificates")
    if isinstance(value, sp.Rational):
        return value
    if isinstance(value, sp.Integer):
        return sp.Rational(value)
    if isinstance(value, int):
        return sp.Rational(value)
    if isinstance(value, str):
        return sp.Rational(value.strip())
    return sp.Rational(value)  # exact for integer-like SymPy objects


def exact_matrix(data: Sequence[Sequence[object]]) -> sp.Matrix:
    if not isinstance(data, Sequence):
        raise TypeError("matrix data must be a sequence of rows")
    rows = [[q(x) for x in row] for row in data]
    if rows and any(len(row) != len(rows[0]) for row in rows):
        raise ValueError("ragged matrix")
    return sp.Matrix(rows)


def exact_vector(data: Sequence[object]) -> sp.Matrix:
    return sp.Matrix([q(x) for x in data])


def subsets(n: int, *, nonempty: bool = False, proper: bool = False) -> Iterator[tuple[int, ...]]:
    start = 1 if nonempty else 0
    stop = n if proper else n + 1
    for size in range(start, stop):
        yield from combinations(range(n), size)


def principal_submatrix(a: sp.Matrix, index_set: Sequence[int]) -> sp.Matrix:
    idx = list(index_set)
    return a.extract(idx, idx)


def signed_principal_minor(a: sp.Matrix, index_set: Sequence[int]) -> sp.Expr:
    idx = tuple(index_set)
    if not idx:
        return sp.Integer(1)
    return sp.expand((-1) ** len(idx) * principal_submatrix(a, idx).det())


def signed_principal_minors(a: sp.Matrix, *, proper_only: bool = False) -> dict[tuple[int, ...], sp.Expr]:
    if a.rows != a.cols:
        raise ValueError("matrix must be square")
    return {
        idx: signed_principal_minor(a, idx)
        for idx in subsets(a.rows, nonempty=True, proper=proper_only)
    }


def negative_signed_principal_sets(a: sp.Matrix) -> list[tuple[int, ...]]:
    return [idx for idx, value in signed_principal_minors(a).items() if value < 0]


def stoichiometric_basis(gamma: sp.Matrix) -> sp.Matrix:
    """Return a rational column basis for im(Gamma)."""
    cols = gamma.columnspace()
    if not cols:
        return sp.zeros(gamma.rows, 0)
    return sp.Matrix.hstack(*cols)


def reduced_restriction(jacobian: sp.Matrix, gamma: sp.Matrix) -> tuple[sp.Matrix, sp.Matrix]:
    """Represent J|_S in a rational basis B of S=im(Gamma).

    Returns (R,B) with J B = B R.  Raises if J does not preserve S.
    """
    if jacobian.rows != jacobian.cols or jacobian.rows != gamma.rows:
        raise ValueError("dimension mismatch")
    basis = stoichiometric_basis(gamma)
    s = basis.cols
    if s == 0:
        return sp.zeros(0, 0), basis
    left_inverse = (basis.T * basis).inv() * basis.T
    reduced = sp.simplify(left_inverse * jacobian * basis)
    if sp.simplify(jacobian * basis - basis * reduced) != sp.zeros(jacobian.rows, s):
        raise ValueError("Jacobian does not preserve the stoichiometric subspace")
    return reduced, basis


def construct_multiscale_diffusion(
    jacobian: sp.Matrix,
    target_set: Iterable[int],
    *,
    start_t: int = 2,
    max_doublings: int = 80,
) -> sp.Matrix:
    """Construct D>0 with det(D-J)<0 from a negative signed principal minor."""
    n = jacobian.rows
    if n != jacobian.cols:
        raise ValueError("Jacobian must be square")
    target = frozenset(target_set)
    if signed_principal_minor(jacobian, tuple(sorted(target))) >= 0:
        raise ValueError("target set does not have a negative signed principal minor")
    t = sp.Integer(start_t)
    for _ in range(max_doublings + 1):
        diagonal = [sp.Rational(1, t) if i in target else t for i in range(n)]
        dmat = sp.diag(*diagonal)
        if sp.expand((dmat - jacobian).det()) < 0:
            return dmat
        t *= 2
    raise RuntimeError("multiscale construction did not reach the certified sign within limit")


def positive_real_root_certified_by_constant_term(matrix: sp.Matrix) -> bool:
    """Return True when det(-matrix)<0 certifies a positive real eigenvalue."""
    if matrix.rows != matrix.cols:
        raise ValueError("matrix must be square")
    return sp.expand((-matrix).det()) < 0


def matrix_to_strings(a: sp.Matrix) -> list[list[str]]:
    return [[str(sp.factor(a[i, j])) for j in range(a.cols)] for i in range(a.rows)]


def vector_to_strings(v: sp.Matrix) -> list[str]:
    return [str(sp.factor(v[i, 0])) for i in range(v.rows)]
