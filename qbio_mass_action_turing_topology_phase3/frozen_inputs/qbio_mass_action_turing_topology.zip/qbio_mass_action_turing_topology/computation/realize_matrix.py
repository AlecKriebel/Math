#!/usr/bin/env python3
"""Realize an exact rational matrix as a classical mass-action Jacobian.

For every row, reactions occur in equal-rate stoichiometrically cancelling pairs.
At x*=1 the network has a strictly positive steady flux, the Jacobian is the
input matrix, and the stoichiometric subspace is all of R^n.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import sympy as sp

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from exact_linear_algebra import exact_matrix  # noqa: E402


def _unit(n: int, i: int, coefficient: int = 1) -> list[int]:
    value = [0] * n
    value[i] = coefficient
    return value


def _sum_complex(*vectors: list[int]) -> list[int]:
    return [sum(entries) for entries in zip(*vectors)]


def realize_matrix(matrix: sp.Matrix, species: list[str] | None = None) -> dict[str, Any]:
    if matrix.rows == 0 or matrix.rows != matrix.cols:
        raise ValueError("matrix must be nonempty and square")
    n = matrix.rows
    names = species or [f"X{i + 1}" for i in range(n)]
    if len(names) != n or len(set(names)) != n:
        raise ValueError("species must contain n distinct names")

    reactions: list[dict[str, Any]] = []
    for i in range(n):
        row_has_nonzero = False
        ei = _unit(n, i)
        two_ei = _unit(n, i, 2)
        three_ei = _unit(n, i, 3)
        for j in range(n):
            entry = sp.Rational(matrix[i, j])
            if entry == 0:
                continue
            row_has_nonzero = True
            rate = str(abs(entry))
            if i == j and entry > 0:
                pair = [(two_ei, three_ei), (ei, [0] * n)]
            elif i == j and entry < 0:
                pair = [(ei, two_ei), (two_ei, ei)]
            elif entry > 0:
                ej = _unit(n, j)
                pair = [
                    (_sum_complex(ei, ej), _sum_complex(two_ei, ej)),
                    (ei, [0] * n),
                ]
            else:
                ej = _unit(n, j)
                pair = [
                    (ei, two_ei),
                    (_sum_complex(ei, ej), ej),
                ]
            for source, target in pair:
                reactions.append({"source": source, "target": target, "k": rate})
        if not row_has_nonzero:
            # Identically cancelling pair: zero vector field and zero Jacobian,
            # but stoichiometric vectors +e_i and -e_i retain full rank.
            reactions.extend(
                [
                    {"source": ei, "target": two_ei, "k": "1"},
                    {"source": ei, "target": [0] * n, "k": "1"},
                ]
            )

    return {
        "species": names,
        "reactions": reactions,
        "x_star": ["1"] * n,
        "expected_jacobian": [[str(sp.factor(matrix[i, j])) for j in range(n)] for i in range(n)],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("matrix", type=Path, help="JSON matrix or object containing key J")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    raw = json.loads(args.matrix.read_text())
    data = raw.get("J") if isinstance(raw, dict) else raw
    network = realize_matrix(exact_matrix(data))
    text = json.dumps(network, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text)
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
