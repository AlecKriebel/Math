#!/usr/bin/env python3
"""Cauchy--Binet flux-polynomial evaluations."""
from __future__ import annotations

from itertools import combinations
from typing import Sequence

import sympy as sp

try:
    from .exact_linear_algebra import principal_submatrix, signed_principal_minor
except ImportError:
    from exact_linear_algebra import principal_submatrix, signed_principal_minor


def tau_value(gamma: sp.Matrix, y: sp.Matrix, flux: sp.Matrix, species_set: Sequence[int]) -> sp.Expr:
    index = tuple(species_set)
    p = len(index)
    if p == 0:
        return sp.Integer(1)
    if gamma.rows != y.rows or gamma.cols != y.cols or flux.rows != gamma.cols:
        raise ValueError("dimension mismatch")
    total = sp.Integer(0)
    for reaction_set in combinations(range(gamma.cols), p):
        g = gamma.extract(index, reaction_set)
        yy = y.extract(index, reaction_set)
        monomial = sp.prod(flux[r] for r in reaction_set)
        total += g.det() * yy.det() * monomial
    return sp.factor((-1) ** p * total)


def verify_principal_minor_formula(
    gamma: sp.Matrix,
    y: sp.Matrix,
    flux: sp.Matrix,
    h: sp.Matrix,
    species_set: Sequence[int],
) -> bool:
    if h.cols != 1 or h.rows != gamma.rows:
        raise ValueError("h must be a column vector")
    j = gamma * sp.diag(*list(flux)) * y.T * sp.diag(*list(h))
    lhs = signed_principal_minor(j, species_set)
    rhs = sp.prod(h[i] for i in species_set) * tau_value(gamma, y, flux, species_set)
    return sp.simplify(lhs - rhs) == 0
