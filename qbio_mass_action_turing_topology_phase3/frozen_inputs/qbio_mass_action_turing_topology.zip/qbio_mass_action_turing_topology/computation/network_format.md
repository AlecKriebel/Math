# Exact network and certificate format

All accepted numbers are JSON integers or strings representing exact rational numbers, such as `"17/23"`. Binary floating-point JSON numbers are rejected by the exact verifier.

A network object has:

```json
{
  "species": ["X1", "X2"],
  "reactions": [
    {"source": [1, 0], "target": [0, 1], "k": "3/2"}
  ]
}
```

The source and target arrays are nonnegative integer stoichiometric vectors in the listed species order. A positive YES certificate additionally supplies `x_star`, positive all-species `diffusion`, a positive squared wave number `q2` (default `1`), and optionally a zero-based `responsible_species` principal set.

The verifier recomputes, rather than trusts, the source matrix `Y`, stoichiometric matrix `Gamma`, flux vector, equilibrium equation, mass-action Jacobian by two independent formulas, stoichiometric reduction, Routh--Hurwitz determinants, spatial determinant, and all principal-minor/flux-polynomial identities.

A network-level NO certificate currently has one universally valid form: a Gordan separator `separator_y` satisfying `Gamma^T separator_y >= 0` componentwise and nonzero. This proves that no strictly positive steady flux exists. A `fixed_j_stationary_no` certificate is a matrix-level certificate only and must not be described as a universal NO certificate for a reaction hypergraph.
