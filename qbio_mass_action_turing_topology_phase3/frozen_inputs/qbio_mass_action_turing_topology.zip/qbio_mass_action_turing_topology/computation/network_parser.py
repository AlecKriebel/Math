#!/usr/bin/env python3
"""JSON parser and exact mass-action matrix construction."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import sympy as sp

try:
    from .exact_linear_algebra import exact_vector, q
except ImportError:  # direct script use
    from exact_linear_algebra import exact_vector, q


@dataclass(frozen=True)
class Reaction:
    source: tuple[int, ...]
    target: tuple[int, ...]
    rate: sp.Rational | None = None


@dataclass(frozen=True)
class Network:
    species: tuple[str, ...]
    reactions: tuple[Reaction, ...]

    @property
    def n(self) -> int:
        return len(self.species)

    @property
    def m(self) -> int:
        return len(self.reactions)

    def source_matrix(self) -> sp.Matrix:
        if self.m == 0:
            return sp.zeros(self.n, 0)
        return sp.Matrix.hstack(*[sp.Matrix(r.source) for r in self.reactions])

    def stoichiometric_matrix(self) -> sp.Matrix:
        if self.m == 0:
            return sp.zeros(self.n, 0)
        return sp.Matrix.hstack(
            *[sp.Matrix(r.target) - sp.Matrix(r.source) for r in self.reactions]
        )

    def rates(self) -> sp.Matrix:
        values = []
        for r in self.reactions:
            if r.rate is None:
                raise ValueError("a reaction is missing its rate constant")
            values.append(r.rate)
        return sp.Matrix(values)


def _complex_vector(value: Any, n: int, label: str) -> tuple[int, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError(f"{label} must be a length-{n} integer vector")
    if len(value) != n:
        raise ValueError(f"{label} has length {len(value)}; expected {n}")
    result: list[int] = []
    for item in value:
        if isinstance(item, bool) or int(item) != item or int(item) < 0:
            raise ValueError(f"{label} entries must be nonnegative integers")
        result.append(int(item))
    return tuple(result)


def parse_network(data: dict[str, Any]) -> Network:
    species_data = data.get("species")
    if not isinstance(species_data, list) or not species_data:
        raise ValueError("species must be a nonempty list")
    species = tuple(str(x) for x in species_data)
    if len(set(species)) != len(species):
        raise ValueError("species names must be distinct")
    reactions_data = data.get("reactions", [])
    if not isinstance(reactions_data, list):
        raise ValueError("reactions must be a list")
    reactions: list[Reaction] = []
    for index, raw in enumerate(reactions_data):
        if not isinstance(raw, dict):
            raise TypeError(f"reaction {index} must be an object")
        source = _complex_vector(raw.get("source"), len(species), f"reaction {index} source")
        target = _complex_vector(raw.get("target"), len(species), f"reaction {index} target")
        if source == target:
            raise ValueError(f"reaction {index} has identical source and target")
        rate_raw = raw.get("k", raw.get("rate"))
        rate = None if rate_raw is None else q(rate_raw)
        if rate is not None and rate <= 0:
            raise ValueError(f"reaction {index} rate must be strictly positive")
        reactions.append(Reaction(source, target, rate))
    return Network(species, tuple(reactions))


def load_network(path: str | Path) -> tuple[Network, dict[str, Any]]:
    raw = json.loads(Path(path).read_text())
    if not isinstance(raw, dict):
        raise ValueError("top-level JSON value must be an object")
    return parse_network(raw), raw


def monomial(x: sp.Matrix, exponent: Sequence[int]) -> sp.Expr:
    if x.rows != len(exponent) or x.cols != 1:
        raise ValueError("dimension mismatch in monomial")
    value = sp.Integer(1)
    for xi, power in zip(x, exponent):
        value *= xi ** int(power)
    return sp.factor(value)


def reaction_flux(network: Network, x_star: sp.Matrix, rates: sp.Matrix | None = None) -> sp.Matrix:
    if x_star.rows != network.n or x_star.cols != 1:
        raise ValueError("equilibrium has wrong dimension")
    if any(value <= 0 for value in x_star):
        raise ValueError("equilibrium must be strictly positive")
    k = network.rates() if rates is None else rates
    if k.rows != network.m or k.cols != 1:
        raise ValueError("rate vector has wrong dimension")
    return sp.Matrix([
        sp.factor(k[r] * monomial(x_star, network.reactions[r].source))
        for r in range(network.m)
    ])


def jacobian_from_flux(network: Network, x_star: sp.Matrix, flux: sp.Matrix) -> sp.Matrix:
    gamma = network.stoichiometric_matrix()
    y = network.source_matrix()
    h = sp.diag(*[sp.factor(1 / value) for value in x_star])
    return sp.simplify(gamma * sp.diag(*list(flux)) * y.T * h)


def direct_mass_action_jacobian(network: Network, x_star: sp.Matrix, rates: sp.Matrix | None = None) -> sp.Matrix:
    k = network.rates() if rates is None else rates
    gamma = network.stoichiometric_matrix()
    j = sp.zeros(network.n, network.n)
    for r, reaction in enumerate(network.reactions):
        base = sp.factor(k[r] * monomial(x_star, reaction.source))
        for col, power in enumerate(reaction.source):
            if power:
                j[:, col] += gamma[:, r] * sp.factor(base * power / x_star[col])
    return sp.simplify(j)


def reconstruct_rates(network: Network, x_star: sp.Matrix, flux: sp.Matrix) -> sp.Matrix:
    if any(value <= 0 for value in flux):
        raise ValueError("flux must be strictly positive")
    return sp.Matrix([
        sp.factor(flux[r] / monomial(x_star, network.reactions[r].source))
        for r in range(network.m)
    ])
