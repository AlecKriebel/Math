#!/usr/bin/env python3
"""Discover and exactify a YES certificate from a fully parameterized network.

This is a discovery helper.  Its output is accepted only after the independent
verifier succeeds.
"""
from __future__ import annotations

import argparse
import json
import sys
from itertools import combinations
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from exact_linear_algebra import construct_multiscale_diffusion, exact_vector, reduced_restriction, signed_principal_minor  # noqa: E402
from hurwitz import is_hurwitz  # noqa: E402
from network_parser import jacobian_from_flux, load_network, reaction_flux  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("network", type=Path, help="JSON with exact rates and x_star")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    network, raw = load_network(args.network)
    if "x_star" not in raw:
        raise SystemExit("input must provide x_star")
    x_star = exact_vector(raw["x_star"])
    gamma = network.stoichiometric_matrix()
    flux = reaction_flux(network, x_star)
    if gamma * flux != sp.zeros(network.n, 1):
        raise SystemExit("provided x_star is not an equilibrium")
    j = jacobian_from_flux(network, x_star, flux)
    reduced, _ = reduced_restriction(j, gamma)
    if not is_hurwitz(reduced):
        raise SystemExit("homogeneous reduced Jacobian is not Hurwitz")
    target = None
    for size in range(1, network.n + 1):
        for idx in combinations(range(network.n), size):
            if signed_principal_minor(j, idx) < 0:
                target = idx
                break
        if target is not None:
            break
    if target is None:
        raise SystemExit("no negative signed principal minor; this route cannot certify YES")
    dmat = construct_multiscale_diffusion(j, target)
    certificate = dict(raw)
    certificate.update(
        {
            "certificate_type": "mass_action_stationary_yes",
            "diffusion": [str(dmat[i, i]) for i in range(network.n)],
            "q2": "1",
            "responsible_species": list(target),
        }
    )
    text = json.dumps(certificate, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text)
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
