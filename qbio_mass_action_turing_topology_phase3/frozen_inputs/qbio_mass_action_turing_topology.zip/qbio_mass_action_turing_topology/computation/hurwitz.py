#!/usr/bin/env python3
"""Exact Routh--Hurwitz tests."""
from __future__ import annotations

import sympy as sp


def characteristic_coefficients(matrix: sp.Matrix) -> list[sp.Expr]:
    """Return [1,a1,...,an] for det(lambda I-A)."""
    if matrix.rows != matrix.cols:
        raise ValueError("matrix must be square")
    if matrix.rows == 0:
        return [sp.Integer(1)]
    lam = sp.Symbol("lambda")
    return [sp.expand(c) for c in matrix.charpoly(lam).all_coeffs()]


def hurwitz_matrix(coefficients: list[sp.Expr]) -> sp.Matrix:
    """Build the n-by-n Hurwitz matrix for a0*x^n+a1*x^(n-1)+...+an.

    The accepted use has a0=1, but the construction is general.
    """
    n = len(coefficients) - 1
    if n < 0:
        raise ValueError("coefficient list cannot be empty")
    if n == 0:
        return sp.zeros(0, 0)
    coeff = {i: sp.sympify(value) for i, value in enumerate(coefficients)}
    return sp.Matrix(
        n,
        n,
        lambda i, j: coeff.get(2 * j - i + 1, sp.Integer(0)),
    )


def hurwitz_determinants_from_coefficients(coefficients: list[sp.Expr]) -> list[sp.Expr]:
    h = hurwitz_matrix(coefficients)
    return [sp.factor(h[:k, :k].det()) for k in range(1, h.rows + 1)]


def hurwitz_determinants(matrix: sp.Matrix) -> list[sp.Expr]:
    return hurwitz_determinants_from_coefficients(characteristic_coefficients(matrix))


def is_hurwitz(matrix: sp.Matrix) -> bool:
    if matrix.rows != matrix.cols:
        raise ValueError("matrix must be square")
    if matrix.rows == 0:
        return True
    coeffs = characteristic_coefficients(matrix)
    if coeffs[0] <= 0:
        return False
    return all(delta > 0 for delta in hurwitz_determinants_from_coefficients(coeffs))
