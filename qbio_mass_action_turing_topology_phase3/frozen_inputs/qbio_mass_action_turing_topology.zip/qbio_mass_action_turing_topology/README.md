# Mass-action stationary Turing topology project

This project audits the proposed landmark problem of characterizing, solely from a finite mass-action reaction hypergraph, whether some strictly positive mass-action realization has a linearly stable positive homogeneous equilibrium that is destabilized by ordinary diagonal diffusion through a **real positive spatial eigenvalue**.

## Final status

The landmark characterization is **not complete**.  The project therefore terminates with the mandated `STOP` outcome rather than converting an exact existential reduction into a claimed topological theorem.

What is complete:

1. an exact all-mobile fixed-Jacobian stationary diagonal-damping theorem;
2. a corrected exact theorem for a designated mobile set, together with a rational 3-by-3 counterexample to the determinant-at-zero criterion proposed in the directive;
3. the correct treatment of conservation laws and nonzero spatial modes;
4. the positive-equilibrium flux parameterization of every mass-action Jacobian;
5. the exact Cauchy--Binet expansion of every principal minor;
6. an exact semialgebraic reaction-network reduction;
7. complete one-species and two-species reductions and the fixed-J three-species stationary criterion;
8. an exact mass-action realization gadget for an arbitrary rational matrix at a positive equilibrium;
9. exact positive witnesses, fixed-J negative certificates, verifiers, and regression tests;
10. a literature and priority audit through 2026-08-12.

What remains open in this project:

* eliminate the simultaneous feasibility of a positive steady flux and a positive right-diagonal stabilizer in arbitrary dimension;
* turn that elimination into a non-tautological finite network certificate for both YES and NO instances;
* determine whether weak stationary admissibility always has a primary simple stationary crossing before any wave crossing;
* complete the unrestricted Turing--Hopf boundary.

## Reproduce

```bash
cd /mnt/data/qbio_mass_action_turing_topology
bash release/one_command_verification.sh
```

The scripts use exact rational arithmetic through SymPy for every accepted certificate.  Numerical searches are discovery-only and never produce `NO`.

The release currently passes **15 exact regression/unit tests**, four formal certificate-schema checks, all independent verifier status assertions, a 57-file mandatory-tree audit, and a LaTeX source/compiled-manuscript audit. A visually inspected 15-page PDF is included at `manuscript/main.pdf`. See [`FINAL_REPORT.md`](FINAL_REPORT.md) for the mandated termination report and `release/verification_outputs/` for machine-readable results.

## Central exact reduction

For an all-mobile network, write

\[
J(v,h)=\Gamma\operatorname{diag}(v)Y^T\operatorname{diag}(h),
\qquad v>0,\quad \Gamma v=0,\quad h>0.
\]

The network is weakly stationary-Turing-admissible exactly when there are such `v,h` for which `J(v,h)|_S` is Hurwitz and one proper signed principal minor is negative.  Equivalently, one of the flux polynomials `tau_I(v)` is negative.  This removes rate constants, concentrations, diffusion coefficients, and wave number, but it does **not** remove the steady-flux and diagonal-stability feasibility variables.  The directive expressly disallows presenting that residual existential condition as the requested topology theorem, so the package records it as a reduction only.
