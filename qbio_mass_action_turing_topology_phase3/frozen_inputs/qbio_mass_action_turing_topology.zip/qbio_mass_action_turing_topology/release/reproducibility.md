# Reproducibility guide

## Environment used

The release was verified on 2026-08-12 with:

```text
Python 3.13.5
SymPy 1.14.0
jsonschema 4.26.0
```

No floating-point eigenvalue is accepted as proof. Certificate scalars are JSON integers or exact rational strings. The verifiers reject binary floating-point values on every exact path.

## One-command verification

```bash
cd /mnt/data/qbio_mass_action_turing_topology
bash release/one_command_verification.sh
```

The command performs:

1. Python byte-code compilation;
2. JSON-schema validation of all formal certificates;
3. the complete unit-test suite;
4. independent verification of the positive two-species mass-action witness;
5. independent verification of the fixed-J signed-`P_0` NO certificate;
6. independent verification of the no-positive-flux network NO certificate;
7. independent verification of the designated-mobile-set counterexample;
8. a regression check for the same-signed-graph fixed-J pair;
9. a check that an unresolved positive-flux network is not mislabeled `NO`;
10. a mandatory-file audit;
11. a LaTeX citation/input/reference and compiled-PDF audit;
12. regeneration of `release/sha256_manifest.txt`.

Expected high-level statuses are:

```text
positive_two_species: YES
fixed_j_p0_no: NO
no_positive_flux: NO
mobile_proposal_counterexample: REFUTES_PROPOSED_MOBILE_CRITERION
raw_positive_flux_network: UNRESOLVED
```

Detailed machine-readable outputs are written to `release/verification_outputs/`.

## Individual commands

```bash
python verifier/verify_positive_witness.py \
  verifier/test_certificates/positive_two_species.json

python verifier/verify_negative_certificate.py \
  verifier/test_certificates/fixed_j_p0_no.json

python verifier/verify_negative_certificate.py \
  verifier/test_certificates/no_positive_flux.json

python verifier/verify_mobile_counterexample.py \
  verifier/test_certificates/mobile_proposal_counterexample.json

python classify_network.py \
  verifier/test_certificates/raw_unresolved_positive_flux.json
```

## Discovery versus verification

`computation/discover_witnesses.py` and `computation/search_small_networks.py` are discovery/reconnaissance utilities. Their failure to find a witness never yields `NO`. Only the independent exact verifiers can emit an accepted `YES` or one of the supported exact `NO` scopes.

## Manuscript source and PDF

The manuscript and supplement are LaTeX sources in `manuscript/`. Rebuild the included 15-page PDF with:

```bash
bash manuscript/build_pdf.sh
```

The build script uses `latexmk` and includes a fallback for installations that expose `bibtex.original` but have a broken `bibtex` alternatives link. The release audit verifies all citation keys, `\input` paths, cross-reference labels, basic brace balance, and a nonempty compiled PDF. The PDF was also rendered page-by-page and visually inspected; PDF compilation is independent of the mathematical certificate checks.

## Scope warning

The software is not a complete arbitrary-network decision procedure. `classify_network.py` deliberately returns `UNRESOLVED` whenever no supported exact certificate applies. This behavior is part of the correctness contract, not a missing error handler.
