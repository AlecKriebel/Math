#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/release/verification_outputs"
mkdir -p "$OUT"
rm -f "$OUT"/*.json "$OUT"/*.txt

export PYTHONPATH="$ROOT/computation${PYTHONPATH:+:$PYTHONPATH}"

printf '[1/10] Compiling Python sources...\n'
python -m compileall -q "$ROOT/computation" "$ROOT/verifier" "$ROOT/adversarial_audit" "$ROOT/classify_network.py"

printf '[2/10] Validating certificate schemas...\n'
python - "$ROOT" <<'PY' > "$OUT/schema_validation.txt"
import json
import sys
from pathlib import Path
import jsonschema

root = Path(sys.argv[1])
schema = json.loads((root / 'verifier/certificate_schema.json').read_text())
files = [
    'positive_two_species.json',
    'fixed_j_p0_no.json',
    'no_positive_flux.json',
    'mobile_proposal_counterexample.json',
]
for name in files:
    data = json.loads((root / 'verifier/test_certificates' / name).read_text())
    jsonschema.validate(data, schema)
    print(f'{name}: SCHEMA_OK')
PY
cat "$OUT/schema_validation.txt"

printf '[3/10] Running unit tests...\n'
python -m unittest discover -s "$ROOT/computation/tests" -v 2>&1 | tee "$OUT/unit_tests.txt"

printf '[4/10] Verifying exact YES/NO certificates...\n'
python "$ROOT/verifier/verify_positive_witness.py" \
  "$ROOT/verifier/test_certificates/positive_two_species.json" \
  > "$OUT/positive_two_species.json"
python "$ROOT/verifier/verify_negative_certificate.py" \
  "$ROOT/verifier/test_certificates/fixed_j_p0_no.json" \
  > "$OUT/fixed_j_p0_no.json"
python "$ROOT/verifier/verify_negative_certificate.py" \
  "$ROOT/verifier/test_certificates/no_positive_flux.json" \
  > "$OUT/no_positive_flux.json"
python "$ROOT/verifier/verify_mobile_counterexample.py" \
  "$ROOT/verifier/test_certificates/mobile_proposal_counterexample.json" \
  > "$OUT/mobile_counterexample.json"

printf '[5/10] Checking conservative classifier behavior...\n'
python "$ROOT/classify_network.py" \
  "$ROOT/verifier/test_certificates/raw_unresolved_positive_flux.json" \
  > "$OUT/raw_unresolved.json"

printf '[6/10] Running exact adversarial regressions...\n'
python "$ROOT/adversarial_audit/counterexample_search.py" > "$OUT/counterexample_regressions.json"

printf '[7/10] Asserting machine-readable statuses...\n'
python - "$OUT" <<'PY'
import json
import sys
from pathlib import Path
out = Path(sys.argv[1])
expected = {
    'positive_two_species.json': 'YES',
    'fixed_j_p0_no.json': 'NO',
    'no_positive_flux.json': 'NO',
    'mobile_counterexample.json': 'REFUTES_PROPOSED_MOBILE_CRITERION',
    'raw_unresolved.json': 'UNRESOLVED',
}
for name, status in expected.items():
    value = json.loads((out / name).read_text()).get('status')
    if value != status:
        raise SystemExit(f'{name}: expected {status}, got {value}')
    print(f'{name}: {value}')
PY

printf '[8/10] Auditing mandatory project files...\n'
python - "$ROOT" <<'PY' > "$OUT/required_files.txt"
import sys
from pathlib import Path
root = Path(sys.argv[1])
required = '''
STATE.md
README.md
theorem_dependency_graph.md
literature_audit/current_status.md
literature_audit/terminology_crosswalk.md
literature_audit/priority_audit.md
definitions/reaction_network_conventions.tex
definitions/turing_definitions.tex
definitions/conservation_laws.tex
definitions/topology_levels.tex
fixed_jacobian/domain_mode_reduction.tex
fixed_jacobian/stationary_diagonal_damping.tex
fixed_jacobian/mobile_set_extension.tex
fixed_jacobian/turing_hopf_boundary.tex
fixed_jacobian/additive_D_stability_audit.tex
mass_action/equilibrium_flux_parameterization.tex
mass_action/jacobian_factorization.tex
mass_action/principal_minor_expansion.tex
mass_action/stable_realization.tex
mass_action/conservative_networks.tex
topology/turing_core_definition.tex
topology/necessity.tex
topology/sufficiency.tex
topology/lifting_and_reduction.tex
topology/exact_characterization.tex
topology/complexity_boundary.tex
low_dimension/one_species.tex
low_dimension/two_species.tex
low_dimension/three_species.tex
low_dimension/comparison_with_known_criteria.tex
benchmarks/classical_positive_examples.tex
benchmarks/structural_negative_classes.tex
benchmarks/coarse_topology_counterexamples.tex
benchmarks/benchmark_table.csv
computation/network_format.md
computation/network_parser.py
computation/exact_linear_algebra.py
computation/flux_cone.py
computation/principal_minors.py
computation/hurwitz.py
computation/search_small_networks.py
computation/discover_witnesses.py
verifier/verify_positive_witness.py
verifier/verify_negative_certificate.py
verifier/verify_characterization_instance.py
verifier/certificate_schema.json
adversarial_audit/assumption_audit.md
adversarial_audit/conservation_audit.md
adversarial_audit/stationary_vs_wave.md
adversarial_audit/nonlinear_claims_audit.md
adversarial_audit/counterexample_search.py
adversarial_audit/unresolved_gaps.md
manuscript/main.tex
manuscript/supplement.tex
manuscript/references.bib
release/reproducibility.md
release/one_command_verification.sh
'''.strip().splitlines()
missing = [rel for rel in required if not (root / rel).is_file()]
if missing:
    raise SystemExit('Missing required files:\n' + '\n'.join(missing))
for rel in required:
    print(f'OK {rel}')
print(f'TOTAL_OK {len(required)}')
PY
cat "$OUT/required_files.txt"

printf '[9/10] Auditing LaTeX source and compiled manuscript...\n'
python - "$ROOT" <<'PY' > "$OUT/latex_source_audit.txt"
import re
import sys
from pathlib import Path

root = Path(sys.argv[1])
tex_files = sorted(root.rglob('*.tex'))
all_text = '\n'.join(path.read_text() for path in tex_files)
main = (root / 'manuscript/main.tex').read_text()
bib = (root / 'manuscript/references.bib').read_text()

cites = set()
for match in re.finditer(r'\\cite\w*\{([^}]*)\}', all_text):
    cites.update(key.strip() for key in match.group(1).split(',') if key.strip())
bib_keys = set(re.findall(r'@\w+\{\s*([^,\s]+)', bib))
missing_bib = sorted(cites - bib_keys)
if missing_bib:
    raise SystemExit('Missing bibliography keys: ' + ', '.join(missing_bib))

input_values = re.findall(r'\\input\{([^}]+)\}', main)
missing_inputs = []
for value in input_values:
    path = root / 'manuscript' / value
    if not path.suffix:
        path = path.with_suffix('.tex')
    if not path.is_file():
        missing_inputs.append(str(path))
if missing_inputs:
    raise SystemExit('Missing input files:\n' + '\n'.join(missing_inputs))

labels = set(re.findall(r'\\label\{([^}]+)\}', all_text))
refs = set(re.findall(r'\\(?:ref|eqref|autoref)\{([^}]+)\}', all_text))
missing_labels = sorted(refs - labels)
if missing_labels:
    raise SystemExit('Missing labels: ' + ', '.join(missing_labels))

for path in tex_files:
    text = '\n'.join(line.split('%', 1)[0] for line in path.read_text().splitlines())
    text = re.sub(r'\\[{}]', '', text)
    balance = 0
    for char in text:
        if char == '{':
            balance += 1
        elif char == '}':
            balance -= 1
        if balance < 0:
            raise SystemExit(f'Negative brace balance in {path}')
    if balance:
        raise SystemExit(f'Unbalanced braces in {path}: {balance}')

pdf = root / 'manuscript/main.pdf'
if not pdf.is_file() or pdf.stat().st_size == 0:
    raise SystemExit('Compiled manuscript/main.pdf is missing or empty')

print(f'TEX_FILES {len(tex_files)}')
print(f'CITATION_KEYS {len(cites)}')
print(f'INPUTS {len(input_values)}')
print(f'COMPILED_PDF_BYTES {pdf.stat().st_size}')
print('LATEX_SOURCE_AUDIT_OK')
PY
cat "$OUT/latex_source_audit.txt"

printf '[10/10] Regenerating SHA-256 manifest...\n'
python - "$ROOT" <<'PY'
import hashlib
import sys
from pathlib import Path
root = Path(sys.argv[1])
manifest = root / 'release/sha256_manifest.txt'
entries = []
for path in sorted(root.rglob('*')):
    if not path.is_file():
        continue
    rel = path.relative_to(root).as_posix()
    if rel == 'release/sha256_manifest.txt' or '__pycache__' in path.parts or path.suffix == '.pyc':
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    entries.append(f'{digest}  {rel}')
manifest.write_text('\n'.join(entries) + '\n')
print(f'wrote {manifest} with {len(entries)} entries')
PY

printf 'ALL EXACT VERIFICATION GATES PASSED\n'
