# Conservation audit

The homogeneous mode is constrained by fixed totals, hence stability is assessed on the stoichiometric subspace `S`.

For any nonzero Neumann eigenfunction `phi`, `integral phi = 0`.  A perturbation `z phi` therefore preserves every total `ell^T integral x` for arbitrary species amplitude `z`.  The spatial matrix acts on the full species space.  Restricting `J-D` to `S` would be invalid unless `D S subset S`, which unequal diagonal diffusion need not satisfy.

If `J|S` is Hurwitz, then `R^n=S direct-sum ker J`, so the transverse conservation zeros are semisimple.  This is explicitly checked in the symbolic derivation and is the reason the mobile-set determinant hypothesis holds for every positive spectral parameter.
