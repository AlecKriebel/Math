# Stationary-versus-wave audit

A sign change of `det(lambda I - (J-D))` proves a positive **real** eigenvalue.  It says nothing about whether a conjugate pair crossed earlier while diffusion was increased from zero.

The project therefore uses three distinct labels:

* `WEAK_STATIONARY`: some spatial matrix has a positive real eigenvalue;
* `PRIMARY_STATIONARY`: a simple zero crossing with every other eigenvalue left of the axis;
* `WAVE`: a nonreal pair crosses.

Only `WEAK_STATIONARY` is characterized by signed principal minors.  The package does not assert weak/primary equivalence in arbitrary dimension.  Exact Hurwitz determinants are available for a supplied one-parameter path, but no topology-only wave theorem was obtained.
