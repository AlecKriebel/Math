# Nonlinear-claims audit

The proved statements concern the spectrum of the linearization at a homogeneous positive equilibrium.  They do not prove:

* existence of a nonconstant steady state;
* nonlinear stability of a patterned branch;
* supercriticality or subcriticality;
* global attraction;
* wavelength selection independent of the domain;
* robustness over a positive-volume kinetic parameter set.

A separate Crandall--Rabinowitz or Lyapunov--Schmidt analysis would require simplicity, transversality, Fredholm conditions, and nonlinear coefficient calculations.  None is silently assumed.
