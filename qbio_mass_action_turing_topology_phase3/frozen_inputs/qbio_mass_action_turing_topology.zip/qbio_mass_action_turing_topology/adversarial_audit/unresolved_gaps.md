# Unresolved gaps

1. **Stable realization:** characterize when some `v>0` in `ker Gamma` and `h>0` make `Gamma diag(v) Y^T diag(h)` Hurwitz on `S`.
2. **Simultaneous compatibility:** a flux that makes `tau_I(v)<0` need not be a flux admitting a stabilizing concentration scaling.
3. **Topology-only certificates:** no compact universal NO certificate was obtained beyond recognized classes.
4. **Primary crossing:** weak positive-real destabilization has not been proved equivalent to a first simple stationary bifurcation.
5. **Wave boundary:** arbitrary-dimensional Turing--Hopf admissibility remains outside the determinant theorem.
6. **Complexity lower bound:** membership in the existential theory of the reals is proved, but no hardness result is claimed.
7. **Minimal reaction cores:** no finite forbidden/required list is proved for arbitrary network size.
