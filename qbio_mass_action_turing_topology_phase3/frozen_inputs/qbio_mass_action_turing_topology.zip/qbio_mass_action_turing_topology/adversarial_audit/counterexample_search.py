#!/usr/bin/env python3
"""Exact regression checks for matrix counterexamples.

The name is retained from the directive.  This file verifies the preserved exact
examples; it does not infer universal claims from a search failure.
"""
from __future__ import annotations

import json
import sys
from itertools import combinations
from pathlib import Path

import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "computation"
if str(COMP) not in sys.path:
    sys.path.insert(0, str(COMP))

from exact_linear_algebra import signed_principal_minor  # noqa: E402
from hurwitz import is_hurwitz  # noqa: E402


def verify_mobile_counterexample() -> dict[str, object]:
    j = sp.Matrix([[-10, 20, -50], [1, 1, 0], [1, 0, 2]])
    mobile = {0}
    immobile = set(range(3)) - mobile
    d = sp.diag(sp.Rational(257, 2), 0, 0)
    lam = sp.Rational(3, 2)
    vector = sp.Matrix([sp.Rational(-1, 2), -1, 1])
    containing = []
    for size in range(len(immobile), 4):
        for idx in combinations(range(3), size):
            if immobile.issubset(idx):
                containing.append((idx, signed_principal_minor(j, idx)))
    assert is_hurwitz(j)
    assert all(value >= 0 for _, value in containing)
    assert (j - d) * vector == lam * vector
    return {
        "name": "mobile determinant-at-zero proposal",
        "status": "REFUTED",
        "characteristic_polynomial": str(j.charpoly().as_expr()),
        "candidate_signed_minors": {str(idx): str(value) for idx, value in containing},
        "lambda": str(lam),
    }


def verify_same_sign_pattern_pair() -> dict[str, object]:
    j_no = sp.Matrix([[-7, -5, -4], [-7, -7, -5], [-3, -4, -6]])
    j_yes = sp.Matrix([[-7, -1, -2], [-7, -4, -4], [-3, -7, -6]])
    assert all(sp.sign(j_no[i, k]) == sp.sign(j_yes[i, k]) for i in range(3) for k in range(3))
    assert is_hurwitz(j_no) and is_hurwitz(j_yes)
    no_minors = [signed_principal_minor(j_no, idx) for r in range(1, 4) for idx in combinations(range(3), r)]
    yes_minors = {idx: signed_principal_minor(j_yes, idx) for r in range(1, 4) for idx in combinations(range(3), r)}
    assert all(value >= 0 for value in no_minors)
    assert yes_minors[(1, 2)] < 0
    d = sp.diag(9, sp.Rational(1, 9), sp.Rational(1, 9))
    assert (d - j_yes).det() < 0
    return {
        "name": "same signed fixed-J graph",
        "status": "COARSE_GRAPH_INSUFFICIENT_AT_FIXED_J",
        "negative_minor_yes": str(yes_minors[(1, 2)]),
        "det_D_minus_J_yes": str((d - j_yes).det()),
    }


def main() -> int:
    print(json.dumps([verify_mobile_counterexample(), verify_same_sign_pattern_pair()], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
