# Assumption audit

* **Classical mass action only:** every Jacobian formula uses integer source complexes and monomial rates.
* **Strictly positive declared rates:** every positive witness lists positive rational rates; no reaction is deleted by setting its rate to zero.
* **Strictly positive equilibrium:** the benchmark uses `x*=(1,1)`.
* **Positive steady flux:** verified exactly as `Gamma v=0` with every flux positive.
* **Relative stability:** conservative systems are tested on `S`, not by demanding the full Jacobian be Hurwitz.
* **Nonzero spatial mode:** domain normalization uses the first Neumann mode on `(0,pi)`.
* **All-mobile core:** positive certificates use strictly positive diffusion for every species.
* **Stationary scope:** acceptance requires a positive real eigenvalue or a negative characteristic constant with the accompanying intermediate-value proof.
* **No nonlinear claim:** no stable stripe, spot, or nonlinear branch is inferred.
* **No topology inflation:** the residual `v,h` feasibility is labeled unresolved.
