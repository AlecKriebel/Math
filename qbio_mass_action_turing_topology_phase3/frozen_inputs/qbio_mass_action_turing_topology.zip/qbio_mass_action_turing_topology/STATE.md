# Project state

## Status

Terminated under the mandated **STOP** outcome on 2026-08-12.

The exact reaction-hypergraph characterization was not proved.  No manuscript in this package claims otherwise.

## Proved statements

### Matrix and spatial reduction

1. **All-mobile fixed-J theorem.**  For a real matrix `J`, there is a positive diagonal `D` for which `J-D` has a strictly positive real eigenvalue if and only if
   \[
   (-1)^{|I|}\det J_{I,I}<0
   \]
   for some principal set `I`.  If `J` is Hurwitz, such an `I` is automatically nonempty and proper.

2. **Mobile-set correction.**  Let `M` be the mobile species and assume `det(lambda I-J)>0` for every `lambda>0`.  There is a diagonal `D`, positive on `M` and zero on `M^c`, such that `J-D` has a positive real eigenvalue if and only if there are `lambda>0` and `I superset M^c` with
   \[
   \det(\lambda I_{I}-J_{I,I})<0.
   \]

3. **The proposed mobile-set criterion is false.**  The rational counterexample
   \[
   J=\begin{pmatrix}-10&20&-50\\1&1&0\\1&0&2\end{pmatrix},\quad
   M=\{1\},\quad D=\operatorname{diag}(257/2,0,0)
   \]
   is Hurwitz, has no negative signed principal minor containing `M^c`, yet `3/2` is an eigenvalue of `J-D` with eigenvector `(-1/2,-1,1)^T`.

4. **Conservative extension.**  If `J(S) subset S` and `J|_S` is Hurwitz, then `R^n=S direct-sum ker J`; the transverse zero eigenvalues are semisimple and `det(lambda I-J)>0` for every `lambda>0`.  Nonzero Neumann modes admit arbitrary amplitude vectors because their spatial mean is zero, so `J-q^2D` must be tested on the full species space, not merely on `S`.

5. **Domain normalization.**  The nonzero mode factor `q^2` is absorbed into the freely chosen positive diagonal diffusion matrix.  The interval `(0,pi)` and first nonzero mode can therefore be used without loss for the existence question.

### Mass action

6. **Flux/equilibrium parameterization.**  Every positive-equilibrium mass-action Jacobian is
   \[
   J(v,h)=\Gamma\operatorname{diag}(v)Y^TH,
   \quad v>0,\quad \Gamma v=0,\quad H=\operatorname{diag}(h)>0,
   \]
   and every such pair is reconstructed by `x*=h^{-1}` and `k_r=v_r/(x*)^{y_r}`.

7. **Principal-minor formula.**  For `|I|=p`,
   \[
   (-1)^p\det J_{I,I}=\Big(\prod_{i\in I}h_i\Big)\tau_I(v),
   \]
   where
   \[
   \tau_I(v)=(-1)^p\sum_{|R|=p}
   \det(\Gamma_{I,R})\det(Y_{I,R})\prod_{r\in R}v_r.
   \]

8. **Exact all-mobile network reduction.**  Weak stationary Turing admissibility is equivalent to the existence of `v,h` satisfying positive steady flux, relative Hurwitz stability, and `tau_I(v)<0` for some `I`.

9. **Arbitrary-Jacobian realization.**  Every rational matrix is exactly the Jacobian at `x*=1` of a full-rank mass-action network with strictly positive rational rates and pairwise balanced positive fluxes.  This shows that the fixed-flux right-diagonal stabilization gate contains the unrestricted matrix diagonal-stabilization problem.

10. **Complex-balanced exclusion.**  At a complex-balanced positive equilibrium, the pseudo-Helmholtz Hessian gives a diagonal Lyapunov form.  Adding any positive diagonal diffusion makes the nonzero-mode linearization strictly dissipative, so ordinary diagonal diffusion cannot produce a linear diffusion-driven instability there.

### Low dimension

11. One species cannot exhibit stationary diffusion-driven instability.

12. For a two-species full-rank mass-action flux matrix `A(v)`, some positive `H` makes `A(v)H` Hurwitz and stationary-Turing-admissible exactly when `det A(v)>0` and the two diagonal entries of `A(v)` have strict opposite signs.  The rank-one analogue replaces `det A>0` by rank one and retains the opposite-sign condition.

13. For a Hurwitz three-by-three fixed Jacobian, weak stationary diffusion destabilization occurs exactly when some diagonal entry is positive or some two-by-two principal determinant is negative.

## Exact dependencies

```text
network Turing characterization
    -> positive steady-flux feasibility
    -> right positive-diagonal Hurwitz stabilization on S
    -> negative flux principal-minor polynomial
    -> simultaneous compatibility of all three
```

The second and fourth arrows are not eliminated in arbitrary dimension.

## Failed approaches preserved

1. `fixed_jacobian/mobile_set_extension.tex` preserves and refutes the proposed condition based only on `det(-J_I)` for `I superset M^c`.
2. `adversarial_audit/stationary_vs_wave.md` records why determinant sign detects a positive real eigenvalue but does not prove that this is the primary crossing.
3. `topology/turing_core_definition.tex` records a candidate definition and the precise missing stable-completion axiom; it is not promoted to a theorem.
4. `topology/complexity_boundary.tex` records why generic quantifier elimination is a terminating method but is not the requested structural endpoint and why no hardness claim is made.

## Numerical observations not yet proved

None is used in a theorem or certificate.  Optional search scripts may print candidates, always labeled `UNRESOLVED` until exact verification succeeds.

## Current blockers

1. an arbitrary-dimension characterization of positive right-diagonal stabilizability for matrices `A(v)` compatible with the flux cone;
2. simultaneous exact elimination of `v` and `h` without a tautological existential formula;
3. a complete primary-stationary versus Turing--Hopf separation in arbitrary dimension;
4. universal finite NO certificates for the network-level problem.

## Landmark theorem complete?

**No.**
## Verification status

The one-command release verification passes:

* 15 unit/regression tests;
* schema validation for the YES, fixed-J NO, no-positive-flux NO, and mobile-counterexample certificates;
* independent status checks `YES`, `NO`, `NO`, `REFUTES_PROPOSED_MOBILE_CRITERION`, and `UNRESOLVED`;
* the 57-file mandatory project-tree audit;
* the LaTeX citation/input/reference audit and nonempty compiled manuscript check.

The 15-page manuscript PDF was rendered and visually inspected for clipping and broken glyphs. Machine-readable outputs are in `release/verification_outputs/`, and file hashes are in `release/sha256_manifest.txt`.

