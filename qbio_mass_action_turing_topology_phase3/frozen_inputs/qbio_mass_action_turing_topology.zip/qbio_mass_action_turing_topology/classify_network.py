#!/usr/bin/env python3
"""Stable command name requested by the project directive."""
from __future__ import annotations

import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).resolve().parent / "verifier" / "verify_characterization_instance.py"), run_name="__main__")
