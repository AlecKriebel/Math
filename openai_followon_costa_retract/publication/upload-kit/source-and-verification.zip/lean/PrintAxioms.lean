import OAI.Algebra.AffineCancellation.Main
#print OAI.ComplexCancellation.main
#print axioms OAI.ComplexCancellation.main
#print axioms OAI.ComplexCancellation.nonpolynomiality
#print axioms OAI.ComplexCancellation.Cylinder.equivalence
#print axioms OAI.ComplexCancellation.Cylinder.forward_backward
#print axioms OAI.ComplexCancellation.Cylinder.backward_forward
