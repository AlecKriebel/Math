/- New audit harness by Alec Kriebel, 2026; licensed under Apache 2.0.
   No successful kernel/axiom run is claimed by including this harness. -/
import OAI.Algebra.AffineCancellation.Main
#print OAI.ComplexCancellation.main
#print axioms OAI.ComplexCancellation.main
#print axioms OAI.ComplexCancellation.nonpolynomiality
#print axioms OAI.ComplexCancellation.Cylinder.equivalence
#print axioms OAI.ComplexCancellation.Cylinder.forward_backward
#print axioms OAI.ComplexCancellation.Cylinder.backward_forward
