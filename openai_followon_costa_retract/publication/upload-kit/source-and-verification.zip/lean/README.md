Pinned OpenAI family 047 sources, Apache 2.0; unchanged OAI modules.
The minimal Lake configuration is an audit adaptation excluding unrelated dependencies.
Run lake update; lake exe cache get; lake build OAI.Algebra.AffineCancellation.Main; lake env lean PrintAxioms.lean.
These commands require sufficient disk and network. Full proof compilation was NOT reproduced in this package audit.
See ../audits/formal_scope.md and ../provenance/lean_source_hashes.json.
