/- Audit adaptation by Alec Kriebel, October 6, 2026.
   Modified configuration: retain exact toolchain/mathlib and autoImplicit=false,
   exclude unrelated upstream dependencies, target only family 047 Main.
   All OAI proof modules remain unchanged. Licensed under Apache 2.0. -/
import Lake
open Lake DSL
package OAI where
  version := v!"0.1.0"
  fixedToolchain := true
  leanOptions := #[⟨`autoImplicit, false⟩]
require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @ "d13f23b723b8a846827a245b89c10fc7d3f11612"
@[default_target] lean_lib OAI where
  roots := #[`OAI.Algebra.AffineCancellation.Main]
