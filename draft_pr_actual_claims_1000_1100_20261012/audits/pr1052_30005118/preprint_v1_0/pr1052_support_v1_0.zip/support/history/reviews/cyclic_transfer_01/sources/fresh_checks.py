#!/usr/bin/env python3
"""Independent finite checks. Explicit guards survive python -O."""
import datetime
import hashlib
import json
import pathlib
import sys

OUT = pathlib.Path(__file__).resolve().parent.parent

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def elems(mask, n):
    return tuple(i for i in range(n) if mask & (1 << i))

def integer_sums(values):
    return frozenset(x + y for x in values for y in values)

def cyclic_sum_mask(mask, n):
    full = (1 << n) - 1
    rest = mask
    result = 0
    while rest:
        bit = rest & -rest
        a = bit.bit_length() - 1
        result |= ((mask << a) | (mask >> (n - a))) & full
        rest ^= bit
    return result

def to_mask(values):
    result = 0
    for x in values:
        result |= 1 << x
    return result

def exact_cyclic_sums(values, n):
    return frozenset((x + y) % n for x in values for y in values)

def reduce_integer_set(values, restricted=False):
    s = frozenset(values)
    if not s:
        return 3, frozenset({0}) if restricted else frozenset()
    t = min(s)
    if t % 2:
        return 5, frozenset({0, 1})
    b = frozenset(x - t for x in s)
    m = max(b)
    return max(3, 2 * m + 1), b

def sparse_verify(n, b, a):
    if type(n) is not int or n < 1:
        return False
    if any(type(x) is not int or x < 0 or x >= n for x in b):
        return False
    if any(type(x) is not int or x < 0 or x >= n for x in a):
        return False
    if len(set(b)) != len(b) or len(set(a)) != len(a):
        return False
    if len(a) > len(b):
        return False
    return exact_cyclic_sums(a, n) == frozenset(b)

def dense_verify(n, b_indicator, a_indicator):
    if type(n) is not int or n < 1:
        return False
    if len(b_indicator) != n or len(a_indicator) != n:
        return False
    if any(type(x) is not int or x not in (0, 1) for x in b_indicator + a_indicator):
        return False
    a = tuple(i for i, bit in enumerate(a_indicator) if bit)
    b = frozenset(i for i, bit in enumerate(b_indicator) if bit)
    return exact_cyclic_sums(a, n) == b

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
results = {'started_utc': started, 'python_optimization_level': sys.flags.optimize,
           'guards': 'explicit conditional RuntimeError; no assert statements',
           'universal_proof_role': 'corroboration only; finite checks do not replace proof',
           'source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}

cyclic_yes = {}
odd_root_checks = 0
cardinality_checks = 0
eligible_target_checks = 0
even_canonical_root_failures = 0
per_n = []
for n in list(range(1, 14)) + [15, 17]:
    limit = (n - 1) // 2
    low = (1 << (limit + 1)) - 1
    yes = set()
    eligible_roots = 0
    for a_mask in range(1 << n):
        b_mask = cyclic_sum_mask(a_mask, n)
        yes.add(b_mask)
        require(a_mask.bit_count() <= b_mask.bit_count(), f'Cardinality bound failed at n={n}, A={a_mask}')
        cardinality_checks += 1
        if b_mask & 1 and not (b_mask & ~low):
            eligible_roots += 1
            a = elems(a_mask, n)
            b = frozenset(elems(b_mask, n))
            actual = integer_sums(a)
            if n % 2:
                require(0 in a, f'Odd zero anchor failed at n={n}, A={a}')
                require(actual == b, f'Odd strong transfer failed at n={n}, A={a}, B={sorted(b)}')
                odd_root_checks += 1
            elif actual != b:
                even_canonical_root_failures += 1
    cyclic_yes[n] = yes
    integer_yes = {integer_sums(elems(t_mask, limit + 1)) for t_mask in range(1 << (limit + 1))}
    n_targets = 0
    for lower in range(1 << limit):
        b_mask = 1 | (lower << 1)
        b = frozenset(elems(b_mask, n))
        require((b_mask in yes) == (b in integer_yes), f'Existence transfer failed at n={n}, B={sorted(b)}')
        eligible_target_checks += 1
        n_targets += 1
    per_n.append({'n': n, 'all_cyclic_roots_enumerated': 1 << n,
                  'eligible_anchored_roots': eligible_roots, 'eligible_targets': n_targets,
                  'distinct_cyclic_sumsets': len(yes)})
results['cyclic_enumeration'] = {'per_n': per_n, 'cardinality_checks': cardinality_checks,
                                'odd_strong_every_root_checks': odd_root_checks,
                                'anchored_yes_no_target_checks': eligible_target_checks,
                                'even_every_root_failures_expected': even_canonical_root_failures}
print(json.dumps({'cyclic_enumeration': results['cyclic_enumeration']}, sort_keys=True))

integer_source_yes = {integer_sums(tuple(i - 2 for i in range(5) if t_mask & (1 << i)))
                      for t_mask in range(1 << 5)}
source_checks = 0
restricted_checks = 0
boundary_examples = []
for s_mask in range(1 << 9):
    s = frozenset(i - 4 for i in range(9) if s_mask & (1 << i))
    is_yes = s in integer_source_yes
    for restricted in (False, True):
        n, b = reduce_integer_set(s, restricted)
        require(n in cyclic_yes, 'Missing complete cyclic census for source output')
        require((to_mask(b) in cyclic_yes[n]) == is_yes, f'Total reduction mismatch S={sorted(s)}')
        if restricted:
            require(n % 2 == 1 and 0 in b and all(2 * x < n for x in b), 'Restricted family output guard failed')
            restricted_checks += 1
        else:
            source_checks += 1
    if s in (frozenset(), frozenset({-3}), frozenset({-4}), frozenset({0}),
             frozenset({-4, -3}), frozenset({-4, -2, 0}), frozenset({-3, -1, 1})):
        n, b = reduce_integer_set(s)
        boundary_examples.append({'S': sorted(s), 'integer_yes': is_yes, 'n': n, 'B': sorted(b)})
results['total_reduction'] = {'source_universe': [-4, 4], 'all_source_sets_checked': source_checks,
                             'all_restricted_outputs_checked': restricted_checks,
                             'integer_root_search_universe': [-2, 2],
                             'why_integer_search_complete': 'For nonempty S subset [-4,4], extrema identities force R subset [-2,2].',
                             'boundary_examples': boundary_examples}
print(json.dumps({'total_reduction': results['total_reduction']}, sort_keys=True))

controls = [
    ('anchor_omitted', 5, (1,), (3,), 'integer target min is odd; cyclic singleton root succeeds'),
    ('oddness_omitted_every_root', 4, (0,), (2,), 'canonical cyclic root is not an integer root'),
    ('strict_bound_violated_odd', 5, (0, 2, 3), (1, 4), 'integer target maximum is odd; cyclic root succeeds'),
    ('strict_bound_at_even_equality', 4, (0, 2), (1, 3), 'cyclic root succeeds; integer target has no root'),
]
control_records = []
for name, n, b, a, reason in controls:
    require(exact_cyclic_sums(a, n) == frozenset(b), name + ': cyclic witness failed')
    require(integer_sums(a) != frozenset(b), name + ': canonical root unexpectedly integer')
    if name in ('anchor_omitted', 'strict_bound_violated_odd'):
        require(min(b) % 2 or max(b) % 2, name + ': extremal integer impossibility witness failed')
    if name == 'strict_bound_at_even_equality':
        integer_candidates = {integer_sums(elems(x, 3)) for x in range(8)}
        require(frozenset(b) not in integer_candidates, name + ': unexpected integer root')
    control_records.append({'name': name, 'n': n, 'B': list(b), 'A': list(a),
                            'ordinary_integer_sums': sorted(integer_sums(a)), 'meaning': reason})
distinct_sum = frozenset((x + y) % 5 for x in (1, 4) for y in (1, 4) if x != y)
require(distinct_sum == frozenset({0}), 'Distinct-summand control failed')
control_records.append({'name': 'diagonal_sums_omitted', 'n': 5, 'B': [0], 'A': [1, 4],
                        'meaning': 'Restricted-sum root has no zero anchor even though n odd and bound holds.'})
results['countercontrols'] = control_records
print(json.dumps({'countercontrols': control_records}, sort_keys=True))

r = (- (1 << 4096), - (1 << 4096) + (1 << 2048))
s = integer_sums(r)
n, b = reduce_integer_set(s)
t = tuple(sorted(x - min(r) for x in r))
require(exact_cyclic_sums(t, n) == b, 'Huge binary sparse witness failed')
require(sparse_verify(n, sorted(b), t), 'Huge binary sparse verifier failed')
results['huge_sparse_control'] = {'source_member_count': len(s),
    'maximum_source_signed_magnitude_bits': max(abs(x).bit_length() for x in s),
    'n_bits': n.bit_length(), 'target_member_count': len(b),
    'maximum_target_member_bits': max(x.bit_length() for x in b),
    'root_member_count': len(t), 'dense_indicator_length_exceeds_2_power': 2049,
    'exact_yes_witness_verified': True}

valid_checks = [
    sparse_verify(1, [0], [0]), sparse_verify(2, [0], [1]),
    sparse_verify(3, [], []), sparse_verify(5, [0, 1, 2], [0, 1]),
    dense_verify(1, [1], [1]), dense_verify(2, [1, 0], [0, 1]),
    dense_verify(3, [0, 0, 0], [0, 0, 0])]
require(all(valid_checks), 'Valid verifier boundary check failed')
invalid_checks = [
    sparse_verify(0, [], []), sparse_verify(-1, [], []),
    sparse_verify(3, [-1], [0]), sparse_verify(3, [3], [0]),
    sparse_verify(3, [0, 0], [0]), sparse_verify(3, [0], [0, 0]),
    sparse_verify(3, [], [0]), sparse_verify(5, [0, 1], [0, 1]),
    dense_verify(0, [], []), dense_verify(3, [1, 0], [1, 0, 0]),
    dense_verify(3, [1, 0, 0], [1, 0]), dense_verify(3, [2, 0, 0], [1, 0, 0]),
    dense_verify(3, [0, 0, 0], [1, 0, 0])]
require(not any(invalid_checks), 'Invalid verifier check unexpectedly accepted')
results['verifier_controls'] = {'valid_controls_accepted': len(valid_checks),
                                'invalid_controls_rejected': len(invalid_checks),
                                'duplicate_convention': 'canonical distinct list; reject duplicates'}
results['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
results['all_checks_passed'] = True
dest = OUT / ('FRESH_CHECKS_OPTIMIZED.json' if sys.flags.optimize else 'FRESH_CHECKS.json')
dest.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'all_checks_passed': True, 'result_file': str(dest.relative_to(OUT)),
                  'huge_sparse_control': results['huge_sparse_control'],
                  'verifier_controls': results['verifier_controls'],
                  'completed_utc': results['completed_utc']}, sort_keys=True))
