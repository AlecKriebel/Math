from pathlib import Path
from datetime import datetime, timezone
import concurrent.futures, hashlib, json, urllib.request, subprocess
root=Path(__file__).resolve().parent
sources=[
('Meilhan','https://arxiv.org/pdf/math/0402036v2'),
('MeilhanYasuhara','https://arxiv.org/pdf/0904.1527v1'),
('Nogueira2014','https://www.mat.uc.pt/preprints/ps/p1409.pdf'),
('Willerton','https://arxiv.org/pdf/math/0104061v1'),
('KauffmanLambropoulouDNA','https://homepages.math.uic.edu/~kauffman/Dresden.pdf'),
('KauffmanLambropoulouClassification','https://arxiv.org/pdf/math/0212011v2'),
('OhtsukiStanford','https://msp.org/gtm/2002/04/gtm-2002-04-024s.pdf'),
('CochranHarvey','https://math.rice.edu/~shelly/publications/arxiv_geometry_knot_conc.pdf'),
('Conant','https://arxiv.org/pdf/math/0503648v2'),
('BarNatan','https://www.math.toronto.edu/drorbn/papers/homotopy/homotopy.pdf'),
('Papakyriakopoulos','https://webhomes.maths.ed.ac.uk/~v1ranick/papers/papa.pdf')]
def fetch(s):
 name,url=s; t=datetime.now(timezone.utc).isoformat()
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=45) as response:
   body=response.read(); result={'id':name,'url':url,'resolved_url':response.geturl(),'status':response.status,'content_type':response.headers.get('Content-Type'),'utc':t,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
  if not body.startswith(b'%PDF'): raise ValueError('not a PDF')
  path=root/'raw'/f'{name}.pdf'; path.write_bytes(body)
  subprocess.run(['pdftotext','-layout',str(path),str(root/'raw'/f'{name}.txt')],check=True,capture_output=True)
  result['pdfinfo']=subprocess.run(['pdfinfo',str(path)],check=True,capture_output=True,text=True).stdout
  return result
 except Exception as e:return {'id':name,'url':url,'utc':t,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor: results=list(executor.map(fetch,sources))
(root/'SOURCE_RETRIEVAL.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results: print(r['id'],r.get('status'),r.get('bytes'),r.get('sha256'),r.get('error',''))
