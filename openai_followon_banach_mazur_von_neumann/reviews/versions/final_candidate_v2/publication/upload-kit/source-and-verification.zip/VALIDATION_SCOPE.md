# Validation scope and preparation snapshot

Preparation date: 7 October 2026. This file describes the evidence bundled
when the source supplement was prepared, rather than reporting the state
of later whole-package reviews, publication or tracker operations. Exact
subsequent frozen-version reviews, root responses and nonsecret publication
receipts are preserved separately in the project repository. A later
successful publication does not retroactively turn an earlier input audit
into a full-package review or a human referee report.

The bundled mathematical audits inspect the OpenAI family-295 manuscript
input, Roydor's complete supplied primary version and conventions, the
arbitrary-predual fixed-source proof arrangement, and the involutive
deformation calculation. Each dated report states what it actually checked.
The final-candidate addendum in the fresh 7 October priority report updates
its preserved initial verdict. Bounded literature searches do not certify
firstness or the absence of an equivalent proof.

The verification scripts use exact arithmetic on stated finite models.
They are falsification checks of mechanisms and do not establish the full
infinite-dimensional theorem. The main TeX source and clean build helper
are provided; PDF visual inspection and clean-package reproduction are
separately recorded by the root researcher. Merely constructing this ZIP
does not certify either check.

No successful fresh Lean kernel build/import or axiom interrogation was
reproduced. The argument relies on independently audited mathematical
proofs and attributed classical results. It does not claim formalization
of this follow-on theorem or verification of all classical inputs from
foundational axioms. AI tools were used extensively. Internal adversarial
AI audits are not conventional human peer review/refereeing.

No final license decision may be inferred from a proposed metadata value.
LICENSES.md and SOURCE_VERSIONS.json explicitly record the decision status.
Publication requires the actual human license choice and the required clean
fresh complete-package review of the exact intended payload and metadata.
The archive itself is not evidence of a Zenodo deposit, submitted record,
assigned DOI or tracker append.
