# Source and verification supplement

Paper: Ordinary Banach–Mazur rigidity of von Neumann algebras.
Author: Alec Kriebel; ORCID 0009-0001-9320-500X. Date: 7 October 2026.
Preparation snapshot: 7 October 2026. See VALIDATION_SCOPE.md for the scope
and timing of these preparation statements. Final complete-package reviews
and publication/tracker receipts are kept separately in the project repository.

Download paper.pdf separately from the deposit. The complete standalone
source is manuscript/main.tex, with an embedded bibliography. From this
extracted directory, using Python 3, Tectonic and Poppler on PATH:

    python3 reproducibility/build_paper.py --render

The helper copies the source to a fresh tmp/ directory, builds there, rejects
compiler errors and overfull boxes, and exports output/pdf/paper.pdf. The
tested runtime is Tectonic 0.16.9 and Poppler 26.08.0. PDF metadata timestamps
can change its byte hash; compare extracted text against the separately
downloaded reviewed PDF. Actual proof claims are justified by the written
proof and audited dependencies, not by a successful TeX build.

Read THEOREM_LEDGER.md and DEPENDENCY_LEDGER.md for exact hypotheses/scope;
APPROACHES.md for competing mechanisms and their gaps. The fresh priority
audit is research/priority_audit_20261007.md; its final-candidate addendum
updates the separately preserved initial checkpoint verdict.

The proof audits in research/ are internal AI checks of particular inputs
and mechanisms. reviews/cohomology_adversary.md is a dated mathematical
source audit of OpenAI's input, not a final-package approval. Its historical
formal-build assignment was not completed: no successful fresh Lean build
or axiom interrogation was reproduced. This follow-on is not claimed to be
formalized. A supplied upstream Lean scope document is not such a build.

Finite exact checks, Python standard library only (tested Python 3.14.6):

    python3 research/cohomology_adversary_checks.py
    python3 research/draft_whole_review_1_checks.py
    python3 research/revised_checkpoint_review_symbolic_central_homotopy/original_symbolic_check.py

These check 5,461 scalar central equations, 16 Catalan cases, 7 block cases,
260,416 noncommutative scalar equations, and 1,022 symbolic central patterns
in the stated finite degree ranges. The first two scripts write their JSON
results locally. Replay in a disposable copy when preserving archive bytes.
None is a computation of the infinite-dimensional theorem.

SOURCE_MANIFEST.json lists the size and SHA256 of every other archive member.
SOURCE_VERSIONS.json identifies pivotal primary texts; inspect those sources
independently. Unchanged OpenAI source is included under Apache-2.0 with its
README, original license and pinned hashes. Roydor/article slides and arXiv
literature PDFs, extractions and renders are not redistributed.

AI tools were used extensively in research, proof development, drafting and
verification. Internal adversarial AI review is not conventional human peer
review; the paper has not undergone conventional human refereeing. The
cohomology breakthrough, geometric and deformation machinery, and predual
reduction are attributed inherited work. The explicit fixed-source proof
assembly supplies the extension beyond the published separable-predual
theorem. No firstness, universal threshold or new cohomology proof is claimed.

Read LICENSES.md for the actual decision status and the upstream exception.
This archive makes no claim of an issued DOI or completed tracker operation.
