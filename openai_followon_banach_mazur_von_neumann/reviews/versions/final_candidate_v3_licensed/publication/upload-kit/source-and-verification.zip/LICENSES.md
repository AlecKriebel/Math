# Licenses and attribution

License status for original project material: **confirmed by the human user**.

The intended license for original manuscript, prose and verification code is
**Creative Commons Attribution 4.0 International** (cc-by-4.0): https://creativecommons.org/licenses/by/4.0/
Author: Alec Kriebel, ORCID https://orcid.org/0009-0001-9320-500X.
If the status above is proposed, no final license decision is represented and
the package is not cleared for publication.

## Unchanged upstream exception

OpenAI's family-295 manuscript, PDF, supplied README and source files, and the
Lean scope document under sources/upstream remain under Apache License 2.0.
Their exact unchanged license is sources/upstream/LICENSE. Preserve the
original OpenAI attribution and manuscript-specific citation in its README.
The project-written sources/upstream/ATTRIBUTION.md documents the pinned copy.
The proposed/selected Creative Commons license does not relicense this
third-party material. Upstream commit: adc7f1241b42e322a6451854ab7e4b4c146bf78a.

No redistribution license is inferred for Roydor's supplied publisher PDF,
the author slides, arXiv comparator PDFs, or other literature acquired during
research. Those files and their extracted text/renders are excluded; their
primary links, versions and hashes are recorded for independent inspection.
