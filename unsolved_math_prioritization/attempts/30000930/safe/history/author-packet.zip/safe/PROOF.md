# An associativity obstruction in the unweighted Springer convolution

## Result and scope

Over the complex numbers, the ordinary pullback–cup–pushforward product on the direct sum of the cohomologies of pairwise intersections of the components of the Springer fiber of Jordan type (2,2) is not associative. Consequently it cannot be isomorphic, as an algebra, to a Yoneda Ext algebra.

This applies to the unweighted natural-complex-orientation product defined on printed page 438 of the 2008 Oberwolfach report cited for OWR-1790-007. It does not refute the corrected weighted associative convolution construction in Stroppel–Webster (2012), nor settle compatibility of that construction with Yoneda multiplication. The distinction is essential. Nonassociativity of the unweighted product was already recorded by Stroppel–Webster; no novelty or first-resolution claim is made here. What follows is a self-contained small geometric witness.

All cohomology is singular cohomology with complex coefficients. Every Gysin map uses the complex orientation. We omit grading shifts while proving nonassociativity, since regrading cannot repair an associator.

## The two components

Let V have basis e1,e2,f1,f2, and define the nilpotent map N by

N(e2)=e1, N(f2)=f1, N(e1)=N(f1)=0.

Put W=ker(N)=im(N)=span(e1,f1). Let Y be the variety of full flags F1⊂F2⊂F3⊂V with dim(Fi)=i and N(Fi)⊂F(i−1), where F0=0 and F4=V. Define closed subvarieties

A={F∈Y : F2=W},
B={F∈Y : F3=N⁻¹(F1)}.

A is isomorphic to P(W)×P(V/W): its coordinates are F1 and F3/W. In particular A≅P1×P1, is smooth, and has dimension 2.

For B, choose a linear splitting V=W⊕W′ such that N:W′→W is an isomorphism. Over P(W), let L=O(−1) be the tautological line and Q=(W⊗O)/L=O(1). If F1=L, then

N⁻¹(L)/L ≅ Q⊕L ≅ O(1)⊕O(−1).

The choice of F2 between F1 and F3=N⁻¹(F1) is a line in this rank-two vector bundle. Thus, with P denoting lines,

B≅P(O(1)⊕O(−1)).

This is the Hirzebruch surface F2. Every such flag satisfies the required N-incidence conditions. B is smooth, irreducible, and two-dimensional.

These are all the irreducible components. Indeed, N(F4)=W⊂F3 and F1⊂W for every flag. If F2≠W, then F2∩W=F1, because a larger intersection would imply F2=W. The hyperplane F3 contains W, so N(F3) is a line contained in F2∩W=F1. Therefore N(F3)=F1 and F3=N⁻¹(F1). Hence Y=A∪B. Neither surface contains the other, so they are its two components. They correspond respectively to the cup diagrams (12)(34) and (14)(23).

## The intersection and its two normal bundles

The intersection C=A∩B is the smooth curve

F1=L, F2=W, F3=N⁻¹(L), for L∈P(W).

It is isomorphic to P1. In A=P(W)×P(V/W), the map induced by N identifies C with the diagonal. In B=P(Q⊕L), it is the section selecting the summand Q=O(1). These descriptions also show that the scheme-theoretic intersection is reduced: in A it is a graph, and in B it is a section given fiberwise by one linear equation.

For the diagonal in P1×P1, the normal bundle is TP1≅O(2). For the section P(Q) in P(Q⊕L), the relative tangent bundle is Hom(Q,L), and is the normal bundle of the section. Therefore

N(C/A)≅O(2),
N(C/B)≅Hom(O(1),O(−1))≅O(−2).

Let t∈H²(C;C) satisfy ∫C t=1. For the inclusions a:C→A and b:C→B, the self-intersection formula gives

a* a_*(1)=c1(N(C/A))=2t,
b* b_*(1)=c1(N(C/B))=−2t.

Here a* and b* denote pullback, while a_* and b_* denote Gysin pushforward.

## The product and the nonzero associator

Let H_XZ=H*(X∩Z;C), for X,Z∈{A,B}. Put H=⊕H_XZ. Set the product of H_XY and H_UZ to zero when Y≠U. For matching indices define

α*β=(X∩Y∩Z→X∩Z)_*(α|_(X∩Y∩Z) ∪ β|_(X∩Y∩Z)).

This is the unweighted convolution in question. Take u=1∈H_AB and v=1∈H_BA. The two copies of 1 are distinct elements of the direct sum. Then

u*v=a_*(1)∈H_AA,
v*u=b_*(1)∈H_BB.

The product with a diagonal block restricts its cohomology class to C. It follows that

(u*v)*u=2t∈H_AB,
u*(v*u)=−2t∈H_AB.

Thus

(u*v)*u−u*(v*u)=4t≠0.

This proves nonassociativity. In particular there cannot be any multiplication-preserving linear bijection from an associative algebra to H. To see this without an idempotent-preservation assumption, transport an arbitrary triple along a purported bijection; associativity in the source would imply associativity for every triple in H. The contradiction is intrinsic and unaffected by change of basis or grading shifts.

The left side of the reported conjecture, the direct-sum Ext algebra of the component half-canonical sheaves in the coherent category of the smooth resolved Slodowy slice, has associative Yoneda composition. Therefore it cannot be isomorphic to this H. The same conclusion holds even if one changes the ambient category or the chosen sheaves, provided the left-hand product is ordinary associative Yoneda composition.

## Exact coordinate model

Use cohomology generators x,y on A with x²=y²=0 and ∫A xy=1. On B let h be the pullback of t from the base, and let s be the divisor class of C. Then

H*(A)=C[x,y]/(x²,y²),
H*(B)=C[h,s]/(h²,s²+2hs),
H*(C)=C[t]/(t²).

The restriction maps and Gysin maps are

x↦t, y↦t, h↦t, s↦−2t,
a_*(1)=x+y, a_*(t)=xy,
b_*(1)=s, b_*(t)=hs.

The formulas for pushforward of t follow by integration. The formula s²=−2hs follows from the self-intersection of C, with ∫B hs=1. This specifies the entire 12-dimensional multiplication table, since diagonal products are cup products, diagonal–off-diagonal products use restriction, and two composable off-diagonal products use one of these Gysin maps.

The accompanying standard-library Python verifier checks all 12³=1728 ordered basis triples over the rationals. Only (u,v,u) and (v,u,v) have nonzero associator; their values are 4tu and −4tv. These computations verify the coordinate model; the preceding geometric argument supplies its applicability to the Springer fiber.

## A precisely bounded sign repair

Keep all cup and restriction operations fixed, but multiply the AB×BA→AA map by a scalar λA and the BA×AB→BB map by λB. Over C this modified product is associative if and only if λA+λB=0.

Necessity follows from the associator 2(λA+λB)t in H_AB. For sufficiency, classify composable triples by their four object labels. Triples with at most one off-diagonal factor reduce to cup-product associativity or the fact that restriction is a ring map. Triples with exactly two off-diagonal factors reduce either to commutativity on C or to the projection formula a_*(a*(r)α)=r a_*(α), and likewise for b. If all three factors are off-diagonal, they alternate. Their associator is their product on C multiplied by λA c1(N(C/A))−λB c1(N(C/B)), or its negative. This is zero precisely under the stated condition. Triples with mismatched indices are zero on both associations.

For λA=1, λB=−1, put p=h and q=−s−h. Then p²=q²=0, both p and q restrict to t, and the corrected pushforwards are

−b_*(1)=p+q, −b_*(t)=pq.

Together with a_*(1)=x+y and a_*(t)=xy, these are exactly the elementary multiplication/comultiplication rules of the usual two-matching arc algebra. This exhibits why changing the product evades the counterexample. It is not a proof that this repaired product equals the Yoneda product.

## General geometric obstruction

The same calculation works for two smooth compact complex surfaces meeting cleanly in a smooth compact curve C in any setting where the displayed pull–cup–push product is defined. The associator of the two off-diagonal unit classes is

c1(N(C/A))−c1(N(C/B))∈H²(C).

If A and B are Lagrangian surfaces in a holomorphic symplectic fourfold, the symplectic pairing induces N(C/A)≅N(C/B)^∨. Indeed the radical of the pairing between TA|C and TB|C is TC on both sides, and clean intersection identifies their common tangent subbundle with TC; the induced rank-one pairing is nondegenerate. In that case the obstruction is 2c1(N(C/A)). This extension is an authored consequence, not an assertion about arbitrary corrected convolutions.

## References

- C. Stroppel, joint work with B. Webster, contribution in Representation Theory of Finite Dimensional Algebras, Oberwolfach Reports 9/2008, printed pp.437–440, especially p.438 and Conjecture 8 on p.440. https://doi.org/10.4171/OWR/2008/09
- C. Stroppel and B. Webster, 2-block Springer fibers: convolution algebras and coherent sheaves, Comment. Math. Helv. 87 (2012), 477–520. Section 4.1, pp.499–500, distinguishes the weighted product from f=1; Theorem 35 gives a suitable associative product; the first paragraph of p.507 identifies the ordinary-complex-orientation product as nonassociative. https://doi.org/10.4171/CMH/261
