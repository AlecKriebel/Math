#!/usr/bin/env python3
"""Exact finite-ring check for the two-component unweighted convolution.
Standard library only. Does NOT calculate coherent-sheaf Ext or resolve
compatibility of the corrected convolution with Yoneda multiplication.
"""
import argparse, itertools, json
from fractions import Fraction as Q
from pathlib import Path

# component, monomial exponents. A: x,y; B: h,s; AB and BA: t.
BASIS = [("AA",0,0),("AA",1,0),("AA",0,1),("AA",1,1),
         ("BB",0,0),("BB",1,0),("BB",0,1),("BB",1,1),
         ("AB",0,0),("AB",1,0),("BA",0,0),("BA",1,0)]
NAMES = ["1_A","x","y","xy","1_B","h","s","hs","u","tu","v","tv"]
IDX = dict(zip(BASIS,range(12)))
DEG = [0,2,2,4,0,2,2,4,1,3,1,3]

def clean(v): return {k: c for k,c in v.items() if c}
def add(a,b,factor=1):
    c=dict(a)
    for k,v in b.items(): c[k]=c.get(k,0)+factor*v
    return clean(c)
def scale(a,c): return clean({k:v*c for k,v in a.items()})
def mono(block,i,j=0,coef=1):
    if block=="AA":
        if i>1 or j>1: return {}
    elif block=="BB":
        # h^2=0; s^2=-2hs.
        if i>1: return {}
        if j>=2: coef*=(-2)**(j-1);i+=j-1;j=1
        if i>1: return {}
    else:
        if i>1: return {}
        assert j==0
    return {IDX[block,i,j]:Q(coef)} if coef else {}
def restrict(block,i,j):
    # x|C=y|C=h|C=t; s|C=-2t.
    return i+j, (-2)**j if block=="BB" else 1

def basis_product(ii,jj,a=Q(1),b=Q(1)):
    X,i,j=BASIS[ii];Y,k,l=BASIS[jj]
    if X[1]!=Y[0]:return {}
    Z=X[0]+Y[1]
    xd=X[0]==X[1];yd=Y[0]==Y[1]
    if xd and yd:return mono(Z,i+k,j+l)
    if xd:
        d,c=restrict(X,i,j);return mono(Z,d+k,coef=c)
    if yd:
        d,c=restrict(Y,k,l);return mono(Z,i+d,coef=c)
    degree=i+k
    if degree>1:return {}
    if Z=="AA":
        return scale(add(mono("AA",1,0),mono("AA",0,1)),a) if degree==0 else mono("AA",1,1,coef=a)
    return mono("BB",0,1,coef=b) if degree==0 else mono("BB",1,1,coef=b)

def mult(v,w,a=Q(1),b=Q(1)):
    z={}
    for i,c in v.items():
        for j,d in w.items(): z=add(z,scale(basis_product(i,j,a,b),c*d))
    return z

def fmt(v):return {NAMES[i]:int(c) if c.denominator==1 else str(c) for i,c in sorted(v.items())}
def inspect(a,b,mod=None):
    U=[{i:Q(1)} for i in range(12)];defects=[]
    for i,j,k in itertools.product(range(12),repeat=3):
        d=add(mult(mult(U[i],U[j],a,b),U[k],a,b),mult(U[i],mult(U[j],U[k],a,b),a,b),-1)
        if mod:d={i:c for i,c in d.items() if c.numerator%mod}
        if d:defects.append({"triple":[NAMES[i],NAMES[j],NAMES[k]],"associator":fmt(d)})
    unit={0:Q(1),4:Q(1)}
    assert all(mult(unit,v,a,b)==v==mult(v,unit,a,b) for v in U)
    for i,j in itertools.product(range(12),repeat=2):
        assert all(DEG[z]==DEG[i]+DEG[j] for z in basis_product(i,j,a,b))
    return {"basis_triples_checked":12**3,"defect_count":len(defects),"defects":defects,"unit_verified":True,"codimension_shift_grading_verified":True}

def arc_coordinate_checks():
    # Sign corrected B block: p=h, q=-s-h. Both square to zero and
    # p+q=-s, pq=-hs, exactly the Frobenius comultiplication outputs.
    p={5:Q(1)};q={6:Q(-1),5:Q(-1)}
    assert not mult(p,p) and not mult(q,q)
    assert add(p,q)=={6:Q(-1)}
    assert mult(p,q)=={7:Q(-1)}
    def restriction_vector(v):
        out={}
        for idx,c in v.items():
            block,i,j=BASIS[idx];degree,coef=restrict(block,i,j)
            if degree<2:out[degree]=out.get(degree,0)+c*coef
        return clean(out)
    assert restriction_vector(p)=={1:Q(1)}
    assert restriction_vector(q)=={1:Q(1)}
    return {"p_squared":0,"q_squared":0,"p_plus_q":"-s","p_times_q":"-hs","p_restricts_to":"t","q_restricts_to":"t"}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);args=ap.parse_args()
    raw=inspect(Q(1),Q(1));corrected=inspect(Q(1),Q(-1));zero=inspect(Q(0),Q(0));char2=inspect(Q(1),Q(1),2)
    assert raw['defects']==[
      {'triple':['u','v','u'],'associator':{'tu':4}},
      {'triple':['v','u','v'],'associator':{'tv':-4}}]
    assert corrected['defect_count']==zero['defect_count']==char2['defect_count']==0
    grid=[]
    for a,b in itertools.product(range(-2,3),repeat=2):
        r=inspect(Q(a),Q(b)); assert (r['defect_count']==0)==(a+b==0)
        grid.append({'a':a,'b':b,'associative':r['defect_count']==0})
    report={'status':'PASS','exact_arithmetic':'fractions.Fraction over Q',
      'basis':NAMES,'natural_complex_convolution':raw,'opposite_sign_repair':corrected,
      'zero_off_diagonal_pairing':zero,'natural_product_mod_2':char2,
      'integer_weight_grid':grid,'arc_coordinate_checks':arc_coordinate_checks(),
      'scope':'Checks the authored 12-dimensional cohomological multiplication model. Not a computation of Ext products.'}
    out=json.dumps(report,indent=2,sort_keys=True)+'\n'
    if args.output:args.output.write_text(out)
    print(out)
if __name__=='__main__':main()
