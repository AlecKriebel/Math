# What remains valid after distinguishing the products

The obstruction in PROOF.md rules out the unweighted natural-complex-orientation product. It does not by itself determine the coherent-sheaf Yoneda multiplication.

For a single cup (k=1), the Springer fiber is P1 and the resolved slice is T*P1. Its half-canonical sheaf is O_P1(−1), pushed forward from the zero section. A local Koszul resolution of that regular divisor gives sheaf Ext in degrees 0 and 1, respectively O_P1 and O_P1(−2). Their cohomology is C in bidegrees (0,0) and (1,1), and zero otherwise. Hence global self-Ext is C in degrees 0 and 2 and zero in every other degree. The identity is its unit, and a degree-2 generator has square zero because Ext^4 vanishes. Therefore the Yoneda ring is C[z]/(z²), deg z=2. The one-component convolution is simply cup product on P1 and agrees as a graded algebra. This small case cannot decide the mixed-component problem.

For k=2, the graded-vector-space shape of the sum is already compatible with both the nonassociative natural product and the associative sign repair:

- Each diagonal block has Hilbert polynomial 1+2q²+q⁴.
- Each off-diagonal block has Hilbert polynomial q+q³.
- The total Hilbert polynomial is 2+2q+4q²+2q³+2q⁴, of dimension 12.

Consequently dimensions, parity, and the self-Ext rings alone cannot distinguish the candidate products. The exact checker verifies this grading for both table variants. This is a concrete explanation of why the existing vector-space calculation does not prove an algebra isomorphism.

The final Stroppel–Webster paper proves the pairwise graded-vector-space identification in Theorem 40 and the individual diagonal ring identification in Theorem 45; it still formulates the full multiplication comparison as Conjecture 42. Its Section 5 uses the smooth resolved slice, with the half-canonical sheaves obtained from cup functors, in the non-equivariant coherent category. These qualifications are part of the comparison.

A more recent relevant result is B. Mladenov, Formality of differential graded algebras and complex Lagrangian submanifolds, Selecta Mathematica 30 (2024), article 8, https://doi.org/10.1007/s00029-023-00894-3. Theorems 0.1.8 and 0.1.12 establish formality for a single compact Kähler spin Lagrangian and a corresponding pairwise module, respectively. They do not assert simultaneous compatibility of every mixed composition in a collection. The paper explicitly separates the collection-level formality question. Thus these results cannot simply be relabeled as a solution of the full crossingless-matching algebra comparison.

No claim of current global openness is proved by a bounded literature search; the precise conclusion is that no resolution of the corrected full Yoneda-product comparison was verified in this investigation.
