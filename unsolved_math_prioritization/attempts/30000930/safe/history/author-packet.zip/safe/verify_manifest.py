#!/usr/bin/env python3
"""Verify every frozen safe-packet file and reject unexpected additions."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST.json').read_text())
expected={x['path']:x for x in m['files']}
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
assert actual==set(expected), {'missing':sorted(set(expected)-actual),'extra':sorted(actual-set(expected))}
for name,e in expected.items():
    p=Path(name)
    assert not p.is_absolute() and '..' not in p.parts
    b=(root/p).read_bytes()
    assert len(b)==e['bytes'],name
    assert hashlib.sha256(b).hexdigest()==e['sha256'],name
print(json.dumps({'status':'PASS','files':len(expected)},sort_keys=True))
