# Research record

## Readiness and duplicate gate

The live default-branch queue was read on 2026-10-04: rank 661, problem 30000930 / OWR-1790-007, title Ext-Algebra Models for Crossingless Matchings, queued, 0/5. The public state file has no target ID. Target-ID branch search and target-ID/title/code pull-request searches returned no results; the target attempt-directory read returned 404. The related-target-group file has no ID/code/title hit. A continuity search found no actual target-specific earlier user attempt. These are bounded negative checks, not a universal absence theorem.

The problem webpage could not be fetched. Its catalogue identity was recovered from an existing local catalogue; no catalogue text is redistributed. The mathematical statement was then checked against the official report, not trusted merely because the catalogue labeled it verified.

## Substantive approach 1 and early stopping

The investigation began by comparing the product in the 2008 report with the final primary article. The report uses unweighted pull–cup–push convolution. The final article inserts a cohomology class f on ordered triple intersections and explicitly distinguishes the nonassociative f=1 case. That source distinction invalidates a direct import of the old unweighted statement into the corrected setting.

An explicit geometric calculation was then completed for Jordan type (2,2). The two components are P1×P1 and F2; their common P1 has normal bundles O(2) and O(−2). The self-intersection formula produces the associator 4t. This gives a complete refutation of the literal unweighted claim. It also verifies that the source's published warning is mathematically operative, rather than a terminology issue.

No additional proof-attempt turns were charged: the assignment allows early stopping after a full rigorous resolution or a verified prior result. Both apply to the literal unweighted formulation, while the repaired conjecture is a distinct retained open comparison. The following checks are supporting work within this single substantive approach; they are not padded into five allegedly independent attempts.

## Supporting mathematical checks

1. A full 12-dimensional ring model was derived from the geometry and checked on all 1728 ordered basis triples with exact rational arithmetic. This reproduces exactly two nonzero basis associators.
2. A two-parameter modification of the mixed Gysin maps was analyzed symbolically. Associativity is equivalent to λA+λB=0 over C. The nondegenerate opposite-sign choice has the ordinary two-matching arc multiplication after an explicit change of coordinates. This establishes the limit of the counterexample.
3. A normal-bundle formula was proved for the same associator for any cleanly intersecting pair of smooth surfaces. The holomorphic symplectic Lagrangian case gives dual normal bundles.
4. The k=1 coherent-sheaf Yoneda algebra was derived directly using a divisor Koszul resolution. Its agreement with cup product illustrates that a single-component calculation cannot settle mixed compositions.
5. The later single-Lagrangian and pairwise-module formality results were inspected. They do not supply the missing collection-wide composition comparison. No full solution of the corrected conjecture was verified.

## Disposition

Source-formulation correction / known obstruction, with an explicit authored proof and reproducible exact test. Do not advertise a new resolution of the corrected Ext/arc-algebra problem. Any public record should preserve this qualified disposition and identify which multiplication is meant. No remote write was made, and fresh uninvolved audit remains required.
