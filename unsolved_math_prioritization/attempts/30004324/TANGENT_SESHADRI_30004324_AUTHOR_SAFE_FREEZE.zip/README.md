# Problem 30004324: tangent-bundle Seshadri characterization

Author freeze prepared 2026-10-05. Status: candidate complete proof, pending fresh independent mathematical audit. No remote publication has been performed by the author worker.

Target: OWR-17296-007, the one-point Fulger--Murayama conjecture for smooth projective varieties over algebraically closed fields of arbitrary characteristic.

The central deliverable is `candidate_proof.md`: a pointed minimal-degree rational-curve family is compactified by stable maps; degree minimality excludes all boundary; very freeness makes its evaluation cover X; its contracted marking section forces numerical Picard rank one; this yields Fano and invokes the already proved Fano case.

The source record, status distinctions, unsuccessful shortcut, explicit controls, and reproducibility files are separate. A claimed general proof must not be presented as established before the independent audit. No historical novelty or human peer review is claimed.

Run with Python 3 standard library only:

    python3 checks.py
    python3 verify_manifest.py
    python3 test_integrity.py

The tests check finite algebraic/combinatorial controls and package integrity, not algebraic geometry or theorem dependencies. Source documents and extracted text are deliberately excluded.
