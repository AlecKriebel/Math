# A pointed minimal-rational-curve route to the tangent-Seshadri conjecture

Author candidate, 2026-10-05. Not yet independently audited. This is an AI-assisted mathematical argument, not a published or refereed resolution. Historical novelty is not established.

## Exact target

Let X be a smooth integral projective variety of dimension n >= 1 over an algebraically closed field k of arbitrary characteristic. Suppose that a closed point x in X satisfies epsilon(T_X;x) > 0, in the relative vector-bundle sense of Fulger--Murayama. The proposed conclusion is X isomorphic over k to P^n.

The conjecture is [FM21, Conjecture 4.9], corresponding to [FM19v2, Conjecture 5.9] and Fulger's contribution to OWR 53/2019, printed p. 3289. No Fano, nef-tangent, general-point, or characteristic-zero hypothesis is added.

## Dependencies (precise uses)

1. [FM21, Corollary 3.21 and Example 3.20]: the normalized-curve formula for vector-bundle Seshadri constants. On P^1 its slope invariant is the least splitting degree, in every characteristic.
2. [FM21, Corollary 4.6]: the positivity hypothesis implies X is uniruled (indeed separably rationally connected). Its proof explicitly also supplies a rational curve through x. Only existence of such a curve is required below. An alternative from uniruledness is to take a dominating family of rational curves of fixed ample degree, compactify it by stable maps, and specialize the marked evaluation to x; a component reached through the contracted subtree carrying the mark is a rational curve through x.
3. [AO, Theorem 2.8 and Section 2.5]: for a projective embedding X in P^N over k, the stack of one-pointed stable maps of genus zero and fixed embedding degree d is a proper Artin stack with finite stabilizers and projective coarse moduli scheme. This formulation holds in arbitrary characteristic; do not assume the whole stack is Deligne--Mumford in positive characteristic.
4. Standard deformation theory of maps from a smooth curve: obstructions to deforming f while fixing its value at distinct points 0 and infinity lie in H^1(P^1,f^*T_X(-0-infinity)); if this group vanishes, evaluation at infinity from the scheme of maps taking 0 to x is smooth at f. This can also be checked directly by the usual Cech lifting argument on the domain. There is no appeal to characteristic-zero generic smoothness.
5. Cohomology and base change for a proper smooth family of genus-zero curves: a line bundle trivial on every geometric fiber is the pullback of its pushforward, which is a line bundle. A section trivializing its pullback then trivializes that line bundle on the base.
6. Ampleness is invariant under numerical equivalence of divisors on a projective variety.
7. [FM21, Proposition 4.8(1)]: a smooth Fano variety over an algebraically closed field, in any characteristic, with epsilon(T_X;x)>0 at some point is P^n. Its cited input is Mori's theorem as [Kollar, Rational Curves on Algebraic Varieties, V.3.2]. This final reduction is not an application of the conjecture itself.

## Lemma 1: every rational curve through x is very free

Let C be an integral rational curve through x and let f:P^1 -> C -> X be its normalization. Put m=mult_x C. Write f^*T_X = direct_sum_i O(a_i). In positive characteristic, Frobenius multiplies every a_i by p, so the asymptotic normalized minimal slope is min_i a_i, just as in characteristic zero. The curve formula gives

min_i a_i >= m epsilon(T_X;x) > 0.

Thus every a_i is a positive integer and f is very free. In particular, -K_X.C=sum_i a_i>0. This uses normalizations of images, so no nonzero differential is being asserted for a purely inseparable multiple cover.

For a normalization, the differential is generically nonzero, hence a nonzero homomorphism O(2)->f^*T_X exists and some a_i>=2. Consequently -K_X.C>=n+1. The stronger bound is a useful control but is not needed for the Fano reduction below.

## Lemma 2: minimal ample degree eliminates every pointed boundary

Choose a very ample line bundle A on X. By dependency 2 there is an integral rational curve through x. Define

d=min{A.C : C is an integral rational curve through x}.

This is a positive integer and is attained. Consider any geometric stable map

(g:D -> X, p), with genus(D)=0, g(p)=x, deg(g^*A)=d.

The dual graph of D is a tree, and each component is P^1. Starting with the component carrying p, follow components contracted to x until reaching a nonconstant component D_v. Such a component exists since d>0. Its image C_v is an integral rational curve through x. If its mapping degree onto its image is e_v, then

d = sum_{w nonconstant} e_w(A.C_w) >= e_v(A.C_v) >= A.C_v >= d.

All summands are positive integers. Hence all inequalities are equalities: D_v is the unique nonconstant component, e_v=1, and A.C_v=d.

There cannot be any contracted component. Indeed each connected contracted subtree attaches to the sole nonconstant vertex by exactly one edge because the whole dual graph is a tree. If it has t>0 vertices and contains m marked points, then m<=1 and its total number of special points, counting incidences at nodes and marks, is

2(t-1)+1+m <= 2t.

Stability would require at least 3t special points. This is impossible. Thus D=P^1 is irreducible and smooth, and g is birational onto its image.

This argument includes a mark initially lying on a contracted component and includes possible inseparable covers. The latter have e_v>1 and are excluded by the degree equality.

## Lemma 3: a proper pointed family with universal P^1-curve exists

Let M_x be the fiber over x of the evaluation morphism from the proper stable-map stack in dependency 3, with genus zero, one mark, and A-degree d. It is proper and nonempty. Lemma 2 shows that every geometric object has smooth domain P^1 and is birational onto its image.

Such an object has trivial automorphism group scheme. An automorphism preserving the map is the identity on the open set where the map is an isomorphism onto its image. The same assertion infinitesimally follows because its vector field lies in the kernel of the generically injective differential of a birational normalization map. Therefore it vanishes. Thus there is no hidden nonreduced stabilizer in positive characteristic.

For clarity, take the reduced structure and then an irreducible component H of M_x containing a chosen normalization f:P^1->X of a degree-d rational curve through x with marked preimage 0. A stack with trivial inertia is an algebraic space; here it agrees with its projective coarse moduli space. Hence H is a proper projective scheme. The universal curve restricts to a smooth proper family

pi:U -> H

with every geometric fiber P^1, a marking section sigma:H->U, and evaluation e:U->X. We have e composed with sigma identically x. All fibers have A-degree d. Degrees of every line bundle pulled back from X are constant on the connected base H. One may equivalently use the normalized pointed RatCurves construction; the stable-map argument was chosen to make the boundary explicit.

## Lemma 4: the universal evaluation covers X

By Lemma 1, f^*T_X splits with all a_i>=1. Therefore

H^1(P^1, f^*T_X(-0-infinity))=direct_sum_i H^1(P^1,O(a_i-2))=0.

By dependency 4, evaluation at infinity on Hom(P^1,X;0 maps to x) is smooth at f. Also H^1(P^1,f^*T_X(-0))=0, so this pointed Hom scheme is smooth at f and has a unique local irreducible component there. Quotienting locally by Aut(P^1,0) maps that local component to the unique local component of M_x through [f,0], which is H. Equivalently, nearby pointed maps and the point infinity define points of U over H. The smooth evaluation supplies an open neighborhood of f(infinity) in the image of e.

Since H and U are proper, e(U) is closed in X. Since X is irreducible and the image contains a nonempty open subset, e(U)=X. This step uses smoothness at the chosen very free map, not generic smoothness of an arbitrary evaluation morphism.

## Lemma 5: the contracted section forces numerical Picard rank one

Let D be any Cartier divisor on X and let b=D.C, where C is the image of any fiber of U->H. Its value is constant by connectedness. Consider the line bundle

L=O_X(dD) tensor A^(-b).

It has degree zero on every fiber image. Thus e^*L restricts to O_{P^1} on every geometric fiber of pi. By dependency 5, e^*L=pi^*B for a line bundle B on H. Pull back by sigma. Because e composed with sigma is the constant map to x, sigma^*e^*L is a trivial line bundle. Hence B is trivial, and e^*L is trivial.

A line bundle whose pullback by a surjective proper morphism of projective varieties is numerically trivial is numerically trivial. Here is the curve argument, including positive characteristic: for any integral curve Gamma in X, choose a component of e^(-1)(Gamma) dominating Gamma, and cut by sufficiently many general hyperplanes to obtain an integral complete curve Gamma' mapping onto Gamma with finite generic degree q>0. The projection formula gives

0=deg(e^*L|Gamma')=q deg(L|Gamma),

so deg(L|Gamma)=0. Thus

d[D] = b[A] in N^1(X)_R.

Every divisor class is proportional to [A], so rho(X)=1.

The argument uses an actual marking section. Merely having a proper unpointed family would not justify it.

## Fano reduction and conclusion

Apply Lemma 5 with D=-K_X. By Lemma 1, b=-K_X.C>0. Therefore

[-K_X]=(b/d)[A], where b/d>0.

So -K_X is ample by numerical invariance of ampleness. X is Fano. Dependency 7 then gives X isomorphic to P^n.

This completes the proposed argument for every n>=1 and every characteristic. For n=1 one can instead use epsilon(T_X;x)=deg(T_X)=2-2g, so positivity forces g=0. Dimension zero is harmless if included by convention: a smooth integral projective zero-fold over k is already P^0.

## Author's verification boundary

No internal gap is currently asserted in this proposed proof. Its acceptance nevertheless depends on fresh independent scrutiny. In particular the reviewer should challenge: (a) minimal A-degree across all rational images through x; (b) the contracted-mark boundary analysis; (c) trivial inertia and existence of the universal family in positive characteristic; (d) smooth evaluation on the correct component; and (e) descent of a fiberwise degree-zero line bundle using the contracted section.

The retrieved 2025 toric paper still presents the unrestricted assertion as a conjecture. That makes a short general proof a reason for unusually careful review, not a reason to assert priority or quietly add hypotheses. The finite checks elsewhere in this packet cannot verify any of dependencies 1--7 or the geometric assertions of these lemmas.
