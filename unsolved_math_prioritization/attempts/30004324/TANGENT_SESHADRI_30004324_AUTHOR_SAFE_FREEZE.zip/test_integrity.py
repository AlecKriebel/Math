#!/usr/bin/env python3
"""Isolated negative controls. Does not mutate the frozen source packet."""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
src=Path(__file__).resolve().parent

def run(root):
    return subprocess.run([sys.executable,str(root/'verify_manifest.py'),str(root)],
                          capture_output=True).returncode==0

cases=[]
for case in ['clean','edit','truncate','delete','extra','symlink','manifest_size','manifest_hash','duplicate_entry','traversal_entry']:
    with tempfile.TemporaryDirectory() as d:
        dst=Path(d)/'packet';shutil.copytree(src,dst)
        target=dst/'controls.md'
        if case=='edit':target.write_bytes(target.read_bytes()+b'changed')
        elif case=='truncate':target.write_bytes(b'')
        elif case=='delete':target.unlink()
        elif case=='extra':(dst/'extra.txt').write_text('extra')
        elif case=='symlink':target.unlink();target.symlink_to(src/'controls.md')
        elif case.startswith('manifest_') or case in ['duplicate_entry','traversal_entry']:
            m=json.loads((dst/'MANIFEST.json').read_text())
            if case=='manifest_size':m['files'][0]['bytes']+=1
            elif case=='manifest_hash':m['files'][0]['sha256']='0'*64
            elif case=='duplicate_entry':m['files'].append(m['files'][0].copy())
            elif case=='traversal_entry':m['files'][0]['path']='../outside'
            (dst/'MANIFEST.json').write_text(json.dumps(m))
        passed=run(dst)
        if passed != (case=='clean'):
            raise AssertionError(case)
        cases.append({'case':case,'accepted':passed})
print(json.dumps({'status':'pass','cases':cases},indent=2,sort_keys=True))
