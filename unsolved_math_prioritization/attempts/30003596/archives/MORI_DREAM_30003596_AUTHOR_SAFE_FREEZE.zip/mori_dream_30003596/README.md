# Mori dream spaces and global Newton–Okounkov cones

Problem 30003596 / OWR-15586-007. Investigation dated 2026-10-06.

**Result: bounded mathematical audit; the exact existence question is not resolved by this investigation.** A prior affirmative announcement exists in the cited Oberwolfach report and in Postinghel–Urbinati, arXiv:1612.03861v4. This report does not certify that announcement as a proof of the exact admissible-flag-on-X statement. It also does not claim that the announcement's conclusion is false or that the literature definitively regards the question as open.

The deliverable contains:

- `MATHEMATICAL_AUDIT.md`: an explicit projection/restriction counterexample, an exact birational descent criterion, and a rational-polyhedral example with a non-finitely-generated value semigroup.
- `APPROACHES.md`: five bounded approaches and their stopping points.
- `STATUS.json`: machine-readable scope and outcome.
- `SOURCES.json`: public bibliographic and retrieval metadata.

The mathematical examples are authored here as explanatory proofs. No novelty is claimed. There is no executable checker in this package; its mathematical claims require proof review. No copied source document, source extract, image, or dataset is included.
