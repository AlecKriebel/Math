K2P DISPLAYED-TREE AUDIT
Prepared for Samuel Martin — 13 August 2026

This compact package provides an exact replay of the source-convention and
displayed-tree checks for the simple Q(sqrt(71)) K2P tree–theta-trinet
collision. It is limited to an exact rational five-coordinate 3-sunlet
convention test, the four-switching graph calculation, and an independent
ordinary-state Markov-pruning check; it does not include the broader paper.

RUN

From this directory, run:

    python3 verify_k2p_displayed_trees.py

Only the Python standard library is required. The verifier reads
certificate_k2p_simple.json from this directory and uses exact arithmetic
throughout. Successful output includes:

    [source convention] PASS  descendant-label rule reproduces all five explicit 3-sunlet coordinates of Lemma 4.1

Its final line is:

    ALL DISPLAYED-TREE CHECKS PASSED

CONTENTS

README.txt
    This guide.

verify_k2p_displayed_trees.py
    First derives five exact rational coordinates from the two retained-edge
    graphs of a 3-sunlet and compares them with the formulas printed in Lemma
    4.1. It then reconstructs the four displayed trees from the certified
    rooted graph, derives their Fourier monomials, materializes the exact K2P
    transition matrices, and compares all 64 network and comparison-tree
    probabilities.

certificate_k2p_simple.json
    Exact graph, parameter, factorization, and comparison-tree data.

verification_report_displayed_trees.txt
    Saved transcript from the verifier and certificate included here.

SHA256SUMS
    SHA-256 checksums for the four files above. This checksum file does not
    list itself.

INTEGRITY CHECK

On macOS:

    shasum -a 256 -c SHA256SUMS

On Linux:

    sha256sum -c SHA256SUMS
