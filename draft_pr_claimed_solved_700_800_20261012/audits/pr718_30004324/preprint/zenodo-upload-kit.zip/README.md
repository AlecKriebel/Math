Upload paper.pdf and source-and-verification.zip separately using the enclosed metadata. The outer ZIP is a convenience kit, not an extra deposit file.
