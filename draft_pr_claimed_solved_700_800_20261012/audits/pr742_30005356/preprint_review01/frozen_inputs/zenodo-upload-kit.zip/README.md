Upload paper.pdf and source-and-verification.zip separately with the exact enclosed metadata. The outer ZIP is a convenience kit, not an extra deposit file.
