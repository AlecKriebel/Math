Upload only paper.pdf and source-and-verification.zip with the exact enclosed metadata. This outer ZIP is a convenience kit. See the source README for scope, credits, review limits and verification.
