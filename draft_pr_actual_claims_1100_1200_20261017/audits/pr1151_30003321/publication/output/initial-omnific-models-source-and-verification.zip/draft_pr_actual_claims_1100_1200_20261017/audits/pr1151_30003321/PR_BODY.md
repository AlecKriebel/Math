## Full affirmative additive-group result

Every discrete initial ordered additive subgroup of the surreal numbers No is order-group-isomorphic onto an initial subgroup of the omnific integers Oz. The statement covers sets and proper classes in NBG with global choice, including the trivial group. Initiality refers to sign-sequence prefixes. Multiplicative closure and preservation of the original simplicity order are not required. The known discrete initial subdomain theorem is not being substituted for this group result.

The complete proof obtains a minimum exponent -alpha and bottom coefficient group 2^(-n) Z from discreteness. A transfinite sign rotation moves the minimum to zero without creating right-predecessor obligations; scaling the bottom coefficient group gives Z. The canonical Hahn-image characterization then gives initiality, and the Oz normal-form criterion gives containment.

The independent internal AI audit accepts the full stated argument without a mathematical correction. Its complete explicit inverse, all prefix and cross-branch cases, empty tails, arbitrary limit ordinals and successors, canonical Hahn-characterization hypotheses, bottom-unit-monomial normalization, and proper-class bookkeeping are retained. The construction transports only source series and does not silently complete the group to a full Hahn product.

The imported source results are from Philip Ehrlich and Elliot Kaplan, [Number systems with simplicity hierarchies: a generalization of Conway’s theory of surreal numbers II](https://doi.org/10.1017/jsl.2017.9), JSL 83 (2018), 617–633. The target is Question 9.1 in the [authenticated author manuscript](https://elliotakaplan.github.io/Number_systems_with_simplicity_hierarchies_II.pdf) and Question 1 in the Kaplan–Ehrlich contribution to [Oberwolfach Report 60/2016](https://ems.press/content/serial-article-files/46663). Source dependencies were checked against that author manuscript, not a byte-authenticated publisher PDF. Public metadata retain the source hashes, byte counts, retrieval and inspection history, and precise source-version qualifications.

This AI-assisted proof and independent internal AI audit are unrefereed. Acceptance is not external human peer review, journal acceptance, or formal proof-assistant certification. No novelty, exhaustive priority, current open-status certification, or result about the adjacent dense-group set-model question is claimed. Diagnostic tests do not replace the proof for arbitrary ordinals, set supports and proper classes.

The original reviewed inputs remain unchanged. Explicit editorial differences update awaiting-review language, add internal-AI/unrefereed framing, and remove nonpublic accounting and coordination details. The complete mathematical proof and substantive audit are preserved. Preparation authenticates the documents without claiming fresh source retrieval or additional source inspection.

This addition-only draft contains eight authored proof, audit, acceptance and permitted public citation/verification files. No copied sources, dataset contents, executable code, raw outputs, private history or coordination are included. QUEUE.md and every unrelated path remain unchanged.

## Exact public-file identities

- `ACCEPTANCE.json`: 2,973 bytes; SHA-256 `27ac22b87eb318a704c3f23bf7c73fb743c212418c0297500d8341314186e7ad`.
- `ACCEPTANCE.md`: 5,119 bytes; SHA-256 `4d7c30dc127af967466e9fa36802390ba83cb50cfe88d2b5fc0d2b3dfe84785d`.
- `AUDIT_REPORT.md`: 14,613 bytes; SHA-256 `5f1e634a2201bd576a7a29607d0b18b6ea741f8f0cb7cea81e7d82e5354f0c46`.
- `MANIFEST.json`: 1,542 bytes; SHA-256 `c9f59dee7df68170b107c32c1e7dfa74fe1ab25c3e950912ecab64fd01be1a93`.
- `PROOF.md`: 11,530 bytes; SHA-256 `3eb600a03878d62c9e2e6f4b6c641af169bb4551fec699c63932ca980bfedf2e`.
- `README.md`: 3,413 bytes; SHA-256 `82de2f08124965e48d62880fd67f7da68d7bf2f39f58165a8d5f44e763eabe36`.
- `SOURCE_METADATA.json`: 4,039 bytes; SHA-256 `81c7f28c2a3b56c0f70bbb72b1d63effbf0786a8b15013c813d8ed5d58456a07`.
- `VERIFICATION_SUMMARY.md`: 3,247 bytes; SHA-256 `28b3c4c9c443d82d50f43f18c1faa858409098ae188a34fd9d4f8eb06eccbd76`.

MANIFEST.json lists the eight members and hashes the other seven. Its separate identity above avoids self-reference.

