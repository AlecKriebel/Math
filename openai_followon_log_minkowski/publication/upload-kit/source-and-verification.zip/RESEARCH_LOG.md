# Smooth even log-Minkowski and Lp-Minkowski research log

All dates below use America/Los_Angeles unless explicitly marked UTC. Percentages are planning estimates, not evidence. No external individuals may be contacted. The upstream clone is read-only. Only owned project files may be published, on remote main, without a GitHub release.

## 2026-10-06 21:11 PDT — Initial checkpoint

Mathematical resolution: **5%**. Publication package: **0%**.

Created the dedicated effort after confirming it did not exist. Read workspace AGENTS.md, exact triage section 1 and both geometry notes, upstream README, manuscript README, exact volume theorem and variance route, Lean scope 091 and comparator. Upstream working HEAD is the requested pin `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Triage is a hypothesis and has no foundational certification.

Shared checkout is on main with large concurrent uncommitted work. Checkpoints will use an isolated index based on the latest remote main; shared checkout, index, and local main will be preserved. No unrelated PRs or queue records will be processed.

Independent agents assigned: upstream analytic proof/semantic audit; smooth He–Liu theorem and actual proof; nonsmooth mixed-volume/Jensen strictness; priority/companion-source audit; exact Lean build and assumptions in pinned project-local copy; external moment/regularity dependencies. Independence was preserved by giving original targets and primary sources.

Strongest verified result at this checkpoint: the endpoint p=0 must exclude singular measures. Equal-volume coordinate boxes give identical cone-volume measures. No all-dimensional unconditional target is yet certified.

Early findings awaiting root verification: He–Liu has sphere-dimension convention changes and omissions in its p>0 second-derivative algebra, but corrected extrema argument appears to survive. The nonsmooth p>0 route avoids any need for full support of the surface-area measure by classical mixed-volume equality. Actual upstream Lean declaration is distinct from the comparator's intentional sorry; no claim of a reproduced build has been made.

## 2026-10-06 21:14 PDT — Checkpoint publication correction

Mathematical resolution: **20%**. Publication package: **3%**.

Initial isolated-index push was commit 77dc822812677450ac4facca9b9b42515f992697. The broad project staging unintentionally included agents' downloaded third-party reference files before redistribution licensing review. Added explicit exclusions and removed those files from the current public tree; local evidence remains preserved. The historical commit is not rewritten or force-pushed. Final Zenodo package will contain owned work and references only. Subsequent checkpoint publishing enforces this exclusion.

The smooth transfer can use a short local geometric-support path with positive curvature, eliminating any need to assert smoothness of every global Wulff interpolation. Detailed existence attribution needs symmetry-preserving generalized existence plus established interior regularity; He–Liu's abbreviated attribution alone is not sufficient. No all-dimensional unconditional target certified yet.

## 2026-10-06 21:19 PDT — Complete proof candidate

Mathematical resolution: **85%**. Publication package: **40%**.

Independent manual upstream proof and moment-dependency audits found no material mathematical gap. Root read the needed proof sections and independently checked the follow-on derivations; exact trace identity, nonsmooth Wulff variation, equality recovery, existence regularity, all boundary constants and n=2 checks are recorded in research/ROOT_VALIDATION.md. Six independent route reports are complete. Pinned-source inventory has 23 byte-verified inputs. The source remains fixed; read-only correction checks found no later commit.

Standalone main.tex now contains both core results with precise positive-support/positive-curvature hypotheses, inherited existence and reductions, and a self-contained endpoint and all-body strictness proof. The native editor compiler succeeded. Actual exported PDF build produced two overfull boxes, which were repaired; latest compilation/render inspection pending. The manuscript frames a consequence and acknowledges Stancu2018. Entire Stancu2022 full text could not be accessed, and no claim about its ultimate implication or firstness is made.

Lean v4.34.1 installed, source semantics and dependency pins inspected, but theorem build/axiom extraction could not run under severe disk pressure. A verification agent inadvertently terminated a concurrent routine dependency download while attempting orphan cleanup; no concurrent files were edited or deleted. The exact incident is recorded in its audit. No further process outside known tool-owned sessions is stopped. Manual analytic verification is the basis, and no reproduced formal certification is claimed.

An invoked CLI instruction generator ignored a help flag and wrote new instruction files under the workspace root. Birth timestamps confirmed they were newly generated by this invocation; all were moved into the ignored dedicated project research directory. No pre-existing tracked file was removed. The final upload will include no generated instruction bundle or third-party sources.

Strongest verified result: complete mathematical theorem chain for T1/T2 relative to established published existence/regularity and the manually audited new log-BM proof. Pending: independent complete-package adversarial reviews, final clean reproduction and visual QA, then authorized production deposit and tracker update. No Zenodo draft or publication exists for this effort at this checkpoint.

## 2026-10-06 21:28 PDT — First complete review and global repair

Mathematical resolution: **95%**. Publication package: **70%**.

Review 01 completed the exact original full package: all five PDF pages, every archive payload hash, 23 upstream hashes, 650 exact algebra cases and boundary checks, clean extracted-source compilation, metadata and attribution. Its report records no substantive blocker. Two precision findings were corrected: the priority report no longer attributes full-range positive smooth existence to Chou–Wang Theorem D alone, and archive-reconstruction instructions distinguish the full author workspace from the extracted public source ZIP.

Independent review 02 identified an overbroad regularity sentence. Bounded positive local Monge–Ampère density alone does not imply chart strict convexity. The manuscript now explicitly invokes BBC Theorem 1.1(i): origin interior gives normal cone `{0}` and an empty exceptional set, hence a C1 boundary and strict affine support charts. Chou–Wang Proposition 1.2 then applies. Root rechecked the exact primary statement and Section 4 proof; the correction was propagated to the smooth-transfer audit, root validation and dependency ledger. The core theorem and metadata scope are unchanged. The revised source compiled with the native editor and Tectonic; all five PDF pages were reinspected with embedded fonts and no warnings. Revised PDF SHA-256: `6192382c55a3ac50ee76ce2514579a330dda1da6d873a32944a03bef26ed3179`.

Strongest verified result remains T1/T2 by the audited analytic dependency and explicit proofs, with singular-measure p=0 excluded. Fresh complete review of the repaired package and final assembled archive remains pending; no deposit has been staged or published. Local state lookup found no prior production attempt for this manifest. Current source tests and native/exported compilation passed; no formal certification is claimed.
