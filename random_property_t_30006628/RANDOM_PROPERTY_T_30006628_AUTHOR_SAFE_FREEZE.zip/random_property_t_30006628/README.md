# Property (T) for random free-product quotients: author freeze

Exact target: 30006628 / OWR-14299911-031, rank 924.

Outcome: a full-scope **candidate proof pending independent audit**. One substantive mathematical approach was used: Perron block-link analysis, with exact endpoint compression and matrix Chernoff concentration. Source triage preceded that approach. No repository publication or queue change was performed by the author of this freeze.

The proof claims the requested result for fixed n >= 3, fixed finite generating alphabets and d > 1/3, along **all relator lengths**. It handles torsion, uneven alphabet sizes, all three length residues, link concentration and finite-index transfer. The source webpage could not be fetched; the complete inherited exact-ID record and actual primary OWR problem were inspected. The September 2026 revision of the main primary source still poses the question. A newer Gromov-model d>1/4 preprint was checked and is not confused with this model.

## Files and reproducibility

- PROOF.md: the frozen complete mathematical derivation. Its SHA256 is 3bed7a81c5562d793bc4991fe62e1c06703818a9046495a7fe96d0b38e1ac100, 19,961 bytes. Mathematical changes after this pin require a separate corrected artifact.
- checker.py: standard-library-only exact finite diagnostics. Run `python checker.py` and `python -O checker.py`.
- checker_normal.json and checker_optimized.json: recorded positive results; they are byte-identical.
- negative_controls.json: deliberate kernel-edge omission, boundary removal, invalid two-factor strict-gap claim and critical-density claim all rejected in both modes. Run `python checker.py --mutant NAME` (and with -O); each must exit 1.
- sources.json: complete byte/hash pins for the three supplied corpus files, canonical full-record pair and six retrieved primary PDFs, plus public retrieval and inspection metadata. The canonical pair uses Python json.dumps with sort_keys=True and default separators, not projected records.
- verify_sources.py: optional provenance replay for a reviewer who possesses the source files. Supply `--catalog PATH --problems PATH --reports PATH --pdf-dir DIRECTORY`; no network or source-text output occurs. Source files are deliberately not bundled. `--mutant source_hash` and `--mutant pair_hash` must reject.
- source_verification_normal.json, source_verification_optimized.json, source_negative_controls.json: provenance replay receipts.
- prior_work_gate.json: exact-ID gate results and its limitations.

The finite diagnostics cover 13 exhaustive small cyclic-word spaces, 54 finite-index cancellation witnesses and 12 limiting spectral cases. They use rational arithmetic for strict spectral inequalities. These tests are meaningful checks of the derivation but cannot certify the asymptotic theorem. Passing AI review is not human peer review or formal certification.

The safe package excludes original third-party PDFs, extracted source text, corpus contents and private coordination material. Hashes and byte counts permit local comparison without distributing those sources. No claim of exhaustive novelty search or journal acceptance is made.
