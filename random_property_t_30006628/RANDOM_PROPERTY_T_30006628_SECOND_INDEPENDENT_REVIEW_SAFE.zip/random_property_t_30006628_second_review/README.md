# Independent review package

The full mathematical verdict is in INDEPENDENT_MATHEMATICAL_REVIEW.md. ACCEPTANCE_RECEIPT.json identifies the exact unchanged proof bytes accepted.

This package is authored review material, not a replacement for the original proof. Source PDFs, extracted source text, and dataset contents are excluded. Public source URLs, sizes, hashes, and inspection descriptions appear in SOURCE_VERIFICATION.json.

The independent checker uses Python 3 standard-library modules. Run it with:

    python independent_checks.py --workspace /path/to/author-workspace
    python -O independent_checks.py --workspace /path/to/author-workspace

That directory must contain the pinned author ZIP, its external manifest, and the supplied local proof at random_property_t_30006628/safe/PROOF.md. The accompanying JSON outputs record both successful runs.

The checker is a finite diagnostic only. Mathematical acceptance rests on the full written review, not on a finite test, a source hash, or an acceptance label.
