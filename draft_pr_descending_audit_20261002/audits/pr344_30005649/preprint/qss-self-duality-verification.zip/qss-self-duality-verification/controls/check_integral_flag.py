#!/usr/bin/env python3
"""Exact integral-flag identities over a formal Laurent ring, standard library only.

Coefficient symbols p,a0,...,a5 have sigma(p)=p, sigma(ai)=a(i+1 mod6),
a0+a2+a4=0, a1+a3+a5=0, and each ai is a unit. These hypotheses
are realized by a trace-zero unit in W(F_{p^6}) when p>3, as proved in REPORT.md.
This verifies identities; it does not numerically approximate Witt vectors.
"""
from itertools import permutations
from math import comb
import json

checks = 0
class Laurent:
    def __init__(self, terms=None):
        self.terms = {m:c for m,c in (terms or {}).items() if c}
    @staticmethod
    def scalar(value):
        return value if isinstance(value,Laurent) else Laurent({(0,)*7:value})
    def __add__(self,other):
        result = dict(self.terms)
        for m,c in Laurent.scalar(other).terms.items():
            result[m] = result.get(m,0)+c
        return Laurent(result)
    __radd__ = __add__
    def __neg__(self): return Laurent({m:-c for m,c in self.terms.items()})
    def __sub__(self,other): return self + (-Laurent.scalar(other))
    def __rsub__(self,other): return Laurent.scalar(other) + (-self)
    def __mul__(self,other):
        result = {}
        for m,c in self.terms.items():
            for n,d in Laurent.scalar(other).terms.items():
                exponent = tuple(x+y for x,y in zip(m,n))
                result[exponent] = result.get(exponent,0)+c*d
        return Laurent(result)
    __rmul__ = __mul__
    def __bool__(self): return bool(self.terms)

def monomial(index,power=1):
    exponent = [0]*7
    exponent[index] = power
    return Laurent({tuple(exponent):1})

def sigma(value,shift):
    result = {}
    for exponent,c in value.terms.items():
        target = [0]*7
        target[0] = exponent[0]
        for i in range(6):
            target[1+(i+shift)%6] = exponent[i+1]
        result[tuple(target)] = result.get(tuple(target),0)+c
    return Laurent(result)

def is_zero(value):
    if not value:
        return True
    # Clear Laurent denominators, then substitute a4=-a0-a2,a5=-a1-a3.
    shift = [max(0,-min(exponent[j] for exponent in value.terms)) for j in range(7)]
    result = {}
    for exponent,c in value.terms.items():
        exponent = [x+y for x,y in zip(exponent,shift)]
        n4,n5 = exponent[5:7]
        for i in range(n4+1):
            for j in range(n5+1):
                target = list(exponent[:5])
                target[1] += i
                target[3] += n4-i
                target[2] += j
                target[4] += n5-j
                target = tuple(target)
                coefficient = c*((-1)**(n4+n5))*comb(n4,i)*comb(n5,j)
                result[target] = result.get(target,0)+coefficient
    return not any(result.values())

def require(condition,message):
    global checks
    checks += 1
    if not condition:
        raise ValueError(message)

def equal(left,right,message):
    require(all(is_zero(a-b) for a,b in zip(left,right)),message)

zero,one = Laurent.scalar(0),Laurent.scalar(1)
p,p2,p3 = monomial(0),monomial(0,2),monomial(0,3)
a = [monomial(1+i) for i in range(6)]
inverse = [monomial(1+i,-1) for i in range(6)]
e = [tuple(one if i==j else zero for i in range(6)) for j in range(6)]
def scale(c,vector): return tuple(c*x for x in vector)
def add(*vectors): return tuple(sum(column,zero) for column in zip(*vectors))
weights = (0,0,1,0,1,1)
def F(vector):
    result = [zero]*6
    for j,c in enumerate(vector):
        result[(j+1)%6] += sigma(c,1)*monomial(0,weights[j])
    return tuple(result)
def V(vector):
    result = [zero]*6
    for j,c in enumerate(vector):
        result[(j-1)%6] += sigma(c,-1)*monomial(0,1-weights[(j-1)%6])
    return tuple(result)
for vector in e:
    equal(F(V(vector)),scale(p,vector),'FV=p failed')
    equal(V(F(vector)),scale(p,vector),'VF=p failed')
    iterate = vector
    for _ in range(6): iterate = F(iterate)
    equal(iterate,scale(p3,vector),'F six-step weight failed')
require(not is_zero(sigma(a[0],1)-sigma(a[0],-1)),'Frobenius control collapsed')

m1 = add(e[1],e[3],e[5])
m0 = add(scale(p,e[0]),e[2],e[4])
r2 = add(e[2],scale(-p*a[2]*inverse[0],e[0]))
r3 = add(e[3],scale(-a[3]*inverse[1],e[1]))
r4 = add(e[4],scale(-p*a[4]*inverse[0],e[0]))
r5 = add(e[5],scale(-a[5]*inverse[1],e[1]))
equal(m0,add(r2,r4),'even trace-zero saturation relation failed')
equal(m1,add(r3,r5),'odd trace-zero saturation relation failed')
x,y = scale(a[1],r3),scale(a[0],r2)
sA,sB = scale(inverse[0],e[0]),scale(inverse[1],e[1])
basis = [m1,m0,x,y,sA,sB]

def coordinates(vector):
    c0,c1 = vector[5],vector[4]
    c2 = (vector[3]-c0)*inverse[1]
    c3 = (vector[2]-c1)*inverse[0]
    c4 = a[0]*(vector[0]-p*c1+p*a[2]*c3)
    c5 = a[1]*(vector[1]-c0+a[3]*c2)
    return (c0,c1,c2,c3,c4,c5)
for j,vector in enumerate(basis):
    equal(coordinates(vector),e[j],'integral basis inverse failed')
for vector in e:
    equal(add(*(scale(c,v) for c,v in zip(coordinates(vector),basis))),vector,'basis transport failed')
determinant = zero
for permutation in permutations(range(6)):
    sign = (-1)**sum(permutation[i]>permutation[j] for i in range(6) for j in range(i+1,6))
    term = Laurent.scalar(sign)
    for j,i in enumerate(permutation): term *= basis[j][i]
    determinant += term
det_sign = 1 if is_zero(determinant-one) else -1
require(is_zero(determinant-det_sign),'integral basis determinant is not a unit')

for operation in (F,V):
    columns = [coordinates(operation(vector)) for vector in basis]
    for size in (2,4):
        require(all(is_zero(value) for column in columns[:size] for value in column[size:]),'integral flag unstable')
    for start in (0,2,4):
        equal(columns[start][start:start+2],(zero,one),'factor x image failed')
        equal(columns[start+1][start:start+2],(p,zero),'factor y image failed')

def pi(vector):
    return (a[0]*vector[0]+p*a[2]*vector[2]+p*a[4]*vector[4],
            a[1]*vector[1]+a[3]*vector[3]+a[5]*vector[5])
def standard_F(vector): return (p*sigma(vector[1],1),sigma(vector[0],1))
def standard_V(vector): return (p*sigma(vector[1],-1),sigma(vector[0],-1))
for vector in e:
    equal(pi(F(vector)),standard_F(pi(vector)),'quotient F morphism failed')
    equal(pi(V(vector)),standard_V(pi(vector)),'quotient V morphism failed')
equal(pi(sA),(one,zero),'quotient A section failed')
equal(pi(sB),(zero,one),'quotient B section failed')
for vector in (m1,m0,x,y): equal(pi(vector),(zero,zero),'kernel flag mismatch')

mod_p_F = [(j,(j+1)%6) for j in range(6) if weights[j]==0]
mod_p_V = [(j,(j-1)%6) for j in range(6) if weights[(j-1)%6]==1]
require(mod_p_F == [(0,1),(1,2),(3,4)],'candidate mod-p F mismatch')
require(mod_p_V == [(0,5),(3,2),(5,4)],'candidate mod-p V mismatch')
require(sum(weights)==3,'cycle unbalanced')
print(json.dumps({'assertions':checks,'integral_F_exponents':weights,
                  'six_step_identity':'F^6=p^3 sigma^6 in the displayed basis',
                  'word_forward':'ffvfvv','word_reverse':'vvfvff',
                  'candidate_mod_p_F':mod_p_F,'candidate_mod_p_V':mod_p_V,
                  'integral_flag_basis_determinant':det_sign,
                  'standard_supersingular_rank_two_factors':3,
                  'quotient_morphism_and_saturation_relations':True,
                  'coefficient_hypotheses':'ai units, sigma(ai)=a(i+1 mod6), even and odd traces zero',
                  'scope':'formal exact identities, not numerical Witt approximation or historical priority certification'},indent=2))
