# Classical supersingular mechanism

This supporting derivation records an independently verified application of classical theory, with no claim of first priority. The main research note uses its simpler finite-module filtration.

## 1. Unambiguous integral construction and classical word

Put W=W(k), K=W[1/p], and let sigma be the Witt Frobenius. Let D be free on e0,...,e5. Define sigma-semilinear F by

    F e0=e1, F e1=e2, F e2=p e3,
    F e3=e4, F e4=p e5, F e5=p e0.

Define sigma-inverse-semilinear V=p F^(-1):

    V e0=e5, V e1=p e0, V e2=p e1,
    V e3=e2, V e4=p e3, V e5=e4.

Both preserve D, and FV=VF=p. Thus pD is contained in FD, and FD is contained in D. By the exact contravariant equivalence for W-free Dieudonné modules, this is an actual p-divisible group H over **k** of height6 and dimension3; dimension is length(D/FD)=3. This invokes the classical classification theorem as stated in Yu Theorem3, not an unsupported liftability assertion.

Modulo p, the only nonzero F arrows are e0 to e1, e1 to e2, e3 to e4, and the only nonzero V arrows are e0 to e5, e3 to e2, e5 to e4. These are exactly the original candidate's arrows, with the prescribed semilinearity. Hence D/pD is the candidate module. The identification with H[p] is the standard p-kernel identification, also expressly built into Oort's construction in2.5.

On an arbitrary vector, six F iterations give

    F^6(sum ci ei)=p^3 sum sigma^6(ci) ei.

This is not a claim that sigma^6 is trivial on all of W(k). Repeated iterations add valuation3 every6 steps; sigma preserves valuation. Thus all Newton slopes are1/2. Alternatively, Oort Lemma2.6 gives slope #V/length for the integral cyclic lift, including a noncoprime letter count. Here the count is3/6.

Oort uses covariant Dieudonné modules (1.3, the notation remark after1.8), with F letters representing forward F and V letters representing backward V in1.4. In our contravariant D, the forward string in the e0,...,e5 order is **ffvfvv**. The dual D^t has forward F exponents(1,1,0,1,0,0), because F on a dual basis is the sigma-twisted transpose of V. Its word is therefore **vvfvff**. With the usual covariant functor D_cov(G)=D_contra(G^D), Oort's covariant vvfvff word describes the same finite group as our contravariant D/pD. It also describes the same p-divisible group using Oort's tautological lift, interpreted covariantly. In this particular six-letter example the complement and reverse happen to coincide; reversal alone must not be used as a general convention conversion.

Oort2.5 explicitly gives the integral arrows used above for any cyclic word, and2.6 introduces d=mu*m, c=mu*n with mu=gcd(d,c). Its statement covers d=c=3. The one-line proof in the author copy writes h:=m+n although the preceding definition is h=d+c. For a word with mu>1 the literal proof line cannot have the reduced h. The stated lemma is nevertheless confirmed by the actual full-cycle identity F^(d+c)=p^c sigma^(d+c), independently checked here for6 and3. This prevents an accidental coprime-only reading or reliance on that typographical conflict.

## 2. An explicit saturated integral flag with elliptic factors

Write S for the standard rank2 module with basis A,B and

    F A=V A=B, F B=V B=p A.

We now give 0<D1<D2<D whose three quotient modules are integrally isomorphic to S.

### Coefficients exist and all denominators are units

The field F_(p^6) is a degree3 extension of F_(p^2). Its trace has a nonzero kernel of dimension2 over F_(p^2), because p>3 and the trace of1 is3. Choose a nonzero trace-zero element abar, and let t=[abar] be its Teichmüller lift to W(F_(p^6)). Put tau=sigma^2 and

    a=t-(t+tau(t)+tau^2(t))/3.

Then tau^3(a)=a, a+tau(a)+tau^2(a)=0, and reduction of a is abar, since the trace correction reduces to0. Thus a is a unit. Put ai=sigma^i(a). All six ai are units, ai+6=ai, and

    a0+a2+a4=0, a1+a3+a5=0.

The trace-zero assertion uses the exact additive trace on Witt vectors, not a false assertion that Teichmüller lifts preserve addition. The correction by3 makes it exact. This argument is restricted to p>3 as required by Takao. No numerical approximation to Witt vectors is involved.

### First factor

Set m1=e1+e3+e5 and m0=p e0+e2+e4, and D1=W m1+W m0. Directly,

    F m1=V m1=m0, F m0=V m0=p m1.

Therefore D1 is integrally S. It is saturated in D: its coefficients in the e5,e4 positions give a unit2-by-2 minor; equivalently the full basis below extends its generators to a W-basis of D.

### Surjective integral quotient and its kernel

Define the W-linear map pi:D to S by

    e0 maps to a0 A,       e1 maps to a1 B,
    e2 maps to p a2 A,     e3 maps to a3 B,
    e4 maps to p a4 A,     e5 maps to a5 B.

It commutes with both F and V, with sigma and sigma inverse applied to coefficients. For instance, F(pi(e1))=sigma(a1)pA=p a2 A=pi(F e1); V(pi(e0))=sigma^(-1)(a0)B=a5 B=pi(V e0). The other ten basis identities are of the same form and are separately checked in the portable control. The map is surjective since pi(e0/a0)=A and pi(e1/a1)=B. Consequently D2=ker(pi) is saturated, rank4 and stable under F and V; D/D2 is S. The exact trace identities imply pi(m0)=pi(m1)=0, so D1 is contained in D2.

A W-basis for D2 is

    r2=e2-p(a2/a0)e0, r4=e4-p(a4/a0)e0,
    r3=e3-(a3/a1)e1,  r5=e5-(a5/a1)e1.

The trace identities give m0=r2+r4 and m1=r3+r5. Thus D1 is also saturated inside D2. In D2/D1 the classes r2,r3 are a basis, and

    F r2=p r3,             V r2=p(a1/a5) r3,
    F r3=(a0/a2) r2,       V r3=r2

where these four displayed equalities are quotient equalities. For example, F r3=r4-(a4/a2)r2; replacing r4 by -r2 gives (a0/a2)r2. Similarly, V r2=-p(a1/a5)r5 becomes p(a1/a5)r3. Set x=a1 r3 and y=a0 r2. Semilinearity now yields

    F x=V x=y, F y=V y=p x.

This proves that the middle factor is exactly S, rather than just an isogenous rank2 object.

The ordered vectors

    m1, m0, x, y, e0/a0, e1/a1

form a W-basis of D with determinant1. In particular all flag inclusions and quotient modules are integral and free. Both operators have upper block triangular matrices in this basis, with all three diagonal2-by-2 blocks equal to the standard S operators, with the appropriate semilinearity. The portable control verifies the full basis inverse, determinant, both stability conditions, all three diagonal blocks, and pi's F/V morphism identities. It therefore checks the exact formulas on which saturation and quotient identification rest.

Reducing this integral flag modulo p stays exact because all the quotient modules are W-free. Its first submodule reduces to span(e1+e3+e5,e2+e4), the candidate's first factor. Its rank4 submodule need not coincide with the original submitted rank4 flag; the explicit flag supplies the same required qss property independently.

### Why S is an elliptic group, without circular use of Yu Lemma4

For every p>3 a supersingular elliptic curve exists over k. One checkable route uses the classical Legendre/Deuring polynomial criterion recorded in Auer–Top Section3, printed5–6. With m=(p-1)/2, put

    Hp(lambda)=(-1)^m sum_(i=0)^m binom(m,i)^2 lambda^i.

This polynomial has positive degree m. Hp(0)=(-1)^m is nonzero, and by Vandermonde's identity Hp(1)=(-1)^m binom(p-1,m)=1 in Fp. Any root in algebraically closed k is therefore neither0 nor1, and the nonsingular Legendre curve y^2=x(x-1)(x-lambda) is supersingular by the stated criterion. Auer–Top recall the criterion from Deuring and Igusa; those two original proofs are not reread here. This classical elliptic-existence input is explicit, not inferred from the existence of an abstract p-divisible group.

For such an elliptic curve E, Yu Lemma4 does apply to M(E[p^infty]) and identifies it with S (Example2(2)). Hence the anti-equivalence identifies our three explicit S factors with E[p^infty]. This is a valid use of Lemma4: it is applied to an actual elliptic curve's module. The arbitrary rank2 quotients have already been explicitly shown isomorphic to S.

Lazard1955 TheoremIV gives a separate older uniqueness input for one-dimensional formal groups of a given height over algebraically closed characteristic-p fields. Nicole–Vasiu2.1 expressly use the unique supersingular height2 p-divisible group and Scholium2.3 give its standard basis. These reinforce the identification; the main explicit proof above does not require treating an arbitrary rank2 group as elliptic before identification.

## 3. Contravariance and exact multiplication-p kernels

Under the contravariant equivalence, the lattice flag corresponds to quotient maps H to G(D2) to G(D1). To obtain the correct subgroup flag define

    H1=G(D/D2), H2=G(D/D1), H3=H=G(D).

Then H1 is contained in H2, which is contained in H; the factors in increasing group order correspond to D/D2, D2/D1 and D1. Thus each factor is E[p^infty]. Every inclusion and quotient is an actual p-divisible group morphism over k, rather than an isogeny-category construction.

For an exact sequence of p-divisible fppf sheaves0 to A to B to C to0, taking p-kernels is exact. The only nontrivial point is surjectivity: given c in C[p], locally lift it to b in B. Then pb lies in A. Since multiplication by p on A is fppf surjective, locally choose a in A with pa=pb; b-a is killed by p and maps to c. The kernel is A[p] directly. Consequently

    0<H1[p]<H2[p]<H[p]

has successive quotients E[p], proving qss exactly as Takao defines it.

The p-divisibility hypothesis is necessary. For0 to Z/p to Z/p^2 to Z/p to0, the middle p-torsion maps to0 in the final Z/p; taking p-kernels is not right exact. No claim of exactness for arbitrary finite groups is used. On the module side, freeness of each integral quotient also guarantees exactness modulo p and gives the same conclusion via finite Dieudonné theory.

## 4. The general saturated-isocrystal mechanism

For completeness the proposed general route also passes over algebraically closed k. Let C be any rank2d integral supersingular Dieudonné lattice. By classical Manin–Dieudonné classification its rational module N is a direct sum of d rank2 slope1/2 simples. Choose an F-stable rational flag Ni of rank2i and put Ci=C intersect Ni.

Each Ci is finitely generated free over the DVR W; it spans Ni because denominators of any K-basis of Ni can be cleared inside C. It is saturated: px in Ci with x in C implies x in Ni, since Ni is a K-subspace. Moreover F is bijective on Ni rationally and V=p F^(-1), so both preserve Ni and each intersection. The Ci/Ci-1 are torsion-free, free rank2 integral Dieudonné lattices. This supplies exact sequences in the integral category. An isocrystal embedding alone would not suffice without these intersection/saturation steps.

Each rank2 factor Q has dimension1: its rational F is conjugate to standard slope1/2 F, whose determinant has valuation1. A semilinear basis change has determinant valuation0 contribution because sigma preserves valuations; thus length(Q/FQ)=1. Since pQ is contained in FQ, this is its dimension over k. Similarly length(Q/VQ)=1.

To identify Q integrally without assuming the desired conclusion, compare it rationally with a standard S lattice. For suitable nonnegative r,s, p^r S is contained in Q, which is contained in p^(-s) S. Since F^2(S)=pS, for t>=r+s+1 we have F^(2t)(Q) contained in pQ. Thus F modulo p is nilpotent, of rank1. In dimension2 this gives image(F)=kernel(F). The equality FV=p and injectivity of integral F give kernel(F modulo p)=VQ/pQ: if Fx=pz=F(Vz), then x=Vz. Thus the mod-p F and V images are the same1-dimensional line, and a(Q)=dim Q/(FQ+VQ)=1.

Yu printed4 states the converse maximal-a-number classification for an arbitrary Dieudonné module: if dim Q/FQ=dim Q/VQ=a(Q)=g over algebraically closed k, Q is M_(1,1)^g. With g=1 this proves Q is S. This invocation is broader than Yu Lemma4's elliptic-specific statement and is noncircular. Lazard's height2 formal uniqueness and Nicole–Vasiu's standard height2 factor treatment are older corroborating primary inputs. Reversing the flag and taking exact p-kernels now proves that the p-torsion of **every** supersingular p-divisible group over algebraically closed k is qss. This last sentence is our deduction from the classical inputs; it is not presented as a quoted theorem explicitly formulated in Yu or Oort.

Oort3.6 Step one expressly uses a sub-p-divisible group of a nonsimple tautological lift and its p-kernel to establish a proper BT1 subgroup when gcd(d,c)>1. Nicole–Vasiu Lemma2.4's proof expressly starts with an exact sequence0 to N to M to M1 to0 of supersingular integral Dieudonné modules, with N rank2. These are direct earlier instances of the operative mechanism. Neither inspected passage states Takao's mixed-characteristic selfduality question verbatim.

## 5. Nonselfduality, mixed characteristic and conservative attribution

The precise candidate reduction also has a short independent nonselfduality check. im(F^2)=k e2 and im(V^2)=k e4 have intersection dimension0. In the dual module F^2 is the twisted transpose of V^2 and V^2 the twisted transpose of F^2. Both dual images are k e0*, so their intersection has dimension1. This dimension is invariant under semilinear Dieudonné isomorphisms; the finite group is therefore not Cartier selfdual. An integral selfduality of H would reduce to one of H[p], so H itself is not selfdual. This is a fresh elementary calculation here, not a historical first-priority claim.

Appending n-3 copies of S for n>=3 preserves supersingularity and gives qss p-torsion of order p^(2n). The additional mod-p blocks have F^2=V^2=0, so the same intersection invariant still distinguishes the group from its dual. This includes all n>=3 asked by the target, under the permitted choice k=algebraic closure of Fp. No descent claim for every perfect k is required for this counterexample.

The original candidate's finite-Honda complement was L=span(e0,e3,e5), complementing im(F)=span(e1,e2,e4), with V injective on L and image span(e5,e2,e4). The complete finite-Honda hypotheses and actual finite flat p-killed realization over W(k) were independently checked in the earlier closed audit against Hoshi/Fontaine–Laffaille primary statements. That prerequisite is recalled honestly and is not reaudited or resealed here. Adding the corresponding standard block complements gives the higher-n finite lifts. The new supersingular mechanism proves the **special-fiber qss** part by classical p-divisible-group structure; it does not replace the finite-Honda realization theorem or assert that this p-divisible H lifts over W(k).

Thus the precise mathematical object is covered by Oort's classical cyclic-lift construction, and its qss property follows from classical supersingular factor structure, with an explicit integral realization of the factor flag given here. In combination with the nonselfduality calculation and the previously verified finite-Honda complement, the proposed mechanism does reach the exact Takao counterexample. It does not transfer the central difficulty to unsupported mixed-characteristic p-divisible liftability.

The conservative attribution implication is that the six-dimensional module, its balanced supersingular completion, and the qss implication must be situated in that older framework. This family does **not** certify that an earlier author explicitly combined all ingredients to answer Takao's exact question, that the old mixed-characteristic target was previously stated, or which paper has first priority. Root independently audits classical word/nonselfduality texts and chronology. No paper, Git release, publication or novelty label has been produced here.

