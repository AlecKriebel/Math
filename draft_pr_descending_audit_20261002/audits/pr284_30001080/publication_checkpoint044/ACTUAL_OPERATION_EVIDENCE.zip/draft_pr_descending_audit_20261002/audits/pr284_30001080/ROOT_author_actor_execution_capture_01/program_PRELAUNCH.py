"""Capture exact nonce-bound branch execution after ROOT runtime grant."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
assert sys.flags.ignore_environment and sys.dont_write_bytecode and not sys.flags.optimize
W=Path(__file__).resolve().parent;B=W/'author_branch_correction_preparation_08';h=B/'native_capture.py'
assert hashlib.sha256(h.read_bytes()).hexdigest()=='8b1f492725ce50c895ca7f6157a383f39292fbf8ee037bc189a80cc24be89ff5'
s=importlib.util.spec_from_file_location('ROOT_native_actor_execute08',h);N=importlib.util.module_from_spec(s);s.loader.exec_module(N)
gp=W/'ROOT_PR284_AUTHOR_BRANCH_GRANT_01.json';g=json.loads(gp.read_bytes());assert g['status']=='ROOT_CLEARS_EXACT_PR284_AUTHOR_BRANCH_CORRECTION' and g['execution_authority'] is True and not Path(g['run_directory']).exists()
O=W/'ROOT_author_actor_execution_capture_01';O.mkdir(exist_ok=False)
for name,p in [('program_PRELAUNCH.py',Path(__file__)),('native_helper_PRELAUNCH.py',h)]: (O/name).write_bytes(p.read_bytes())
for k in list(os.environ):
 if k in ('GH_DEBUG','GITHUB_DEBUG','DEBUG','NODE_DEBUG','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONINSPECT','PYTHONOPTIMIZE') or k.startswith('GIT_TRACE'):os.environ.pop(k,None)
argv=['/opt/homebrew/bin/python3','-B',str(B/'actor.py'),'execute','--run-dir',g['run_directory'],'--plan',g['plan']['path'],'--plan-sha256',g['plan']['sha256'],'--grant',str(gp),'--grant-sha256',N.pin(gp)['sha256']]
result=N.call(O,'actual_execute',argv,timeout=900,cleanup_timeout=5,context={'ROOT_grant':N.pin(gp),'source_and_plan_review':g['source_and_plan_review'],'source_catalog':g['source_catalog'],'sources':g['sources'],'actual_ROOT_recorder_PID':os.getpid(),'one_use_branch_CAS_only':True})
v=json.loads(result);assert v['status']=='BRANCH_CONTENT_CAS_AND_FULL_READBACK_SUCCEEDED_PENDING_ROOT_ADVERSARY' and v['ref_updates']==1 and v['head']==g['expected_after_commit'] and v['metadata_writes']==0
print(json.dumps({'status':'ACTUAL_BRANCH_RESULT_PENDING_SEPARATE_ROOT_ADVERSARIAL_ACCEPTANCE','actual_recorder_PID':os.getpid(),'native_execution':N.pin(O/'private/native/actual_execute/execution.json'),'result':N.pin(Path(g['run_directory'])/'RESULT.json'),'head':v['head'],'metadata_ready_merge_authority':False}))
