"""ROOT native user-authorized publication operation recorder."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, signal, subprocess, sys, threading, time
W=Path(__file__).resolve().parent
def now():return datetime.now(timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b),mode=p.stat().st_mode&0o777)
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
    assert sys.flags.optimize==0
    label,src,cwd,*args=sys.argv[1:];s=Path(src).resolve();d=W/'native'/label
    assert '/' not in label and s.is_relative_to('/Users/alec/Documents/Math/draft_pr_descending_audit_20261002')
    d.mkdir(parents=True,exist_ok=False)
    (d/'program_PRELAUNCH.py').write_bytes(s.read_bytes())
    (d/'recorder_PRELAUNCH.py').write_bytes(Path(__file__).read_bytes())
    cmd=['/opt/homebrew/bin/python3','-E','-B',str(s),*args]
    req=dict(issued_UTC=now(),actual_recorder_PID=os.getpid(),actual_parent_PID=os.getppid(),argv=cmd,cwd=cwd,
             program=pin(s),prelaunch=pin(d/'program_PRELAUNCH.py'),recorder=pin(d/'recorder_PRELAUNCH.py'),timeout_seconds=180,
             user_persistent_publication_and_native_PR_merge_scope=True,primary_checkout_index_or_controller_modification=False,no_automatic_retry=True)
    save(d/'request.json',req)
    communicated=False;p=None;out=err=b'';exc=None;expired=threading.Event();timer=None;cleanup=[];clock=time.monotonic()
    def kill():
        if p is not None:
            try:os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            except BaseException as e:cleanup.append("signal:"+repr(e))
    def timeout():expired.set();kill()
    try:
        assert s.read_bytes()==(d/'program_PRELAUNCH.py').read_bytes()
        p=subprocess.Popen(cmd,cwd=cwd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        timer=threading.Timer(180,timeout);timer.daemon=True;timer.start()
        save(d/'started.json',dict(UTC=now(),actual_child_PID=p.pid,actual_recorder_PID=os.getpid()))
        out,err=p.communicate(timeout=180);communicated=True
    except BaseException as e:
        exc=repr(e)
        if isinstance(e,subprocess.TimeoutExpired):
            expired.set();out=e.output or out;err=e.stderr or err
    finally:
        if timer:timer.cancel()
        if p is not None:
            kill()
            if not communicated:
                try:out,err=p.communicate(timeout=5);communicated=True
                except BaseException as e:
                    cleanup.append(repr(e))
                    if isinstance(e,subprocess.TimeoutExpired):out=e.output or out;err=e.stderr or err
                    try:p.kill()
                    except BaseException as e:cleanup.append("kill:"+repr(e))
                    try:p.wait(timeout=1)
                    except BaseException as e:cleanup.append(repr(e))
    if cleanup:exc=(exc+";" if exc else "")+";".join(cleanup)
    (d/'stdout.bin').write_bytes(out);(d/'stderr.bin').write_bytes(err)
    receipt=dict(req,finished_UTC=now(),actual_child_PID=None if p is None else p.pid,returncode=None if p is None else p.returncode,
                 child_reaped=p is not None and p.returncode is not None,exception=exc,timed_out=expired.is_set(),elapsed_seconds=time.monotonic()-clock,
                 stdout=pin(d/'stdout.bin'),stderr=pin(d/'stderr.bin'),cleanup=cleanup,
                 host_or_permanent_storage_failure_containment_certified=False)
    save(d/'execution.json',receipt)
    print(json.dumps(receipt))
    if exc or expired.is_set() or p is None or p.returncode!=0:raise SystemExit(1)
if __name__=='__main__':main()
