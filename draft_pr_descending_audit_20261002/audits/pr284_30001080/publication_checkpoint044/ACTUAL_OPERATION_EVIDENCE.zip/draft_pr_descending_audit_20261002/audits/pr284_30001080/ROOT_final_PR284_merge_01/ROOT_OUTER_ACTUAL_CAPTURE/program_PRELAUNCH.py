"""User-authorized final metadata, readiness or expected-head native merge."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,sys
assert sys.flags.ignore_environment and sys.dont_write_bytecode and not sys.flags.optimize
W=Path(__file__).resolve().parent;stage=sys.argv[1];assert stage in ('metadata','ready','merge')
acp=W/'ROOT_PR284_ACTUAL_AUTHOR_BRANCH_ACCEPTANCE_01.json';ac=json.loads(acp.read_bytes());assert ac['status']=='ROOT_ACCEPTS_EXACT_PR284_ACTUAL_AUTHOR_BRANCH' and ac['accepted'] is True and ac['unresolved_issues']==[] and ac['execution_authority'] is False
head=ac['head'];assert head=='7d244eed5d7ddd89d5c540aecfa72490b7b30073'
M=W/'pr284_final_pr_metadata_preparation_03';assert hashlib.sha256((M/'OWN_BODY_CATALOG.json').read_bytes()).hexdigest()=='fa0281090700aac61c04bfa82188dda86c17d53e84682c2bb78ffff796f4e52e'
title=(M/'PR_TITLE.txt').read_text();body=(M/'PR_BODY.md').read_text();assert hashlib.sha256(title.encode()).hexdigest()=='527e80490e7b8d7c34dc148ee26197406a8f458781bc145e5094f18bf267033c' and hashlib.sha256(body.encode()).hexdigest()=='18fbc939a19d4b41c25080411f6a0625bfd718102cedc1a2849015105c52f4bd';title=title.removesuffix('\n')
helper=W.parent/'pr288_30001994/metadata_completion_preparation_01/native_capture.py';assert hashlib.sha256(helper.read_bytes()).hexdigest()=='d8ccb5a9609448717c8785a19e161526b9e168f681a0499d734c4220fd4fbe9d'
s=importlib.util.spec_from_file_location('ROOT_PR284_final_native3993',helper);N=importlib.util.module_from_spec(s);s.loader.exec_module(N)
gh=Path('/opt/homebrew/Cellar/gh/2.85.0/bin/gh');assert hashlib.sha256(gh.read_bytes()).hexdigest()=='91f6e182bce24da56581ab999088c55ae0216309af19bc6167bbc4396c3f4ea5'
for k in list(os.environ):
 if k in ('GH_DEBUG','GITHUB_DEBUG','DEBUG','NODE_DEBUG') or k.startswith('GIT_TRACE'):os.environ.pop(k,None)
os.environ.update(GH_NO_UPDATE_NOTIFIER='1',GH_NO_EXTENSION_UPDATE_NOTIFIER='1',GH_PROMPT_DISABLED='1',GH_PAGER='cat',GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
O=W/('ROOT_final_PR284_'+stage+'_01');O.mkdir(exist_ok=False)
(O/'program_PRELAUNCH.py').write_bytes(Path(__file__).read_bytes());(O/'native_helper_PRELAUNCH.py').write_bytes(helper.read_bytes())
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':p.stat().st_mode&0o777}
def call(label,argv):return N.call(O,label,[str(gh),*argv],timeout=55,cleanup_timeout=5)
def get(label,path):return json.loads(call(label,['api','--hostname','github.com','--method','GET','--header','Accept: application/vnd.github+json','--header','X-GitHub-Api-Version: 2022-11-28',path]))
def check(x):
 assert x['number']==284 and x['id']==4705883104 and x['head']['sha']==head and x['head']['ref']=='dot/math-30001080' and x['base']['ref']=='main' and x['head']['repo']['id']==x['base']['repo']['id']==1307717439
 return x
before=check(get('before_PR','repos/AlecKriebel/Math/pulls/284'));assert before['state']=='open' and before['merged'] is False
if stage!='metadata':assert before['title']==title and before['body']==body
if stage=='metadata':
 assert before['draft'] is True
 call('exact_title_body_edit',['pr','edit','284','--repo','AlecKriebel/Math','--title',title,'--body-file',str(M/'PR_BODY.md')])
 after=check(get('after_PR','repos/AlecKriebel/Math/pulls/284'));assert after['state']=='open' and after['draft'] is True and after['title']==title and after['body']==body
elif stage=='ready':
 assert (W/'ROOT_final_PR284_metadata_01/RESULT.json').exists()
 if before['draft']:call('mark_ready',['pr','ready','284','--repo','AlecKriebel/Math'])
 after=check(get('after_PR','repos/AlecKriebel/Math/pulls/284'));assert after['state']=='open' and after['draft'] is False and after['title']==title and after['body']==body
 view=json.loads(call('ready_checks_policy',['pr','view','284','--repo','AlecKriebel/Math','--json','number,state,isDraft,headRefOid,baseRefName,mergeable,mergeStateStatus,statusCheckRollup,reviewDecision']))
 assert view['headRefOid']==head and view['isDraft'] is False; (O/'CHECKS.json').write_text(json.dumps(view,indent=2)+'\n')
else:
 assert (W/'ROOT_final_PR284_ready_01/RESULT.json').exists() and before['draft'] is False
 repo=get('native_repository_merge_policy','repos/AlecKriebel/Math');assert repo['id']==1307717439 and repo['full_name']=='AlecKriebel/Math' and repo['allow_merge_commit'] is True
 view=json.loads(call('before_merge_checks',['pr','view','284','--repo','AlecKriebel/Math','--json','number,state,isDraft,headRefOid,baseRefName,mergeable,mergeStateStatus,statusCheckRollup,reviewDecision']))
 assert view['headRefOid']==head and view['isDraft'] is False and view['mergeable']=='MERGEABLE';(O/'CHECKS.json').write_text(json.dumps(view,indent=2)+'\n')
 call('expected_head_native_merge',['pr','merge','284','--repo','AlecKriebel/Math','--merge','--match-head-commit',head])
 after=check(get('after_PR','repos/AlecKriebel/Math/pulls/284'));assert after['state']=='closed' and after['merged'] is True and after['merged_at'] and after['merge_commit_sha']
 main=get('after_main_reference','repos/AlecKriebel/Math/git/ref/heads/main');assert main['object']['type']=='commit';commit=get('actual_merge_commit','repos/AlecKriebel/Math/git/commits/'+after['merge_commit_sha']);assert commit['sha']==after['merge_commit_sha'] and head in [x['sha'] for x in commit['parents']]
 (O/'MERGED_COMMIT.json').write_text(json.dumps(commit,indent=2)+'\n')
result={'status':'ACTUAL_PR284_'+stage.upper()+'_AND_EXACT_READBACK_SUCCEEDED','UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_ROOT_recorder_PID':os.getpid(),'actual_argv':sys.orig_argv,'head':head,'branch_acceptance':pin(acp),'title_body_catalog':pin(M/'OWN_BODY_CATALOG.json'),'native_operation':stage,'state':after['state'],'draft':after['draft'],'merged':after['merged'],'merge_commit':after.get('merge_commit_sha') if after['merged'] else None,'individual_communication':False,'Zenodo_GWS_release_operations':0}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
