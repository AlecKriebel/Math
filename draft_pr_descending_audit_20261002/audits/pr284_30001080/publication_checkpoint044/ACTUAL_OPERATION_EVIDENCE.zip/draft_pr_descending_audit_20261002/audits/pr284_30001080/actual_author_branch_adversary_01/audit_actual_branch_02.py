from pathlib import Path
from datetime import datetime, timezone, timedelta
import base64
import gzip
import hashlib
import json
import os
import re
import stat

R = Path('/Users/alec/Documents/Math')
W = R / 'draft_pr_descending_audit_20261002/audits/pr284_30001080'
A = W / 'actual_author_branch_adversary_01'
NONCE = 'ffc6dd67b4f7a490716e4d3b407c477ee04ea0f6e3ebbb74'
RUN = W / ('ROOT_author_branch_execution_' + NONCE)
OUTER = W / 'ROOT_author_actor_execution_capture_01'
S = W / 'author_branch_correction_preparation_08'
OLD = '391cb662b1599ef564ff15b63cd8ed73c7d1f125'
MAIN = 'f36cb1e34696d460b9cfb5b03425998de48c4669'
HEAD = '7d244eed5d7ddd89d5c540aecfa72490b7b30073'
TREE = 'cdbc30401d63ae3a008e272a10fcfc8cd14bae33'
PEER = '1252d9d7855ab2ca7c856d644698d2863a19558e'
P = 'repos/AlecKriebel/Math/git/'
Q = 'unsolved_math_prioritization/QUEUE.md'
T = 'unsolved_math_prioritization/attempts/30001080'
checks = []

def check(name, **detail):
    checks.append({'name': name, 'passed': True, **detail})

def digest(b):
    return hashlib.sha256(b).hexdigest()

def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': digest(b), 'mode': stat.S_IMODE(p.stat().st_mode)}

def exact(t):
    actual = pin(t['path'])
    assert all(actual[k] == v for k, v in t.items() if k in actual)
    return actual

def load(p):
    return json.loads(Path(p).read_bytes())

def oid(kind, b):
    return hashlib.sha1(kind.encode() + b' ' + str(len(b)).encode() + b'\0' + b).hexdigest()

def tree_hash(entries):
    raw = b''
    for name, t in sorted(entries.items(), key=lambda kv: kv[0].encode() + (b'/' if kv[1]['type'] == 'tree' else b'')):
        assert '/' not in name and '\0' not in name
        assert (t['mode'], t['type']) in [('040000', 'tree'), ('100644', 'blob'), ('100755', 'blob'), ('120000', 'blob'), ('160000', 'commit')]
        raw += (b'40000' if t['mode'] == '040000' else t['mode'].encode()) + b' ' + name.encode() + b'\0' + bytes.fromhex(t['sha'])
    return oid('tree', raw)

def tree_response(x):
    assert x['truncated'] is False
    entries = {t['path']: {k: t[k] for k in ['mode', 'type', 'sha']} for t in x['tree']}
    assert len(entries) == len(x['tree']) and tree_hash(entries) == x['sha']
    return entries

def blob_response(x):
    assert x['encoding'] == 'base64'
    b = base64.b64decode(x['content'])
    assert len(b) == x['size'] and oid('blob', b) == x['sha']
    return b

def catalog(d, expected=None):
    d = Path(d)
    cp = d / 'FULL_CATALOG.json'
    if expected is not None: exact(expected)
    c = load(cp)
    rows = c['files']
    assert len({t['path'] for t in rows}) == len(rows)
    assert {t['path'] for t in rows} == {p.relative_to(d).as_posix() for p in d.rglob('*') if p.is_file() and p != cp}
    for t in rows:
        assert not t['path'].startswith('/') and '..' not in Path(t['path']).parts
        p = d / t['path']
        assert not p.is_symlink()
        b = p.read_bytes()
        assert len(b) == t['bytes'] and digest(b) == t['sha256']
    assert set(c['directories']) == {p.relative_to(d).as_posix() or '.' for p in [d] + [p for p in d.rglob('*') if p.is_dir()]}
    assert all(stat.S_IMODE(p.stat().st_mode) == (0o444 if p.is_file() else 0o555) for p in [d] + list(d.rglob('*')))
    return c

def native(d, stdin=False, rich=True):
    d = Path(d)
    assert {p.name for p in d.iterdir()} == {'request.json', 'started.json', 'execution.json', 'stdout.gz', 'stderr.gz'} | ({'stdin.gz'} if stdin else set())
    q, s, e = [load(d / name) for name in ['request.json', 'started.json', 'execution.json']]
    assert q['argv'] == e['argv'] and q['cwd'] == str(R)
    assert q['actual_recorder_PID'] == e['actual_recorder_PID'] and s['actual_child_PID'] == e['actual_child_PID']
    assert e['returncode'] == 0 and e['failure'] is None and e['cleanup_errors'] == []
    assert all(e[k] is True for k in ['reaped', 'communication_complete', 'wait_completed'])
    if rich:
        assert q['prelaunch_error'] is None and q['executable_custody'] == 'AVAILABLE'
        exact(q['executable'])
        for p in q['script_arguments']: exact(p)
        assert q['environment_intentionally_not_recorded'] is True
    if 'time_ns' in q and 'time_ns' in s:
        assert q['time_ns'] <= s['time_ns'] <= e['time_ns']
    streams = {}
    for name in ['stdout', 'stderr']:
        t = e['streams'][name]
        p = d / (name + '.gz')
        assert t['path'] == str(p) and t['complete'] is True
        stored = p.read_bytes(); b = gzip.decompress(stored)
        assert len(stored) == t['stored_bytes'] and digest(stored) == t['stored_sha256']
        assert len(b) == t['logical_bytes'] and digest(b) == t['logical_sha256']
        streams[name] = b
    if stdin:
        b = gzip.decompress((d / 'stdin.gz').read_bytes())
        assert len(b) == q['stdin_bytes'] and digest(b) == q['stdin_sha256']
        streams['stdin'] = b
    else:
        assert q['stdin_bytes'] == 0 and q['stdin_sha256'] is None
    return q, s, e, streams

def worker(d, parent):
    q, s, e, streams = native(d, True)
    assert q['actual_recorder_PID'] == parent
    assert q['argv'] == ['/opt/homebrew/opt/python@3.14/bin/python3.14', '-B', str(S / 'http_worker.py')]
    assert q['script_arguments'] == [sources['http_worker.py']]
    assert q['context'] == {'actor': sources['actor.py'], 'transport_worker': sources['http_worker.py']}
    assert q['timeout_seconds'] == 55 and q['cleanup_timeout_seconds'] == 5
    assert streams['stderr'] == b''
    env = json.loads(streams['stdin']); x = json.loads(streams['stdout'])
    assert set(env) == {'method', 'path', 'payload', 'execution_authority', 'authority', 'mutation_ordinal'}
    assert x['actual_worker_PID'] == e['actual_child_PID']
    assert x['complete'] is True and x['status'] in [200, 201]
    assert x['requests_sent'] == 1 and x['redirects_followed'] == x['retries'] == 0
    assert x['response_headers_intentionally_not_recorded'] is True
    b = base64.b64decode(x['body_base64'], validate=True)
    assert len(b) == x['body_bytes'] and digest(b) == x['body_sha256']
    data = json.loads(b)
    assert not data.get('errors')
    m = x['credential_metadata']
    assert m['actual_parent_PID'] == e['actual_child_PID'] and m['secret_stream_full_capture_claim'] is False and m['environment_recorded'] is False
    public = re.fullmatch(r'repos/AlecKriebel/Math/compare/[0-9a-f]{40}\.\.\.[0-9a-f]{40}\?per_page=1&page=2', env['path']) is not None and env['method'] == 'GET'
    if public:
        assert x['request_credentialless'] is True and x['Authorization_header_sent'] is False
        assert x['public_body_policy']['safe'] is True and x['public_body_policy']['credential_echo_screening_performed'] is False
        assert m['credential_subprocess_started'] is False and m['token_environment_read'] is False and m['actual_child_PID'] is None
    else:
        assert x['screen_policy']['safe'] is True
        assert m['argv'] == ['/opt/homebrew/bin/gh', 'auth', 'token', '--hostname', 'github.com']
        assert m['returncode'] == 0 and m['cleanup_errors'] == [] and all(m[k] is True for k in ['reaped', 'communication_complete', 'wait_completed'])
        assert m['secret_streams'] == 'INTENTIONALLY_UNRETAINED_IN_MEMORY_ONLY'
        assert m['secret_stdout_bytes'] > 0 and m['secret_stderr_bytes'] == 0
        exact(m['executable'])
        assert e['actual_child_PID'] != m['actual_child_PID']
    return {'dir': d, 'request': q, 'started': s, 'execution': e, 'envelope': env, 'worker_result': x, 'data': data, 'public': public}

baseline = load(A / 'BASELINE.json')
assert baseline['before_any_future_actual_branch_result_or_result_verdict_read'] is True
assert len(baseline['protected_complete_body_pins']) == 589
for t in baseline['protected_complete_body_pins']: exact(t)
check('all589_original_independent_protected_baseline_bodies_exact_before_actual_review')

sa = load(W / 'ROOT_AUTHOR_BRANCH_SOURCE_ACCEPTANCE_08.json')
review = load(W / 'ROOT_PR284_AUTHOR_ACTOR_PLAN_REVIEW_01.json')
g = load(W / 'ROOT_PR284_AUTHOR_BRANCH_GRANT_01.json')
assert len(g) == 34
gp = pin(W / 'ROOT_PR284_AUTHOR_BRANCH_GRANT_01.json')
pp = exact(g['plan']); bp = exact(g['candidate_binding'])
plan = load(pp['path']); binding = load(bp['path'])
sources = {k: exact(v) for k, v in sa['sources'].items()}
assert sa['accepted'] is True and sa['execution_authority'] is False and sa['actual_branch_update_performed'] is False
assert sa['unresolved_issues'] == [] and review['unresolved_issues'] == [] and review['execution_authority'] is False
assert g['status'] == 'ROOT_CLEARS_EXACT_PR284_AUTHOR_BRANCH_CORRECTION' and g['execution_authority'] is True and g['fixture_only'] is False and g['unresolved_issues'] == []
assert g['sources'] == plan['sources'] == review['sources'] == sources
assert g['plan'] == review['plan'] == pp and g['candidate_binding'] == review['candidate_binding'] == bp
assert review['source_acceptance'] == pin(W / 'ROOT_AUTHOR_BRANCH_SOURCE_ACCEPTANCE_08.json')
assert g['source_and_plan_review'] == pin(W / 'ROOT_PR284_AUTHOR_ACTOR_PLAN_REVIEW_01.json')
assert g['source_catalog'] == sa['source_catalog']
catalog(S, g['source_catalog'])
catalog(Path(review['fresh_review_catalog']['path']).parent, review['fresh_review_catalog'])
assert load(review['fresh_review_verdict']['path'])['actual_plan_accepted'] is True
exact(review['fresh_review_verdict'])
assert (plan['expected_pr_head'], plan['expected_main_head'], plan['after_commit'], plan['after_root']) == (OLD, MAIN, HEAD, TREE)
assert plan['parents'] == [OLD, MAIN] and g['expected_pr_head'] == OLD and g['expected_main_head'] == MAIN and g['expected_after_commit'] == HEAD and g['expected_after_tree'] == TREE
assert g['nonce'] == NONCE and g['run_directory'] == str(RUN)
assert g['scope'] == 'existing_PR284_branch_only_immutable_objects_then_one_expected_old_force_false_CAS' and type(g['maximum_ref_updates']) is int and g['maximum_ref_updates'] == 1
assert g['forbidden_actions'] == ['metadata', 'ready', 'merge', 'close', 'comment', 'release', 'Zenodo', 'GWS', 'local_git_mutation']
assert binding['expected_main_head'] == MAIN and binding['expected_pr_head'] == OLD and binding['expected_main_target'] == {}
assert binding['execution_authority'] is False and binding['unresolved_issues'] == []
for t in binding['prerequisites']: exact(t)
for k, bkey in [('publication_readiness', 'publication_readiness'), ('proposed_manifest', 'proposed_manifest'), ('full_candidate_catalog', 'full_catalog'), ('administrative_finalization_acceptance', 'administrative_finalization_acceptance')]:
    assert g[k] == plan[k] == binding[bkey]
    exact(g[k])
assert g['expected_main_queue_transition'] == plan['expected_main_queue_transition'] == binding['expected_main_queue_transition']
assert g['raw_parent_inputs'] == plan['raw_parent_inputs'] == binding['raw_parent_inputs']
catalog(Path(g['plan']['path']).parent)
catalog(Path(g['full_candidate_catalog']['path']).parent, g['full_candidate_catalog'])
check('closed_source08_plan04_grant01_binding04_entire_literals_fourpins_prerequisites_and_separate_authorities')

main_dir = W / 'ROOT_main_selected_baseline_readback_07'
catalog(main_dir)
main = load(main_dir / 'RESULT.json')
assert main['expected_main_head'] == MAIN and main['expected_pr_head'] == OLD and main['expected_main_target'] == {}
assert main['execution_authority'] is False and main['remote_mutations'] == main['primary_checkout_or_QUEUE_writes'] == 0
assert datetime.fromisoformat(main['UTC']) < datetime.fromisoformat(g['issued_UTC'])
for h, m in main['trees'].items(): assert tree_hash(m) == h and plan['trees_before'][h] == m
assert main['commits'][MAIN] == plan['commits_before'][MAIN]
main_queue = (main_dir / 'MAIN_QUEUE_FULL.bin').read_bytes()
assert oid('blob', main_queue) == main['main_QUEUE_blob_SHA1']
assert base64.b64decode(plan['blobs_before'][main['main_QUEUE_blob_SHA1']], validate=True) == main_queue
assert main_queue == Path(baseline['full_fresh_main_QUEUE_pin_only_no_copy']['path']).read_bytes()
main_native = []
for d in sorted((main_dir / 'private/native').iterdir()):
    q, s, e, streams = native(d, rich=False)
    assert q['actual_recorder_PID'] == 57054 and e['actual_recorder_PID'] == 57054
    assert q['argv'][5] == 'GET'
    main_native.append({'label': d.name, 'actual_recorder_PID': e['actual_recorder_PID'], 'actual_child_PID': e['actual_child_PID'], 'execution': pin(d / 'execution.json')})
assert len(main_native) == 8
check('frozen_main7_actual_pre_grant_native_baseline_complete_canonical_maps_and_QUEUE_historical_main5_only', native_children=8)

raw_parents = {}
for h, t in g['raw_parent_inputs'].items():
    exact(t); b = Path(t['path']).read_bytes()
    assert oid('commit', b) == h and base64.b64decode(plan['raw_parents'][h], validate=True) == b
    raw_parents[h] = b
    fields = b.split(b'\n\n', 1)[0].splitlines()
    assert fields[0].removeprefix(b'tree ').decode() == plan['commits_before'][h]['tree']['sha']
    assert [x.removeprefix(b'parent ').decode() for x in fields if x.startswith(b'parent ')] == [x['sha'] for x in plan['commits_before'][h]['parents']]
assert b'parent 974de6221dda5addefa08705c85e57058cb505ef\nparent ' + PEER.encode() + b'\n' in raw_parents[OLD]
peerraw = (W / 'ROOT_exact_raw_peer_parent_commit_readback_01/RAW_COMMIT.bin').read_bytes()
assert oid('commit', peerraw) == PEER
readback = load(review['ROOT_readback']['path'])
catalog(Path(readback['current_peer_ancestry']['path']).parent, readback['current_peer_ancestry'])
peer = worker(W / 'ROOT_current_peer_parent_ancestry_01/private/native/0001_GET', 59944)
assert peer['public'] is True and peer['envelope']['path'] == 'repos/AlecKriebel/Math/compare/' + PEER + '...' + MAIN + '?per_page=1&page=2'
assert peer['data']['base_commit']['sha'] == peer['data']['merge_base_commit']['sha'] == PEER and peer['data']['status'] in ['ahead', 'identical']
assert peer['data']['base_commit']['commit']['tree']['sha'] == peerraw.split(b'\n', 1)[0].removeprefix(b'tree ').decode()
scope_dir = W / 'ROOT_public_original_join_scope_01'
catalog(scope_dir, binding['original_peer_scope_proof'])
scope = load(scope_dir / 'original_pr_vs_peer_parent/RESULT.json')
scope_maps = {}
for d in sorted((scope_dir / 'original_pr_vs_peer_parent').glob('*_GET')):
    q, r = load(d / 'REQUEST.json'), load(d / 'RESPONSE.json')
    b = (d / 'RAW_RESPONSE.bin').read_bytes()
    assert q['method'] == 'GET' and q['host'] == 'api.github.com' and q['redirects'] == q['retries'] == 0
    assert q['authentication'] == 'NONE; no credential reads'
    assert r['status'] == 200 and r['complete_eof'] is True and r['full_bytes'] == len(b) and r['sha256'] == digest(b)
    x = json.loads(b)
    if '/git/trees/' in q['path']: scope_maps[x['sha']] = tree_response(x)
assert scope_maps == scope['canonical_trees']
assert scope['before_tree'] == peerraw.split(b'\n', 1)[0].removeprefix(b'tree ').decode()
assert scope['after_tree'] == raw_parents[OLD].split(b'\n', 1)[0].removeprefix(b'tree ').decode()
diff = {}
def diff_tree(before, after, prefix=''):
    if before == after: return
    b = scope_maps.get(before, {}) if before else {}
    a = scope_maps.get(after, {}) if after else {}
    for name in sorted(set(a) | set(b)):
        x, y = b.get(name), a.get(name)
        if x == y: continue
        path = prefix + name
        if (x is None or x['type'] == 'tree') and (y is None or y['type'] == 'tree'):
            diff_tree(x['sha'] if x else None, y['sha'] if y else None, path + '/')
        else: diff[path] = {'before': x, 'after': y}
diff_tree(scope['before_tree'], scope['after_tree'])
assert len(diff) == 22 and set(diff) == set(scope['changed_files'])
assert Q in diff and all(p == Q or p.startswith(T + '/') for p in diff)
check('raw391_and_main7_canonical_parents_original22_full_Merkle_scope_rawpeer1252_and_fresh_peer_ancestry')

C = Path(binding['candidate_directory'])
manifest = load(g['proposed_manifest']['path'])
selected = {t['path']: (C / 'proposed' / t['path']).read_bytes() for t in manifest['files']}
assert len(selected) == 69
for t in manifest['files']:
    b = selected[t['path']]
    assert len(b) == t['bytes'] and digest(b) == t['sha256']
rows = main_queue.splitlines(keepends=True)
ix = [i for i, b in enumerate(rows) if len(b.rstrip(b'\r\n').split(b'|')) > 2 and b.rstrip(b'\r\n').split(b'|')[2].strip() == b'30001080 / OWR-2093-003']
assert ix == [316]
i = ix[0]; oldrow = rows[i]; core = oldrow.rstrip(b'\r\n'); eol = oldrow[len(core):]
approved_rows = [b for b in selected[Q].splitlines() if b.split(b'|')[2:3] == [b' 30001080 / OWR-2093-003 ']]
assert len(approved_rows) == 1
before_cells, after_cells = core.split(b'|'), approved_rows[0].split(b'|')
assert len(before_cells) == len(after_cells) == 14
assert [k for k, (x, y) in enumerate(zip(before_cells, after_cells)) if x != y] == [8, 9, 11, 12]
assert after_cells[8].strip() == b'claimed_solved' and after_cells[9].strip() == b'3/5'
assert after_cells[12].strip() == b'[10.5281/zenodo.23180194](https://doi.org/10.5281/zenodo.23180194)'
expected_queue = b''.join(rows[:i]) + approved_rows[0] + eol + b''.join(rows[i + 1:])
selected[Q] = expected_queue
assert digest(expected_queue) == plan['queue_preservation']['after_whole_sha256']
assert plan['queue_preservation']['changed_cell_indices'] == [8, 9, 11, 12]
assert len(expected_queue.splitlines(keepends=True)) == len(rows)
selected_rows = [{'path': p, 'bytes': len(b), 'sha256': digest(b), 'blob': oid('blob', b)} for p, b in sorted(selected.items())]
assert selected_rows == plan['selected']
blobs = {oid('blob', b): {'content': base64.b64encode(b).decode(), 'encoding': 'base64'} for b in selected.values()}
assert len(blobs) == 63 and blobs == plan['blob_requests']
check('exact69_scientific_admin_bodies_and_fresh_full_QUEUE_only_reviewed8_9_11_12_every_other_row_byte_EOL_preserved', selected_count=69, deduplicated_blobs=63)

trie = {}
for path, b in selected.items():
    node = trie
    parts = path.split('/')
    for name in parts[:-1]: node = node.setdefault(name, {})
    node[parts[-1]] = b
newtrees = {}; preservation = []
def build(old, changes, path=''):
    before = dict(plan['trees_before'][old]) if old else {}
    after = dict(before)
    for name, value in changes.items():
        if isinstance(value, dict):
            previous = before.get(name)
            assert previous is None or previous['type'] == 'tree'
            h = build(previous['sha'] if previous else None, value, path + name + '/')
            after[name] = {'mode': '040000', 'type': 'tree', 'sha': h}
        else: after[name] = {'mode': '100644', 'type': 'blob', 'sha': oid('blob', value)}
    h = tree_hash(after)
    newtrees[h] = {'tree': [{'path': n, **t} for n, t in sorted(after.items())]}
    preservation.append({'path': path.rstrip('/') or '.', 'before': old, 'after': h, 'unselected': {n: t for n, t in before.items() if n not in changes}, 'selected_children': sorted(changes)})
    return h
for h, entries in plan['trees_before'].items(): assert tree_hash(entries) == h
assert build(plan['main_root'], trie) == TREE
assert newtrees == plan['tree_requests'] and preservation == plan['merkle_preservation'] and len(newtrees) == 13
cp = plan['commit_request']
assert set(cp) == {'message', 'tree', 'parents', 'author', 'committer'} and cp['parents'] == [OLD, MAIN] and cp['tree'] == TREE
raw = b'tree ' + TREE.encode() + b'\n' + b''.join(b'parent ' + h.encode() + b'\n' for h in [OLD, MAIN])
for role in ['author', 'committer']:
    person = cp[role]
    dt = datetime.fromisoformat(person['date'])
    assert dt.utcoffset() == timedelta(0) and dt.microsecond == 0
    raw += f"{role} {person['name']} <{person['email']}> {int(dt.timestamp())} +0000\n".encode()
raw += b'\n' + cp['message'].encode()
assert raw == base64.b64decode(plan['commit_raw_base64'], validate=True) and len(raw) == 538 and oid('commit', raw) == HEAD
check('independent_full_canonical_tree_overlay_all_unselected_main7_siblings_and_complete_two_parent_commit_serialization', rebuilt_trees=13, commit_raw_bytes=len(raw))

rc = catalog(RUN, {'path': str(RUN / 'FULL_CATALOG.json'), 'bytes': 345410, 'sha256': '98e635c992a50eb9b590c366d17cd525aa049f4583ea2363a5d5c458a1d95c88', 'mode': 0o444})
oc = catalog(OUTER, {'path': str(OUTER / 'FULL_CATALOG.json'), 'bytes': 1597, 'sha256': '489b4f492e57254aa95466dcfd0a9e99ed614d184aac6b57099d3980fbc91567', 'mode': 0o444})
q, s, e, streams = native(OUTER / 'private/native/actual_execute')
assert (q['actual_recorder_PID'], e['actual_child_PID']) == (72339, 72340)
assert q['argv'] == ['/opt/homebrew/bin/python3', '-B', str(S / 'actor.py'), 'execute', '--run-dir', str(RUN), '--plan', pp['path'], '--plan-sha256', pp['sha256'], '--grant', gp['path'], '--grant-sha256', gp['sha256']]
assert q['script_arguments'] == [sources['actor.py'], pp, gp]
assert q['context']['ROOT_grant'] == gp and q['context']['source_and_plan_review'] == g['source_and_plan_review'] and q['context']['source_catalog'] == g['source_catalog'] and q['context']['sources'] == sources
assert q['context']['actual_ROOT_recorder_PID'] == 72339 and q['context']['one_use_branch_CAS_only'] is True
assert q['timeout_seconds'] == 900 and q['cleanup_timeout_seconds'] == 5
assert streams['stderr'] == b''
result = load(RUN / 'RESULT.json')
assert json.loads(streams['stdout']) == result
assert pin(RUN / 'RESULT.json')['sha256'] == '746362bb8433a85317c0294a329d43938c3c3d4e94508ede8a04ec68efb029a8'
assert result['status'] == 'BRANCH_CONTENT_CAS_AND_FULL_READBACK_SUCCEEDED_PENDING_ROOT_ADVERSARY'
assert (result['head'], result['tree'], result['parents']) == (HEAD, TREE, [OLD, MAIN])
assert result['ref_updates'] == 1 and result['metadata_writes'] == 0 and result['execution_does_not_clear_metadata_ready_merge_or_publication'] is True and result['grant'] == gp
consumed = load(RUN / 'ONE_TIME_NONCE_CONSUMED.json')
assert consumed['grant'] == gp and consumed['nonce'] == NONCE and consumed['actual_PID'] == 72340 and consumed['automatic_retry'] is False
issued, expiry = [datetime.fromisoformat(g[k]) for k in ['issued_UTC', 'expires_UTC']]
assert expiry - issued == timedelta(minutes=30) and issued <= datetime.fromisoformat(consumed['UTC']) < datetime.fromisoformat(result['UTC']) < expiry
check('entire_closed_actual_RUN_and_ROOT_outer_full_native_context_result_source_pins_one_use_nonce_terminal')

workers = [worker(d, 72340) for d in sorted((RUN / 'private/native').iterdir())]
assert len(workers) == len(rc['native']) == 262
assert [w['dir'].name for w in workers] == [f"{i:04d}_{w['envelope']['method']}" for i, w in enumerate(workers, 1)]
assert len({w['execution']['actual_child_PID'] for w in workers}) == 262
assert workers[0]['execution']['actual_child_PID'] == 72341 and workers[-1]['execution']['actual_child_PID'] == 76004
for w, t in zip(workers, rc['native']):
    assert t == {'label': w['dir'].name, 'recorder_PID': 72340, 'child_PID': w['execution']['actual_child_PID'], 'returncode': 0}
    env = w['envelope']
    if env['method'] == 'GET':
        assert env['payload'] is None and env['authority'] is None and env['mutation_ordinal'] is None and env['execution_authority'] is False
        assert env['path'] in ['user', 'repos/AlecKriebel/Math', 'repos/AlecKriebel/Math/pulls/284', P + 'ref/heads/main', P + 'ref/heads/dot/math-30001080'] or re.fullmatch(re.escape(P) + r'(commits|trees|blobs)/[0-9a-f]{40}', env['path']) or w['public']
    else:
        assert env['method'] == 'POST' and env['execution_authority'] is True
        assert env['authority'] == {'grant': gp, 'plan': pp, 'run_directory': str(RUN)}
    assert q['time_ns'] < w['request']['time_ns'] < w['execution']['time_ns'] < e['time_ns']
check('all262_actual_worker_children_full_six_artifacts_executable_argv_cwd_stdin_streams_source_context_PIDs_exit_wait_reap_typed_policies', credentialless=sum(w['public'] for w in workers), authenticated=sum(not w['public'] for w in workers))

expected = [('POST', P + 'blobs', payload, h) for h, payload in sorted(blobs.items())]
pending = dict(newtrees)
while pending:
    ready = sorted(h for h, payload in pending.items() if all(t['type'] != 'tree' or t['sha'] not in pending for t in payload['tree']))
    assert ready
    for h in ready: expected.append(('POST', P + 'trees', pending.pop(h), h))
expected.append(('POST', P + 'commits', cp, HEAD))
cas = {'query': 'mutation PR284AuthorBranchExactCAS($input:UpdateRefsInput!){updateRefs(input:$input){clientMutationId}}', 'variables': {'input': {'repositoryId': 'R_kgDOTfIvPw', 'refUpdates': [{'name': 'refs/heads/dot/math-30001080', 'beforeOid': OLD, 'afterOid': HEAD, 'force': False}], 'clientMutationId': 'pr284_' + NONCE}}}
expected.append(('POST', 'graphql', cas, None))
posts = [w for w in workers if w['envelope']['method'] == 'POST']
assert len(posts) == len(expected) == 78
assert len(list(RUN.glob('WORKER_MUTATION_*_STARTED.json'))) == len(list(RUN.glob('WORKER_MUTATION_*_RESULT.json'))) == 78
assert len(list(RUN.glob('ACTOR_MUTATION_*_READBACK_COMPLETE.json'))) == 77
gaps = []
for i, (w, item) in enumerate(zip(posts, expected)):
    method, route, payload, h = item
    env = w['envelope']
    assert (env['method'], env['path'], env['payload'], env['mutation_ordinal']) == (method, route, payload, i)
    started = load(RUN / f'WORKER_MUTATION_{i:04d}_STARTED.json')
    saved = load(RUN / f'WORKER_MUTATION_{i:04d}_RESULT.json')
    assert started['ordinal'] == i and started['actual_worker_PID'] == w['execution']['actual_child_PID'] and started['grant'] == gp and started['automatic_retry'] is False
    assert saved == w['worker_result']
    assert issued <= datetime.fromisoformat(started['UTC']) < expiry - timedelta(seconds=75)
    assert started['time_ns'] < saved['credential_metadata']['time_ns'] < saved['time_ns']
    if i:
        gap = w['request']['time_ns'] - posts[i - 1]['execution']['time_ns']
        assert gap >= 1000000000
        gaps.append(gap)
    if h:
        assert w['data']['sha'] == h
        marker = load(RUN / f'ACTOR_MUTATION_{i:04d}_READBACK_COMPLETE.json')
        assert marker == {'mutation_ordinal': i, 'canonical_object': h, 'complete_full_readback': True}
        position = workers.index(w)
        later = workers[position + 1: workers.index(posts[i + 1])]
        readback_route = route + '/' + h
        readbacks = [r for r in later if r['envelope']['method'] == 'GET' and r['envelope']['path'] == readback_route]
        assert len(readbacks) == 1
        rb = readbacks[0]['data']
        if route.endswith('/blobs'): assert blob_response(rb) == base64.b64decode(payload['content'], validate=True)
        elif route.endswith('/trees'): assert tree_response(rb) == {t['path']: {k: t[k] for k in ['mode', 'type', 'sha']} for t in payload['tree']}
        else: assert rb['sha'] == HEAD and rb['tree']['sha'] == TREE and [p['sha'] for p in rb['parents']] == [OLD, MAIN]
    else:
        assert w['data'] == {'data': {'updateRefs': {'clientMutationId': 'pr284_' + NONCE}}}
intent = load(RUN / 'FINAL_CAS_INTENT.json')
assert intent['beforeOid'] == OLD and intent['afterOid'] == HEAD and intent['main_before'] == MAIN and intent['force'] is False and intent['automatic_retry'] is False and intent['maximum_ref_updates'] == 1 and intent['grant'] == gp
assert intent['time_ns'] < posts[-1]['request']['time_ns']
check('exact78_serial_POSTs_63blobs_13trees_commit_one_expectedold_forceFalse_CAS_all_consumed_77_full_readbacks_before_next_no_retry', minimum_post_gap_ns=min(gaps))

pre = workers[:workers.index(posts[0])]
for h, c in plan['commits_before'].items():
    found = [w['data'] for w in pre if w['envelope']['path'] == P + 'commits/' + h]
    assert found == [c]
for h, rows in plan['trees_before'].items():
    found = [w['data'] for w in pre if w['envelope']['path'] == P + 'trees/' + h]
    assert len(found) == 1 and tree_response(found[0]) == rows
for h, b in plan['blobs_before'].items():
    found = [w['data'] for w in pre if w['envelope']['path'] == P + 'blobs/' + h]
    assert len(found) == 1 and blob_response(found[0]) == base64.b64decode(b, validate=True)
for key, x in plan['ancestry_before'].items():
    found = [w['data'] for w in pre if w['envelope']['path'] == 'repos/AlecKriebel/Math/compare/' + key + '?per_page=1&page=2']
    assert found == [x]
check('complete_actual_before_write_frozen_parent_ancestry_tree_blob_inputs_equal_plan_immutables')

def identity_group(group, head):
    assert [w['envelope']['path'] for w in group] == ['user', 'repos/AlecKriebel/Math', 'repos/AlecKriebel/Math/pulls/284', P + 'ref/heads/dot/math-30001080', P + 'ref/heads/main']
    u, r, pr, branch, mainref = [w['data'] for w in group]
    assert u['login'] == 'AlecKriebel' and u['id'] == 6109370
    assert r['id'] == 1307717439 and r['node_id'] == 'R_kgDOTfIvPw' and r['full_name'] == 'AlecKriebel/Math' and r['default_branch'] == 'main' and r['archived'] is False and r['permissions']['push'] is True
    assert pr['number'] == 284 and pr['id'] == 4705883104 and pr['node_id'] == 'PR_kwDOTfIvP88AAAABGH4T4A' and pr['state'] == 'open' and pr['draft'] is True and pr['merged'] is False
    assert pr['head']['sha'] == head and pr['head']['ref'] == 'dot/math-30001080' and pr['base']['ref'] == 'main'
    for side in ['head', 'base']: assert pr[side]['repo']['id'] == 1307717439 and pr[side]['repo']['node_id'] == 'R_kgDOTfIvPw'
    assert branch['ref'] == 'refs/heads/dot/math-30001080' and branch['object']['sha'] == head and branch['object']['type'] == 'commit'
    assert mainref['ref'] == 'refs/heads/main' and mainref['object']['sha'] == MAIN and mainref['object']['type'] == 'commit'
    return pr
identity_group(workers[:5], OLD)
cas_pos = workers.index(posts[-1])
identity_group(workers[cas_pos - 5:cas_pos], OLD)
final_pr = identity_group(workers[cas_pos + 1:cas_pos + 6], HEAD)
tail = workers[cas_pos + 6:]
assert tail[0]['envelope']['path'] == P + 'commits/' + HEAD
after_commit = tail[0]['data']
assert after_commit['sha'] == HEAD and after_commit['tree']['sha'] == TREE and [p['sha'] for p in after_commit['parents']] == [OLD, MAIN]
assert after_commit['message'] == cp['message'].rstrip('\n')
for role in ['author', 'committer']:
    assert after_commit[role]['name'] == cp[role]['name'] and after_commit[role]['email'] == cp[role]['email']
    assert datetime.fromisoformat(after_commit[role]['date'].replace('Z', '+00:00')) == datetime.fromisoformat(cp[role]['date'])
final_maps = {}; final_blobs = {}
for w in tail[1:]:
    route, data = w['envelope']['path'], w['data']
    if '/trees/' in route: final_maps[data['sha']] = tree_response(data)
    elif '/blobs/' in route: final_blobs[data['sha']] = blob_response(data)
    else: raise AssertionError('unexpected final operation')
assert set(final_maps) == set(newtrees) and len(final_maps) == 13
assert set(final_blobs) == set(blobs) and len(final_blobs) == 63
for h, payload in newtrees.items(): assert final_maps[h] == {t['path']: {k: t[k] for k in ['mode', 'type', 'sha']} for t in payload['tree']}
for h, payload in blobs.items(): assert final_blobs[h] == base64.b64decode(payload['content'], validate=True)
def locate(path):
    h = TREE
    parts = path.split('/')
    for i, name in enumerate(parts):
        t = final_maps[h][name]
        if i == len(parts) - 1: return t
        assert t['type'] == 'tree' and t['mode'] == '040000'
        h = t['sha']
for path, b in selected.items():
    t = locate(path)
    assert t == {'mode': '100644', 'type': 'blob', 'sha': oid('blob', b)} and final_blobs[t['sha']] == b
leaves = {}
def walk(h, prefix):
    for name, t in final_maps[h].items():
        path = prefix + '/' + name
        if t['type'] == 'tree': walk(t['sha'], path)
        else: leaves[path] = t
walk(locate(T)['sha'], T)
assert set(leaves) == set(selected) - {Q}
check('complete_postCAS_exact_open_draft_PR_refs_currentmain_preserved_full_commit_13trees_63fullblobs_all69_selected_and_unselected_siblings', final_readback_children=len(tail) + 5)

for t in baseline['protected_complete_body_pins']: exact(t)
assert len(posts) == 78 and all(w['envelope']['method'] in ['GET', 'POST'] for w in workers)
check('protected589_public_math_readiness5_DOI23180194_trackerrow30_admin69_unchanged_no_extra_mutation_or_authority')

native_index = []
for w in workers:
    d = w['dir']
    native_index.append({'label': d.name, 'actual_recorder_PID': 72340, 'actual_worker_PID': w['execution']['actual_child_PID'], 'credential_child_PID': w['worker_result']['credential_metadata']['actual_child_PID'], 'method': w['envelope']['method'], 'path': w['envelope']['path'], 'mutation_ordinal': w['envelope']['mutation_ordinal'], 'argv': w['request']['argv'], 'cwd': w['request']['cwd'], 'six_actual_artifact_pins': [pin(d / n) for n in ['request.json', 'started.json', 'execution.json', 'stdin.gz', 'stdout.gz', 'stderr.gz']], 'complete_success_exit0_wait_reap': True})
output = {
    'schema': 'independent-actual-author-branch-full-evidence-checks-v1',
    'UTC': datetime.now(timezone.utc).isoformat(),
    'actual_PID': os.getpid(),
    'all_passed': True,
    'check_count': len(checks),
    'checks': checks,
    'blocking_findings': [],
    'actual_author_branch_result_accepted': True,
    'actual_author_branch_correction_accepted': True,
    'ROOT_acceptance_issued': False,
    'execution_authority': False,
    'baseline': pin(A / 'BASELINE.json'),
    'PLAN4pin': pp,
    'binding4pin': bp,
    'grant4pin_terminal_NEVER_REPLAY': gp,
    'source_catalog4pin': pin(S / 'FULL_CATALOG.json'),
    'source_acceptance4pin': pin(W / 'ROOT_AUTHOR_BRANCH_SOURCE_ACCEPTANCE_08.json'),
    'plan_ROOT_review4pin': pin(W / 'ROOT_PR284_AUTHOR_ACTOR_PLAN_REVIEW_01.json'),
    'sources4pins': sources,
    'actual_RUN_catalog4pin': pin(RUN / 'FULL_CATALOG.json'),
    'actual_result4pin': pin(RUN / 'RESULT.json'),
    'actual_ROOT_outer_catalog4pin': pin(OUTER / 'FULL_CATALOG.json'),
    'actual_ROOT_outer_execution4pin': pin(OUTER / 'private/native/actual_execute/execution.json'),
    'frozen_main7_catalog4pin': pin(main_dir / 'FULL_CATALOG.json'),
    'frozen_main7_result4pin': pin(main_dir / 'RESULT.json'),
    'canonical_result': {'head': HEAD, 'tree': TREE, 'ordered_parents': [OLD, MAIN], 'commit_complete_canonical_bytes': len(raw), 'commit_complete_canonical_sha256': digest(raw), 'selected_count': 69, 'immutable_objects': 77, 'POSTs': 78, 'ref_updates': 1, 'actual_worker_children': 262},
    'selected_final_full_body_pins': selected_rows,
    'minimum_serial_mutation_gap_ns': min(gaps),
    'actual_nonce_consumed': pin(RUN / 'ONE_TIME_NONCE_CONSUMED.json'),
    'actual_final_CAS_intent': pin(RUN / 'FINAL_CAS_INTENT.json'),
    'complete_native_index': native_index,
    'main7_provenance_timing': 'Main7 native evidence was produced before ROOT grant/actual CAS. This reviewer received status beforehand but first independently read it after actual completion, before own actual checks. Historical own main5 baseline and all589 protected bodies are retained, not replaced or a runtime grant.',
    'historical_plan_review_arithmetic_note': 'Earlier source-only plan adversary02 says79 future POSTs. Independent exact plan and complete actual transcript establish78 =63blobs+13trees+commit+CAS. That arithmetic statement is not relied on for authority or actual acceptance.',
    'raw_final_commit_custody_qualification': 'Complete final canonical bytes are rebuilt from authorized immutable POST payload, equal preserved plan bytes, hash to the authenticated returned/read-back Git object SHA1, and match full identities/message. Both existing parents use separately captured actual raw Git bytes. No fresh raw-final Git fetch or remote call was made by reviewer.',
    'credential_capture_qualification': 'Authenticated credential child process custody is complete; secret stdout/stderr values were intentionally not retained by the approved worker. This review does not recover, read or fabricate those streams. Complete retained HTTP bodies have accepted finite/typed screening metadata.',
    'no_live_operations_by_reviewer': True,
    'no_third_math_review_or_broad_source_fixture_suite': True,
    'scope': 'Exact completed branch content/CAS/full evidence readback only. Separate literal ROOT branch acceptance is still required. No metadata/readiness/merge/close/release/publication/tracker authority.'
}
with (A / 'ACTUAL_BRANCH_REVIEW_RESULTS.json').open('xb') as f:
    f.write((json.dumps(output, indent=2) + '\n').encode())
print(json.dumps({'passed': True, 'checks': len(checks), 'actual_workers': 262, 'actual_POSTs': 78, 'actual_PID': os.getpid(), 'protected': 589}))
