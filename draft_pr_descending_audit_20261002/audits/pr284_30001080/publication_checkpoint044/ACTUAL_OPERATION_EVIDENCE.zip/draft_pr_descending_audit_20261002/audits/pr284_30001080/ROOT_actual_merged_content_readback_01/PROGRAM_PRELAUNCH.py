"""Read-only exact native merged tree/QUEUE preservation proof; no mutation."""
from pathlib import Path
from datetime import datetime,timezone
import base64,hashlib,importlib.util,json,os,sys
assert sys.flags.ignore_environment and sys.dont_write_bytecode and not sys.flags.optimize
W=Path(__file__).resolve().parent;R=W.parents[2];O=W/'ROOT_actual_merged_content_readback_01';O.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':p.stat().st_mode&0o777}
H=W.parent/'pr288_30001994/metadata_completion_preparation_01/native_capture.py';assert sha(H.read_bytes())=='d8ccb5a9609448717c8785a19e161526b9e168f681a0499d734c4220fd4fbe9d';s=importlib.util.spec_from_file_location('ROOT284merge_native3993',H);N=importlib.util.module_from_spec(s);s.loader.exec_module(N)
(O/'PROGRAM_PRELAUNCH.py').write_bytes(Path(__file__).read_bytes());(O/'NATIVE_HELPER_PRELAUNCH.py').write_bytes(H.read_bytes())
gh='/opt/homebrew/Cellar/gh/2.85.0/bin/gh';assert sha(Path(gh).read_bytes())=='91f6e182bce24da56581ab999088c55ae0216309af19bc6167bbc4396c3f4ea5'
for k in list(os.environ):
 if k in ('GH_DEBUG','GITHUB_DEBUG','DEBUG','NODE_DEBUG') or k.startswith('GIT_TRACE'):os.environ.pop(k,None)
os.environ.update(GH_NO_UPDATE_NOTIFIER='1',GH_PROMPT_DISABLED='1',GH_PAGER='cat',GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1')
n=0
def get(path):
 global n;n+=1;return json.loads(N.call(O,f'{n:04d}_GET',[gh,'api','--hostname','github.com','--method','GET','--header','Accept: application/vnd.github+json','--header','X-GitHub-Api-Version: 2022-11-28',path],timeout=55,cleanup_timeout=5))
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
Q='unsolved_math_prioritization/QUEUE.md';T='unsolved_math_prioritization/attempts/30001080';G='repos/AlecKriebel/Math/git/'
head='7d244eed5d7ddd89d5c540aecfa72490b7b30073';merge='9d634abcc7a0758f0b2526b88b0a302a9d562b57';parent='735a11defdf906d1552912815810ff72779874a7'
ac=load(W/'ROOT_PR284_ACTUAL_AUTHOR_BRANCH_ACCEPTANCE_01.json');assert ac['accepted'] is True and ac['head']==head and ac['unresolved_issues']==[]
P=load(ac['plan']['path']);selected={x['path']:x for x in P['selected']}
pr=get('repos/AlecKriebel/Math/pulls/284');assert pr['number']==284 and pr['id']==4705883104 and pr['merged'] is True and pr['state']=='closed' and pr['draft'] is False and pr['head']['sha']==head and pr['merge_commit_sha']==merge and pr['base']['ref']=='main'
M=W/'pr284_final_pr_metadata_preparation_03';assert pr['title']==(M/'PR_TITLE.txt').read_text().removesuffix('\n') and pr['body']==(M/'PR_BODY.md').read_text()
mc=get(G+'commits/'+merge);pc=get(G+'commits/'+parent);assert mc['sha']==merge and [x['sha'] for x in mc['parents']]==[parent,head] and mc==load(W/'ROOT_final_PR284_merge_01/MERGED_COMMIT.json')
trees={};fetched={}
def canonical(x):
 assert x['truncated'] is False;rows={z['path']:{k:z[k] for k in ('mode','type','sha')} for z in x['tree']};assert len(rows)==len(x['tree']);raw=b''
 for name,z in sorted(rows.items(),key=lambda kv:kv[0].encode()+(b'/' if kv[1]['type']=='tree' else b'')):
  assert name and '/' not in name and '\0' not in name;raw+=z['mode'].lstrip('0').encode()+b' '+name.encode()+b'\0'+bytes.fromhex(z['sha'])
 assert oid('tree',raw)==x['sha'];return rows
def tree(h):
 if h not in trees:
  x=get(G+'trees/'+h);assert x['sha']==h;trees[h]=canonical(x);fetched[h]=x
 return trees[h]
before_root=pc['tree']['sha'];after_root=mc['tree']['sha'];before=tree(before_root);after=tree(after_root)
preserved=[]
def siblings(a,b,changed,path):
 assert set(a)-set(changed)==set(b)-set(changed)
 assert {n:z for n,z in a.items() if n not in changed}=={n:z for n,z in b.items() if n not in changed};preserved.append({'path':path,'unselected':{n:z for n,z in a.items() if n not in changed}})
siblings(before,after,['unsolved_math_prioritization'],'.')
br=tree(before['unsolved_math_prioritization']['sha']);ar=tree(after['unsolved_math_prioritization']['sha']);siblings(br,ar,['QUEUE.md','attempts'],'unsolved_math_prioritization')
bt=tree(br['attempts']['sha']);at=tree(ar['attempts']['sha']);siblings(bt,at,['30001080'],'unsolved_math_prioritization/attempts');assert '30001080' not in bt
approved={h:canonical({'sha':h,'truncated':False,'tree':z['tree']}) for h,z in P['tree_requests'].items()}
def locate(h,path,maps):
 parts=path.split('/')
 for i,n in enumerate(parts):
  x=maps[h][n]
  if i==len(parts)-1:return x
  assert x['mode']=='040000' and x['type']=='tree';h=x['sha']
expected_target=locate(P['after_root'],T,approved);assert at['30001080']==expected_target and expected_target['mode']=='040000'
leaves={}
def walk(h,p):
 for n,x in approved[h].items():
  if x['type']=='tree':walk(x['sha'],p+'/'+n)
  else:leaves[p+'/'+n]=x
walk(expected_target['sha'],T);assert set(leaves)==set(selected)-{Q}
for p,x in leaves.items():assert x=={'mode':'100644','type':'blob','sha':selected[p]['blob']}
def fullblob(h):
 x=get(G+'blobs/'+h);assert x['sha']==h and x['encoding']=='base64';b=base64.b64decode(x['content']);assert len(b)==x['size'] and oid('blob',b)==h;return b
beforeq=fullblob(br['QUEUE.md']['sha']);afterq=fullblob(ar['QUEUE.md']['sha']);(O/'BEFORE_MAIN_QUEUE_FULL.bin').write_bytes(beforeq);(O/'AFTER_MERGED_QUEUE_FULL.bin').write_bytes(afterq)
def matchrow(z):return len(z.split(b'|'))>2 and z.split(b'|')[2].strip()==b'30001080 / OWR-2093-003'
brows=beforeq.splitlines(keepends=True);arows=afterq.splitlines(keepends=True);bi=[i for i,z in enumerate(brows) if matchrow(z)];ai=[i for i,z in enumerate(arows) if matchrow(z)];assert bi==ai and len(bi)==1;i=bi[0];assert len(brows)==len(arows) and all(x==y for j,(x,y) in enumerate(zip(brows,arows)) if j!=i)
bcore=brows[i].rstrip(b'\r\n');acore=arows[i].rstrip(b'\r\n');bc,acells=bcore.split(b'|'),acore.split(b'|');assert len(bc)==len(acells)==14 and [k for k,(x,y) in enumerate(zip(bc,acells)) if x!=y]==[8,9,11,12] and bc[8].strip()==b'queued' and bc[9].strip()==b'0/5' and acells[8].strip()==b'claimed_solved' and acells[9].strip()==b'3/5'
assert brows[i][len(bcore):]==arows[i][len(acore):] and sha(acore)==P['expected_main_queue_transition']['after_row_sha256']
assert acells[12].strip()==b'[10.5281/zenodo.23180194](https://doi.org/10.5281/zenodo.23180194)'
result={'status':'ROOT_VERIFIES_EXACT_NATIVE_PR284_MERGED_CONTENT','UTC':datetime.now(timezone.utc).isoformat(),'actual_ROOT_PID':os.getpid(),'actual_argv':sys.orig_argv,'merge_commit':merge,'head':head,'ordered_merge_parents':[parent,head],'before_actual_main_tree':before_root,'merged_tree':after_root,'complete_canonical_changed_ancestor_trees':fetched,'all_unselected_actual_main_siblings_preserved':preserved,'exact_approved68_target_leaves':leaves,'approved_target_tree':expected_target,'QUEUE_before':pin(O/'BEFORE_MAIN_QUEUE_FULL.bin'),'QUEUE_after':pin(O/'AFTER_MERGED_QUEUE_FULL.bin'),'exact_reviewed_row_only_changed':True,'selected69_science_admin_and_own_QUEUE_row_preserved':True,'PR_closed_merged_and_exact_metadata':True,'read_only_actual_native_GETs':n,'remote_mutations':0,'execution_authority':False,'unresolved_issues':[]}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'merge':merge,'GETs':n,'preserved_selected_paths':69,'new_publication_tracker_or_ref_writes':0}))
