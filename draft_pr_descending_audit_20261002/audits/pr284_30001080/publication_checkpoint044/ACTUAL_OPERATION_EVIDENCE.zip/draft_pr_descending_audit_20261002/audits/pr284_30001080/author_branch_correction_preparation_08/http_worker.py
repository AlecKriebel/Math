"""One authenticated request or exact credentialless fixed page2 comparison.
No redirects, retries or header debug.
Token acquisition is a special secret-in-memory read, not an evidence capture:
credential stdout/stderr are intentionally never persisted, hashed or echoed.
Only truthful nonsensitive child PID/argv/executable/exit/reap metadata is emitted.
Import is pure. Preparation tests supply an in-memory fake connection/credential.
"""
import base64,hashlib,http.client,json,math,os,pathlib,re,signal,ssl,stat,subprocess,sys,time,urllib.parse
GH='/opt/homebrew/bin/gh'; HOST='api.github.com'
MAX_RESPONSE_BYTES=8*1024*1024
MAX_SCREEN_BYTES=32*1024*1024
MAX_SCREEN_ITEMS=65536
MAX_JSON_DEPTH=64
MAX_DECODE_DEPTH=4
class ScreenUnknown(Exception):pass
class CredentialEchoDetected(Exception):pass
def screen_response(raw,token):
    """Bounded, reversible-encoding screening BEFORE any body/hash retention.
    Supported: strict UTF-8 JSON with decoded keys/strings, raw token, standard
    and URL-safe base64 (padded/unpadded, whole-field whitespace), hexadecimal
    of either case (whole-field whitespace), and strict percent bytes. Recursively
    inspect recognized byte decodings (including opaque binary) up to four rounds; exceeding budgets/depth, malformed
    JSON/percent/declared base64, residual textual Unicode/hex escapes, surrogate
    text, and ambiguous JSON structures are UNKNOWN without body evidence.
    Opaque binary is screened for the same ASCII-advertised reversible forms,
    including valid percent transformations and nested base64/hex/percent.
    Complete ASCII Unicode/hex escape syntax in opaque binary is UNKNOWN;
    incomplete random binary escape bytes are literal. Nonfinite parsed floats,
    including exponent overflow, are UNKNOWN.
    Maximal base64 runs use four starting phases/up to3 trailing trims; hex
    runs use two phases/up to1 trim, in raw and bounded whitespace-compacted
    bytes (including opaque binary). Generation and scanning share bounded
    byte/item expansion before scheduling, with deduplication.
    No claim covers arbitrary codecs, compression, ciphers, split-field encoding
    or undisclosed transformations. This function returns no body, digest or text.
    """
    secret=token.encode('ascii');hexsecret=secret.hex().encode()
    baseforms=[base64.b64encode(secret),base64.urlsafe_b64encode(secret)]
    baseforms+=[x.rstrip(b'=') for x in baseforms]
    def hit(b):return secret in b or hexsecret in b.lower() or any(x in b for x in baseforms)
    def pairs(rows):
        out={}
        for k,v in rows:
            if k in out:raise ScreenUnknown('duplicate JSON key')
            out[k]=v
        return out
    try:
        if len(raw)>MAX_RESPONSE_BYTES:raise ScreenUnknown('response byte budget')
        if hit(raw):return {'safe':False,'reason':'CREDENTIAL_ECHO'}
        value=json.loads(raw.decode('utf-8',errors='strict'),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ScreenUnknown('nonfinite JSON')))
        if not isinstance(value,dict):raise ScreenUnknown('unexpected API JSON root')
        seeds=[];stack=[(value,0)];count=0
        while stack:
            x,depth=stack.pop();count+=1
            if depth>MAX_JSON_DEPTH or count>MAX_SCREEN_ITEMS:raise ScreenUnknown('JSON structure budget')
            if isinstance(x,dict):
                for k,v in x.items():seeds.append(k.encode('utf-8',errors='strict'));stack.append((v,depth+1))
            elif isinstance(x,list):stack.extend((v,depth+1) for v in x)
            elif isinstance(x,str):seeds.append(x.encode('utf-8',errors='strict'))
            elif type(x) is float:
                if not math.isfinite(x):raise ScreenUnknown('nonfinite parsed JSON float')
            elif x is None or type(x) in (bool,int):pass
            else:raise ScreenUnknown('unexpected JSON value')
        # Explicitly declared Git blob encoding must be well formed before it
        # can reach later object validation or complete-response evidence.
        declared=None
        if value.get('encoding')=='base64':
            content=value.get('content')
            if not isinstance(content,str):raise ScreenUnknown('declared base64 content')
            cleaned=re.sub(r'\s+','',content)
            declared=base64.b64decode(cleaned,validate=True)
        initial=[(b,0) for b in seeds]+([] if declared is None else [(declared,1)])
        pending=[];scheduled=set();seen=set();expanded=0;used=0;items=0
        for b,depth in initial:
            if b not in scheduled:
                expanded+=len(b);scheduled.add(b);pending.append((b,depth))
        if expanded>MAX_SCREEN_BYTES or len(scheduled)>MAX_SCREEN_ITEMS:raise ScreenUnknown('decoded expansion budget')
        def admit(z,depth):
            nonlocal expanded
            if hit(z):raise CredentialEchoDetected()
            if not z or z in scheduled:return
            if depth>=MAX_DECODE_DEPTH:raise ScreenUnknown('recognized decoding exceeds bounded depth')
            expanded+=len(z)
            if expanded>MAX_SCREEN_BYTES or len(scheduled)>=MAX_SCREEN_ITEMS:raise ScreenUnknown('decoded expansion budget')
            scheduled.add(z);pending.append((z,depth+1))
        while pending:
            b,depth=pending.pop()
            if hit(b):return {'safe':False,'reason':'CREDENTIAL_ECHO'}
            if b in seen:continue
            seen.add(b);used+=len(b);items+=1
            if used>MAX_SCREEN_BYTES or items>MAX_SCREEN_ITEMS:raise ScreenUnknown('decoded screening budget')
            try:text=b.decode('utf-8',errors='strict')
            except UnicodeDecodeError:text=None
            if (text is not None and re.search(r'\\[uUxX](?:[0-9a-fA-F]|\{|$)',text)) or (text is None and re.search(rb'\\(?:u[0-9a-fA-F]{4}|U[0-9a-fA-F]{8}|x[0-9a-fA-F]{2})',b)):raise ScreenUnknown('unhandled residual textual escape')
            if b'%' in b:
                if text is not None and text.lstrip().startswith('%') and re.search(r'%(?![0-9a-fA-F]{2})',text):raise ScreenUnknown('malformed percent field')
                if re.search(rb'%[0-9a-fA-F]{2}',b):
                    z=re.sub(rb'%([0-9a-fA-F]{2})',lambda m:bytes.fromhex(m.group(1).decode('ascii')),b)
                    if z!=b:admit(z,depth)
            candidates=set(re.findall(rb'[A-Za-z0-9_+/\-]{16,}={0,2}',b))
            compact=re.sub(r'\s+','',text).encode('utf-8') if text is not None else re.sub(rb'[ \t\r\n\v\f]+',b'',b)
            candidates.update(re.findall(rb'[A-Za-z0-9_+/\-]{16,}={0,2}',compact))
            if len(compact)>=16 and re.fullmatch(rb'[A-Za-z0-9_+/\-]+={0,2}',compact):candidates.add(compact)
            for c in candidates:
                # Four starting phases and up to three trailing trims handle
                # maximal runs joined by adjacent alphabet bytes. Never search
                # arbitrary substrings: these16 strict decodings are bounded.
                for phase in range(4):
                    for trim in range(4):
                        part=c[phase:len(c)-trim if trim else None]
                        if len(part)<16 or len(part)%4==1:continue
                        try:z=base64.b64decode(part+b'='*((-len(part))%4),altchars=b'-_',validate=True)
                        except (ValueError,base64.binascii.Error):continue
                        if z!=b:admit(z,depth)
            hexcandidates=set(re.findall(rb'[0-9a-fA-F]{16,}',b))
            hexcandidates.update(re.findall(rb'[0-9a-fA-F]{16,}',compact))
            if len(compact)>=16 and re.fullmatch(rb'[0-9a-fA-F]+',compact):hexcandidates.add(compact)
            for c in hexcandidates:
                # Two nibble phases/trims; exact analogous embedded-hex boundary.
                for phase in range(2):
                    for trim in range(2):
                        part=c[phase:len(c)-trim if trim else None]
                        if len(part)<16 or len(part)%2:continue
                        z=bytes.fromhex(part.decode('ascii'))
                        if z!=b:admit(z,depth)
        return {'safe':True,'reason':'BOUNDED_POLICY_PASS','decode_depth_limit':MAX_DECODE_DEPTH}
    except CredentialEchoDetected:
        return {'safe':False,'reason':'CREDENTIAL_ECHO'}
    except BaseException:
        # Never retain parser/decoder exception strings or the offending value.
        return {'safe':False,'reason':'MALFORMED_UNHANDLED_OR_BUDGET_UNKNOWN'}
def sha(b):return hashlib.sha256(b).hexdigest()
def executable_pin(p):
    p=pathlib.Path(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
def credential():
    argv=[GH,'auth','token','--hostname','github.com'];meta={'actual_parent_PID':os.getpid(),'argv':argv,'executable':executable_pin(GH),'time_ns':time.time_ns(),'secret_streams':'INTENTIONALLY_UNRETAINED_IN_MEMORY_ONLY','secret_stream_full_capture_claim':False,'environment_recorded':False}
    p=None;token=None;out=b'';err=b'';failure=False;complete=False;waited=False;cleanup=[]
    try:
        p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        meta['actual_child_PID']=p.pid;out,err=p.communicate(timeout=10);complete=True
    except BaseException as e:failure=True;meta['failure_type']=type(e).__name__
    finally:
        if p is not None and not complete:
            try:os.killpg(p.pid,signal.SIGKILL)
            except BaseException as e:cleanup.append({'stage':'signal_group','type':type(e).__name__})
            try:out,err=p.communicate(timeout=5);complete=True
            except BaseException as e:cleanup.append({'stage':'collect','type':type(e).__name__})
        if p is not None:
            try:p.wait(timeout=5);waited=True
            except BaseException as e:cleanup.append({'stage':'wait','type':type(e).__name__})
        meta.update(actual_child_PID=p.pid if p else None,returncode=p.returncode if p else None,reaped=p is not None and p.returncode is not None and (waited or complete),communication_complete=complete,wait_completed=waited,cleanup_errors=cleanup,secret_stdout_bytes=len(out),secret_stderr_bytes=len(err))
    if not failure and not cleanup and complete and meta['reaped'] and meta['returncode']==0:
        value=out.strip()
        if value and not any(c in value for c in b'\r\n\0'):
            try:token=value.decode('ascii')
            except UnicodeDecodeError:meta['credential_parse']='UNKNOWN_NONASCII';token=None
    # Do not expose token bytes or hashes in this receipt or diagnostics.
    out=b'';err=b''
    return token,meta
def send(envelope,token,connection_factory=http.client.HTTPSConnection):
    method,path,payload=envelope['method'],envelope['path'],envelope['payload']
    from actor import allowed
    if not allowed(method,path,payload):raise ValueError('request allowlist rejected')
    body=None if payload is None else (json.dumps(payload,sort_keys=True,ensure_ascii=False,separators=(',',':'))+'\n').encode()
    if body is not None and not screen_response(body,token)['safe']:return {'complete':False,'outcome':'UNKNOWN_UNSCREENABLE_REQUEST_NO_SEND','requests_sent':0,'redirects_followed':0,'retries':0}
    headers={'Accept':'application/vnd.github+json','User-Agent':'PR284-exact-author-branch-actor','Authorization':'Bearer '+token,'X-GitHub-Api-Version':'2022-11-28'}
    if body is not None:headers['Content-Type']='application/json'
    connection=None;sent=0
    try:
        connection=connection_factory(HOST,timeout=40,context=ssl.create_default_context())
        # One application send only. HTTPSConnection has no redirect handler or retry loop.
        sent=1;connection.request(method,'/'+path,body=body,headers=headers)
        response=connection.getresponse();raw=response.read(MAX_RESPONSE_BYTES+1)
        if len(raw)<=MAX_RESPONSE_BYTES:
            tail=response.read(1);remaining=response.length
            if tail!=b'' or response.isclosed() is not True or not (remaining is None or type(remaining) is int and remaining==0):raise ScreenUnknown('authenticated HTTP completion unknown')
        # A hostile peer must not make the credential reappear in public evidence.
        # Check raw body; on a match retain no body and mark unknown instead.
        screened=screen_authenticated_response(raw,token,method,path)
        if not screened['safe']:return {'complete':False,'outcome':'UNKNOWN_RESPONSE_BODY_AND_HASH_INTENTIONALLY_EXCLUDED','screen_reason':screened['reason'],'status':response.status,'requests_sent':sent,'redirects_followed':0,'retries':0}
        return {'complete':True,'status':response.status,'body_base64':base64.b64encode(raw).decode(),'body_bytes':len(raw),'body_sha256':sha(raw),'requests_sent':sent,'redirects_followed':0,'retries':0,'response_headers_intentionally_not_recorded':True,'screen_policy':screened}
    except BaseException as e:
        # Exception strings can contain URLs/headers/secrets, so emit type only.
        return {'complete':False,'outcome':'UNKNOWN_TRANSPORT_NO_RETRY','exception_type':type(e).__name__,'requests_attempted':sent,'requests_sent':None,'redirects_followed':0,'retries':0}
    finally:
        try:
            if connection is not None:connection.close()
        except BaseException:pass
        headers.clear();token=None
def public_route(method,path,payload=None):
    """Only exact fixed page2 comparisons remain credentialless.
    All immutable Git objects, identity/ref GETs and POSTs are authenticated.
    """
    if method!='GET' or payload is not None or type(path) is not str:return False
    cmp=re.fullmatch(r'repos/AlecKriebel/Math/compare/([0-9a-f]{40})\.\.\.([0-9a-f]{40})\?per_page=1&page=2',path)
    return cmp is not None and all(h!='0'*40 for h in cmp.groups())
def screen_authenticated_response(raw,token,method,path):
    """Typed blob-content normalization before the unchanged finite screen.
    No arbitrary response normalization or expanded privacy budget. The six
    parsed values remain exact except declared content ASCII whitespace; JSON
    wire formatting is canonicalized in memory only. Original raw bytes may be
    retained only after this gate succeeds, never on malformed/unknown/echo.
    """
    route=re.fullmatch(r'repos/AlecKriebel/Math/git/blobs/([0-9a-f]{40})',path)
    if method!='GET' or route is None:return screen_response(raw,token)
    try:
        secret=token.encode('ascii');hexsecret=secret.hex().encode()
        forms=[base64.b64encode(secret),base64.urlsafe_b64encode(secret)];forms+=[x.rstrip(b'=') for x in forms]
        if secret in raw or hexsecret in raw.lower() or any(x in raw for x in forms):return {'safe':False,'reason':'CREDENTIAL_ECHO'}
        if not public_json_policy(raw)['safe']:raise ScreenUnknown('strict bounded blob JSON')
        x=json.loads(raw);h=route[1]
        if h=='0'*40 or set(x)!={'sha','node_id','size','url','content','encoding'}:raise ScreenUnknown('exact declared blob schema')
        if any(type(x[k]) is not str for k in ['sha','node_id','url','content','encoding']) or not x['node_id'] or type(x['size']) is not int or x['size']<0:raise ScreenUnknown('exact declared blob field types')
        if x['sha']!=h or x['url']!='https://api.github.com/'+path or x['encoding']!='base64':raise ScreenUnknown('literal blob hash URL encoding')
        content=x['content'].encode('ascii',errors='strict')
        if re.search(rb'[^A-Za-z0-9+/= \t\r\n\v\f]',content):raise ScreenUnknown('declared content alphabet')
        clean=re.sub(rb'[ \t\r\n\v\f]+',b'',content);decoded=base64.b64decode(clean,validate=True)
        if base64.b64encode(decoded)!=clean or len(decoded)!=x['size'] or hashlib.sha1(b'blob '+str(len(decoded)).encode()+b'\0'+decoded).hexdigest()!=h:raise ScreenUnknown('canonical decoded Git blob identity')
        normalized=dict(x);normalized['content']=clean.decode('ascii');wire=(json.dumps(normalized,sort_keys=True,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
        screened=screen_response(wire,token)
        if not screened['safe']:return screened
        return {**screened,'scope':'EXACT_DECLARED_GIT_BLOB_CONTENT_ASCII_WHITESPACE_NORMALIZATION','strict_requested_Git_blob_identity_validated':True,'all_other_parsed_fields_preserved':True,'original_raw_retained_only_after_normalization_and_finite_screen':True,'privacy_budgets_unchanged':True}
    except BaseException:return {'safe':False,'reason':'MALFORMED_UNHANDLED_OR_BUDGET_UNKNOWN'}
def public_json_policy(raw):
    """Strict bounded JSON only. No token, credential screening or decoding.
    Uses unchanged raw response/JSON-depth/item limits. Git canonical object
    and expected identity/body validation remain in the unchanged actor.
    """
    def pairs(rows):
        out={}
        for k,v in rows:
            if k in out:raise ScreenUnknown('duplicate public JSON key')
            out[k]=v
        return out
    try:
        if len(raw)>MAX_RESPONSE_BYTES:raise ScreenUnknown('public response byte budget')
        x=json.loads(raw.decode('utf-8',errors='strict'),object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(ScreenUnknown('nonfinite public JSON')))
        if type(x) is not dict:raise ScreenUnknown('unexpected public JSON root')
        stack=[(x,0)];items=0
        while stack:
            v,depth=stack.pop();items+=1
            if depth>MAX_JSON_DEPTH or items>MAX_SCREEN_ITEMS:raise ScreenUnknown('public JSON structure budget')
            if type(v) is dict:
                for k,z in v.items():k.encode('utf-8',errors='strict');stack.append((z,depth+1))
            elif type(v) is list:stack.extend((z,depth+1) for z in v)
            elif type(v) is str:v.encode('utf-8',errors='strict')
            elif type(v) is float:
                if not math.isfinite(v):raise ScreenUnknown('nonfinite parsed public float')
            elif v is None or type(v) in (bool,int):pass
            else:raise ScreenUnknown('unexpected public value')
        return {'safe':True,'scope':'EXACT_CREDENTIALLESS_PUBLIC_JSON','credential_echo_screening_performed':False,'complete_strict_bounded_json':True}
    except BaseException:return {'safe':False,'scope':'UNKNOWN_PUBLIC_JSON_NO_BODY_OR_HASH','credential_echo_screening_performed':False}
def send_public(envelope,connection_factory=http.client.HTTPSConnection):
    """One actually credentialless HTTPS GET; never acquire/read credentials."""
    if not public_route(envelope['method'],envelope['path'],envelope['payload']) or envelope['execution_authority'] is not False or envelope['authority'] is not None or envelope['mutation_ordinal'] is not None:raise ValueError('exact credentialless public GET required')
    headers={'Accept':'application/vnd.github+json','User-Agent':'PR284-exact-author-branch-actor','X-GitHub-Api-Version':'2022-11-28'}
    connection=None;sent=0
    try:
        connection=connection_factory(HOST,timeout=40,context=ssl.create_default_context())
        sent=1;connection.request('GET','/'+envelope['path'],body=None,headers=headers)
        response=connection.getresponse();raw=response.read(MAX_RESPONSE_BYTES+1)
        # read(amt) can return a valid JSON prefix before declared completion.
        # A bounded empty tail plus closed response and exhausted length are
        # required before retaining any body/count/hash. No retry or redirect.
        if len(raw)<=MAX_RESPONSE_BYTES:
            tail=response.read(1);remaining=response.length
            if tail!=b'' or response.isclosed() is not True or not (remaining is None or type(remaining) is int and remaining==0):raise ScreenUnknown('public HTTP completion unknown')
        policy=public_json_policy(raw)
        if not policy['safe']:return {'complete':False,'outcome':'UNKNOWN_CREDENTIALLESS_PUBLIC_JSON_BODY_AND_HASH_EXCLUDED','status':response.status,'requests_sent':sent,'redirects_followed':0,'retries':0,'public_body_policy':policy}
        return {'complete':True,'status':response.status,'body_base64':base64.b64encode(raw).decode(),'body_bytes':len(raw),'body_sha256':sha(raw),'requests_sent':sent,'redirects_followed':0,'retries':0,'response_headers_intentionally_not_recorded':True,'public_body_policy':policy,'request_credentialless':True,'Authorization_header_sent':False}
    except BaseException as e:return {'complete':False,'outcome':'UNKNOWN_CREDENTIALLESS_PUBLIC_TRANSPORT_NO_RETRY','exception_type':type(e).__name__,'requests_attempted':sent,'requests_sent':None,'redirects_followed':0,'retries':0}
    finally:
        try:
            if connection is not None:connection.close()
        except BaseException:pass
        headers.clear()
def no_credential_metadata():
    """No process/secret stream exists; absent PID/exit/reap remain None."""
    return {'actual_parent_PID':os.getpid(),'time_ns':time.time_ns(),'credential_acquisition':'NOT_PERFORMED_EXACT_CREDENTIALLESS_PUBLIC_GET','argv':None,'actual_child_PID':None,'returncode':None,'reaped':None,'communication_complete':None,'wait_completed':None,'credential_subprocess_started':False,'token_environment_read':False,'secret_streams':'NO_CREDENTIAL_SUBPROCESS_OR_SECRET_STREAMS','secret_stream_full_capture_claim':False,'environment_recorded':False}
def authorize(x):
    """Independent worker gate; literal exact grant and one-use request marker.
    An operational execution_authority boolean alone is never authority.
    """
    from actor import match,check_grant,pin,literal,W,mutations,need,utc,canonical,candidate
    if x['method']=='GET':
        need(x['authority'] is None and x['mutation_ordinal'] is None,'read-only envelope');return None
    auth=x['authority'];need(isinstance(auth,dict) and set(auth)=={'grant','plan','run_directory'},'fresh worker authority context')
    gp=auth['grant'];g=json.loads(match(gp));p=pathlib.Path(gp['path'])
    need(p.parent==W and p.name.startswith('ROOT_PR284_AUTHOR_BRANCH_GRANT_'),'literal ROOT worker grant')
    pp=auth['plan'];plan=json.loads(match(pp));bp=plan['candidate_binding'];check_grant(g,bp,pp,plan)
    candidate(bp)
    d=literal(auth['run_directory']);need(str(d)==g['run_directory'] and d.parent==W and d.name.startswith('ROOT_author_branch_execution_') and d.name.endswith('_'+g['nonce']),'exact dedicated existing nonce runtime')
    consumed=json.loads((d/'ONE_TIME_NONCE_CONSUMED.json').read_bytes());need(consumed['grant']==gp and consumed['nonce']==g['nonce'] and consumed['automatic_retry'] is False,'one-use actor launch evidence')
    requests=mutations(plan,g['nonce']);i=x['mutation_ordinal'];need(type(i) is int and 0<=i<len(requests) and requests[i]==[x['method'],x['path'],x['payload']],'exact ROOT reviewed request and ordinal')
    for j in range(i):
        prior=json.loads((d/f'WORKER_MUTATION_{j:04d}_RESULT.json').read_bytes());need(prior['complete'] is True and prior['status'] in (200,201) and prior['requests_sent']==1 and prior['retries']==0,'prior exact request complete; unknown cannot advance')
        verified=json.loads((d/f'ACTOR_MUTATION_{j:04d}_READBACK_COMPLETE.json').read_bytes());need(verified['mutation_ordinal']==j and verified['complete_full_readback'] is True,'prior immutable object independently read back before advancing')
    marker=d/f'WORKER_MUTATION_{i:04d}_STARTED.json'
    with marker.open('xb') as f:f.write(canonical({'UTC':utc(),'time_ns':time.time_ns(),'actual_worker_PID':os.getpid(),'grant':gp,'ordinal':i,'outcome':'UNKNOWN_UNTIL_RECORDED_HTTP_RESPONSE','automatic_retry':False}))
    return d/f'WORKER_MUTATION_{i:04d}_RESULT.json'
def main():
    if any(k in os.environ for k in ('GH_DEBUG','GITHUB_DEBUG')):raise ValueError('debug environment forbidden')
    x=json.loads(sys.stdin.buffer.read());from actor import allowed
    if set(x)!={'method','path','payload','execution_authority','authority','mutation_ordinal'} or not allowed(x['method'],x['path'],x['payload']) or x['execution_authority']!=(x['method']!='GET'):raise ValueError('exact operational envelope required')
    result_path=authorize(x) # consume exact worker request before credential acquisition
    if public_route(x['method'],x['path'],x['payload']):result=send_public(x);meta=no_credential_metadata();token=None
    else:
        token,meta=credential()
        if token is None:result={'complete':False,'outcome':'UNKNOWN_CREDENTIAL_READ_NO_API_SEND','requests_sent':0,'redirects_followed':0,'retries':0}
        else:result=send(x,token)
    token=None;result['credential_metadata']=meta;result['actual_worker_PID']=os.getpid();result['time_ns']=time.time_ns()
    if result_path is not None:
        with result_path.open('xb') as f:f.write((json.dumps(result,sort_keys=True)+'\n').encode())
    print(json.dumps(result,sort_keys=True));sys.exit(0 if result['complete'] else 2)
if __name__=='__main__':main()
