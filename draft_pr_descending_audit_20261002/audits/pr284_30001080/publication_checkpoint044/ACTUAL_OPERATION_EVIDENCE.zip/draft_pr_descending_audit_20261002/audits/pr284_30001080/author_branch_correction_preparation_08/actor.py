"""PR284 existing branch correction actor. Import is pure; no authority is bundled.
prepare is read-only remotely. execute requires fresh ROOT candidate acceptance,
source/plan review and a one-use grant. No local Git operations or metadata writes.
"""
import argparse,base64,datetime,gzip,hashlib,json,os,pathlib,re,stat,sys,time
from native_capture import call
B=pathlib.Path(__file__).resolve().parent
W=B.parent
REPO='AlecKriebel/Math'; RID=1307717439; RN='R_kgDOTfIvPw'
PR=284; PN='PR_kwDOTfIvP88AAAABGH4T4A'; PID=4705883104
ACCOUNT='AlecKriebel'; UID=6109370; BRANCH='dot/math-30001080'
OLD='391cb662b1599ef564ff15b63cd8ed73c7d1f125'
T='unsolved_math_prioritization/attempts/30001080'
SCIENTIFIC_MANIFEST_SHA256='3cbda71cac5de12a198c6bb563620eb1731fd6d686cc7d3cf6c482606b73d32f'
Q='unsolved_math_prioritization/QUEUE.md'; PREFIX='repos/'+REPO+'/git/'
CAS_QUERY='mutation PR284AuthorBranchExactCAS($input:UpdateRefsInput!){updateRefs(input:$input){clientMutationId}}'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def canonical(x):return (json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,msg):
    if not v:raise ValueError(msg+'; STOP, preserve evidence; read-only reconciliation only')
def oid(x):return isinstance(x,str) and re.fullmatch('[0-9a-f]{40}',x) is not None and x!='0'*40
def safe(x):
    need(isinstance(x,str) and x and not x.startswith('/') and '\\' not in x and '\0' not in x,'literal relative path')
    need(all(y not in ('','.','..') and y.casefold()!='.git' for y in x.split('/')),'literal path components')
    x.encode('utf-8',errors='strict');return x
def literal(p):
    p=pathlib.Path(p);need(p.is_absolute(),'absolute literal local input')
    need(all(not x.is_symlink() for x in [p,*p.parents]),'no symlink in input ancestry')
    return p
def pin(p):
    p=literal(p);need(p.is_file(),'complete regular literal input')
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
def match(x):
    need(set(x)=={'path','bytes','sha256','mode'} and pin(x['path'])==x and x['mode']==0o444,'exact sealed full-byte pin')
    return pathlib.Path(x['path']).read_bytes()
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def write(d,name,x):
    safe(name);p=d/name;need(not p.exists(),'append-only own evidence filename')
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(canonical(x));return pin(p)
def object_oid(kind,body):return hashlib.sha1(kind.encode()+b' '+str(len(body)).encode()+b'\0'+body).hexdigest()
def blob_oid(body):return object_oid('blob',body)
def tree_raw(rows):
    seen=set();encoded=[]
    for x in rows:
        name=safe(x['path']);need('/' not in name and name not in seen,'unique nonrecursive tree name');seen.add(name)
        mode=x['mode'];kind=x['type'];h=x['sha']
        need(oid(h) and ((mode=='040000' and kind=='tree') or (mode in ('100644','100755','120000') and kind=='blob') or (mode=='160000' and kind=='commit')),'complete supported tree identity')
        key=name.encode()+ (b'/' if kind=='tree' else b'')
        encoded.append((key,('40000' if mode=='040000' else mode).encode()+b' '+name.encode()+b'\0'+bytes.fromhex(h)))
    return b''.join(b for _,b in sorted(encoded))
def checked_tree(x,h):
    need(x['sha']==h and x.get('truncated') is False,'complete untruncated nonrecursive tree')
    raw=tree_raw(x['tree']);need(object_oid('tree',raw)==h,'full tree canonical SHA1 reconstruction')
    return {z['path']:{k:z[k] for k in ('mode','type','sha')} for z in x['tree']}
def commit_raw(payload):
    need(set(payload)=={'message','tree','parents','author','committer'} and oid(payload['tree']) and len(payload['parents'])==2 and all(oid(x) for x in payload['parents']) and len(set(payload['parents']))==2,'exact two-parent commit')
    def person(k):
        x=payload[k];need(set(x)=={'name','email','date'} and all(isinstance(x[z],str) and x[z] and not any(c in x[z] for c in '\n\r\0<>') for z in ('name','email')),'literal author identity')
        dt=datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00'))
        need(dt.utcoffset()==datetime.timedelta(0) and dt.microsecond==0,'whole-second UTC commit timestamp')
        seconds=int(dt.timestamp());need(-(2**63)<=seconds<2**63,'signed int64 seconds')
        return (k+' '+x['name']+' <'+x['email']+'> '+str(seconds)+' +0000\n').encode()
    need(isinstance(payload['message'],str) and payload['message'] and '\0' not in payload['message'],'literal complete commit message')
    return b'tree '+payload['tree'].encode()+b'\n'+b''.join(b'parent '+x.encode()+b'\n' for x in payload['parents'])+person('author')+person('committer')+b'\n'+payload['message'].encode()
def raw_commit(raw,h):
    """Actual full raw bytes only. No REST timestamp/message reconstruction."""
    need(isinstance(raw,bytes) and len(raw)<=1024*1024 and object_oid('commit',raw)==h,'exact complete raw commit canonical SHA1')
    header,sep,body=raw.partition(b'\n\n');need(sep and header,'complete raw commit header/body separation')
    fields=[]
    for line in header.split(b'\n'):
        if line.startswith(b' '):
            need(fields,'valid raw continuation header');fields[-1][1]+=b'\n'+line
        else:
            key,space,value=line.partition(b' ');need(space and key and value and key.isascii(),'literal raw header')
            fields.append([key,value])
    def values(key):return [v for k,v in fields if k==key]
    ts=values(b'tree');parents=values(b'parent')
    need(len(ts)==1 and oid(ts[0].decode('ascii')) and all(oid(p.decode('ascii')) for p in parents) and len(values(b'author'))==len(values(b'committer'))==1,'full raw commit structural identities')
    return {'sha':h,'tree':ts[0].decode('ascii'),'parents':[p.decode('ascii') for p in parents]}
def existing_commit(x,h,raw=None):
    need(raw is not None,'ROOT pinned actual raw commit input required; normalized REST cannot supply bytes')
    parsed=raw_commit(raw,h)
    need(x['sha']==h and x['tree']['sha']==parsed['tree'] and [z['sha'] for z in x['parents']]==parsed['parents'],'API head/tree/ordered-parent identity agrees with actual complete raw bytes')
    return raw
def raw_parent_inputs(binding):
    specs=binding['raw_parent_inputs'];need(set(specs)=={binding['expected_pr_head'],binding['expected_main_head']},'exact ROOT raw input for both expected parents')
    out={}
    for h,x in specs.items():
        p=literal(x['path']);need(p.name=='RAW_COMMIT.bin' and p.parent.parent==W and p.parent.name.startswith('ROOT_exact_raw_'),'dedicated actual ROOT raw-read input; never fetch/rebaseline')
        b=match(x);raw_commit(b,h);out[h]=b
    return out
def queue_row(body):
    rows=body.splitlines(keepends=True);found=[]
    for i,line in enumerate(rows):
        core=line.rstrip(b'\r\n');cells=core.split(b'|')
        if len(cells)>2 and cells[2].strip()==b'30001080 / OWR-2093-003':found.append((i,core,line[len(core):]))
    need(len(found)==1,'exact single target QUEUE physical row');return rows,found[0]
def queue_transition_spec(x):
    need(type(x) is dict and set(x)=={'schema','before_row_sha256','after_row_sha256','before_status','before_budget','after_status','after_budget','reviewed_scientific_manifest_sha256'},'exact typed reviewed scientific QUEUE transition')
    need(x['schema']=='ROOT_EXACT_PR284_REVIEWED_SCIENTIFIC_QUEUE_TRANSITION_V1' and (x['before_status'],x['before_budget'],x['after_status'],x['after_budget'])==('queued','0/5','claimed_solved','3/5'),'only existing reviewed queued0/5 to claimed_solved3/5 scientific correction')
    need(all(type(x[k]) is str and re.fullmatch('[0-9a-f]{64}',x[k]) is not None for k in ('before_row_sha256','after_row_sha256','reviewed_scientific_manifest_sha256')) and x['reviewed_scientific_manifest_sha256']==SCIENTIFIC_MANIFEST_SHA256,'exact before/after row hashes and immutable reviewed03 scientific manifest identity')
    return x
def validate_queue_transition(binding,readiness,selected):
    x=binding.get('expected_main_queue_transition')
    if x is None:return
    queue_transition_spec(x)
    need(x['before_row_sha256']==binding['expected_main_queue_row_sha256'] and x['after_row_sha256']==sha(queue_row(selected[Q])[1][1]),'ROOT binds exact fresh-main-to-selected scientific row transition')
    need(readiness_pin(readiness['final_global_candidate_manifest'])['sha256']==x['reviewed_scientific_manifest_sha256'],'scientific transition targets original immutable mathematical readiness03; no new review/turn')
def splice_queue(main,proposed,expected_old,transition=None):
    rows,(i,before,eol)=queue_row(main);_,(_,after,_)=queue_row(proposed)
    need(sha(before)==expected_old,'ROOT binds latest main own row, no implicit overwrite')
    oldcells=before.split(b'|');newcells=after.split(b'|')
    need(b'\n' not in after and b'\r' not in after and len(oldcells)==len(newcells)==14,'one well-formed literal target row with exact14 cells')
    if transition is None:
        need(all(x==y for k,(x,y) in enumerate(zip(oldcells,newcells)) if k not in (11,12)),'default fresh-main-to-final relation preserves every own-row cell except Notes/DOI; stale protected cells stop')
        need(oldcells[8].strip()==newcells[8].strip()==b'claimed_solved' and oldcells[9].strip()==newcells[9].strip()==b'3/5','default fresh main mathematical status and3/5 budget literal and protected')
    else:
        x=queue_transition_spec(transition)
        need(x['before_row_sha256']==expected_old==sha(before) and x['after_row_sha256']==sha(after),'exact ROOT-bound reviewed scientific before/after row bodies')
        need(all(z==y for k,(z,y) in enumerate(zip(oldcells,newcells)) if k not in (8,9,11,12)),'reviewed scientific transition preserves all other fresh-main own-row cells')
        need(oldcells[8].strip()==x['before_status'].encode() and oldcells[9].strip()==x['before_budget'].encode() and newcells[8].strip()==x['after_status'].encode() and newcells[9].strip()==x['after_budget'].encode(),'actual fresh-main/proposed status and budget equal exact reviewed transition')
    result=b''.join(rows[:i])+after+eol+b''.join(rows[i+1:])
    check,j=queue_row(result);need(j[0]==i and all(x==y for k,(x,y) in enumerate(zip(rows,check)) if k!=i) and len(check)==len(rows),'every other QUEUE byte and line ending preserved')
    return result,{'before_row_sha256':sha(before),'after_row_sha256':sha(after),'physical_index':i,'before_whole_sha256':sha(main),'after_whole_sha256':sha(result),'reviewed_scientific_transition':transition,'changed_cell_indices':[k for k,(x,y) in enumerate(zip(oldcells,newcells)) if x!=y]}
def readiness_pin(x):
    """Strict external publication-v2 pin: no implicit mode/extra keys."""
    need(type(x) is dict and set(x)=={'path','bytes','sha256'},'readiness exact three-field full-byte pin')
    need(type(x['path']) is str and type(x['bytes']) is int and x['bytes']>=0 and type(x['sha256']) is str and re.fullmatch('[0-9a-f]{64}',x['sha256']) is not None,'readiness literal path/integer bytes/SHA256 types')
    literal(x['path']);return dict(x)
def readiness_sealed(x):
    """Lookup-only conversion; never modify the external readiness body."""
    return {**readiness_pin(x),'mode':0o444}
def sealed_pin_projection(x):
    """Actor bindings/grants remain four-field sealed inputs."""
    need(type(x) is dict and set(x)=={'path','bytes','sha256','mode'} and type(x['mode']) is int and x['mode']==0o444,'actor input exact four-field sealed444 pin')
    return readiness_pin({k:x[k] for k in ('path','bytes','sha256')})
def validate_readiness(readiness,manifest_pin):
    need(readiness['schema']=='root-preprint-readiness-v2','exact shared publication-v2 readiness schema')
    need(readiness['status']=='ROOT_PREPRINT_APPROVED_FOR_USER_AUTHORIZED_PREPRINT_PUBLICATION' and readiness['original_PR_head']==OLD and readiness['original_submitted_status']=='claimed_solved' and readiness['unresolved_issues']==[] and type(readiness['fresh_sequential_whole_reviews_completed']) is int and readiness['fresh_sequential_whole_reviews_completed']>=2 and readiness['latest_fresh_whole_review_unresolved_issues']==[],'fresh sequential whole-review publication readiness; repaired rejection is not silently clearance')
    gp=readiness_pin(readiness['final_global_candidate_manifest']);cp=readiness_pin(readiness['candidate'])
    need(gp==sealed_pin_projection(manifest_pin),'readiness exact final closed global manifest bytes')
    match(readiness_sealed(gp));match(readiness_sealed(cp)) # lookup-only444; external exact3 body preserved
    return readiness
def closed_selected(c,catalog_pin,manifest_pin):
    """Complete sealed topology and full selected bodies, without authority."""
    c=literal(c);need(pathlib.Path(catalog_pin['path'])==c/'FULL_CATALOG.json' and pathlib.Path(manifest_pin['path'])==c/'PROPOSED_TREE_MANIFEST.json','exact whole catalog and manifest paths')
    catalog=json.loads(match(catalog_pin));seen={}
    for x in catalog['files']:
        rel=safe(x['path']);need(rel not in seen,'catalog exact unique file');p=c/rel
        need(p.is_file() and not p.is_symlink() and p.stat().st_size==x['bytes'] and sha(p.read_bytes())==x['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444,'every complete candidate stored body/mode');seen[rel]=x
    actual={p.relative_to(c).as_posix() for p in c.rglob('*') if p.is_file()}
    need(actual==set(seen)|{'FULL_CATALOG.json'} and all(not p.is_symlink() for p in c.rglob('*')),'complete literal closed candidate topology')
    dirs={'.'}|{p.relative_to(c).as_posix() for p in c.rglob('*') if p.is_dir()}
    need(dirs==set(catalog['directories']) and all(stat.S_IMODE((c/d).stat().st_mode)==0o555 for d in dirs),'every closed candidate directory')
    m=json.loads(match(manifest_pin));selected={}
    for x in m['files']:
        target=safe(x['path']);need(target not in selected and (target==Q or target.startswith(T+'/')),'only exact own attempt/QUEUE payload')
        body=(c/'proposed'/target).read_bytes();need(len(body)==x['bytes'] and sha(body)==x['sha256'],'every selected complete body');selected[target]=body
    actual_proposed={p.relative_to(c/'proposed').as_posix() for p in (c/'proposed').rglob('*') if p.is_file()}
    need(actual_proposed==set(selected) and Q in selected,'complete literal proposed payload');return selected
def candidate(binding_pin):
    binding=json.loads(match(binding_pin));p=pathlib.Path(binding_pin['path'])
    need(p.parent==W and p.name.startswith('ROOT_PR284_FINAL_AUTHOR_CANDIDATE_BINDING_'),'new literal ROOT candidate binding')
    need(binding['status']=='ROOT_ACCEPTS_EXACT_PR284_FINAL_AUTHOR_CANDIDATE' and binding['execution_authority'] is False and not binding.get('fixture_only',False) and binding['publication_ready'] is True and binding['whole_preprint_accepted'] is True and binding['unresolved_issues']==[],'fresh final whole candidate and readiness acceptance; preparation04 is never presumed accepted')
    raw_parent_inputs(binding)
    c=literal(binding['candidate_directory']);need(c.parent==W and c.name.startswith('global_claim_correction_preparation_'),'dedicated candidate domain')
    selected=closed_selected(c,binding['full_catalog'],binding['proposed_manifest'])
    need(len(selected)==binding['selected_count'] and sum(map(len,selected.values()))==binding['selected_bytes'],'complete selected count/body length')
    rp=pathlib.Path(binding['publication_readiness']['path']);need(rp.parent==W and rp.name.startswith('ROOT_'),'literal ROOT readiness domain')
    readiness=json.loads(match(binding['publication_readiness']))
    lineage=binding.get('administrative_finalization_acceptance')
    if lineage is None:validate_readiness(readiness,binding['proposed_manifest'])
    else:
        import administrative_lineage
        administrative_lineage.validate(__import__(__name__),lineage,binding,readiness,selected)
    validate_queue_transition(binding,readiness,selected)
    for x in binding['prerequisites']:match(x)
    snapshot=json.loads(match(binding['snapshot_manifest']));need(snapshot['original_head']==OLD and snapshot['PR']==PR,'exact original immutable snapshot')
    original={}
    for x in snapshot['files']:
        path=safe(x['repository_path']);body=match(x['snapshot']);need(blob_oid(body)==x['Git_blob_SHA1'] and path not in original and (path==Q or path.startswith(T+'/')),'every original complete Git blob')
        original[path]={'mode':'100644','type':'blob','sha':blob_oid(body)}
    need(len(original)==snapshot['attempt_files']+1 and Q in original,'original snapshot complete counts')
    return binding,selected,original
def target_set(leaves):return {k:v for k,v in leaves.items() if k.startswith(T+'/')}
def validate_own(pr_leaves,main_leaves,original,expected_main):
    need(target_set(pr_leaves)==target_set(original),'existing PR exact original own files; extra/changed/unreviewed author files prohibit overwrite')
    need(target_set(main_leaves)==expected_main,'latest main own subtree exact plan ROOT binding; no changed own files ignored')
def ref_payload(before,after,nonce):
    need(oid(before) and oid(after) and before!=after and re.fullmatch('[0-9a-f]{48}',nonce or ''),'exact one-time CAS IDs/nonce')
    return {'query':CAS_QUERY,'variables':{'input':{'repositoryId':RN,'refUpdates':[{'name':'refs/heads/'+BRANCH,'beforeOid':before,'afterOid':after,'force':False}],'clientMutationId':'pr284_'+nonce}}}
def allowed(method,path,payload=None):
    if method=='GET':return payload is None and (path in ('user','repos/'+REPO,'repos/'+REPO+'/pulls/284',PREFIX+'ref/heads/main',PREFIX+'ref/heads/'+BRANCH) or any(re.fullmatch(re.escape(PREFIX+k+'/')+'[0-9a-f]{40}',path) for k in ('commits','trees','blobs')) or re.fullmatch(re.escape('repos/'+REPO+'/compare/')+'[0-9a-f]{40}\\.\\.\\.[0-9a-f]{40}(?:\\?per_page=1&page=2)?',path) is not None)
    if method!='POST' or not isinstance(payload,dict):return False
    if path==PREFIX+'blobs':return set(payload)=={'content','encoding'} and payload['encoding']=='base64' and isinstance(payload['content'],str)
    if path==PREFIX+'trees':
        try:return set(payload)=={'tree'} and bool(payload['tree']) and all(set(x)=={'path','mode','type','sha'} and '/' not in safe(x['path']) and oid(x['sha']) and ((x['mode']=='040000' and x['type']=='tree') or (x['mode'] in ('100644','100755','120000') and x['type']=='blob') or (x['mode']=='160000' and x['type']=='commit')) for x in payload['tree']) and len({x['path'] for x in payload['tree']})==len(payload['tree'])
        except (ValueError,KeyError,TypeError):return False
    if path==PREFIX+'commits':
        try:commit_raw(payload);return True
        except (ValueError,KeyError,TypeError):return False
    if path!='graphql':return False
    try:
        x=payload['variables']['input'];u=x['refUpdates'][0]
        return set(payload)=={'query','variables'} and payload['query']==CAS_QUERY and set(payload['variables'])=={'input'} and set(x)=={'repositoryId','refUpdates','clientMutationId'} and x['repositoryId']==RN and len(x['refUpdates'])==1 and set(u)=={'name','beforeOid','afterOid','force'} and u['name']=='refs/heads/'+BRANCH and u['force'] is False and oid(u['beforeOid']) and oid(u['afterOid']) and u['beforeOid']!=u['afterOid'] and re.fullmatch('pr284_[0-9a-f]{48}',x['clientMutationId']) is not None
    except (ValueError,KeyError,TypeError,IndexError):return False
class API:
    def __init__(self,run,mutations=(),authority=None):self.run=run;self.n=0;self.mutations=list(mutations);self.sent=[];self.authority=authority;self.last_mutation_completed=None
    def request(self,method,path,payload=None):
        need(allowed(method,path,payload),'endpoint/method/body allowlist; metadata/ready/merge/release/DOI/GWS forbidden')
        if method!='GET':
            need(self.mutations and self.mutations[0]==[method,path,payload],'exact reviewed next immutable/CAS request, no broadened write')
            self.mutations.pop(0);self.sent.append([method,path,payload]) # consume before transport, never retry
            if self.last_mutation_completed is not None:
                while True:
                    remaining=1.0-(time.monotonic()-self.last_mutation_completed)
                    if remaining<=0:break
                    time.sleep(remaining)
        self.n+=1;label=f'{self.n:04d}_{method}'
        envelope={'method':method,'path':path,'payload':payload,'execution_authority':method!='GET','authority':self.authority if method!='GET' else None,'mutation_ordinal':len(self.sent)-1 if method!='GET' else None}
        try:raw=call(self.run,label,[sys.executable,'-B',str(B/'http_worker.py')],stdin=canonical(envelope),timeout=55,context={'actor':pin(B/'actor.py'),'transport_worker':pin(B/'http_worker.py')})
        finally:
            if method!='GET':self.last_mutation_completed=time.monotonic()
        response=json.loads(raw);need(response['complete'] is True and response['status'] in (200,201) and response['requests_sent']==1 and response['redirects_followed']==0 and response['retries']==0,'complete successful one-send HTTP response')
        body=base64.b64decode(response['body_base64'],validate=True);need(len(body)==response['body_bytes'] and sha(body)==response['body_sha256'],'lossless HTTP body custody')
        data=json.loads(body);need(not isinstance(data,dict) or not data.get('errors'),'no GraphQL errors; mutative unknown is never retried')
        return data
    def get(self,path):return self.request('GET',path)
    def post(self,path,payload):return self.request('POST',path,payload)
class Objects:
    def __init__(self,api,raw_parents=None):self.api=api;self.trees={};self.commits={};self.blobs={};self.raw_parents=raw_parents or {};self.ancestry={}
    def commit(self,h):
        if h not in self.commits:
            x=self.api.get(PREFIX+'commits/'+h);existing_commit(x,h,self.raw_parents.get(h));self.commits[h]=x
        return self.commits[h]
    def tree(self,h):
        if h not in self.trees:self.trees[h]=checked_tree(self.api.get(PREFIX+'trees/'+h),h)
        return self.trees[h]
    def blob(self,h):
        if h not in self.blobs:
            x=self.api.get(PREFIX+'blobs/'+h);need(x['sha']==h and x['encoding']=='base64','exact immutable blob encoding')
            b=base64.b64decode(x['content']);need(len(b)==x['size'] and blob_oid(b)==h,'full blob canonical SHA1 reconstruction');self.blobs[h]=b
        return self.blobs[h]
    def locate(self,root,path):
        node=root;parts=safe(path).split('/')
        for i,name in enumerate(parts):
            rows=self.tree(node);x=rows.get(name)
            if x is None:return None
            if i==len(parts)-1:return x
            need(x['mode']=='040000' and x['type']=='tree','no file/symlink/submodule ancestor');node=x['sha']
    def target(self,root):
        x=self.locate(root,T)
        if x is None:return {}
        need(x['type']=='tree' and x['mode']=='040000','own attempt is regular tree')
        result={}
        def walk(h,p):
            rows=self.tree(h);need(rows,'no hidden empty own-target tree')
            for n,z in rows.items():
                key=p+'/'+n
                if z['type']=='tree':walk(z['sha'],key)
                else:result[key]=z
        walk(x['sha'],T);return result
    def ancestor(self,ancestor,head,limit=10000):
        need(oid(ancestor) and oid(head),'literal ancestry comparison inputs')
        key=ancestor+'...'+head
        if key not in self.ancestry:self.ancestry[key]=self.api.get('repos/'+REPO+'/compare/'+key+'?per_page=1&page=2')
        x=self.ancestry[key]
        need(x['base_commit']['sha']==ancestor,'exact comparison base identity')
        return x['merge_base_commit']['sha']==ancestor and x['status'] in ('ahead','identical')
def identity(api,prhead,mainhead):
    u=api.get('user');r=api.get('repos/'+REPO);p=api.get('repos/'+REPO+'/pulls/284')
    need(u['login']==ACCOUNT and u['id']==UID,'exact authenticated account')
    need(r['id']==RID and r['node_id']==RN and r['full_name']==REPO and r['default_branch']=='main' and r['archived'] is False and r['permissions']['push'] is True,'exact current writable repository')
    need(p['number']==PR and p['id']==PID and p['node_id']==PN and p['state']=='open' and p['draft'] is True and p['head']['sha']==prhead and p['head']['ref']==BRANCH and p['head']['repo']['id']==RID and p['head']['repo']['node_id']==RN and p['base']['ref']=='main' and p['base']['repo']['id']==RID and p['base']['repo']['node_id']==RN and p['html_url']=='https://github.com/'+REPO+'/pull/284','exact existing open draft author PR identity/head/domain')
    for branch,head in ((BRANCH,prhead),('main',mainhead)):
        f=api.get(PREFIX+'ref/heads/'+branch);need(f['ref']=='refs/heads/'+branch and f['object']['type']=='commit' and f['object']['sha']==head,'fresh exact main/author-branch heads')
    return p
def overlay(objects,mainroot,selected):
    """Rebuild only selected ancestor trees; retain every untouched sibling entry."""
    trie={}
    for p,b in selected.items():
        safe(p);node=trie;parts=p.split('/')
        for part in parts[:-1]:
            need(part not in node or isinstance(node[part],dict),'no file ancestor collision');node=node.setdefault(part,{})
        need(parts[-1] not in node,'unique selected leaf');node[parts[-1]]=b
    newtrees={};proof=[]
    def build(old,changes,prefix=''):
        before=dict(objects.tree(old)) if old else {};after=dict(before)
        for name,value in changes.items():
            path=prefix+name;x=before.get(name)
            if isinstance(value,dict):
                need(x is None or (x['type']=='tree' and x['mode']=='040000'),'no selected foreign ancestor overwrite')
                h=build(x['sha'] if x else None,value,path+'/');after[name]={'mode':'040000','type':'tree','sha':h}
            else:
                need(x is None or (x['type']=='blob' and x['mode']=='100644'),'selected leaf must be regular nonexecutable blob')
                after[name]={'mode':'100644','type':'blob','sha':blob_oid(value)}
        need(all(after[n]==x for n,x in before.items() if n not in changes),'every unselected Merkle sibling identity preserved')
        rows=[{'path':n,**x} for n,x in after.items()];h=object_oid('tree',tree_raw(rows));newtrees[h]={'tree':sorted(rows,key=lambda x:x['path'])}
        proof.append({'path':prefix.rstrip('/') or '.','before':old,'after':h,'unselected':{n:x for n,x in before.items() if n not in changes},'selected_children':sorted(changes)})
        return h
    return build(mainroot,trie),newtrees,proof
def derive(objects,binding,selected,original,prhead,mainhead,commit_spec):
    need(oid(prhead) and oid(mainhead) and prhead!=mainhead and prhead==OLD,'distinct exact original PR/fresh main parents; changed PR requires new mechanism/review')
    pr=objects.commit(prhead);main=objects.commit(mainhead);original_commit=objects.commit(OLD)
    need(objects.ancestor(OLD,prhead),'original submission is ancestor of current author branch')
    need(original_commit['parents'],'original ancestry anchor available')
    anchor=original_commit['parents'][0]['sha'];anchor_in_main=objects.ancestor(anchor,mainhead) # truthful observation; direct two-parent join needs no parent-to-parent ancestry
    prtarget=objects.target(pr['tree']['sha']);maintarget=objects.target(main['tree']['sha'])
    validate_own(prtarget,maintarget,original,binding['expected_main_target'])
    prqueue=objects.locate(pr['tree']['sha'],Q)
    need(prqueue and prqueue['mode']=='100644' and prqueue['type']=='blob','existing PR own QUEUE row is inspectable')
    need(queue_row(objects.blob(prqueue['sha']))[1][1]==queue_row(objects.blob(original[Q]['sha']))[1][1],'existing PR own QUEUE row unchanged from original snapshot')
    need(set(maintarget)<=set(selected),'accepted subtree covers every existing main own file; no silent retained extra author file')
    q=objects.locate(main['tree']['sha'],Q);need(q and q['mode']=='100644' and q['type']=='blob','latest main full QUEUE regular blob')
    selected=dict(selected);selected[Q],qproof=splice_queue(objects.blob(q['sha']),selected[Q],binding['expected_main_queue_row_sha256'],binding.get('expected_main_queue_transition'))
    tree,trees,proof=overlay(objects,main['tree']['sha'],selected)
    cp={'message':commit_spec['message'],'tree':tree,'parents':[prhead,mainhead],'author':commit_spec['author'],'committer':commit_spec['committer']}
    raw=commit_raw(cp);commit=object_oid('commit',raw)
    blobs={blob_oid(b):b for b in selected.values()}
    return {'schema':'PR284-author-branch-plan-v1','execution_authority':False,'expected_pr_head':prhead,'expected_main_head':mainhead,'original_ancestry_anchor':anchor,'original_ancestry_anchor_in_main':anchor_in_main,'main_root':main['tree']['sha'],'after_root':tree,'after_commit':commit,'parents':[prhead,mainhead],'commit_request':cp,'commit_raw_base64':base64.b64encode(raw).decode(),'selected':[{'path':p,'bytes':len(b),'sha256':sha(b),'blob':blob_oid(b)} for p,b in sorted(selected.items())],'blob_requests':{h:{'content':base64.b64encode(b).decode(),'encoding':'base64'} for h,b in sorted(blobs.items())},'tree_requests':trees,'merkle_preservation':proof,'queue_preservation':qproof,'expected_main_target':maintarget,'expected_main_queue_transition':binding.get('expected_main_queue_transition'),'trees_before':objects.trees,'commits_before':objects.commits,'raw_parents':{h:base64.b64encode(b).decode() for h,b in objects.raw_parents.items()},'ancestry_before':objects.ancestry,'blobs_before':{h:base64.b64encode(b).decode() for h,b in objects.blobs.items()}},selected
def sourcepins():return {n:pin(B/n) for n in ('actor.py','http_worker.py','native_capture.py','administrative_lineage.py')}
def rootpin(path,digest,prefix):
    p=literal(path);need(p.parent==W and p.name.startswith(prefix),'literal ROOT-owned domain path')
    x=pin(p);need(x['sha256']==digest and x['mode']==0o444,'exact immutable ROOT record pin');return x
def run_directory(path,kind,nonce=None):
    p=literal(path);need(p.parent==W and p.name.startswith('ROOT_author_branch_'+kind+'_'),'dedicated ROOT-created future runtime domain')
    if nonce:need(p.name.endswith('_'+nonce),'exact nonce-bound one-use run path')
    need(not p.exists(),'new run dir only, cannot reuse nonce evidence');p.mkdir();return p
def prepare(a):
    bp=rootpin(a.binding,a.binding_sha256,'ROOT_PR284_FINAL_AUTHOR_CANDIDATE_BINDING_');binding,selected,original=candidate(bp)
    need(binding['expected_main_head']==a.main_head and binding['expected_pr_head']==a.pr_head,'exact ROOT accepted planning heads')
    run=run_directory(a.run_dir,'readonly');api=API(run);identity(api,a.pr_head,a.main_head)
    objects=Objects(api,raw_parent_inputs(binding));plan,_=derive(objects,binding,selected,original,a.pr_head,a.main_head,load(a.commit_spec))
    plan.update(candidate_binding=bp,publication_readiness=binding['publication_readiness'],proposed_manifest=binding['proposed_manifest'],full_candidate_catalog=binding['full_catalog'],raw_parent_inputs=binding['raw_parent_inputs'],administrative_finalization_acceptance=binding.get('administrative_finalization_acceptance'),sources=sourcepins(),UTC=utc(),time_ns=time.time_ns(),status='READONLY_PREPARED_NO_EXECUTION_AUTHORITY')
    identity(api,a.pr_head,a.main_head)
    pp=run/'PLAN.json';pp.write_bytes(canonical(plan));pp.chmod(0o444)
    print(json.dumps({'status':plan['status'],'plan':pin(pp),'expected_commit':plan['after_commit'],'external_mutations':0},indent=2))
class FrozenObjects(Objects):
    def __init__(self,plan):
        self.api=None;self.trees=plan['trees_before'];self.commits=plan['commits_before'];self.raw_parents={h:base64.b64decode(b,validate=True) for h,b in plan['raw_parents'].items()};self.ancestry=plan['ancestry_before'];self.blobs={h:base64.b64decode(b,validate=True) for h,b in plan['blobs_before'].items()}
        for h,x in self.trees.items():need(object_oid('tree',tree_raw([{'path':n,**z} for n,z in x.items()]))==h,'every complete plan baseline tree reconstruction')
        for h,x in self.commits.items():existing_commit(x,h,self.raw_parents.get(h))
        for h,b in self.blobs.items():need(blob_oid(b)==h,'every complete baseline blob reconstruction')
def check_grant(g,bp,pp,plan,now=None):
    now=now or datetime.datetime.now(datetime.timezone.utc)
    need(g['status']=='ROOT_CLEARS_EXACT_PR284_AUTHOR_BRANCH_CORRECTION' and g['execution_authority'] is True and g['fixture_only'] is False and g['unresolved_issues']==[],'fresh exact ROOT execution grant only')
    need(g['candidate_binding']==bp and g['plan']==pp and g['sources']==sourcepins(),'entire exact readiness/plan/source binding')
    need(g['publication_readiness']==plan['publication_readiness'] and g['proposed_manifest']==plan['proposed_manifest'] and g['full_candidate_catalog']==plan['full_candidate_catalog'],'explicit exact ROOT readiness and final closed candidate selector pins')
    need(g['administrative_finalization_acceptance']==plan['administrative_finalization_acceptance'],'exact optional ROOT administrative lineage acceptance in plan and grant')
    need(g['expected_main_queue_transition']==plan['expected_main_queue_transition'],'exact reviewed scientific QUEUE transition/null in plan and grant')
    need(g['raw_parent_inputs']==plan['raw_parent_inputs'],'exact ROOT raw parent byte input pins in plan and grant')
    need(g['source_catalog']==pin(B/'FULL_CATALOG.json') and g['source_catalog']['mode']==0o444 and all(x['mode']==0o444 for x in g['sources'].values()),'whole sealed preparation catalog and critical source modes')
    need(g['repository']==REPO and g['repository_id']==RID and g['repository_node_id']==RN and g['PR']==PR and g['pull_request_id']==PID and g['pull_request_node_id']==PN and g['branch']==BRANCH and g['account']==ACCOUNT and g['expected_pr_head']==plan['expected_pr_head'] and g['expected_main_head']==plan['expected_main_head'] and g['expected_after_commit']==plan['after_commit'] and g['expected_after_tree']==plan['after_root'],'exact expected heads, identities and deterministic result')
    need(g['scope']=='existing_PR284_branch_only_immutable_objects_then_one_expected_old_force_false_CAS' and g['maximum_ref_updates']==1 and g['forbidden_actions']==['metadata','ready','merge','close','comment','release','Zenodo','GWS','local_git_mutation'],'explicit branch-only write scope')
    need(re.fullmatch('[0-9a-f]{48}',g['nonce'] or '') is not None,'fresh ROOT supplied one-time nonce, no bundled grant')
    expiry=datetime.datetime.fromisoformat(g['expires_UTC']);issued=datetime.datetime.fromisoformat(g['issued_UTC'])
    need(issued.tzinfo is not None and expiry.tzinfo is not None and issued<=now and expiry>now+datetime.timedelta(seconds=75) and expiry-issued<=datetime.timedelta(minutes=30),'fresh nonexpired bounded grant with late-check buffer')
    review=json.loads(match(g['source_and_plan_review']))
    rp=pathlib.Path(g['source_and_plan_review']['path']);need(rp.parent==W and rp.name.startswith('ROOT_PR284_AUTHOR_ACTOR_PLAN_REVIEW_'),'literal ROOT-owned final source/plan review')
    need(review['status']=='ROOT_ACCEPTS_EXACT_PR284_AUTHOR_ACTOR_AND_PLAN' and review['unresolved_issues']==[] and review['sources']==g['sources'] and review['plan']==pp and review['candidate_binding']==bp,'fresh independent whole-source and plan acceptance')
    return g
def mutations(plan,nonce):
    out=[['POST',PREFIX+'blobs',v] for _,v in sorted(plan['blob_requests'].items())]
    # A tree references children created before it. Compute exact bottom-up order.
    pending=dict(plan['tree_requests']);done=set()
    while pending:
        ready=[h for h,p in pending.items() if all(z['type']!='tree' or z['sha'] not in pending for z in p['tree'])]
        need(ready,'acyclic complete new tree DAG')
        for h in sorted(ready):out.append(['POST',PREFIX+'trees',pending.pop(h)]);done.add(h)
    out.append(['POST',PREFIX+'commits',plan['commit_request']]);out.append(['POST','graphql',ref_payload(plan['expected_pr_head'],plan['after_commit'],nonce)])
    return out
def execute(a):
    planpath=literal(a.plan);need(planpath.name=='PLAN.json' and planpath.parent.parent==W and planpath.parent.name.startswith('ROOT_author_branch_readonly_'),'exact dedicated ROOT read-only plan domain')
    pp=pin(planpath);need(pp['sha256']==a.plan_sha256 and pp['mode']==0o444,'exact ROOT-reviewed plan bytes')
    plan=json.loads(match(pp));bp=plan['candidate_binding'];binding,selected,original=candidate(bp)
    need(plan['expected_main_queue_transition']==binding.get('expected_main_queue_transition'),'exact reviewed scientific QUEUE transition/null in plan and candidate binding')
    need(plan['administrative_finalization_acceptance']==binding.get('administrative_finalization_acceptance'),'final plan exact administrative lineage acceptance pin')
    actualraw=raw_parent_inputs(binding);need(plan['raw_parent_inputs']==binding['raw_parent_inputs'] and plan['raw_parents']=={h:base64.b64encode(b).decode() for h,b in actualraw.items()},'plan complete parent bytes equal exact ROOT raw input pins')
    gp=rootpin(a.grant,a.grant_sha256,'ROOT_PR284_AUTHOR_BRANCH_GRANT_');g=check_grant(json.loads(match(gp)),bp,pp,plan)
    need(plan['sources']==sourcepins(),'source remained exact after source review')
    rebuilt,_=derive(FrozenObjects(plan),binding,selected,original,plan['expected_pr_head'],plan['expected_main_head'],plan['commit_request'])
    need(all(plan[k]==v for k,v in rebuilt.items()),'full deterministic reviewed plan replay')
    need(a.run_dir==g['run_directory'],'exact ROOT grant nonce run path')
    run=run_directory(a.run_dir,'execution',g['nonce']) # exclusive mkdir burns this nonce before any API write
    write(run,'ONE_TIME_NONCE_CONSUMED.json',{'UTC':utc(),'time_ns':time.time_ns(),'actual_PID':os.getpid(),'nonce':g['nonce'],'grant':gp,'outcome':'UNKNOWN_UNTIL_FULL_READBACK','automatic_retry':False})
    api=API(run,mutations(plan,g['nonce']),authority={'grant':gp,'plan':pp,'run_directory':str(run)});identity(api,plan['expected_pr_head'],plan['expected_main_head'])
    check_grant(json.loads(match(gp)),bp,pp,plan);candidate(bp)
    # Verify immutable baseline objects again without reconstructing repository refs.
    objects=Objects(api,raw_parent_inputs(binding))
    for h,x in plan['commits_before'].items():need(objects.commit(h)==x,'exact baseline commit unchanged')
    for key in plan['ancestry_before']:
        anchor,head=key.split('...');need(objects.ancestor(anchor,head)==FrozenObjects(plan).ancestor(anchor,head),'fresh exact bound-head ancestry boolean agrees with frozen plan, including truthful negative relation')
    for h,x in plan['trees_before'].items():need(objects.tree(h)==x,'every immutable selected Merkle slice unchanged')
    for h,b in plan['blobs_before'].items():need(objects.blob(h)==base64.b64decode(b,validate=True),'full latest-main QUEUE body unchanged')
    for h,payload in sorted(plan['blob_requests'].items()):
        x=api.post(PREFIX+'blobs',payload);need(x['sha']==h,'uploaded blob expected canonical identity');need(objects.blob(h)==base64.b64decode(payload['content'],validate=True),'full uploaded blob readback')
        write(run,f'ACTOR_MUTATION_{len(api.sent)-1:04d}_READBACK_COMPLETE.json',{'mutation_ordinal':len(api.sent)-1,'canonical_object':h,'complete_full_readback':True})
    while api.mutations and api.mutations[0][1]==PREFIX+'trees':
        _,path,payload=api.mutations[0];h=object_oid('tree',tree_raw(payload['tree']))
        x=api.post(path,payload);need(x['sha']==h,'uploaded tree expected canonical identity');need(objects.tree(h)=={z['path']:{k:z[k] for k in ('mode','type','sha')} for z in payload['tree']},'every uploaded tree full readback')
        write(run,f'ACTOR_MUTATION_{len(api.sent)-1:04d}_READBACK_COMPLETE.json',{'mutation_ordinal':len(api.sent)-1,'canonical_object':h,'complete_full_readback':True})
    cp=plan['commit_request'];x=api.post(PREFIX+'commits',cp);need(x['sha']==plan['after_commit'],'uploaded commit canonical SHA1 expected')
    objects.raw_parents[plan['after_commit']]=base64.b64decode(plan['commit_raw_base64'],validate=True)
    c=objects.commit(plan['after_commit']);need(c['tree']['sha']==plan['after_root'] and [z['sha'] for z in c['parents']]==plan['parents'] and existing_commit(c,plan['after_commit'],objects.raw_parents[plan['after_commit']])==base64.b64decode(plan['commit_raw_base64'],validate=True),'full exact uploaded two-parent merge-ancestry commit')
    write(run,f'ACTOR_MUTATION_{len(api.sent)-1:04d}_READBACK_COMPLETE.json',{'mutation_ordinal':len(api.sent)-1,'canonical_object':plan['after_commit'],'complete_full_readback':True})
    identity(api,plan['expected_pr_head'],plan['expected_main_head']);check_grant(json.loads(match(gp)),bp,pp,plan);candidate(bp)
    write(run,'FINAL_CAS_INTENT.json',{'UTC':utc(),'time_ns':time.time_ns(),'beforeOid':plan['expected_pr_head'],'afterOid':plan['after_commit'],'main_before':plan['expected_main_head'],'force':False,'maximum_ref_updates':1,'automatic_retry':False,'grant':gp})
    response=api.post('graphql',ref_payload(plan['expected_pr_head'],plan['after_commit'],g['nonce']))
    need(response['data']['updateRefs']['clientMutationId']=='pr284_'+g['nonce'] and not api.mutations,'sole exact CAS acknowledgment')
    identity(api,plan['after_commit'],plan['expected_main_head'])
    final=Objects(api,{plan['after_commit']:base64.b64decode(plan['commit_raw_base64'],validate=True)});after=final.commit(plan['after_commit']);need(after['tree']['sha']==plan['after_root'] and [z['sha'] for z in after['parents']]==plan['parents'],'full fresh immutable after commit')
    expectedtarget={x['path']:{'mode':'100644','type':'blob','sha':x['blob']} for x in plan['selected'] if x['path'].startswith(T+'/')}
    need(final.target(plan['after_root'])==expectedtarget,'full exact final attempt topology')
    for x in plan['selected']:
        z=final.locate(plan['after_root'],x['path']);need(z=={'mode':'100644','type':'blob','sha':x['blob']},'every selected final path/mode/blob')
        b=final.blob(x['blob']);need(len(b)==x['bytes'] and sha(b)==x['sha256'],'every final selected full-byte readback')
    for proof in plan['merkle_preservation']:
        rows=final.tree(proof['after']);need(all(rows[n]==x for n,x in proof['unselected'].items()),'every unselected main Merkle sibling full readback')
    result={'status':'BRANCH_CONTENT_CAS_AND_FULL_READBACK_SUCCEEDED_PENDING_ROOT_ADVERSARY','UTC':utc(),'time_ns':time.time_ns(),'branch':BRANCH,'PR':PR,'head':plan['after_commit'],'tree':plan['after_root'],'parents':plan['parents'],'ref_updates':1,'metadata_writes':0,'grant':gp,'execution_does_not_clear_metadata_ready_merge_or_publication':True}
    write(run,'RESULT.json',result);print(json.dumps(result,indent=2))
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','execute']);p.add_argument('--run-dir',required=True)
    for k in ('binding','binding-sha256','main-head','pr-head','commit-spec','plan','plan-sha256','grant','grant-sha256'):p.add_argument('--'+k)
    a=p.parse_args();prepare(a) if a.mode=='prepare' else execute(a)
if __name__=='__main__':main()
