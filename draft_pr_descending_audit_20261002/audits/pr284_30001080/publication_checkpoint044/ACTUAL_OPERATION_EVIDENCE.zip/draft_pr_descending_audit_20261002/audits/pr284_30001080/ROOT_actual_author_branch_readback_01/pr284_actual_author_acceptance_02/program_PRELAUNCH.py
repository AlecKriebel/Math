"""ROOT independent completed-operation readback, local only, no new authority."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import base64,gzip,hashlib,json,os,stat,sys
assert sys.flags.ignore_environment and sys.dont_write_bytecode and not sys.flags.optimize
W=Path(__file__).resolve().parent;R=W.parents[2]
NONCE='ffc6dd67b4f7a490716e4d3b407c477ee04ea0f6e3ebbb74'
RUN=W/('ROOT_author_branch_execution_'+NONCE);OUT=W/'ROOT_author_actor_execution_capture_01'
D=W/'actual_author_branch_adversary_01';O=W/'ROOT_actual_author_branch_readback_01'
OLD='391cb662b1599ef564ff15b63cd8ed73c7d1f125';MAIN='f36cb1e34696d460b9cfb5b03425998de48c4669'
HEAD='7d244eed5d7ddd89d5c540aecfa72490b7b30073';TREE='cdbc30401d63ae3a008e272a10fcfc8cd14bae33'
GIT='repos/AlecKriebel/Math/git/';Q='unsolved_math_prioritization/QUEUE.md';T='unsolved_math_prioritization/attempts/30001080'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b),mode=stat.S_IMODE(p.stat().st_mode))
def exact(x):
 p=Path(x['path']);actual=pin(p);assert not p.is_symlink() and {'path','bytes','sha256'}<=set(x)<=set(actual) and all(actual[k]==z for k,z in x.items());return p.read_bytes()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def packet(d,h):
 cp=d/('OWN_BODY_CATALOG.json' if d==D else 'FULL_CATALOG.json');assert pin(cp)['sha256']==h;c=load(cp);entries=c.get('files',c.get('entries'));names=[x['path'] for x in entries]
 assert len(names)==len(set(names)) and {p.relative_to(d).as_posix() for p in d.rglob('*') if p.is_file()}==set(names)|{cp.name}
 for x in entries:
  p=d/x['path'];assert p.is_relative_to(d) and '..' not in Path(x['path']).parts;b=p.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 for p in [d,*d.rglob('*')]:assert not p.is_symlink() and stat.S_IMODE(p.stat().st_mode)==(0o555 if p.is_dir() else 0o444)
 return pin(cp)
def tree(x):
 assert x['truncated'] is False;m={z['path']:{k:z[k] for k in ('mode','type','sha')} for z in x['tree']};assert len(m)==len(x['tree']);raw=b''
 for n,z in sorted(m.items(),key=lambda kv:kv[0].encode()+(b'/' if kv[1]['type']=='tree' else b'')):
  assert n and '/' not in n and '\0' not in n and (z['mode'],z['type']) in [('040000','tree'),('100644','blob'),('100755','blob'),('120000','blob'),('160000','commit')]
  raw+=z['mode'].lstrip('0').encode()+b' '+n.encode()+b'\0'+bytes.fromhex(z['sha'])
 assert oid('tree',raw)==x['sha'];return m
def blob(x):
 assert x['encoding']=='base64';b=base64.b64decode(x['content']);assert len(b)==x['size'] and oid('blob',b)==x['sha'];return b
def native(d,expected_rc=0):
 q,s,e=[load(d/n) for n in ('request.json','started.json','execution.json')]
 assert q['argv']==e['argv'] and q['cwd']==str(R) and q['actual_recorder_PID']==e['actual_recorder_PID'] and s['actual_child_PID']==e['actual_child_PID']
 assert e['returncode']==expected_rc and e['failure'] is None and e['cleanup_errors']==[] and all(e[k] is True for k in ('reaped','communication_complete','wait_completed'))
 if 'prelaunch_error' in q:
  assert q['prelaunch_error'] is None and q['executable_custody']=='AVAILABLE';exact(q['executable'])
  for x in q['script_arguments']:exact(x)
 if 'time_ns' in q:assert q['time_ns']<=s['time_ns']<=e['time_ns']
 streams={}
 for n,z in e['streams'].items():
  p=d/(n+'.gz');stored=p.read_bytes();b=gzip.decompress(stored);assert z['path']==str(p) and z['complete'] is True and len(stored)==z['stored_bytes'] and sha(stored)==z['stored_sha256'] and len(b)==z['logical_bytes'] and sha(b)==z['logical_sha256'];streams[n]=b
 if q['stdin_bytes']:
  b=gzip.decompress((d/'stdin.gz').read_bytes());assert len(b)==q['stdin_bytes'] and sha(b)==q['stdin_sha256'];streams['stdin']=b
 else:assert q['stdin_sha256'] is None
 return q,e,streams
adh,vh=sys.argv[1:];adc=packet(D,adh);vp=D/'VERDICT.json';v=load(vp);assert pin(vp)['sha256']==vh and v['status'].startswith('PASS') and v['execution_authority'] is False and v['unresolved_issues']==[] and v['blocking_findings']==[]
assert v['actual_author_branch_result_accepted'] is True
for d in sorted((D/'private/native').iterdir()):
 rc=load(d/'execution.json')['returncode'];assert type(rc) is int and rc in (0,1);native(d,rc)
assert load(D/'ACTUAL_BRANCH_REVIEW_RESULTS.json')['all_passed'] is True
for x in v['own_genuine_native_custody_all_attempts']:
 exact(x['execution4pin']);e=load(x['execution4pin']['path']);assert e['actual_recorder_PID']==x['actual_recorder_PID'] and e['actual_child_PID']==x['actual_child_PID'] and e['argv']==x['actual_argv'] and e['returncode']==x['returncode']
for k in ('full_actual_results4pin','independent_pre_result_baseline4pin','fixed_matrix_before_result_view4pin','actual_raw_parent_custody_addendum4pin','successful_actual_review_native4pin','raw_parent_addendum_native4pin'):exact(v[k])
assert load(D/'RAW_PARENT_CUSTODY_ADDENDUM.json')['passed'] is True
baseline=load(D/'BASELINE.json');assert len(baseline['protected_complete_body_pins'])==589
for x in baseline['protected_complete_body_pins']:exact(x)
ac=load(W/'ROOT_PR284_AUTHOR_ACTOR_PLAN_REVIEW_01.json');assert ac['status']=='ROOT_ACCEPTS_EXACT_PR284_AUTHOR_ACTOR_AND_PLAN' and not ac['execution_authority'] and ac['unresolved_issues']==[]
P=json.loads(exact(ac['plan']));B=json.loads(exact(ac['candidate_binding']));g=load(W/'ROOT_PR284_AUTHOR_BRANCH_GRANT_01.json');gp=pin(W/'ROOT_PR284_AUTHOR_BRANCH_GRANT_01.json')
assert P['sources']==ac['sources']==g['sources'] and g['plan']==ac['plan'] and g['candidate_binding']==ac['candidate_binding'] and g['source_and_plan_review']==pin(W/'ROOT_PR284_AUTHOR_ACTOR_PLAN_REVIEW_01.json')
for x in P['sources'].values():exact(x)
assert (P['expected_pr_head'],P['expected_main_head'],P['after_commit'],P['after_root'])==(OLD,MAIN,HEAD,TREE) and P['parents']==[OLD,MAIN]
assert g['nonce']==NONCE and g['maximum_ref_updates']==1 and g['forbidden_actions']==['metadata','ready','merge','close','comment','release','Zenodo','GWS','local_git_mutation']
manifest=json.loads(exact(B['proposed_manifest']));C=Path(B['candidate_directory']);selected={}
for x in manifest['files']:
 b=(C/'proposed'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];selected[x['path']]=b
assert len(selected)==69
mainq=(W/'ROOT_main_selected_baseline_readback_07/MAIN_QUEUE_FULL.bin').read_bytes();rows=mainq.splitlines(keepends=True)
def isrow(z):return len(z.split(b'|'))>2 and z.split(b'|')[2].strip()==b'30001080 / OWR-2093-003'
indices=[i for i,z in enumerate(rows) if isrow(z)];assert len(indices)==1;i=indices[0];old=rows[i].rstrip(b'\r\n');new=[z for z in selected[Q].splitlines() if isrow(z)];assert len(new)==1;new=new[0]
a,b=old.split(b'|'),new.split(b'|');assert len(a)==len(b)==14 and [k for k,(x,y) in enumerate(zip(a,b)) if x!=y]==[8,9,11,12] and b[8].strip()==b'claimed_solved' and b[9].strip()==b'3/5'
selected[Q]=b''.join(rows[:i])+new+rows[i][len(old):]+b''.join(rows[i+1:]);assert sha(selected[Q])==P['queue_preservation']['after_whole_sha256']
assert P['selected']==[dict(path=p,bytes=len(z),sha256=sha(z),blob=oid('blob',z)) for p,z in sorted(selected.items())]
blobs={oid('blob',z):{'encoding':'base64','content':base64.b64encode(z).decode()} for z in selected.values()};assert blobs==P['blob_requests'] and len(blobs)==63
cp=P['commit_request'];raw=b'tree '+TREE.encode()+b'\n'+b''.join(b'parent '+h.encode()+b'\n' for h in [OLD,MAIN])
for role in ('author','committer'):
 x=cp[role];dt=datetime.fromisoformat(x['date']);assert dt.utcoffset()==timedelta(0) and not dt.microsecond;raw+=(role+' '+x['name']+' <'+x['email']+'> '+str(int(dt.timestamp()))+' +0000\n').encode()
raw+=b'\n'+cp['message'].encode();assert raw==base64.b64decode(P['commit_raw_base64'],validate=True) and oid('commit',raw)==HEAD
for h,x in P['raw_parent_inputs'].items():assert oid('commit',exact(x))==h
assert v['PLAN4pin']==ac['plan'] and v['binding4pin']==ac['candidate_binding'] and v['sources4pins']==P['sources'] and v['grant4pin_terminal_NEVER_REPLAY']==gp
rc=packet(RUN,'98e635c992a50eb9b590c366d17cd525aa049f4583ea2363a5d5c458a1d95c88');oc=packet(OUT,'489b4f492e57254aa95466dcfd0a9e99ed614d184aac6b57099d3980fbc91567')
assert v['actual_RUN_catalog4pin']==rc and v['actual_ROOT_outer_catalog4pin']==oc and v['actual_result4pin']==pin(RUN/'RESULT.json')
oq,oe,ostream=native(OUT/'private/native/actual_execute');assert (oq['actual_recorder_PID'],oe['actual_child_PID'])==(72339,72340) and oq['context']['ROOT_grant']==gp and oq['context']['sources']==P['sources'] and ostream['stderr']==b''
result=load(RUN/'RESULT.json');assert json.loads(ostream['stdout'])==result and result['head']==HEAD and result['tree']==TREE and result['parents']==[OLD,MAIN] and result['ref_updates']==1 and result['metadata_writes']==0 and result['grant']==gp
consumed=load(RUN/'ONE_TIME_NONCE_CONSUMED.json');assert consumed['actual_PID']==72340 and consumed['nonce']==NONCE and consumed['grant']==gp and consumed['automatic_retry'] is False
issued,expiry=map(datetime.fromisoformat,(g['issued_UTC'],g['expires_UTC']));assert expiry-issued==timedelta(minutes=30) and issued<=datetime.fromisoformat(consumed['UTC'])<datetime.fromisoformat(result['UTC'])<expiry
workers=[];pids=set()
for n,d in enumerate(sorted((RUN/'private/native').iterdir()),1):
 q,e,streams=native(d);assert q['actual_recorder_PID']==72340 and streams['stderr']==b'' and q['context']=={'actor':P['sources']['actor.py'],'transport_worker':P['sources']['http_worker.py']} and q['script_arguments']==[P['sources']['http_worker.py']]
 assert oq['time_ns']<q['time_ns']<e['time_ns']<oe['time_ns'] and e['actual_child_PID'] not in pids;pids.add(e['actual_child_PID'])
 env=json.loads(streams['stdin']);x=json.loads(streams['stdout']);assert d.name==f'{n:04d}_'+env['method'] and x['actual_worker_PID']==e['actual_child_PID'] and x['complete'] is True and x['status'] in (200,201) and x['requests_sent']==1 and x['redirects_followed']==x['retries']==0
 body=base64.b64decode(x['body_base64'],validate=True);assert len(body)==x['body_bytes'] and sha(body)==x['body_sha256'];data=json.loads(body);assert not data.get('errors')
 m=x['credential_metadata'];assert m['actual_parent_PID']==e['actual_child_PID'] and m['secret_stream_full_capture_claim'] is False and m['environment_recorded'] is False
 if x.get('request_credentialless'):
  assert x['Authorization_header_sent'] is False and x['public_body_policy']['safe'] is True and m['credential_subprocess_started'] is False and m['actual_child_PID'] is None
 else:
  assert x['screen_policy']['safe'] is True and m['returncode']==0 and m['cleanup_errors']==[] and all(m[k] is True for k in ('wait_completed','communication_complete','reaped'));exact(m['executable']);assert m['secret_streams']=='INTENTIONALLY_UNRETAINED_IN_MEMORY_ONLY'
 if env['method']=='GET':assert env['execution_authority'] is False and env['payload'] is env['authority'] is env['mutation_ordinal'] is None
 else:assert env['method']=='POST' and env['execution_authority'] is True and env['authority']=={'grant':gp,'plan':ac['plan'],'run_directory':str(RUN)}
 workers.append(dict(d=d,q=q,e=e,env=env,x=x,data=data))
assert len(workers)==262 and min(pids)==72341 and workers[-1]['e']['actual_child_PID']==76004
expected=[(GIT+'blobs',z,h) for h,z in sorted(blobs.items())];pending=dict(P['tree_requests'])
while pending:
 ready=sorted(h for h,z in pending.items() if all(x['type']!='tree' or x['sha'] not in pending for x in z['tree']));assert ready
 for h in ready:expected.append((GIT+'trees',pending.pop(h),h))
expected.append((GIT+'commits',cp,HEAD));cas={'query':'mutation PR284AuthorBranchExactCAS($input:UpdateRefsInput!){updateRefs(input:$input){clientMutationId}}','variables':{'input':{'repositoryId':'R_kgDOTfIvPw','refUpdates':[{'name':'refs/heads/dot/math-30001080','beforeOid':OLD,'afterOid':HEAD,'force':False}],'clientMutationId':'pr284_'+NONCE}}};expected.append(('graphql',cas,None))
posts=[x for x in workers if x['env']['method']=='POST'];assert len(posts)==len(expected)==78
assert len(list(RUN.glob('WORKER_MUTATION_*_STARTED.json')))==len(list(RUN.glob('WORKER_MUTATION_*_RESULT.json')))==78 and len(list(RUN.glob('ACTOR_MUTATION_*_READBACK_COMPLETE.json')))==77
for i,(w,(route,payload,h)) in enumerate(zip(posts,expected)):
 env=w['env'];assert (env['path'],env['payload'],env['mutation_ordinal'])==(route,payload,i)
 sm=load(RUN/f'WORKER_MUTATION_{i:04d}_STARTED.json');assert sm['actual_worker_PID']==w['e']['actual_child_PID'] and sm['ordinal']==i and sm['grant']==gp and sm['automatic_retry'] is False and issued<=datetime.fromisoformat(sm['UTC'])<expiry-timedelta(seconds=75)
 assert load(RUN/f'WORKER_MUTATION_{i:04d}_RESULT.json')==w['x']
 if i:assert w['q']['time_ns']-posts[i-1]['e']['time_ns']>=1000000000
 if h:
  assert w['data']['sha']==h and load(RUN/f'ACTOR_MUTATION_{i:04d}_READBACK_COMPLETE.json')=={'mutation_ordinal':i,'canonical_object':h,'complete_full_readback':True}
  between=workers[workers.index(w)+1:workers.index(posts[i+1])];rb=[x['data'] for x in between if x['env']['path']==route+'/'+h];assert len(rb)==1
  if route.endswith('blobs'):assert blob(rb[0])==base64.b64decode(payload['content'],validate=True)
  elif route.endswith('trees'):assert tree(rb[0])=={x['path']:{k:x[k] for k in ('mode','type','sha')} for x in payload['tree']}
  else:assert rb[0]['tree']['sha']==TREE and [x['sha'] for x in rb[0]['parents']]==[OLD,MAIN]
 else:assert w['data']=={'data':{'updateRefs':{'clientMutationId':'pr284_'+NONCE}}}
pre=workers[:workers.index(posts[0])]
for h,x in P['commits_before'].items():assert [w['data'] for w in pre if w['env']['path']==GIT+'commits/'+h]==[x]
for h,x in P['trees_before'].items():assert [tree(w['data']) for w in pre if w['env']['path']==GIT+'trees/'+h]==[x]
for h,x in P['blobs_before'].items():assert [blob(w['data']) for w in pre if w['env']['path']==GIT+'blobs/'+h]==[base64.b64decode(x,validate=True)]
pos=workers.index(posts[-1]);before=workers[pos-5:pos];after=workers[pos+1:pos+6]
def group(group,head):
 assert [x['env']['path'] for x in group]==['user','repos/AlecKriebel/Math','repos/AlecKriebel/Math/pulls/284',GIT+'ref/heads/dot/math-30001080',GIT+'ref/heads/main']
 u,r,p,b,m=[x['data'] for x in group];assert u['login']=='AlecKriebel' and u['id']==6109370 and r['id']==1307717439 and p['id']==4705883104 and p['number']==284 and p['state']=='open' and p['draft'] is True and p['merged'] is False and p['head']['sha']==head and p['head']['ref']=='dot/math-30001080' and p['base']['ref']=='main' and b['object']['sha']==head and m['object']['sha']==MAIN
group(workers[:5],OLD);group(before,OLD);group(after,HEAD)
tail=workers[pos+6:];commit=tail[0]['data'];assert tail[0]['env']['path']==GIT+'commits/'+HEAD and commit['sha']==HEAD and commit['tree']['sha']==TREE and [x['sha'] for x in commit['parents']]==[OLD,MAIN] and commit['message']==cp['message'].rstrip('\n')
for role in ('author','committer'):assert all(commit[role][k]==cp[role][k] for k in ('name','email')) and datetime.fromisoformat(commit[role]['date'].replace('Z','+00:00'))==datetime.fromisoformat(cp[role]['date'])
fm={};fb={}
for w in tail[1:]:
 route=w['env']['path'];assert '/trees/' in route or '/blobs/' in route
 if '/trees/' in route:fm[w['data']['sha']]=tree(w['data'])
 else:fb[w['data']['sha']]=blob(w['data'])
assert set(fm)==set(P['tree_requests']) and len(fm)==13 and set(fb)==set(blobs) and len(fb)==63
for h,z in P['tree_requests'].items():assert fm[h]=={x['path']:{k:x[k] for k in ('mode','type','sha')} for x in z['tree']}
for x in P['merkle_preservation']:assert {n:fm[x['after']][n] for n in x['unselected']}==x['unselected']
def locate(p):
 h=TREE;parts=p.split('/')
 for i,n in enumerate(parts):
  x=fm[h][n]
  if i==len(parts)-1:return x
  assert x['type']=='tree';h=x['sha']
for p,b in selected.items():assert locate(p)=={'mode':'100644','type':'blob','sha':oid('blob',b)} and fb[locate(p)['sha']]==b
leaves={}
def walk(h,p):
 for n,x in fm[h].items():
  if x['type']=='tree':walk(x['sha'],p+'/'+n)
  else:leaves[p+'/'+n]=x
walk(locate(T)['sha'],T);assert set(leaves)==set(selected)-{Q}
intent=load(RUN/'FINAL_CAS_INTENT.json');assert intent['beforeOid']==OLD and intent['afterOid']==HEAD and intent['main_before']==MAIN and intent['force'] is False and intent['maximum_ref_updates']==1 and intent['automatic_retry'] is False
M=W/'pr284_final_pr_metadata_preparation_03';mc=load(M/'OWN_BODY_CATALOG.json');assert pin(M/'OWN_BODY_CATALOG.json')['sha256']=='fa0281090700aac61c04bfa82188dda86c17d53e84682c2bb78ffff796f4e52e'
for x in mc['files']:
 b=(M/x['relative_path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
newbody=(M/'PR_BODY.md').read_bytes();oldbody=(W/'pr284_final_pr_metadata_preparation_02/PR_BODY.md').read_bytes()
for f in ('README.md','verify_package.py'):
 p=T+'/preprint/verification/'+f;absolute=('https://github.com/AlecKriebel/Math/blob/'+HEAD+'/'+p).encode();assert absolute in newbody and p in selected;newbody=newbody.replace(absolute,p.encode())
assert newbody==oldbody
for x in baseline['protected_complete_body_pins']:exact(x)
rb={'UTC':datetime.now(timezone.utc).isoformat(),'actual_ROOT_PID':os.getpid(),'actual_argv':sys.orig_argv,'head':HEAD,'tree':TREE,'ordered_parents':[OLD,MAIN],'plan':ac['plan'],'candidate_binding':ac['candidate_binding'],'sources':P['sources'],'grant_terminal_NEVER_REPLAY':gp,'actual_run_catalog':rc,'actual_outer_catalog':oc,'actual_result':pin(RUN/'RESULT.json'),'fresh_adversary_catalog':adc,'fresh_adversary_verdict':pin(vp),'full_native_workers':262,'canonical_POSTs':78,'immutable_objects_with_full_readback':77,'ref_updates':1,'metadata_writes':0,'all69_selected_bytes_and_full_QUEUE_transition_verified':True,'all_unselected_main7_siblings_preserved':True,'all589_protected_bodies_unchanged':True,'metadata03_only_two_immutable_link_destinations_changed':True,'execution_authority':False,'credential_stream_qualification':'Actual secret streams intentionally not retained; no recovery or full secret-stream capture claim.','final_raw_commit_qualification':'Canonical final bytes independently reconstructed from immutable request and full readback, hash to HEAD; no new raw-final remote fetch.'}
O.mkdir(exist_ok=False);rp=O/'READBACK.json';rp.write_text(json.dumps(rb,indent=2)+'\n');rp.chmod(0o444)
accepted={'status':'ROOT_ACCEPTS_EXACT_PR284_ACTUAL_AUTHOR_BRANCH','accepted':True,'UTC':rb['UTC'],'actual_ROOT_PID':os.getpid(),'head':HEAD,'tree':TREE,'ordered_parents':[OLD,MAIN],'unresolved_issues':[],'execution_authority':False,'ROOT_readback':pin(rp),'fresh_review_catalog':adc,'fresh_review_verdict':pin(vp),'actual_run_catalog':rc,'actual_outer_catalog':oc,'actual_result':pin(RUN/'RESULT.json'),'plan':ac['plan'],'candidate_binding':ac['candidate_binding'],'sources':P['sources'],'grant_terminal_NEVER_REPLAY':gp,'DOI':'10.5281/zenodo.23180194','tracker_row':30,'remote_mutations_by_this_ROOT_validator':0}
ap=W/'ROOT_PR284_ACTUAL_AUTHOR_BRANCH_ACCEPTANCE_01.json';assert not ap.exists();ap.write_text(json.dumps(accepted,indent=2)+'\n');ap.chmod(0o444);print(json.dumps({'acceptance':pin(ap),'verified_workers':262,'verified_POSTs':78,'selected_paths':69,'head':HEAD}))
