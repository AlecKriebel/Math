"""Pure, additive administrative lineage gate; never executes recipe or authority.
Original readiness remains bound to immutable03. ROOT's separate exact literal
acceptance authenticates actual publication/tracker evidence and full69 parity.
This module independently guards protected bodies and the complete exact delta.
"""
import base64,datetime,gzip,json,pathlib,re
BASE_MANIFEST='3cbda71cac5de12a198c6bb563620eb1731fd6d686cc7d3cf6c482606b73d32f'
BASE_CATALOG='00b25a65baabd44b4412e34f3fe01e0ee50f9afeb71e6f5259df14ebb8cf1456'
SECOND_REVIEW='2644862432d006fb12f9e21df089a08f4d6879d919d45b9d89f813223eb01e3d'
DEPENDENT={'FROZEN_INPUT_MANIFEST.json':{'schema','frozen_at_utc','status','files','whole_preprint_review_history','administrative_publication_status','candidate03_ancestry'},'FROZEN_MANIFEST.json':{'schema','frozen_at_utc','state','files','whole_preprint_review_history','administrative_publication_status','candidate03_ancestry'},'independent_review/HASH_CHECK.json':{'author_manifest_sha256','frozen_input_manifest_sha256','author','administrative_publication_status','candidate03_ancestry'},'independent_review/REVIEW_MANIFEST.json':{'author_manifest_sha256','frozen_input_manifest_sha256','files','verdict','whole_preprint_review_history','administrative_publication_status','candidate03_ancestry'}}
HISTORY={'new_independent_second_whole_review_pending','current_whole_preprint_clean_certified','publication_ready','second_review_ROOT_acceptance','second_review_subject'}

def portable(p):return {'artifact':pathlib.Path(p['path']).name,'bytes':p['bytes'],'sha256':p['sha256']}
def pack(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def pointer(o,p):
    if not isinstance(p,str) or not p.startswith('/'):raise ValueError('explicit actual evidence pointer required')
    for part in p[1:].split('/'):
        key=part.replace('~1','/').replace('~0','~');o=o[int(key)] if isinstance(o,list) else o[key]
    return o

def status(ac,p,t):
    s=ac['publication_status']
    pub={'record_id':p['record_id'],'doi':p['doi'],'record_url':p['record_url'],'doi_url':p['doi_url'],'accepted_asof_UTC':p['asof_UTC'],'actual_published_verified':True}
    tracker={k:t[k] for k in ['spreadsheet_id','sheet_id','sheet_title','row_number','range','asof_UTC']}
    if s['publication']!=pub or s['tracker']!=tracker or s['asof_UTC']!=t['asof_UTC']:raise ValueError('literal portable actual publication/tracker facts')
    if s['native_merge_completed'] is not False or s['original2_plus_one_joint_repair_total_turns']!=3 or s['remaining_turns']!=2 or s['turn4_authorized'] is not False:raise ValueError('no invented merge/turn4/counter completion')
    for k,pin in [('candidate03_catalog',ac['base_full_catalog']),('candidate03_manifest',ac['base_proposed_manifest']),('second_whole_review_ROOT_acceptance',ac['second_review_ROOT_acceptance']),('actual_publication_ROOT_acceptance',ac['actual_publication_ROOT_acceptance']),('actual_tracker_ROOT_acceptance',ac['actual_tracker_ROOT_acceptance'])]:
        if s[k]!=portable(pin):raise ValueError('literal portable03/evidence ancestry')
    if s['review_subject']!='Second clean content review applies to immutable candidate03. Administrative successor requires separate exact ROOT parity/source-guard acceptance.':raise ValueError('no fabricated whole-review04 subject')
    return s
def prefix(ac):
    b=base64.b64decode(ac['administrative_prefix_base64'],validate=True)
    if not b or len(b)>65536 or b'\0' in b:raise ValueError('bounded full literal administrative prefix')
    b.decode('utf-8',errors='strict');return b
def delta(a,base,final):
    def body(b):return None if b is None else {'bytes':len(b),'sha256':a.sha(b)}
    return [{'path':p,'before':body(base.get(p)),'after':body(final.get(p))} for p in sorted(set(base)|set(final))]
def check_acceptance(a,ac,binding,readiness):
    a.need(ac['schema']=='pr284-root-exact-administrative-finalization-acceptance-v1' and ac['status']=='ROOT_ACCEPTS_EXACT_PR284_ADMINISTRATIVE_FINALIZATION' and ac['execution_authority'] is False and ac['fixture_only'] is False and ac['unresolved_issues']==[],'separate actual exact ROOT administrative acceptance; never a whole-review04 or execution grant')
    a.need(ac['base_candidate_directory']==str(a.W/'global_claim_correction_preparation_03') and ac['base_proposed_manifest']['sha256']==BASE_MANIFEST and ac['base_full_catalog']['sha256']==BASE_CATALOG,'immutable exact03 ancestry')
    a.need(ac['final_candidate_directory']==binding['candidate_directory'] and ac['final_proposed_manifest']==binding['proposed_manifest'] and ac['final_full_catalog']==binding['full_catalog'] and ac['base_proposed_manifest']!=ac['final_proposed_manifest'],'literal new final candidate manifest/catalog binding')
    a.need(ac['publication_readiness']==binding['publication_readiness'] and a.sealed_pin_projection(ac['public_package_manifest'])==a.readiness_pin(readiness['candidate']),'original publication gate/public22 exact pins')
    a.validate_readiness(readiness,ac['base_proposed_manifest'])
    a.need(ac['second_review_ROOT_acceptance']['sha256']==SECOND_REVIEW,'exact second-whole03 proof pin; recipe version separately ROOT accepted')

def body_parity(a,base,final,public_manifest,budget,s,accepted_delta,pr):
    """Full-body independent preservation; no fixture or boolean shortcuts."""
    pre=a.T+'/';a.need(set(final)==set(base)|{pre+'PUBLICATION_STATUS.json'} and len(base)==68 and len(final)==69,'exact additive69 body topology; no deleted or extra scientific files')
    a.need(accepted_delta==delta(a,base,final),'complete literal69 before/after full-byte delta, including unchanged files')
    files=public_manifest['files'];a.need(len(files)==22 and len({x['path'] for x in files})==22,'exact frozen22 public file selector')
    for x in files:
        rel=pre+'preprint/'+a.safe(x['path']);a.need(rel in base and base[rel]==final[rel] and len(base[rel])==x['bytes'] and a.sha(base[rel])==x['sha256'],'each entire public body unchanged and frozen22 hash-bound')
    a.need(final[pre+'PUBLICATION_STATUS.json']==pack(s),'portable status exact actual evidence projection; no scientific verdict04')
    docs=set(budget['Markdown_prepend_only_retaining_entire_prior_body']);logs=set(budget['Markdown_append_only_retaining_entire_prior_body']);fields=budget['JSON_allowed_top_level_keys']
    allowed_fields={'CLAIM_STATUS.json':{'state','publication_clearance','fresh_global_preprint_review_accepted','whole_preprint_review_history','administrative_publication_status','progress_is_historical_asof'},'PREPRINT_BINDING.json':{'fresh_whole_preprint_reviews_pending','publication_ready','manuscript_DOI','administrative_publication_status'},'PRIORITY_ACCEPTANCE.json':{'fresh_whole_preprint_reviews_pending','publication_ready','whole_preprint_review_history','administrative_publication_status','progress_is_historical_asof'},'TURN_STATE.json':{'state','publication_clearance','fresh_global_preprint_review_accepted','whole_preprint_review_history','administrative_publication_status','progress_is_historical_asof'},'independent_review/SCOPED_REVIEW_CREDITS.json':{'current_global_verdict','whole_preprint_review_history','administrative_publication_status'},'metadata.json':{'doi','status','publication_clearance','fresh_whole_preprint_review_accepted','whole_preprint_review_history','administrative_publication_status','progress_is_historical_asof'},'source_manifest.json':{'administrative_evidence_pins'}}
    a.need(docs=={'SCOPE_AND_CREDIT.md','RESULT.md','TURN_2.md','TURN_3.md','SOURCE_AUDIT.md','REPRODUCTION.md','REVIEW_REQUEST.md','independent_review/INDEPENDENT_REVIEW.md','independent_review/SOURCE_NOTES.md'} and logs=={'RESEARCH_LOG.md'} and set(fields)==set(allowed_fields) and all(set(fields[k])<=v for k,v in allowed_fields.items()) and set(budget['dependent_manifests_regenerate'])==set(DEPENDENT) and budget['new_public_files_only']==['PUBLICATION_STATUS.json'],'ROOT recipe may narrow but never broaden administrative surface budget')
    for rel,old in base.items():
        new=final[rel];short=rel[len(pre):] if rel.startswith(pre) else None
        if short in docs:a.need(new==pr+old,'entire scientific/source Markdown body retained after exact dated prefix')
        elif short in logs:a.need(new==old+b'\n'+pr,'entire research history retained before exact dated append')
        elif short in fields or short in DEPENDENT:
            before=json.loads(old);after=json.loads(new);allowed=set(fields[short]) if short in fields else DEPENDENT[short]
            a.need({k:v for k,v in before.items() if k not in allowed}=={k:v for k,v in after.items() if k not in allowed},'all nonadministrative JSON fields unchanged')
            if 'progress' in before:a.need(after['progress']==before['progress'] and after['progress_is_historical_asof']==before['progress']['workflow_asof_UTC'],'frozen counters and historical checkpoint unchanged')
            if 'whole_preprint_review_history' in before:
                bh=before['whole_preprint_review_history'];ah=after['whole_preprint_review_history']
                a.need({k:v for k,v in bh.items() if k not in HISTORY}=={k:v for k,v in ah.items() if k not in HISTORY},'first rejection and immutable history unchanged')
                a.need(ah['new_independent_second_whole_review_pending'] is False and ah['current_whole_preprint_clean_certified'] is True and ah['publication_ready'] is True and ah['second_review_ROOT_acceptance']==s['second_whole_review_ROOT_acceptance'] and ah['second_review_subject']==s['review_subject'],'second clean verdict explicitly targets03')
            if short=='source_manifest.json':a.need(after['administrative_evidence_pins']=={k:s[k] for k in ['second_whole_review_ROOT_acceptance','actual_publication_ROOT_acceptance','actual_tracker_ROOT_acceptance']},'source exact actual ROOT evidence pins')
            else:a.need(after['administrative_publication_status']==s,'all administrative wrappers exact actual status')
            if short in DEPENDENT:
                a.need(after['candidate03_ancestry']=={k:s[k] for k in ['candidate03_catalog','candidate03_manifest','second_whole_review_ROOT_acceptance']},'dependent exact03 ancestry')
                if short in {'FROZEN_INPUT_MANIFEST.json','FROZEN_MANIFEST.json'}:a.need(after['frozen_at_utc']==s['asof_UTC'],'actual administrative freeze date')
        elif rel==a.Q:
            aa,(i,core,eol)=a.queue_row(old);bb,(j,newcore,neweol)=a.queue_row(new)
            a.need(i==j==316 and len(aa)==len(bb) and aa[:i]==bb[:i] and aa[i+1:]==bb[i+1:],'only literal317 own QUEUE row; all other bytes identical03')
            oldcells=aa[i].rstrip(b'\r\n').split(b'|');newcells=bb[i].rstrip(b'\r\n').split(b'|')
            a.need(len(oldcells)==len(newcells)==14 and all(x==y for k,(x,y) in enumerate(zip(oldcells,newcells)) if k not in (11,12)) and oldcells[8].strip()==newcells[8].strip()==b'claimed_solved' and oldcells[9].strip()==newcells[9].strip()==b'3/5' and eol==neweol,'literal mathematical status claimed_solved and all QUEUE cells except Notes/DOI retained')
            marker=b'fresh whole-preprint review pending; A-only preprint integrated';a.need(oldcells[11].count(marker)==1,'literal historical administrative note slot')
            science=oldcells[11].split(marker,1)[0];a.need(newcells[11].startswith(science) and b'original2 plus one joint repair turn3, no turn4' in newcells[11] and s['publication']['doi'].encode() in newcells[11],'entire original mathematical scope/gaps and turn budget retained in Notes')
            a.need(newcells[12].strip()==('['+s['publication']['doi']+']('+s['publication']['doi_url']+')').encode(),'exact actual manuscript DOI cell')
        else:a.need(new==old,'entire protected scientific/control/source body outside administrative budget unchanged')
    # Full dependency selector/body hashes independently reconstructed.
    own={p[len(pre):]:b for p,b in final.items() if p.startswith(pre)}
    author={p for p in own if not p.startswith('independent_review/') and p not in {'FROZEN_INPUT_MANIFEST.json','FROZEN_MANIFEST.json'}}
    def verify(rows,root,expected):
        a.need(len(rows)==len(expected) and {x['path'] for x in rows}==expected,'complete unique regenerated dependency manifest')
        for x in rows:
            b=own[root+x['path']];a.need(len(b)==x['bytes'] and a.sha(b)==x['sha256'],'every fresh dependency full-body hash')
    fi=json.loads(own['FROZEN_INPUT_MANIFEST.json']);fm=json.loads(own['FROZEN_MANIFEST.json']);hc=json.loads(own['independent_review/HASH_CHECK.json']);rm=json.loads(own['independent_review/REVIEW_MANIFEST.json'])
    verify(fi['files'],'',author);verify(fm['files'],'',author|{'FROZEN_INPUT_MANIFEST.json'});verify(hc['author'],'',author|{'FROZEN_INPUT_MANIFEST.json'})
    review={p[len('independent_review/'):] for p in own if p.startswith('independent_review/') and p!='independent_review/REVIEW_MANIFEST.json'};verify(rm['files'],'independent_review/',review)
    for o in [hc,rm]:a.need(o['author_manifest_sha256']==a.sha(own['FROZEN_MANIFEST.json']) and o['frozen_input_manifest_sha256']==a.sha(own['FROZEN_INPUT_MANIFEST.json']),'fresh author and input wrapper pins')
    a.need(rm['verdict']=='ADMINISTRATIVE_SUCCESSOR_OF_ROOT_REVIEWED_CANDIDATE03_PENDING_PARITY_ACCEPTANCE','no fabricated fresh whole-review04 verdict')
    return True

def evidence_consistency(a,ac,base):
    def three(x):
        a.need(set(x)=={'path','bytes','sha256'},'recipe actual evidence full-byte pin schema');return {**x,'mode':0o444}
    def root(x):
        z=three(x);q=a.literal(z['path']);a.need(q.parent==a.W and q.name.startswith('ROOT_'),'actual acceptance/source-guard ROOT literal domain');return json.loads(a.match(z))
    ep=a.literal(ac['actual_evidence_binding']['path']);a.need(ep.parent==a.W and ep.name.startswith('ROOT_'),'literal ROOT actual evidence adapter binding domain')
    eb=json.loads(a.match(ac['actual_evidence_binding']));a.need(set(eb)=={'schema','second_review_acceptance','publication_acceptance','tracker_acceptance'} and eb['schema']=='pr284-actual-administrative-evidence-binding-v1','strict actual publication/tracker binding schema')
    a.need(three(eb['second_review_acceptance'])==ac['second_review_ROOT_acceptance'],'actual literal second-whole03 pin')
    second=root(eb['second_review_acceptance']);a.need(second['final_global_candidate_manifest']['sha256']==BASE_MANIFEST and second['fresh_sequential_whole_reviews_completed']==2 and second['latest_whole_review_unresolved_issues']==[],'actual second-whole03 proof; no successor verdict')
    p=json.loads(a.match(three(eb['publication_acceptance'])));t=json.loads(a.match(three(eb['tracker_acceptance'])))
    a.need(p['schema']=='pr284-actual-publication-adapter-v1' and t['schema']=='pr284-actual-tracker-adapter-v1' and three(p['actual_ROOT_acceptance'])==ac['actual_publication_ROOT_acceptance'] and three(t['actual_ROOT_acceptance'])==ac['actual_tracker_ROOT_acceptance'],'literal actual ROOT publication/tracker acceptance pins, not boolean override')
    for x,keys,scope in [(p,['actual_publication_accepted','publication_content_ready','asof_UTC','record_id','doi','record_url','doi_url','reviewed_candidate_manifest_sha256'],'publication'),(t,['actual_tracker_accepted','asof_UTC','spreadsheet_id','sheet_id','sheet_title','row_number','range','exact_row_cells','publication_record_id','doi'],'tracker')]:
        r=root(x['actual_ROOT_acceptance']);a.need(set(x['ROOT_projection_pointers'])==set(keys),'complete actual ROOT projection keys')
        for k in keys:a.need(pointer(r,x['ROOT_projection_pointers'][k])==x[k],'literal actual ROOT evidence projection')
        guard=root(x['ROOT_source_guard_acceptance']);gf=x['ROOT_source_guard_fields'];a.need(set(gf['pointers'])=={'accepted','source_sha256','operation_scope'},'complete actual source guard pointers')
        for k in gf['pointers']:a.need(pointer(guard,gf['pointers'][k])==gf[k],'literal actual source guard projection')
        a.need(gf['accepted'] is True and re.fullmatch('[0-9a-f]{64}',gf['source_sha256']) and gf['operation_scope']==scope,'correct actual operation/source acceptance scope')
    a.need(p['actual_publication_accepted'] is True and p['publication_content_ready'] is True and t['actual_tracker_accepted'] is True and p['reviewed_candidate_manifest_sha256']==BASE_MANIFEST,'actual ROOT publication/tracker accepted exact03')
    a.need(re.fullmatch(r'10\.5281/zenodo\.[0-9]+',p['doi']) and p['doi']==t['doi'] and str(p['record_id'])==str(t['publication_record_id']) and p['doi_url']=='https://doi.org/'+p['doi'] and p['record_url']=='https://zenodo.org/records/'+str(p['record_id']),'actual record/DOI identity consistent')
    # Every adapter-referenced raw/submission/download/row body must exist sealed;
    # their provider authenticity and exhaustive recipe projection is accepted
    # by literal ROOT finalization acceptance plus exact native parity result.
    for x in [p['raw_public_record'],p['submitted_metadata'],t['raw_row_readback']]+[z['body'] for z in p['downloaded_public_files']]:a.match(three(x))
    a.need(len(p['downloaded_public_files'])==2 and {z['filename'] for z in p['downloaded_public_files']}=={'mass_stationarity_markov.pdf','mass_stationarity_verification.zip'},'complete actual public download set')
    for z in p['downloaded_public_files']:a.need(a.match(three(z['body']))==base[a.T+'/preprint/'+z['filename']],'actual public download complete body equals reviewed source')
    return ep,p,t

def validate(a,acceptance_pin,binding,readiness,final):
    p=a.literal(acceptance_pin['path']);a.need(p.parent==a.W and p.name.startswith('ROOT_PR284_ADMINISTRATIVE_FINALIZATION_ACCEPTANCE_'),'literal separate ROOT admin acceptance domain')
    ac=json.loads(a.match(acceptance_pin));check_acceptance(a,ac,binding,readiness)
    base=a.closed_selected(ac['base_candidate_directory'],ac['base_full_catalog'],ac['base_proposed_manifest'])
    recipe=a.literal(ac['recipe_directory']);a.need(recipe.parent==a.W and recipe.name.startswith('author_publication_finalization_preparation_') and pathlib.Path(ac['recipe_catalog']['path'])==recipe/'FULL_CATALOG.json' and pathlib.Path(ac['recipe_source']['path'])==recipe/'scaffold.py','eventual exact ROOT accepted closed deterministic recipe source domain; preparation01 is never automatically approved')
    cat=json.loads(a.match(ac['recipe_catalog']));seen=set()
    for x in cat['files']:
        rel=a.safe(x['path']);a.need(rel not in seen,'unique recipe catalog');seen.add(rel);b=(recipe/rel).read_bytes();a.need(len(b)==x['bytes'] and a.sha(b)==x['sha256'] and a.pin(recipe/rel)['mode']==0o444,'every literal recipe source/evidence body')
    a.need({p.relative_to(recipe).as_posix() for p in recipe.rglob('*') if p.is_file()}==seen|{'FULL_CATALOG.json'} and all(not p.is_symlink() for p in recipe.rglob('*')),'complete sealed recipe file topology')
    a.need({'.'}|{p.relative_to(recipe).as_posix() for p in recipe.rglob('*') if p.is_dir()}==set(cat['directories']) and all((recipe/x).stat().st_mode&0o777==0o555 for x in cat['directories']),'complete sealed recipe directories')
    a.match(ac['recipe_source']);budget=json.loads((recipe/'surfaces.json').read_bytes())
    ep,p,t=evidence_consistency(a,ac,base)
    actualstatus=status(ac,p,t);pr=prefix(ac);body_parity(a,base,final,json.loads(a.match(a.readiness_sealed(readiness['candidate']))),budget,actualstatus,ac['exact_selected_delta'],pr)
    c=pathlib.Path(binding['candidate_directory']);bc=pathlib.Path(ac['base_candidate_directory'])
    a.need((c/'PR_TITLE.txt').read_bytes()==(bc/'PR_TITLE.txt').read_bytes() and (c/'PR_BODY.md').read_bytes()==pr+(bc/'PR_BODY.md').read_bytes(),'PR sidecars exact whole retained03 body and administrative prefix')
    native=a.literal(ac['parity_native_execution']['path']);a.need(native.name=='execution.json' and native.is_relative_to(a.W) and native.relative_to(a.W).parts[0].startswith('ROOT_'),'dedicated actual ROOT native parity receipt')
    n=json.loads(a.match(ac['parity_native_execution']));a.need(n['outcome']=='COMPLETE_NATIVE_ZERO_ONLY' and n['returncode']==0 and n['reaped'] is True and n['communication_complete'] is True and n['failure'] is None and n['cleanup_errors']==[] and type(n['actual_child_PID']) is int and n['actual_child_PID']>0,'actual successful completely collected/reaped parity process')
    req=json.loads(a.match(a.pin(native.parent/'request.json')));argv=req['argv'];a.need(argv==n['argv'] and argv[1:]==['-B',str(recipe/'scaffold.py'),'check-parity',str(c/'proposed'),str(ep)] and ac['recipe_source'] in req['script_arguments'],'exact prelaunch pinned native parity source/argv/final/evidence inputs')
    a.need(a.pin(req['executable']['path'])==req['executable'] and type(req['time_ns']) is int and type(n['time_ns']) is int and type(req['actual_recorder_PID']) is int and req['actual_recorder_PID']>0 and n['actual_recorder_PID']==req['actual_recorder_PID'] and n['wait_completed'] is True and ac['actual_evidence_binding'] in req['script_arguments'] and set(n['streams'])=={'stdout','stderr'},'truthful exact native executable/input/PID/integer timestamp/full stream custody')
    started=json.loads(a.match(a.pin(native.parent/'started.json')));a.need(started['actual_child_PID']==n['actual_child_PID'] and started['actual_recorder_PID']==n['actual_recorder_PID'],'real native parity started PID matches fully reaped receipt');out=None
    for name,z in n['streams'].items():
        f=a.literal(z['path']);a.need(f.parent==native.parent and f.name==name+'.gz' and a.pin(f)['mode']==0o444 and z['complete'] is True,'complete sealed parity stream domain')
        b=f.read_bytes();raw=gzip.decompress(b);a.need(len(b)==z['stored_bytes'] and a.sha(b)==z['stored_sha256'] and len(raw)==z['logical_bytes'] and a.sha(raw)==z['logical_sha256'],'whole native parity stream byte custody')
        if name=='stdout':out=json.loads(raw)
    a.need(out==ac['parity_result'] and out['successor_repository_files']==69 and out['mathematics_and_selected22_unchanged'] is True and out['publication_or_branch_action_authorized_by_scaffold'] is False and isinstance(out['status'],str) and out['status'],'complete literal ROOT accepted actual recipe parity result; no execution authority')
    return ac
