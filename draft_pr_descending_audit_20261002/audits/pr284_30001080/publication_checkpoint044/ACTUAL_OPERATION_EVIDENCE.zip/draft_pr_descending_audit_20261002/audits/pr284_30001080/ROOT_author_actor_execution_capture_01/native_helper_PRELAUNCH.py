"""Full nonsensitive native custody, no credentials/environment/header debug.
Prelaunch pins executable and requested sources. Every failure is UNKNOWN, with
truthful cleanup/reap evidence. No retry belongs to this recorder.
"""
import datetime,gzip,hashlib,json,os,pathlib,signal,stat,subprocess,time
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
    p=pathlib.Path(p);b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
def err(e):return {'type':type(e).__name__,'message':'native operation failed; preserved nonsensitive stream evidence'}
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def call(run,label,argv,*,stdin=None,timeout=55,cleanup_timeout=5,context=None):
    if not label or '/' in label or label in ('.','..'):raise ValueError('literal capture label')
    if not argv or not pathlib.Path(argv[0]).is_absolute():raise ValueError('absolute executable required')
    if any(k in os.environ for k in ('GH_DEBUG','GITHUB_DEBUG')):raise ValueError('debug environment forbidden')
    d=pathlib.Path(run)/'private'/'native'/label;d.mkdir(parents=True,exist_ok=False)
    prelaunch_error=None;executable=None;scripts=[]
    try:
        executable=pin(pathlib.Path(argv[0]).resolve());scripts=[pin(pathlib.Path(x).resolve()) for x in argv[1:] if pathlib.Path(x).is_absolute() and pathlib.Path(x).is_file()]
    except BaseException as e:prelaunch_error=err(e)
    request={'UTC':utc(),'time_ns':time.time_ns(),'actual_recorder_PID':os.getpid(),'argv':argv,'cwd':str(pathlib.Path.cwd()),'executable':executable,'executable_custody':'AVAILABLE' if executable else 'UNKNOWN_UNAVAILABLE_NO_SPAWN','literal_executable_path':argv[0],'script_arguments':scripts,'prelaunch_error':prelaunch_error,'context':context,'stdin_bytes':len(stdin or b''),'stdin_sha256':sha(stdin) if stdin is not None else None,'timeout_seconds':timeout,'cleanup_timeout_seconds':cleanup_timeout,'environment_intentionally_not_recorded':True}
    save(d/'request.json',request)
    if stdin is not None:(d/'stdin.gz').write_bytes(gzip.compress(stdin,mtime=0))
    p=None;out=b'';stderr=b'';failure=None;cleanup=[];complete=False;waited=False
    try:
        if prelaunch_error:raise RuntimeError('UNKNOWN unavailable executable; no spawn')
        p=subprocess.Popen(argv,stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        save(d/'started.json',{'UTC':utc(),'time_ns':time.time_ns(),'actual_child_PID':p.pid,'actual_recorder_PID':os.getpid()})
        out,stderr=p.communicate(stdin,timeout=timeout);complete=True
    except BaseException as e:
        failure=err(e)
        if isinstance(getattr(e,'output',None),bytes):out=e.output
        if isinstance(getattr(e,'stderr',None),bytes):stderr=e.stderr
    finally:
        if p is not None and not complete:
            try:os.killpg(p.pid,signal.SIGKILL)
            except BaseException as e:cleanup.append({'stage':'signal_group',**err(e)})
            # Collection is attempted even if signaling failed or child exited.
            try:out,stderr=p.communicate(None,timeout=cleanup_timeout);complete=True
            except BaseException as e:
                cleanup.append({'stage':'collect_streams',**err(e)})
                if isinstance(getattr(e,'output',None),bytes):out=e.output
                if isinstance(getattr(e,'stderr',None),bytes):stderr=e.stderr
        if p is not None:
            try:p.wait(timeout=cleanup_timeout);waited=True
            except BaseException as e:cleanup.append({'stage':'wait_reap',**err(e)})
    streams={}
    for name,b in [('stdout',out),('stderr',stderr)]:
        f=d/(name+'.gz');f.write_bytes(gzip.compress(b,mtime=0));stored=f.read_bytes()
        streams[name]={'path':str(f),'logical_bytes':len(b),'logical_sha256':sha(b),'stored_bytes':len(stored),'stored_sha256':sha(stored),'complete':complete}
    code=p.returncode if p is not None else None;reaped=p is not None and code is not None and (waited or complete)
    receipt={'UTC':utc(),'time_ns':time.time_ns(),'actual_recorder_PID':os.getpid(),'actual_child_PID':p.pid if p else None,'argv':argv,'returncode':code,'reaped':reaped,'wait_completed':waited,'communication_complete':complete,'failure':failure,'cleanup_errors':cleanup,'streams':streams,'outcome':'COMPLETE_NATIVE_ZERO_ONLY' if not failure and not cleanup and complete and reaped and code==0 else 'UNKNOWN_OR_FAILED_NO_MUTATION_RETRY'}
    save(d/'execution.json',receipt)
    if failure or cleanup or not complete or not reaped or code!=0:raise RuntimeError('UNKNOWN native failure; preserve evidence; no mutation retry')
    return out
