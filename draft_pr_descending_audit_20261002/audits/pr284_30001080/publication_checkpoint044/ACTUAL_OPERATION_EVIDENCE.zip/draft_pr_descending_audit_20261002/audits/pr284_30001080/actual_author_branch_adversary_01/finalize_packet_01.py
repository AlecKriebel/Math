from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import stat

R = Path('/Users/alec/Documents/Math')
A = R / 'draft_pr_descending_audit_20261002/audits/pr284_30001080/actual_author_branch_adversary_01'

def encoded(x): return (json.dumps(x, indent=2) + '\n').encode()

def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'mode': stat.S_IMODE(p.stat().st_mode)}

def native(label, exit_code):
    d = A / 'private/native' / label
    q, s, e = [json.loads((d / n).read_bytes()) for n in ['request.json', 'started.json', 'execution.json']]
    assert q['argv'] == e['argv'] and q['cwd'] == str(R)
    assert q['actual_recorder_PID'] == e['actual_recorder_PID'] and s['actual_child_PID'] == e['actual_child_PID']
    assert e['returncode'] == exit_code and e['failure'] is None and e['cleanup_errors'] == []
    assert all(e[k] is True for k in ['reaped', 'wait_completed', 'communication_complete'])
    for name in ['stdout', 'stderr']:
        t = e['streams'][name]
        p = d / (name + '.gz')
        stored = p.read_bytes(); raw = gzip.decompress(stored)
        assert t['path'] == str(p) and t['complete'] is True
        assert len(stored) == t['stored_bytes'] and hashlib.sha256(stored).hexdigest() == t['stored_sha256']
        assert len(raw) == t['logical_bytes'] and hashlib.sha256(raw).hexdigest() == t['logical_sha256']
    return {'label': label, 'actual_recorder_PID': e['actual_recorder_PID'], 'actual_child_PID': e['actual_child_PID'], 'actual_argv': e['argv'], 'cwd': q['cwd'], 'returncode': exit_code, 'full_stdout_stderr_wait_reap_verified': True, 'execution4pin': pin(d / 'execution.json'), 'request4pin': pin(d / 'request.json'), 'started4pin': pin(d / 'started.json'), 'stdout4pin': pin(d / 'stdout.gz'), 'stderr4pin': pin(d / 'stderr.gz')}

assert all(not (A / n).exists() for n in ['VERDICT.json', 'CLOSURE.json', 'OWN_BODY_CATALOG.json'])
results = json.loads((A / 'ACTUAL_BRANCH_REVIEW_RESULTS.json').read_bytes())
addendum = json.loads((A / 'RAW_PARENT_CUSTODY_ADDENDUM.json').read_bytes())
assert results['all_passed'] is True and results['check_count'] == 12 and results['blocking_findings'] == [] and results['execution_authority'] is False
assert results['actual_author_branch_result_accepted'] is True and results['ROOT_acceptance_issued'] is False
assert addendum['passed'] is True and addendum['blocking_findings'] == [] and addendum['native_children'] == 9 and addendum['execution_authority'] is False
base = json.loads((A / 'BASELINE.json').read_bytes())
assert len(base['protected_complete_body_pins']) == 589
for t in base['protected_complete_body_pins']:
    actual = pin(Path(t['path']))
    assert all(actual[k] == t[k] for k in ['path', 'bytes', 'sha256'])
for p in (A / 'source_revisions').iterdir():
    assert p.read_bytes() == (A / p.name).read_bytes()
for name in ['BASELINE_PRELAUNCH.json', 'BASELINE_PRELAUNCH02.json', 'ACTUAL_REVIEW_PRELAUNCH01.json', 'ACTUAL_REVIEW_PRELAUNCH02.json', 'RAW_PARENT_ADDENDUM_PRELAUNCH01.json']:
    before = json.loads((A / name).read_bytes())
    for t in before['source_pins_before_first_native_capture']:
        b = Path(t['path']).read_bytes()
        assert len(b) == t['bytes'] and hashlib.sha256(b).hexdigest() == t['sha256'] and b == Path(t['preserved_copy']).read_bytes()

utc = datetime.now(timezone.utc).isoformat()
log = A / 'RESEARCH_LOG.md'
with log.open('a') as f:
    f.write(f'''\n{utc} — Final checkpoint:100% of the scoped actual branch-result audit. Native actual review02 driver85153/child85154 completed exit0/full streams/wait/reap: all12 fixed checks passed, exact262 actual worker children,78 mutative POSTs,77 immutable objects fully read back before each next mutation, one expected-old force=false CAS, and full fresh final69 scientific/administrative bodies/QUEUE/tree/commit/refs readback. All589 baseline-protected bodies remain exact. Minimum serial POST gap was1002182000ns. The separately captured raw-parent addendum independently authenticates9 actual historical native Git children, full raw391/f36/1252 canonical bodies and closed raw main/peer catalogs. No live operation was performed by this reviewer.\n\nROOT explicitly steered execution inputs from the initially open source06/main5 context to closed source08/frozenmain7. Own original baseline is preserved unchanged. Main7 captures preceded grant/CAS; this reviewer received context before execution, first independently inspected main7 after actual completion, and does not fabricate a pre-execution own main7 inspection. The fixed matrix's earlier conditional baseline wording is qualified by that explicit steering and actual immutable native provenance.\n\nThe earlier source-only plan adversary02 arithmetic says79 future POSTs; canonical plan and complete actual transcript establish78 (63blobs+13trees+commit+CAS). It is an isolated historical bookkeeping statement, not authority and not a missing/extra actual request. Two own validator failures are preserved: baseline01 raw DOI expectation versus actual Markdown DOI link; actual review01 rich4793 fields expected in historical3993 main7 request schema. Both failed sources/native receipts/full stderr/exit1 remain separate. Production inputs and remote action were never changed or retried by this agent.\n\nVerdict:PASS, blocking_findings=[], actual_author_branch_result_accepted=true for exact completed branch content/CAS/full evidence only. execution_authority=false and ROOT_acceptance_issued=false. Literal ROOT branch acceptance remains separate. No additional mathematics, publication, tracker row, metadata/readiness mutation, merge/close/release authority is asserted. Files are sealed0444/directories0555 and whole packet is below2MB.\n''')
for p in [p for p in A.rglob('*') if p.is_file()]: p.chmod(0o444)
own = [native('baseline_01', 1), native('baseline_02', 0), native('actual_review_01', 1), native('actual_review_02', 0), native('raw_parent_addendum_01', 0)]
assert [(t['actual_recorder_PID'], t['actual_child_PID']) for t in own[:4]] == [(10976, 10977), (11383, 11384), (84611, 84614), (85153, 85154)]
verdict = {
    'schema': 'independent_actual_author_branch_adversary_01_verdict_v1',
    'UTC': utc,
    'status': 'PASS',
    'verdict': 'PASS',
    'blocking_findings': [],
    'unresolved_issues': [],
    'actual_author_branch_result_accepted': True,
    'actual_author_branch_correction_accepted': True,
    'actual_branch_result_accepted': True,
    'ROOT_acceptance_issued': False,
    'execution_authority': False,
    'actual_branch_scope_only': True,
    'own_fixed_checks': results['checks'],
    'full_actual_results4pin': pin(A / 'ACTUAL_BRANCH_REVIEW_RESULTS.json'),
    'independent_pre_result_baseline4pin': pin(A / 'BASELINE.json'),
    'fixed_matrix_before_result_view4pin': pin(A / 'FOCUSED_MATRIX.json'),
    'actual_raw_parent_custody_addendum4pin': pin(A / 'RAW_PARENT_CUSTODY_ADDENDUM.json'),
    'own_genuine_native_custody_all_attempts': own,
    'successful_actual_review_native4pin': own[3]['execution4pin'],
    'raw_parent_addendum_native4pin': own[4]['execution4pin'],
    'all589_baseline_protected_bodies_unchanged': True,
    'no_extra_math_source_fixture_or_live_operation': True,
    'retained_own_failed_validator_attempts_are_not_production_findings': True,
    'no_metadata_ready_merge_close_release_publication_or_tracker_authority': True,
    'scope': results['scope'],
    'main7_provenance_timing': results['main7_provenance_timing'],
    'historical_plan_review_arithmetic_note': results['historical_plan_review_arithmetic_note'],
    'raw_final_commit_custody_qualification': results['raw_final_commit_custody_qualification'],
    'credential_capture_qualification': results['credential_capture_qualification'],
    'raw_parent3993_schema_qualification': addendum['qualification'],
    'review_completion_percent': 100,
}
for k in ['PLAN4pin', 'binding4pin', 'grant4pin_terminal_NEVER_REPLAY', 'source_catalog4pin', 'source_acceptance4pin', 'plan_ROOT_review4pin', 'sources4pins', 'actual_RUN_catalog4pin', 'actual_result4pin', 'actual_ROOT_outer_catalog4pin', 'actual_ROOT_outer_execution4pin', 'frozen_main7_catalog4pin', 'frozen_main7_result4pin', 'canonical_result', 'minimum_serial_mutation_gap_ns', 'actual_nonce_consumed', 'actual_final_CAS_intent']:
    verdict[k] = results[k]
(A / 'VERDICT.json').write_bytes(encoded(verdict)); (A / 'VERDICT.json').chmod(0o444)
closure = {'schema': 'closed_independent_actual_author_branch_adversary_01_v1', 'UTC': utc, 'closed': True, 'verdict4pin': pin(A / 'VERDICT.json'), 'blocking_findings': [], 'actual_author_branch_result_accepted': True, 'execution_authority': False, 'ROOT_acceptance_issued': False, 'actual_whole_packet_files': 0, 'actual_whole_packet_bytes': 0, 'maximum_actual_whole_packet_bytes': 2000000, 'all_files_mode': '0444', 'all_directories_mode': '0555', 'sole_exact_root_relative_catalog_exception': 'OWN_BODY_CATALOG.json', 'nested_catalogs_included_if_present': True, 'primary_QUEUE_PDF_ZIP_copies': False, 'genuine_own_native_full_streams_all_attempts_preserved': True, 'sealing_is_tool_boundary_not_a_fabricated_native_receipt': True}
cp = A / 'OWN_BODY_CATALOG.json'
for _ in range(10):
    (A / 'CLOSURE.json').write_bytes(encoded(closure))
    entries = []
    for p in sorted(A.rglob('*')):
        assert not p.is_symlink()
        if p.is_file() and p != cp:
            t = pin(p)
            entries.append({'path': p.relative_to(A).as_posix(), 'bytes': t['bytes'], 'sha256': t['sha256'], 'mode': '0444'})
    c = {'schema': 'whole_own_actual_branch_review_body_catalog_v1', 'root': A.relative_to(R).as_posix(), 'sole_exact_root_relative_exception': 'OWN_BODY_CATALOG.json', 'nested_catalogs_included_if_present': True, 'catalogued_body_files': len(entries), 'catalogued_body_bytes': sum(t['bytes'] for t in entries), 'entries': entries}
    cp.write_bytes(encoded(c))
    files = [p for p in A.rglob('*') if p.is_file()]
    count, size = len(files), sum(p.stat().st_size for p in files)
    if (count, size) == (closure['actual_whole_packet_files'], closure['actual_whole_packet_bytes']): break
    closure['actual_whole_packet_files'], closure['actual_whole_packet_bytes'] = count, size
else: raise AssertionError('Whole size did not stabilize')
assert size <= 2000000 and count == len(entries) + 1
assert {t['path'] for t in entries} == {p.relative_to(A).as_posix() for p in files if p != cp}
for p in files: p.chmod(0o444)
for p in sorted([p for p in A.rglob('*') if p.is_dir()], key=lambda p: len(p.parts), reverse=True) + [A]: p.chmod(0o555)
for t in entries:
    b = (A / t['path']).read_bytes()
    assert len(b) == t['bytes'] and hashlib.sha256(b).hexdigest() == t['sha256']
assert all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in files)
assert all(stat.S_IMODE(p.stat().st_mode) == 0o555 for p in [A] + [p for p in A.rglob('*') if p.is_dir()])
print(json.dumps({'whole_files': count, 'whole_bytes': size, 'all_files444_directories555': True, 'VERDICT': pin(A / 'VERDICT.json'), 'CLOSURE': pin(A / 'CLOSURE.json'), 'OWN_BODY_CATALOG': pin(cp), 'actual_review_driver_child': [85153, 85154], 'raw_addendum_driver_child': [own[4]['actual_recorder_PID'], own[4]['actual_child_PID']]}, indent=2))
