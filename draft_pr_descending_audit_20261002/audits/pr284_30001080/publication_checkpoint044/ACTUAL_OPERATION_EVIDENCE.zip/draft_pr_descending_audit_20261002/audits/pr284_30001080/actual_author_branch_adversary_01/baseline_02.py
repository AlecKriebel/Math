from pathlib import Path
from datetime import datetime, timezone
import base64
import gzip
import hashlib
import json
import os
import stat

R = Path('/Users/alec/Documents/Math')
W = R / 'draft_pr_descending_audit_20261002/audits/pr284_30001080'
A = W / 'actual_author_branch_adversary_01'

def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def exact(t):
    p = pin(t['path'])
    assert all(p[k] == t[k] for k in ['path', 'bytes', 'sha256'])
    return p

def obj(kind, b):
    return hashlib.sha1(kind.encode() + b' ' + str(len(b)).encode() + b'\0' + b).hexdigest()

def native(d):
    d = Path(d)
    assert sorted(p.name for p in d.iterdir()) == ['execution.json', 'request.json', 'started.json', 'stderr.gz', 'stdout.gz']
    q = json.loads((d / 'request.json').read_bytes())
    e = json.loads((d / 'execution.json').read_bytes())
    s = json.loads((d / 'started.json').read_bytes())
    assert q['argv'] == e['argv'] and q['cwd'] == str(R)
    assert q['actual_recorder_PID'] == e['actual_recorder_PID']
    assert s['actual_child_PID'] == e['actual_child_PID']
    assert e['returncode'] == 0 and e['failure'] is None and e['cleanup_errors'] == []
    assert all(e[k] is True for k in ['reaped', 'communication_complete', 'wait_completed'])
    raw = {}
    for k in ['stdout', 'stderr']:
        t = e['streams'][k]
        p = d / (k + '.gz')
        assert t['path'] == str(p) and t['complete'] is True
        b = p.read_bytes()
        raw[k] = gzip.decompress(b)
        assert len(b) == t['stored_bytes'] and hashlib.sha256(b).hexdigest() == t['stored_sha256']
        assert len(raw[k]) == t['logical_bytes'] and hashlib.sha256(raw[k]).hexdigest() == t['logical_sha256']
    return q, e, raw

old = W / 'administrative69_actual_evidence_adversary_01'
sealed = json.loads((old / 'OWN_BODY_CATALOG.json').read_bytes())
assert sealed['sole_exact_root_relative_exception'] == 'OWN_BODY_CATALOG.json'
assert {t['path'] for t in sealed['entries']} == {p.relative_to(old).as_posix() for p in old.rglob('*') if p.is_file() and p.name != 'OWN_BODY_CATALOG.json'}
for t in sealed['entries']:
    b = (old / t['path']).read_bytes()
    assert len(b) == t['bytes'] and hashlib.sha256(b).hexdigest() == t['sha256']
v = json.loads((old / 'VERDICT.json').read_bytes())
assert v['verdict'] == 'PASS' and v['blocking_findings'] == [] and v['actual_administrative69_accepted'] is True and v['execution_authority'] is False
historical = json.loads((old / 'BASELINE.json').read_bytes())
protected = {t['path']: exact(t) for t in historical['protected_complete_body_pins']}

admin = json.loads((W / 'ROOT_PR284_ADMINISTRATIVE_FINALIZATION_ACCEPTANCE_01.json').read_bytes())
assert admin['status'] == 'ROOT_ACCEPTS_EXACT_PR284_ADMINISTRATIVE_FINALIZATION'
assert admin['execution_authority'] is False and admin['branch_or_merge_accepted'] is False
assert admin['unresolved_issues'] == [] and admin['remote_mutations'] == 0
for k in ['final_full_catalog', 'final_proposed_manifest', 'publication_readiness', 'public_package_manifest', 'actual_publication_ROOT_acceptance', 'actual_tracker_ROOT_acceptance', 'fresh_independent_actual69_verdict']:
    t = exact(admin[k]); protected[t['path']] = t
C = Path(admin['final_candidate_directory'])
catalog = json.loads((C / 'FULL_CATALOG.json').read_bytes())
assert len(catalog['files']) == 76
assert {t['path'] for t in catalog['files']} == {p.relative_to(C).as_posix() for p in C.rglob('*') if p.is_file() and p != C / 'FULL_CATALOG.json'}
for t in catalog['files']:
    p = C / t['path']; b = p.read_bytes()
    assert len(b) == t['bytes'] and hashlib.sha256(b).hexdigest() == t['sha256']
    protected[str(p)] = pin(p)
assert all(stat.S_IMODE(p.stat().st_mode) == (0o444 if p.is_file() else 0o555) for p in [C] + list(C.rglob('*')))
manifest = json.loads((C / 'PROPOSED_TREE_MANIFEST.json').read_bytes())
assert len(manifest['files']) == 69
selected = []
for t in manifest['files']:
    b = (C / 'proposed' / t['path']).read_bytes()
    assert len(b) == t['bytes'] and hashlib.sha256(b).hexdigest() == t['sha256']
    selected.append({**t, 'canonical_git_blob_SHA1': obj('blob', b)})

main_dir = W / 'ROOT_main_selected_baseline_readback_05'
m = json.loads((main_dir / 'RESULT.json').read_bytes())
assert m['status'] == 'EXACT_FRESH_MAIN_OWN_TARGET_AND_QUEUE_READ_ONLY'
assert m['execution_authority'] is False and m['remote_mutations'] == 0 and m['primary_checkout_or_QUEUE_writes'] == 0
assert m['expected_pr_head'] == '391cb662b1599ef564ff15b63cd8ed73c7d1f125'
assert m['expected_main_head'] == '6dc1648a00bb1e0f34cb68f5a6a7dd83016fda77'
assert m['expected_main_target'] == {} and m['native_GET_count'] == 8
for p in main_dir.rglob('*'):
    if p.is_file(): protected[str(p)] = pin(p)
main_native = []
native_objects = []
for i in range(1, 9):
    d = main_dir / 'private/native' / f'{i:04d}_GET'
    q, e, raw = native(d)
    assert q['argv'][5] == 'GET' and e['actual_recorder_PID'] == 96821
    assert '--input' not in q['argv']
    main_native.append({'label': d.name, 'argv': q['argv'], 'actual_recorder_PID': e['actual_recorder_PID'], 'actual_child_PID': e['actual_child_PID'], 'execution': pin(d / 'execution.json')})
    native_objects.append(json.loads(raw['stdout']))
assert native_objects[0]['object']['sha'] == native_objects[7]['object']['sha'] == m['expected_main_head']
assert native_objects[6]['head']['sha'] == m['expected_pr_head'] and native_objects[6]['state'] == 'open' and native_objects[6]['merged'] is False
assert native_objects[1] == m['commits'][m['expected_main_head']]
canonical_trees = []
for response in native_objects[2:5]:
    assert response['truncated'] is False
    entries = {t['path']: {k: t[k] for k in ['mode', 'type', 'sha']} for t in response['tree']}
    assert entries == m['trees'][response['sha']]
    raw = b''
    for name, t in sorted(entries.items(), key=lambda item: item[0].encode() + (b'/' if item[1]['type'] == 'tree' else b'')):
        assert '/' not in name and '\0' not in name and t['type'] in ['tree', 'blob']
        raw += t['mode'].lstrip('0').encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(t['sha'])
    assert obj('tree', raw) == response['sha']
    canonical_trees.append({'sha': response['sha'], 'entries': entries, 'full_canonical_SHA1_verified': True})
root_tree = m['trees'][m['main_tree']]
ump = m['trees'][root_tree['unsolved_math_prioritization']['sha']]
attempts = m['trees'][ump['attempts']['sha']]
assert '30001080' not in attempts
qraw = (main_dir / 'MAIN_QUEUE_FULL.bin').read_bytes()
assert qraw == base64.b64decode(native_objects[5]['content']) and len(qraw) == native_objects[5]['size']
assert obj('blob', qraw) == native_objects[5]['sha'] == m['main_QUEUE_blob_SHA1'] == ump['QUEUE.md']['sha']
row = qraw.splitlines(keepends=True)[m['own_row_physical_index']]
assert row.rstrip(b'\r\n') == base64.b64decode(m['own_row_base64'])
assert hashlib.sha256(row.rstrip(b'\r\n')).hexdigest() == m['expected_main_queue_row_sha256']
assert m['own_row_status'] == 'queued' and m['own_row_budget'] == '0/5'
candidate_queue = (C / 'proposed/unsolved_math_prioritization/QUEUE.md').read_bytes()
candidate_rows = [r for r in candidate_queue.splitlines(keepends=True) if b'| 30001080 / OWR-2093-003 |' in r]
assert len(candidate_rows) == 1
candidate_row = candidate_rows[0]
fields = candidate_row.rstrip(b'\r\n').split(b'|')
assert fields[8].strip() == b'claimed_solved' and fields[9].strip() == b'3/5' and fields[12].strip() == b'[10.5281/zenodo.23180194](https://doi.org/10.5281/zenodo.23180194)'
parents = []
for sha, folder in [('391cb662b1599ef564ff15b63cd8ed73c7d1f125', 'ROOT_exact_raw_original_PR_commit_readback_01'), ('6dc1648a00bb1e0f34cb68f5a6a7dd83016fda77', 'ROOT_exact_raw_main_commit_readback_05')]:
    d = W / folder
    raw = (d / 'RAW_COMMIT.bin').read_bytes()
    assert obj('commit', raw) == sha
    header = raw.split(b'\n\n', 1)[0].splitlines()
    parents.append({'sha': sha, 'raw_commit': pin(d / 'RAW_COMMIT.bin'), 'tree': header[0].decode().removeprefix('tree '), 'parents': [r.decode().removeprefix('parent ') for r in header if r.startswith(b'parent ')], 'complete_raw_canonical_SHA1_verified': True})
    for p in d.rglob('*'):
        if p.is_file() and 'private_raw_objects.git' not in p.parts: protected[str(p)] = pin(p)
assert parents[0]['parents'][0] == '974de6221dda5addefa08705c85e57058cb505ef'
assert parents[1]['tree'] == m['main_tree']
for n in ['ROOT_PR284_ADMINISTRATIVE_FINALIZATION_ACCEPTANCE_01.json', 'ROOT_PR284_FINAL_AUTHOR_CANDIDATE_BINDING_02.json', 'administrative69_actual_evidence_adversary_01/OWN_BODY_CATALOG.json']:
    protected[str(W / n)] = pin(W / n)
for t in protected.values(): exact(t)
result = {
    'schema': 'independent-before-actual-author-branch-result-baseline-v1',
    'UTC': datetime.now(timezone.utc).isoformat(),
    'actual_PID': os.getpid(),
    'before_any_future_actual_branch_result_or_result_verdict_read': True,
    'source06_open_not_inspected': True,
    'future_ROOT_plan_source_grant_result_not_inspected': True,
    'accepted_admin69_manifest': pin(C / 'PROPOSED_TREE_MANIFEST.json'),
    'accepted_admin69_catalog': pin(C / 'FULL_CATALOG.json'),
    'ROOT_admin_acceptance': pin(W / 'ROOT_PR284_ADMINISTRATIVE_FINALIZATION_ACCEPTANCE_01.json'),
    'selected69_accepted_body_and_canonical_blob_pins': selected,
    'publication_and_tracker_record_row': {'record': 23180194, 'doi': '10.5281/zenodo.23180194', 'row': 30},
    'protected_complete_body_pins': list(protected.values()),
    'fresh_main_baseline5': pin(main_dir / 'RESULT.json'),
    'expected_direct_parent_SHA1s_in_order': [p['sha'] for p in parents],
    'complete_raw_parents': parents,
    'canonical_fresh_main_merkle_trees': canonical_trees,
    'fresh_main_target_absent': True,
    'full_fresh_main_QUEUE_pin_only_no_copy': pin(main_dir / 'MAIN_QUEUE_FULL.bin'),
    'full_fresh_main_QUEUE_canonical_blob_SHA1': obj('blob', qraw),
    'main_queue_selected_row_physical_index': m['own_row_physical_index'],
    'main_queue_selected_row_base64': base64.b64encode(row).decode(),
    'reviewed_candidate_queue_row_base64': base64.b64encode(candidate_row).decode(),
    'reviewed_queue_only_allowed_field_indices': [8, 9, 11, 12],
    'fresh_main_native_GET_custody': main_native,
    'branch_operation_performed_by_reviewer': False,
    'live_remote_requests_auth_token_Git_GWS_API_operations': 0,
    'execution_authority': False,
    'no_new_mathematics_review_or_publication_or_tracker_row_or_metadata_or_ready_or_merge_or_close_or_release': True,
    'scope': 'Baseline only. Later independently check complete actual branch tree/readback, exact direct parent ancestry, selected69/QUEUE splice, all unselected Merkle siblings, one expected-old force=false existing branch CAS, native full custody and no additional mutations. No source plan grant or execution authority.'
}
with (A / 'BASELINE.json').open('xb') as f:
    f.write((json.dumps(result, indent=2) + '\n').encode())
(A / 'BASELINE.json').chmod(0o444)
print(json.dumps({'baseline_complete': True, 'protected_bodies': len(protected), 'selected_bodies': len(selected), 'canonical_main_trees': len(canonical_trees), 'actual_PID': os.getpid()}))
