"""Lossless private native recorder; explicit argv, no credential logging.
Incomplete collection always reaches communicate despite signalling failure.
A native zero status alone never authorizes a successful recorded call.
"""
import datetime,gzip,hashlib,json,os,pathlib,signal,subprocess
UTC=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
SHA=lambda b:hashlib.sha256(b).hexdigest()
def error(e):return {"type":type(e).__name__,"message":str(e)}
def call(run,label,argv,*,stdin=None,timeout=55,cleanup_timeout=5):
    d=pathlib.Path(run)/"private"/"native"/label
    d.mkdir(parents=True,exist_ok=False)
    request={"UTC":UTC(),"actual_recorder_PID":os.getpid(),"argv":argv,"cwd":str(pathlib.Path.cwd()),"stdin_bytes":len(stdin or b""),"stdin_sha256":SHA(stdin) if stdin is not None else None,"timeout_seconds":timeout,"cleanup_timeout_seconds":cleanup_timeout}
    (d/"request.json").write_text(json.dumps(request,indent=2)+"\n")
    if stdin is not None:(d/"stdin.gz").write_bytes(gzip.compress(stdin,mtime=0))
    p=None;out=b"";err=b"";failure=None;cleanup_errors=[]
    complete=False;wait_completed=False;communication_attempted=False
    try:
        p=subprocess.Popen(argv,stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        (d/"started.json").write_text(json.dumps({"UTC":UTC(),"actual_child_PID":p.pid},indent=2)+"\n")
        communication_attempted=True
        out,err=p.communicate(stdin,timeout=timeout)
        complete=True
    except BaseException as e:
        failure=error(e)
        # TimeoutExpired may carry observed partial streams. Retain them until
        # a completed communicate supplies the entire streams.
        if isinstance(getattr(e,"output",None),bytes):out=e.output
        if isinstance(getattr(e,"stderr",None),bytes):err=e.stderr
    finally:
        if p is not None and not complete:
            try:os.killpg(p.pid,signal.SIGKILL)
            except BaseException as e:cleanup_errors.append({"stage":"signal_group",**error(e)})
            # Never put this communicate inside the signalling try. The child
            # may have exited between timeout and killpg (ProcessLookupError).
            try:
                out,err=p.communicate(None,timeout=cleanup_timeout)
                complete=True
            except BaseException as e:
                cleanup_errors.append({"stage":"collect_streams",**error(e)})
                if isinstance(getattr(e,"output",None),bytes):out=e.output
                if isinstance(getattr(e,"stderr",None),bytes):err=e.stderr
        if p is not None:
            try:p.wait(timeout=cleanup_timeout);wait_completed=True
            except BaseException as e:cleanup_errors.append({"stage":"wait_reap",**error(e)})
    streams={}
    for name,b in [("stdout",out),("stderr",err)]:
        f=d/(name+".gz");f.write_bytes(gzip.compress(b,mtime=0))
        streams[name]={"path":str(f),"logical_bytes":len(b),"logical_sha256":SHA(b),"stored_bytes":f.stat().st_size,"stored_sha256":SHA(f.read_bytes()),"complete":complete}
    returncode=p.returncode if p is not None else None
    # communicate already waits/reaps on success. A later failing wait must
    # not discard its completed bytes or overwrite the observed native code.
    reaped=p is not None and returncode is not None and (wait_completed or complete)
    receipt={"UTC":UTC(),"argv":argv,"actual_child_PID":p.pid if p else None,"actual_recorder_PID":os.getpid(),"returncode":returncode,"reaped":reaped,"communication_complete":complete,"wait_completed":wait_completed,"failure":failure,"cleanup_errors":cleanup_errors,"streams":streams}
    (d/"execution.json").write_text(json.dumps(receipt,indent=2)+"\n")
    if failure or cleanup_errors or not complete or not reaped or returncode!=0:
        raise RuntimeError("Native custody/command failure; preserve attempt, reconcile read-only; do not retry any mutation.")
    return out
