from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

A = Path('/Users/alec/Documents/Math/draft_pr_descending_audit_20261002/audits/pr284_30001080/actual_author_branch_adversary_01')
H = A.parent.parent / 'pr288_30001994/metadata_completion_preparation_01/native_capture.py'
assert len(H.read_bytes()) == 3993 and hashlib.sha256(H.read_bytes()).hexdigest() == 'd8ccb5a9609448717c8785a19e161526b9e168f681a0499d734c4220fd4fbe9d'
pins = []
for name in ['raw_parent_custody_addendum_01.py', 'capture_raw_parent_addendum_01.py']:
    b = (A / name).read_bytes()
    p = A / 'source_revisions' / name
    with p.open('xb') as f: f.write(b)
    p.chmod(0o444)
    pins.append({'path': str(A / name), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'preserved_copy': str(p)})
with (A / 'RAW_PARENT_ADDENDUM_PRELAUNCH01.json').open('x') as f:
    json.dump({'actual_driver_PID': os.getpid(), 'actual_argv': sys.orig_argv, 'cwd': str(Path.cwd()), 'source_pins_before_first_native_capture': pins, 'stable_native_helper': {'path': str(H), 'bytes': 3993, 'sha256': hashlib.sha256(H.read_bytes()).hexdigest()}, 'local_pure_actual_audit_only': True}, f, indent=2)
    f.write('\n')
s = importlib.util.spec_from_file_location('stable3993_raw_parent_addendum01', H)
m = importlib.util.module_from_spec(s)
s.loader.exec_module(m)
m.call(A, 'raw_parent_addendum_01', ['/opt/homebrew/bin/python3', '-E', '-B', str(A / 'raw_parent_custody_addendum_01.py')], timeout=55, cleanup_timeout=5)
print('Independent full actual branch review complete')
