from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import stat

R = Path('/Users/alec/Documents/Math')
W = R / 'draft_pr_descending_audit_20261002/audits/pr284_30001080'
A = W / 'actual_author_branch_adversary_01'

def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'mode': stat.S_IMODE(p.stat().st_mode)}

def load(p): return json.loads(p.read_bytes())

specs = [
    ('ROOT_exact_raw_original_PR_commit_readback_01', '391cb662b1599ef564ff15b63cd8ed73c7d1f125', 2488, None),
    ('ROOT_exact_raw_main_commit_readback_07', 'f36cb1e34696d460b9cfb5b03425998de48c4669', 56916, 'dd79de35bddab424cb588a4503548ce571781510eacc387b545b36a40aa1f8da'),
    ('ROOT_exact_raw_peer_parent_commit_readback_01', '1252d9d7855ab2ca7c856d644698d2863a19558e', 67757, '766c090d441a5001fa2ebaa6e1a35bbf7dfe49cc138338c1a87ce38a3e7024e4'),
]
proofs = []
for folder, expected_SHA1, recorder, catalog_SHA256 in specs:
    d = W / folder
    cp = d / 'FULL_CATALOG.json'
    if catalog_SHA256:
        assert pin(cp)['sha256'] == catalog_SHA256
        catalog = load(cp)
        assert catalog['execution_authority'] is False
        assert {t['path'] for t in catalog['files']} == {p.relative_to(d).as_posix() for p in d.rglob('*') if p.is_file() and p != cp}
        for t in catalog['files']:
            b = (d / t['path']).read_bytes()
            assert len(b) == t['bytes'] and hashlib.sha256(b).hexdigest() == t['sha256']
        assert all(stat.S_IMODE(p.stat().st_mode) == (0o444 if p.is_file() else 0o555) for p in [d] + list(d.rglob('*')))
    raw = (d / 'RAW_COMMIT.bin').read_bytes()
    assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == expected_SHA1
    full_native = []
    for nd in sorted((d / 'private/native').iterdir()):
        assert {p.name for p in nd.iterdir()} == {'request.json', 'started.json', 'execution.json', 'stdout.gz', 'stderr.gz'}
        q, s, e = [load(nd / n) for n in ['request.json', 'started.json', 'execution.json']]
        assert q['argv'] == e['argv'] and q['cwd'] == str(R)
        assert q['actual_recorder_PID'] == e['actual_recorder_PID'] == recorder
        assert s['actual_child_PID'] == e['actual_child_PID']
        assert q['stdin_bytes'] == 0 and q['stdin_sha256'] is None
        assert e['returncode'] == 0 and e['failure'] is None and e['cleanup_errors'] == []
        assert all(e[k] is True for k in ['communication_complete', 'reaped', 'wait_completed'])
        decoded = {}
        for name in ['stdout', 'stderr']:
            meta = e['streams'][name]
            p = nd / (name + '.gz')
            stored = p.read_bytes(); b = gzip.decompress(stored)
            assert meta['path'] == str(p) and meta['complete'] is True
            assert len(stored) == meta['stored_bytes'] and hashlib.sha256(stored).hexdigest() == meta['stored_sha256']
            assert len(b) == meta['logical_bytes'] and hashlib.sha256(b).hexdigest() == meta['logical_sha256']
            decoded[name] = b
        argv = q['argv']
        assert argv[0] == '/usr/bin/git' and 'core.hooksPath=/dev/null' in argv and 'credential.helper=' in argv
        if nd.name == 'exact_raw_commit':
            assert argv[-3:] == ['cat-file', 'commit', expected_SHA1]
            assert decoded['stdout'] == raw and decoded['stderr'] == b''
        elif nd.name == 'fetch_exact_commit_no_trees':
            assert argv[-7:] == ['fetch', '--no-tags', '--no-write-fetch-head', '--filter=tree:0', '--depth=1', 'https://github.com/AlecKriebel/Math.git', expected_SHA1]
        else:
            assert nd.name == 'initialize_private_store' and argv[-4:] == ['init', '--bare', '--initial-branch=main', str(d / 'private_raw_objects.git')]
        full_native.append({'label': nd.name, 'actual_recorder_PID': recorder, 'actual_child_PID': e['actual_child_PID'], 'argv': argv, 'execution': pin(nd / 'execution.json'), 'request': pin(nd / 'request.json'), 'started': pin(nd / 'started.json'), 'full_stdout_stderr_exit0_wait_reap': True})
    assert len(full_native) == 3
    proofs.append({'folder': folder, 'expected_canonical_commit_SHA1': expected_SHA1, 'actual_full_raw_commit4pin': pin(d / 'RAW_COMMIT.bin'), 'whole_catalog4pin': pin(cp) if catalog_SHA256 else None, 'native': full_native})
readback = load(W / 'ROOT_actual_author_plan_readback_01/READBACK.json')
actual_peer_pin = pin(W / 'ROOT_exact_raw_peer_parent_commit_readback_01/RAW_COMMIT.bin')
assert actual_peer_pin == readback['original_peer_raw_commit']
output = {'schema': 'independent-actual-raw-parent-full-native-custody-addendum-v1', 'UTC': datetime.now(timezone.utc).isoformat(), 'actual_PID': os.getpid(), 'passed': True, 'blocking_findings': [], 'full_custody': proofs, 'native_children': 9, 'existing_original391_no_new_catalog_claimed': True, 'no_new_live_requests_or_mutations': True, 'execution_authority': False, 'qualification': 'Historical raw Git captures use the3993 full-stream/argv/PID request schema. Rich executable/source context is separately mandatory and verified for the actual262 workers and ROOT outer4793. No raw Git fetch, credential acquisition or operation was performed by this reviewer.'}
with (A / 'RAW_PARENT_CUSTODY_ADDENDUM.json').open('xb') as f:
    f.write((json.dumps(output, indent=2) + '\n').encode())
print(json.dumps({'passed': True, 'actual_PID': os.getpid(), 'full_native_raw_parent_children': 9}))
