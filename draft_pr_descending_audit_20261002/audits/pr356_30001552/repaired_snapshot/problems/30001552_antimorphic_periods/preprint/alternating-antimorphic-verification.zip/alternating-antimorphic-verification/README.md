# Alternating antimorphic Fine-Wilf verification supplement

This package accompanies Alec Kriebel's unrefereed research note, version1.0,
dated3 October2026. The note proves the exact unnumbered alternating-period
conjecture afterTheorem23 on printed2220 of OWR37/2010, including arbitrary
antimorphic involutions and fixed letters. The proof uses the common finite
word theta(w)w and credits classical Fine-Wilf and the originating reflections.

Run Python3.10 or later, without optimization or additional dependencies:

    python3 -B verify_supplement.py
    python3 -B verify_supplement.py --full

Default mode checks every package payload, the exact actual inventory,
the unchanged16 submitted files, and the complete expected output of all
four public audit verifiers. It does not rerun mathematical loops.
The explicit --full mode additionally reproduces all six finite-control
programs, matching each complete stdout byte-for-byte. Signed graph controls
take roughly40 seconds on the audit machine; other controls are shorter.
Both modes require empty stderr and unchanged package bytes. They do not
fetch sources, install software or write package files.

submitted_problem/ preserves the submitted historical packet exactly.
In particular its old README reports68413 checks with five private source
bindings. That historical mode has NOT been reproduced by this review;
the current portable run reproduces68408 public checks. The original
absolute-path checker is preserved as history and is not run by this package.
Do not reinterpret unchanged historical exposure/status statements as a
current public provenance certification. The current note, root audit and
bounded priority report define this package's accepted conclusions.

Sharpness means only that the formula cannot be lowered by one uniformly:
abb with reversal at p2,q3. Pairwise optimality is not asserted. The priority
audit found no earlier exact theorem among inspected sources, with its named
access/version gaps. It does not certify first discovery or universal novelty.
Public seals include hashes referring to omitted private records; public
verification never requires those records or claims their provenance checks.
Raw copyrighted primary PDFs, extracts, screenshots and private execution
histories are omitted. The complete public query/retrieval records are included.

AI tools were used extensively in solving, verification, literature research,
writing, computation and adversarial reviews. Those are automated reviews,
not external human peer review. No independent external human review is claimed.
