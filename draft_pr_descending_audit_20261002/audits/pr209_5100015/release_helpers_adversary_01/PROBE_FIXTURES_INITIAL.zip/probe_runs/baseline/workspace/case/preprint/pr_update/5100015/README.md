synthetic reviewed README.md
