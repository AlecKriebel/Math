synthetic reviewed RESEARCH_LOG.md
