synthetic reviewed PROOF.md
