SYNTHETIC PARSER SUCCESSOR ONLY: no scientific or release authority.
