SYNTHETIC parser control only. No actual review or authority.
