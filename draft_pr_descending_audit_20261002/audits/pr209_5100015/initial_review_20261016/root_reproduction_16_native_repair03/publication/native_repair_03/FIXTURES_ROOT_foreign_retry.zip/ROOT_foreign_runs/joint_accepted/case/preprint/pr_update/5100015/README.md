SYNTHETIC reviewed science README.md
