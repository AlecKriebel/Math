SYNTHETIC helper review 1; no real authority.
