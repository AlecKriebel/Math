SYNTHETIC whole review 2; no real authority.
