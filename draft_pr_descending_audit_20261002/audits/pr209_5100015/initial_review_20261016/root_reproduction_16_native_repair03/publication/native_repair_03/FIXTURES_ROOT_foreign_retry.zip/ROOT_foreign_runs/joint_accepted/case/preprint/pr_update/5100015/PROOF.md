SYNTHETIC reviewed science PROOF.md
