#!/usr/bin/env bash
# Publish the preservation patch from an existing, clean AlecKriebel/Math checkout.
# Creates a NEW branch and draft PR; does not force-push, merge, or overwrite a directory.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:?Usage: bash publish_checkpoint.sh /path/to/Math}"
REPO="$(cd "$REPO" && pwd)"
BRANCH="lean/bell-settings-checkpoint-20260910"
DEST="qubit_povm_pvm_minimum_settings/lean"
fail() { printf '%s\n' "$*" >&2; exit 1; }
for cmd in git gh python3; do command -v "$cmd" >/dev/null || fail "Required command not found: $cmd"; done
python3 "$HERE/verify_preservation.py"
[[ -f "$HERE/checkpoint.patch" ]] || fail 'checkpoint.patch is missing.'
TOP="$(git -C "$REPO" rev-parse --show-toplevel)"
[[ "$TOP" == "$REPO" ]] || fail 'Pass the repository root directory.'
URL="$(git -C "$REPO" remote get-url origin)"
case "$URL" in
  https://github.com/AlecKriebel/Math|https://github.com/AlecKriebel/Math.git|git@github.com:AlecKriebel/Math|git@github.com:AlecKriebel/Math.git|ssh://git@github.com/AlecKriebel/Math|ssh://git@github.com/AlecKriebel/Math.git) ;;
  *) fail 'Refusing to publish: origin is not the expected AlecKriebel/Math repository.' ;;
esac
[[ -z "$(git -C "$REPO" status --porcelain)" ]] || fail 'Working tree must be clean; existing changes were not modified.'
git -C "$REPO" var GIT_COMMITTER_IDENT >/dev/null || fail 'Configure your Git committer identity first.'
if git -C "$REPO" show-ref --verify --quiet "refs/heads/$BRANCH"; then
  fail "Local branch already exists: $BRANCH. Inspect it before continuing; nothing was overwritten."
fi
gh auth status --hostname github.com >/dev/null || fail 'GitHub CLI authentication is required.'
set +e
git -C "$REPO" ls-remote --exit-code --heads origin "$BRANCH" >/dev/null
REMOTE_STATUS=$?
set -e
case "$REMOTE_STATUS" in
  0) fail "Remote branch already exists: $BRANCH. Nothing was overwritten." ;;
  2) ;;
  *) fail "Unable to check remote branch (exit $REMOTE_STATUS); publication stopped." ;;
esac
git -C "$REPO" fetch origin main
[[ -z "$(git -C "$REPO" ls-tree origin/main -- "$DEST")" ]] || fail "Destination already exists on origin/main: $DEST. Refusing to overwrite."
[[ ! -e "$REPO/$DEST" ]] || fail 'Destination already exists locally; refusing to overwrite it.'
git -C "$REPO" switch --create "$BRANCH" origin/main
if ! git -c core.autocrlf=false -C "$REPO" am --keep-cr "$HERE/checkpoint.patch"; then
  fail 'Patch application failed. Inspect git status; the helper did not reset or discard anything.'
fi
git -C "$REPO" push --set-upstream origin "$BRANCH"
gh pr create --repo AlecKriebel/Math --base main --head "$BRANCH" --draft \
  --title 'Preserve recovered Lean formalization checkpoint (uncompiled)' \
  --body-file "$HERE/PR_BODY.md"
printf 'Published branch: %s\n' "$BRANCH"
