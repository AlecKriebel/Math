#!/usr/bin/env bash
# Kernel-check the WRITTEN SUBSET. A successful run is NOT full-paper certification.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p reports
python3 - <<'PY_RESET'
import json, pathlib
pathlib.Path('reports/kernel_report.json').write_text(json.dumps({
  'status':'in_progress','lean_build_invoked':False,
  'written_subset_kernel_checked':False,'full_paper_formalized':False},indent=2)+'\n')
PY_RESET
stage="static_source_audit"
lean_invoked=false
finish() {
  code=$?
  trap - EXIT
  STAGE="$stage" CODE="$code" LEAN_INVOKED="$lean_invoked" python3 - <<'PY'
import json, os, pathlib
r={"status":"passed" if int(os.environ["CODE"])==0 else "failed_or_not_run",
   "exit_code":int(os.environ["CODE"]),
   "last_stage":os.environ["STAGE"],
   "lean_build_invoked":os.environ["LEAN_INVOKED"]=="true",
   "written_subset_kernel_checked":int(os.environ["CODE"])==0 and os.environ["STAGE"]=="complete",
   "full_paper_formalized":False,
   "note":"Open end targets remain definitions of propositions, not proved theorems."}
pathlib.Path("reports/kernel_report.json").write_text(json.dumps(r,indent=2)+"\n")
PY
  exit "$code"
}
trap finish EXIT
python3 scripts/source_audit.py | tee reports/source_audit.log
stage="toolchain_discovery"
if ! command -v lake >/dev/null 2>&1; then
  echo "NOT RUN: lake is not installed or is not on PATH." | tee reports/lean_build.log
  echo "Install the pinned Lean toolchain using elan, then rerun this script." | tee -a reports/lean_build.log
  exit 127
fi
lake env lean --version | tee reports/lean_version.log
case "${1:-}" in
  --bootstrap)
    stage="dependency_cache"
    lake exe cache get 2>&1 | tee reports/lean_cache.log
    ;;
  "") ;;
  *) echo "Usage: bash scripts/check.sh [--bootstrap]" >&2; exit 2 ;;
esac
stage="lean_build"
lean_invoked=true
lake build 2>&1 | tee reports/lean_build.log
stage="dependency_audit"
lake env lean Bell/Audit.lean 2>&1 | tee reports/lean_axioms.log
python3 scripts/check_axioms.py reports/lean_axioms.log
stage="complete"
echo "The WRITTEN SUBSET passed. MainClaims and the other open targets are still unproved."
