#!/usr/bin/env python3
"""Fail closed unless Lean printed an allowed dependency result for every theorem."""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ALLOWED={'propext','Classical.choice','Quot.sound'}


def main() -> None:
    (ROOT/'reports').mkdir(exist_ok=True)
    (ROOT/'reports'/'axiom_audit.json').write_text(json.dumps({
        'status':'in_progress','written_subset_dependency_audit_passed':False,
        'full_paper_formalized':False},indent=2)+'\n')
    log_path=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'reports'/'lean_axioms.log'
    log=log_path.read_text()
    expected=json.loads((ROOT/'reports'/'declarations.json').read_text())
    results=[]
    for decl in expected:
        name=decl['name']
        pat=re.compile(r"'?"+re.escape(name)+r"'?\s+(?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)",re.S)
        match=pat.search(log)
        if match is None:
            raise AssertionError(f'Missing or unrecognized Lean dependency report: {name}')
        axioms=set() if match.group(1) is None else {
            a.strip() for a in match.group(1).split(',') if a.strip()}
        unexpected=axioms-ALLOWED
        if unexpected:
            raise AssertionError(f'{name}: unapproved axioms {sorted(unexpected)}')
        results.append({'name':name,'axioms':sorted(axioms)})
    report={'status':'passed','written_subset_dependency_audit_passed':True,
            'full_paper_formalized':False,
            'scope':'Only existing theorem declarations, not open target propositions',
            'allowed_standard_axioms':sorted(ALLOWED),'declarations':results}
    (ROOT/'reports'/'axiom_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'DEPENDENCY AUDIT PASS: {len(results)} written theorems, standard axioms only.')
    print('The main paper targets remain unproved; this is not full-paper certification.')

if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        (ROOT/'reports').mkdir(exist_ok=True)
        (ROOT/'reports'/'axiom_audit.json').write_text(json.dumps({
            'status':'failed','written_subset_dependency_audit_passed':False,
            'full_paper_formalized':False,'error':str(exc)},indent=2)+'\n')
        raise
