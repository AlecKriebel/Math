#!/usr/bin/env python3
"""Package the current source checkpoint, without claiming kernel verification.

Usage: python3 scripts/package.py [output.zip]
This script records bytes, not mathematical correctness. It omits build products,
Python caches and Git metadata. It does not change any proof status.
"""
from __future__ import annotations
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OMIT_DIRS = {'.lake', '.git', '__pycache__'}
OMIT_SUFFIXES = {'.pyc', '.olean', '.ilean', '.o'}


def main() -> None:
    output = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else ROOT.parent/'bell_setting_lean.zip'
    if output == ROOT or ROOT in output.parents:
        raise ValueError('Write the archive outside the source root to avoid recursive packaging.')
    files = sorted(p for p in ROOT.rglob('*') if p.is_file()
        and not any(part in OMIT_DIRS for part in p.relative_to(ROOT).parts)
        and p.suffix not in OMIT_SUFFIXES and p.name != 'SHA256SUMS.txt')
    sums = ''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n' for p in files)
    (ROOT/'SHA256SUMS.txt').write_text(sums)
    files.append(ROOT/'SHA256SUMS.txt')
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in files:
            archive.write(p, 'bell_lean/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise AssertionError(f'Archive CRC failure: {bad}')
        for line in sums.splitlines():
            expected, rel = line.split('  ', 1)
            actual = hashlib.sha256(archive.read('bell_lean/'+rel)).hexdigest()
            if actual != expected:
                raise AssertionError(f'Archive hash mismatch: {rel}')
    print(json.dumps({'archive':str(output),'file_count':len(files),
        'bytes':output.stat().st_size,
        'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'archive_integrity_checked':True,
        'note':'Archive integrity does not establish Lean compilation or proof correctness.'},indent=2))


if __name__ == '__main__':
    main()
