#!/usr/bin/env python3
"""Static source inventory and audit-command generation; not Lean verification."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def strip_comments(text: str) -> str:
    """Remove nested Lean block comments and line comments, preserving newlines."""
    result=[]
    i=0
    depth=0
    quoted=False
    while i<len(text):
        if depth:
            if text.startswith('/-',i):
                depth+=1; result.extend('  '); i+=2
            elif text.startswith('-/',i):
                depth-=1; result.extend('  '); i+=2
            else:
                result.append('\n' if text[i]=='\n' else ' '); i+=1
        elif quoted:
            # Strings are not declaration syntax or proof commands.
            if text[i]=='\\' and i+1<len(text):
                result.extend('  '); i+=2
            elif text[i]=='"':
                quoted=False; result.append(' '); i+=1
            else:
                result.append('\n' if text[i]=='\n' else ' '); i+=1
        elif text.startswith('/-',i):
            depth=1; result.extend('  '); i+=2
        elif text.startswith('--',i):
            j=text.find('\n',i)
            if j<0: j=len(text)
            result.extend(' '*(j-i)); i=j
        elif text[i]=='"':
            quoted=True; result.append(' '); i+=1
        else:
            result.append(text[i]); i+=1
    if depth or quoted:
        raise ValueError('Unterminated comment or string')
    return ''.join(result)


def main() -> None:
    (ROOT/'reports').mkdir(exist_ok=True)
    (ROOT/'reports'/'source_audit.json').write_text(json.dumps({
        'status':'in_progress','static_audit_passed':False,
        'static_audit_only':True,'lean_kernel_checked':False},indent=2)+'\n')
    files=sorted(p for p in ROOT.rglob('*.lean')
                 if '.lake' not in p.parts and p.name!='Audit.lean')
    forbidden=re.compile(r'\b(sorry|admit|axiom|native_decide|unsafe|implemented_by|extern)\b')
    declarations=[]
    inventory=[]
    for path in files:
        text=path.read_text()
        clean=strip_comments(text)
        matches=list(forbidden.finditer(clean))
        if matches:
            details=[{'token':m.group(),'line':clean[:m.start()].count('\n')+1} for m in matches]
            raise AssertionError(f'Forbidden source tokens in {path}: {details}')
        ns=[]
        for line_number,line in enumerate(clean.splitlines(),1):
            line=line.strip()
            m=re.match(r'namespace\s+([^\s]+)',line)
            if m: ns.append(m.group(1)); continue
            m=re.match(r'end\s+([^\s]+)',line)
            if m:
                if ns: ns.pop()
                continue
            m=re.match(r'(?:protected\s+|private\s+)?(theorem|lemma)\s+([^\s({:]+)',line)
            if m:
                name='.'.join([*ns,m.group(2)])
                declarations.append({'name':name,'file':str(path.relative_to(ROOT)),
                                     'line':line_number,'kind':m.group(1),
                                     'kernel_checked':False})
        inventory.append({'file':str(path.relative_to(ROOT)),
                          'lines':len(text.splitlines()),
                          'sha256':hashlib.sha256(text.encode()).hexdigest()})
    if len({d['name'] for d in declarations})!=len(declarations):
        raise AssertionError('Duplicate declaration name in static inventory')
    audit='import Bell\n\n/-! Generated dependency audit. A successful audit checks ONLY the written\nsubset, not the unproved main target propositions in Bell.Targets. -/\n\n'
    audit+='\n'.join(f"#print axioms {d['name']}" for d in declarations)+'\n'
    (ROOT/'Bell'/'Audit.lean').write_text(audit)
    (ROOT/'reports').mkdir(exist_ok=True)
    (ROOT/'reports'/'declarations.json').write_text(json.dumps(declarations,indent=2)+'\n')
    report={'status':'passed','static_audit_passed':True,
            'static_audit_only':True,'lean_kernel_checked':False,
            'forbidden_source_tokens_found':[], 'theorem_declaration_count':len(declarations),
            'source_lines_excluding_generated_audit':sum(f['lines'] for f in inventory),
            'files':inventory}
    (ROOT/'reports'/'source_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f"STATIC PASS: {len(declarations)} theorem declarations; {len(files)} source modules")
    print('This is a text audit, not parsing, elaboration, or kernel verification.')

if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        (ROOT/'reports').mkdir(exist_ok=True)
        (ROOT/'reports'/'source_audit.json').write_text(json.dumps({
            'status':'failed','static_audit_passed':False,'static_audit_only':True,
            'lean_kernel_checked':False,'error':str(exc)},indent=2)+'\n')
        raise
