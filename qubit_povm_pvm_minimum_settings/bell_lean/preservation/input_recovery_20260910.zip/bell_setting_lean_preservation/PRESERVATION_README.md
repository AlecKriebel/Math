# Lean checkpoint preservation package

The connected GitHub plugin rejected branch creation with HTTP 403,
`Resource not accessible by integration`. It did not create a branch or PR.
This package preserves all available artifacts independently of that failure.

The repository-ready directory is:

    qubit_povm_pvm_minimum_settings/lean/

It includes the original ZIP and all 21 available continuation attachments.
Read the enclosed `RECOVERY_STATUS.md` for important recovery gaps. In
particular, `Bell/Assembly.lean` and some continuation-only scripts/reports
were not available. This is not a claim of recovering the entire prior runtime.

## Verify the package

    python3 verify_preservation.py

This checks hashes, not Lean proofs. No Lean compilation was run.

## Publish with an authorized local Git/GitHub CLI connection

From this extracted package, run:

    bash publish_checkpoint.sh /path/to/your/Math

The helper checks the repository, clean working tree, new destination, and
absence of a conflicting branch before creating
`lean/bell-settings-checkpoint-20260910`, applying `checkpoint.patch`, pushing,
and opening a **draft** pull request against `main`. It does not force-push or
merge. It requires `git`, `gh`, `python3`, and existing authorized Git/GitHub
credentials. It neither requests nor stores access tokens.

The helper has been syntax-checked, and the patch was applied in an isolated
local repository and compared byte for byte. The helper's real remote publish
sequence has not been executed or represented as successful.

Alternatively, apply `checkpoint.patch` to a new branch based on the real
repository's main branch using `git am`, then publish the branch and use
`PR_BODY.md` for the draft PR. The patch only adds the new Lean directory.
Its local generation commit has an empty local parent, not the remote main;
`git am` applies the changes onto the real main without replacing repository
history or deleting any existing project files.
