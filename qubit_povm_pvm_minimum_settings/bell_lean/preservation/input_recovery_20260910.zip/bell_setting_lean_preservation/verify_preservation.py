#!/usr/bin/env python3
"""Verify retained file bytes. This does NOT run Lean or verify mathematics."""
from pathlib import Path, PurePosixPath
import hashlib
import json

root = Path(__file__).resolve().parent
count = 0
for line in (root/'MANIFEST.sha256').read_text().splitlines():
    digest, name = line.split('  ', 1)
    rel = PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts:
        raise SystemExit(f'Unsafe manifest path: {name}')
    path = root.joinpath(*rel.parts)
    if not path.is_file():
        raise SystemExit(f'Missing preserved file: {name}')
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != digest:
        raise SystemExit(f'Checksum mismatch: {name}')
    count += 1
print(json.dumps({'verified_file_count':count, 'byte_integrity':'passed',
                  'lean_compilation':'not_run', 'mathematical_verification':'not_claimed'},indent=2))
