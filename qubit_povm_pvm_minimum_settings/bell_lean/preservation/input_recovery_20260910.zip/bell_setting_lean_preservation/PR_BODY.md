## Purpose

Preserve the available Lean formalization work for *Minimum Bell-Setting Complexity for Qubit POVM–PVM Separation* (DOI 10.5281/zenodo.21699161) in the new directory `qubit_povm_pvm_minimum_settings/lean/`.

This is a **draft preservation checkpoint**, not a claim that the paper has been formally verified.

## Contents

- The complete original v0.1.0 archive, retained byte for byte, and its extracted project files.
- Every available continuation attachment: 14 additional Lean modules, the exact rational SOS certificate, both retained SOS checkers, and the continuation status/coverage/blueprint/certificate notes.
- 24 recovered Lean source files (excluding the generated audit), with 278 theorem/lemma proof-attempt declarations by static text count.
- Pinned Lean and Mathlib configuration, original source/build/audit scripts, and retained historical reports.
- File-level recovery provenance, a missing-file register, and a new checksum manifest.
- A reconstructed aggregate `Bell.lean` import list that includes all available source modules. No mathematical source module was edited during preservation.

## Important limitations

**No Lean compiler or kernel verification was run during preservation, and the full proof remains incomplete.** The universal two-input equality, physical/analytic bridges, and strengthened physical attainment remain unresolved.

This is a recovery of available artifacts, not the entire former working directory. `Bell/Assembly.lean`, some continuation scripts/logs, the rank-trichotomy shortcut note, and numerical search provenance were mentioned in prior notes but their bytes were not recovered. Files without a later attachment use the initial ZIP version. See `RECOVERY_STATUS.md` and `reports/recovery_manifest.json`.

The continuation notes are retained unchanged. Their previous 25-file/280-declaration count and references to unavailable files describe the former working directory, not a completeness claim for this recovery. Historical verification logs are not fresh proof evidence for the recovered project.

## Preservation checks performed

- Validated the initial ZIP's CRCs and embedded SHA-256 checksums.
- Verified that all 21 continuation attachments are preserved byte for byte.
- Verified that every available mathematical Lean module is unchanged.
- Checked local import filenames; this is not Lean elaboration.
- Created and verified the preservation archive and Git patch. No mathematical test suite was rerun.

The nested `.github/workflows/lean.yml` is preserved as standalone-project configuration; no repository-root workflow or manuscript change is included.

## Publication history

The assistant's connected GitHub branch-creation attempt returned HTTP 403 (`Resource not accessible by integration`), so that attempt created no branch, pushed no files, and opened no PR. The included error receipt records that earlier attempt only. If this PR is subsequently published using the helper or a repaired connection, that publication is a separate later operation.
