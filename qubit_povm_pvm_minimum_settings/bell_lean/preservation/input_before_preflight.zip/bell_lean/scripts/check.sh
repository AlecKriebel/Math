#!/usr/bin/env bash
# Compile all imported source and audit public dependencies, including main claims.
# A compiler success proves the formal statements, not their faithful translation
# of every sentence in the manuscript. This script has NOT been run in this release.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p reports
stage="static_source_audit"
lean_invoked=false
finish() {
  code=$?
  trap - EXIT
  STAGE="$stage" CODE="$code" LEAN_INVOKED="$lean_invoked" python3 - <<'PY'
import json, os, pathlib
passed=int(os.environ['CODE'])==0 and os.environ['STAGE']=='complete'
r={'status':'passed' if passed else 'failed_or_not_run',
   'exit_code':int(os.environ['CODE']),'last_stage':os.environ['STAGE'],
   'lean_build_invoked':os.environ['LEAN_INVOKED']=='true',
   'all_imported_source_kernel_checked':passed,
   'main_declarations_kernel_checked':passed,
   'statement_to_manuscript_review_required':True,
   'note':'All imported modules and listed public theorem declarations, including Assembly and StrengthenedWitness, are in scope.'}
pathlib.Path('reports/kernel_report.json').write_text(json.dumps(r,indent=2)+'\n')
PY
  exit "$code"
}
trap finish EXIT
python3 - <<'PY'
import json,pathlib
pathlib.Path('reports/kernel_report.json').write_text(json.dumps({
  'status':'in_progress','lean_build_invoked':False,
  'all_imported_source_kernel_checked':False,'main_declarations_kernel_checked':False},indent=2)+'\n')
PY
python3 scripts/source_audit.py | tee reports/source_audit.log
stage="toolchain_discovery"
if ! command -v lake >/dev/null 2>&1; then
  echo "NOT RUN: lake is not installed or is not on PATH." | tee reports/lean_build.log
  exit 127
fi
lake env lean --version | tee reports/lean_version.log
case "${1:-}" in
  --bootstrap)
    stage="dependency_cache"
    lake exe cache get 2>&1 | tee reports/lean_cache.log
    ;;
  "") ;;
  *) echo "Usage: bash scripts/check.sh [--bootstrap]" >&2; exit 2 ;;
esac
stage="lean_build"
lean_invoked=true
lake build 2>&1 | tee reports/lean_build.log
stage="dependency_audit"
lake env lean Bell/Audit.lean 2>&1 | tee reports/lean_axioms.log
python3 scripts/check_axioms.py reports/lean_axioms.log
stage="complete"
echo "All imported source and named main declarations passed the Lean build and dependency audit."
