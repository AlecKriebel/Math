#!/usr/bin/env python3
"""Package the available source, reports, and handoff; omit toolchain/build caches."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
EXCLUDED={'.git','.lake','__pycache__'}
FONT_SUFFIXES={'.ttf','.otf','.woff','.woff2','.eot'}

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda:stream.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    target=Path(sys.argv[1] if len(sys.argv)>1 else str(ROOT.parent/'bell_lean_continuation_20260910.zip')).resolve()
    if target.is_relative_to(ROOT.resolve()):raise SystemExit('Write the archive outside the source tree.')
    paths=sorted(p for p in ROOT.rglob('*') if p.is_file()
        and not any(k in EXCLUDED for k in p.relative_to(ROOT).parts)
        and p.suffix.lower() not in FONT_SUFFIXES)
    checks=''.join(f'{digest(p)}  {p.relative_to(ROOT).as_posix()}\n'
                  for p in paths if p.relative_to(ROOT).as_posix()!='SHA256SUMS.txt')
    (ROOT/'SHA256SUMS.txt').write_text(checks)
    if ROOT/'SHA256SUMS.txt' not in paths:paths.append(ROOT/'SHA256SUMS.txt')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(paths):z.write(p,'bell_lean/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None:raise RuntimeError('ZIP CRC failure')
        for line in checks.splitlines():
            expected,name=line.split('  ',1)
            if hashlib.sha256(z.read('bell_lean/'+name)).hexdigest()!=expected:
                raise RuntimeError(f'ZIP checksum failure: {name}')
    receipt={'archive':str(target),'bytes':target.stat().st_size,'files':len(paths),
      'sha256':digest(target),'zip_crc_and_embedded_hashes_checked':True,
      'lean_kernel_checked':False,'full_paper_proved':False}
    target.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
