# Formalization status — 10 September 2026

## Outcome

**A partial Lean 4 proof-source project was written. It is not a completed or kernel-verified formalization of the paper.**

Paper: Alec Kriebel, *Minimum Bell-Setting Complexity for Qubit POVM–PVM Separation*, DOI 10.5281/zenodo.21699161. The retained 34-page July 2026 PDF matches the original v1.1.0 GitHub release by SHA-256.

## Concrete deliverables

The project contains 114 Lean theorem declarations with proof attempts across 10 source files (1542 lines, excluding the generated audit module). It includes physical complex-qubit definitions; the explicit Bell witness and ideal discrimination certificate; scalar gap/robustness proofs; Lorentz-incidence algebra; a general transportation construction and physical deterministic-mixture simulator; explicit unresolved main targets; pinned build configuration; an axiom-audit command; independent checks; and a continuation blueprint.

## Executed checks

| Check | Result |
|---|---|
| Static proof-escape token audit | Passed; not a Lean parse or proof check |
| Python/SymPy exact algebra and finite checks | 122 passed |
| Exact rational transportation regressions | 1,215 passed |
| Simulator probabilities compared | 43,740 entries, covering all 36 declared entries in every regression |
| Build wrapper | Exit 127: `lake` unavailable |
| Lean compilation | Not invoked |
| Lean axiom-dependency audit | Not executed against Lean output |
| Project declarations kernel-checked here | 0 |

The witness was checked against the exact value `L0 = 20√2 + 16/25` and the positive scalar difference `L0 − U = 3(2−√2)/250`. This does not prove that `U` bounds all PVM strategies: that universal physical bound remains a separate unproved target.

## Main remaining obligations

The global physical PVM upper-bound derivation remains missing. The universal two-input hull equality remains missing, including its cone/extremal reductions, physical incidence reconstruction, multiplier and differential-geometric arguments, and complete rank trichotomy. The source has only conditional assembly for the resulting separation and minimum-architecture conclusions. Appendix B's stronger physical attainment is also not implemented.

A successful future build of the current subset would not, by itself, resolve those mathematical obligations. No `sorry` or new axiom was used to make the main results appear finished.

## Resume

With `elan` installed and Internet access, run from the extracted `bell_lean` directory:

```bash
bash scripts/check.sh --bootstrap
```

This is the first unfinished computation. Repair any failures rather than inserting placeholder proofs. Follow `docs/BLUEPRINT.md` after the existing subset compiles. The independent checks run using `python3 scripts/exact_checks.py` after installing the pinned SymPy dependency.

The source can contain undetected Lean errors because it has never been compiled. It is a checkpoint for continuation, not a publication-ready formal verification artifact.
