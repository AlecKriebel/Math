# Resume blueprint and proof dependencies

## First unfinished computation

```bash
cd bell_lean
bash scripts/check.sh --bootstrap
```

The supplied runtime has no `lean`, `lake`, or `elan`. The saved result is exit 127 at toolchain discovery, before any Lean build. Direct installation/download routes failed; the official nightly artifact available through the connector exceeded its download-size limit. No different compiler was silently substituted.

Install `elan` in an environment with Internet access, retain the pinned toolchain and Mathlib revision, then run the command above. Review `lake-manifest.json` if Lake rejects its reconstructed metadata. Do not change the mathematical scope to make an initial build pass.

The first phase is to repair any parsing, elaboration, API, or tactic failures in the **existing subset**. Compilation errors would be new diagnostic information; they have not yet been observed because no compiler has run. Keep the independent exact checks available as regressions while editing.

## Stage 0 — validate the checkpoint

Run the source audit, then the exact checker. Validate the archive checksum manifest. The expected numbers are 114 inventoried theorem declarations, 122 exact checks, and 1,215 rational transport instances. Changing the source will require refreshing the inventory, hashes, and reports; the current count is not a goal to preserve.

Run a genuine Lean build and the generated dependency audit. Accept only the standard dependencies `propext`, `Classical.choice`, and `Quot.sound`. Do not use `sorry`, additional axioms, externally asserted booleans, or native evaluation to replace mathematical proofs. Record the *actual* successful logs and source hashes before changing kernel-verification status. A successful stage 0 is still partial-paper verification.

## Stage 1 — close the explicit separation theorem

The simplest route to the first end-to-end main theorem is Section 3, not the entire equality theorem.

1. Establish the general finite-dimensional quantum preliminaries needed for the physical reduction: Born positivity/normalization, linear optimization over density matrices, pure-state reduction, local unitary invariance, and Schmidt form for complex qubits.
2. Prove the possible ternary-qubit PVM support/rank patterns and the handling of coarse-grained labels and degenerate binary observables. Derive the degenerate CHSH bound.
3. Prove the Schmidt-state correlation formula and the two CHSH deficit estimates, with all endpoint/degenerate cases covered.
4. Connect binary discrimination of the selected score operators to `pairScore`, and cover all singleton/two-label supports. The scalar robustness lemma is already written, but this operator-to-scalar reduction is not.
5. For every raw physical PVM strategy, produce the scalar hypotheses of `global_upper_from_deficits`. Prove `ProjectiveGlobalUpperBound` *without extra assumptions*. Apply the existing conditional assembly to the actual witness and convex hull.

Success criterion: an unconditional, kernel-checked proof of `ProjectiveGlobalUpperBound` and the strict physical separation, with the complete declaration dependency audit. The attainment and upper bound need not be exact global optima.

## Stage 2 — complete general preliminaries for the equality theorem

Prove compactness of the raw finite-alphabet strategy images and the relevant convex hulls. Formalize support-function separation in finite-dimensional behavior space, including attainment and the passage to an extreme maximizing behavior. Cover stochastic postprocessing as finite deterministic relabeling without increasing local dimension.

Prove the one-input nonsignaling/local decomposition and its physical PVM realization; the latter's deterministic/finite-mixture component is already written. This closes `OneInputEquality` only after the complete Born-behavior link and every architecture boundary are handled.

Formalize the pointed-cone circuit theorem and the one-binary-party reduction, with the parallel-axis, scalar-observable, rank-deficient, and zero-weight cases retained. Prove the physical filtering lemma, extremal qubit POVM rank-square argument, and residual binary-plus-ternary reduction. The scalar filtering identity alone does not establish these.

## Stage 3 — incidence model and local physical completeness

Formalize complex Hermitian qubit matrices in Pauli/Lorentz coordinates. Derive all scale factors in the trace and determinant pairings; do not conflate a coefficient quadratic form with the inverse-metric incidence constraint.

Prove the actual state/effect representation, invertibility assumptions, strict inequalities, and Lorentz signature of the physical stratum. Formalize smooth local frame construction and the inverse construction of a physical state and measurements from nearby incidence data. Prove independent constraint differentials and the normalized 14-dimensional manifold result. Check the treatment of zero *joint probabilities*: openness of other conditions must not exclude them.

Success criterion: the genuine local reconstruction theorem and the ability to integrate every incidence tangent into a two-sided physical curve.

## Stage 4 — duality, multipliers, and second variation

Prove finite POVM strong duality with attainment and complementary slackness. Prove the determinant pullback with the manuscript's factor `4*|det Ξ|^2`. Identify the normalization multipliers and prove nonnegative, then strictly positive, outcome multipliers at a putative strict non-PVM maximizer. Include the deterministic replacement/locality argument when a multiplier vanishes.

Derive the first and second derivatives of the inverse metric, the weighted Hessian formula, the compatible tangent space, normalization correction, and inertia `(4,12)`. The existing bilinear identity and independent symbolic inverse-Hessian check do not substitute for these differentiability and linear-algebra theorems.

Success criterion: a formal contradiction for every `rank D ≥ 2` putative strict maximizer.

## Stage 5 — rank-one and rank-zero closure

Complete the projective-fiber theorem. The generic inverse and base-locus algebra are written; the four exceptional divisors require full uniqueness and exhaustion, including their intersections, zero target coordinates, rescaling justifications, and strict inequalities. Do not divide by a coordinate merely because it is generically nonzero.

Prove the rank-one contradiction using distinct source rays and strict multiplier positivity.

For rank zero, prove the five-ray permutation/scaling argument, preservation of the binary/ternary parts, common positive scale, and normalization. Transport the table and labels to the actual normalized architecture. Then apply `rankZeroTable_mem`, after compilation and verification, rather than taking normalized-table hypotheses as unproved premises.

Success criterion: each branch of the exhaustive trichotomy is closed for every genuine residual strict maximizer.

## Stage 6 — unconditional equality and minimum architecture

Assemble the reductions, strict separation argument, and exhaustive trichotomy to prove `UniversalTwoInputEquality` for every finite input-dependent output architecture. Combine it with `OneInputEquality` and the verified Section 3 separator to obtain the minimum architecture result. The present `main_claims_of_missing_theorems` is only an assembly template until its arguments are supplied by unconditional proofs.

Repeat the full build, dependency audit, source-fidelity review, and regression checks. A final release should distinguish the main equality/separation theorem from ancillary claims still outside scope.

## Optional distinct stage — Appendix B attainment

The stronger radical comparison and one-parameter scalar upper bound are written. To formalize the stronger *attained* value, separately construct the nonmaximally entangled state, observables, and three-outcome POVM; verify normalization, positivity, exact score, and any asserted dual certificate. Populate `StrengthenedAttainment` only after that physical construction is proved. Do not infer attainment from a scalar family upper bound.

## Packaging discipline

Preserve completed source and successful proof logs after each stage. Keep source hashes, paper hash, toolchain/Mathlib pins, axiom reports, open-target inventory, and the exact next failing command in the checkpoint. Do not promote a successful finite benchmark to a universal theorem, a compiled conditional statement to an unconditional one, or a successful subset build to full-paper certification.
