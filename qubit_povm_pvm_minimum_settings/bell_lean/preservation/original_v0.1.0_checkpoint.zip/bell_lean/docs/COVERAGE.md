# Claim-by-claim coverage register

**All Lean entries below are uncompiled proof sources. None is reported as kernel-verified.** “General” describes a universally quantified *written statement*, not an executed proof result. Python exact checks are a separate evidence layer.

The source is the 34-page July 2026 PDF retained in `source/`, matching the original v1.1.0 GitHub release manifest. Section and theorem numbers below refer to that PDF.

## Source modules

| Module | Paper correspondence and written content | Important boundary |
|---|---|---|
| `Quantum` | Section 2: complex 2×2 effects; 4×4 density matrices; POVMs/PVMs; Born behaviors; finite, input-dependent alphabets; raw and convexified sets; PVM-to-POVM inclusions; Gram positivity | General normalization/nonnegativity/nonsignaling of the Born map and topology/compactness results are not proved here |
| `Convexity` | Scalar finite-mixture bound; a linear inequality extends to Mathlib's convex hull; scalar filtering-average identity; binary spectral weights | Not the compactness theorem, full postprocessing argument, support-function converse, spectral decomposition, or physical filtering construction |
| `Scalars` | Section 3/Appendix A: strict gap, scalar deficit bounds, polynomial robustness certificate, pair-score estimate, completion of the square, upper bound conditional on scalar deficits; Appendix B: stronger radical comparison and family upper bound | No derivation of the scalar hypotheses from arbitrary physical PVMs; no physical attainment of the Appendix B strategy |
| `Witness` | Section 3.1: concrete complex-qubit strategy, density/effect Gram factorizations, positivity/normalization, Bell trace identity, three auxiliary probabilities, CHSH correlations, attained value, raw/hull membership | Establishes a POVM strategy above a number; only a separate global PVM theorem can make that number a separating upper bound |
| `Discrimination` | Section 3.1: rational Gram certificates for all ideal dual slacks, complementary slackness, general ideal POVM score upper bound, attainment | Fixed ideal score operators only; not a state-varying global Bell bound or general finite-POVM strong duality |
| `Lorentz` | Sections 5–9/Appendices F–G: circuit kernel; outer-product independence; null metric form; five base lines; generic inverse; cross-branch identities/exclusion; direct zero-coordinate root uniqueness; two eliminants and nondegeneracy; bilinear square completion | Does not establish the physical incidence model, Lorentz signature, differentiability, full exceptional-fiber injectivity, multiplier signs, inertia, or trichotomy |
| `Transportation` | Appendix H: general three-label bounded-flow existence with all nonnegative/boundary capacities; explicit intersection of three intervals; row/column/mass identities | Hypotheses are those of the normalized table; they are not automatically consequences of an arbitrary incidence point |
| `LocalSimulation` | Proposition 9.2/Appendix H: deterministic identity/zero qubit PVMs, finite mixtures in the actual convex PVM set, common 18-branch transport mixture, all 36 declared probabilities, normalized-table PVM membership | Does not prove the rank-zero geometric reduction, common-scale argument, or arbitrary relabeling correspondence |
| `Targets` | Explicit main target propositions; Bell linearity; conditional separation and minimal-input assembly | Open targets have no proof. Conditional theorem arguments remain genuine unresolved obligations |

`Bell.lean` is the aggregate import. `Bell/Audit.lean` is generated and contains `#print axioms` commands; it does not provide missing proofs.

## Main conclusions

| Paper conclusion | Status |
|---|---|
| Section 3.1: explicit physical strategy attains `20√2 + 16/25` | Proof source written, not compiled. Exact matrix/value checks passed independently |
| Exact positive scalar gap `3(2−√2)/250` | Proof source written, not compiled. Exact checks passed independently |
| Section 3.2: **every** fixed-qubit PVM strategy has score at most `U` | **Missing physical proof**; scalar consequences are written separately |
| Theorem 3.1: strict fixed-qubit Bell separation | **Conditional only** on the preceding missing global upper bound |
| Appendix B: stronger strategy physically attains `(16+8√7813)/25` | **Missing**; only scalar comparison/family upper bound written |
| Theorem 6.1: local physical completeness | **Missing** |
| Proposition 6.2: smooth 14-dimensional incidence manifold | **Missing**; coefficient outer-product independence written |
| Proposition 7.3: strictly positive multipliers | **Missing** |
| Proposition 8.1 and rank≥2 second-variation contradiction | **Missing**; square-completion algebra written, not full Hessian/geometry |
| Proposition 9.1: total projective injectivity off the base locus | **Partial source only**; full exceptional-chart assembly missing |
| Proposition 9.2: arbitrary rank-zero incidence point is PVM-simulable | **Partial source only**; general normalized-table simulation written, geometric reduction missing |
| Theorem 9.3: universal two-input equality of convexified behavior sets | **Missing** |
| Corollary 9.4: minimum architecture is 3×2, up to exchange | **Conditional only** on missing one-input/two-input equalities and separation bound |

No percentage-of-paper figure is assigned. Counts of source declarations and checks would be a misleading proxy for completion of the load-bearing geometric arguments.

## Explicit unresolved proposition definitions

The definitions are in `Bell/Targets.lean`:

```lean
ProjectiveGlobalUpperBound : Prop
UniversalTwoInputEquality : Prop
OneInputEquality : Prop
StrengthenedAttainment : Prop
MainClaims : Prop
```

Their exact bodies quantify over the genuine complex-qubit strategy images and shared-randomness hulls where appropriate. There is no axiom asserting that any of these propositions holds.

The following declarations must retain their conditional interpretation:

```lean
convex_projective_bound_of_raw
three_by_two_separation_of_projective_upper_bound
minimum_inputs_of_equality_theorems
main_claims_of_missing_theorems
```

The scalar declaration `global_upper_from_deficits` is also conditional: it receives real-number inequalities, and does not prove that every physical PVM strategy supplies them.

## Executed evidence, kept separate

The exact checker passed 122 named checks, including finite witness/dual certificates and universally symbolic polynomial/matrix identities. It also tested 1,215 exact rational transportation instances, comparing the same mixture against all 36 declared probabilities in each instance (43,740 entries).

These tests validate their own finite or symbolic formulas in Python/SymPy. They do not parse Lean, verify the Lean proof terms, establish the general transportation theorem by finite enumeration, or close the physical/geometric steps listed above.

The static audit found no forbidden proof-escape tokens in the local source. It is intentionally labeled *static* and is not a Lean parser or proof checker. The attempted build wrapper found no `lake` and exited 127 before invoking Lean. The workflow and axiom-log audit were supplied for later execution, not run successfully in this environment.

## Model-fidelity checklist for future review

The encoded local space is complex dimension two, not a real-qubit restriction. The joint density matrix may be mixed or entangled. The witness lies in a real plane, but the general strategy definitions do not impose that restriction. No ancilla or larger local Hilbert space is introduced.

All PVM outcomes, including zero projectors, use the same declared labels as the corresponding POVM problem. The first two Alice inputs in the explicit separator have a zero-padded third label. The common randomization is over complete strategies, not independent convexification of individual measurement operators. The simulation module uses one branch distribution for all four input blocks.

The raw images and their convex hulls have separate names. No same-state or raw-set equality is asserted. The paper's claim about arbitrary input-dependent finite outputs is represented by a schema over `Architecture`, not an identification of tables with different index types. The formal target's fidelity to the intended minimum-setting notion remains part of the human review, even after future successful compilation.
