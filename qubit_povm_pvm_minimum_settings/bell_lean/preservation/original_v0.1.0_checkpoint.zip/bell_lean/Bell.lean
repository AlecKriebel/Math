import Bell.Quantum
import Bell.Convexity
import Bell.Scalars
import Bell.Witness
import Bell.Discrimination
import Bell.Lorentz
import Bell.Transportation
import Bell.LocalSimulation
import Bell.Targets

/-! Partial, uncompiled source draft for DOI 10.5281/zenodo.21699161.
Read README.md and docs/COVERAGE.md before interpreting a build result.
The full-paper goals in Bell.Targets are NOT proved by this package. -/
