# Exact verifier entry points

This small submission-support capsule exposes the exact commands, Python dependency
lock, active theorem map, and release-provenance checker used for the
manuscript.  Exact PDF replay additionally requires Bash, checksum utilities,
Tectonic 0.16.9 with default bundle v33, and (for the public-download gate)
GitHub CLI `gh`; these tools are not installed by `requirements.txt`.
It is not the complete proof archive: the graph encodings, regenerated
relations, exact polynomial records, and clean-checkout transcripts are too
large and are published as the hash-bound assets of the immutable release:

https://github.com/AlecKriebel/Math/releases/tag/stc-jc-sharp-boundary-v1.1.4

After cloning that tag, run from the monorepository root:

```bash
bash s_tc_jc_landmark_closure/reproducibility/verify_quick.sh
bash s_tc_jc_landmark_closure/reproducibility/verify_full.sh
bash s_tc_jc_landmark_closure/reproducibility/verify_regenerate_all.sh
python s_tc_jc_landmark_closure/reproducibility/verify_public_release.py
```

The last command downloads and verifies the public release assets.  A plain
archive extraction has no Git history, so its fail-closed gate is instead:

```bash
python s_tc_jc_landmark_closure/reproducibility/verify_active_release.py
```

The public verifier also executes the extracted-archive gate automatically.
The
internal `SHA256SUMS` file authenticates every file in this capsule relative
to the submission package's outer manifest.  No script submits a manuscript,
contacts an editor, chooses a license, or creates a DOI.
