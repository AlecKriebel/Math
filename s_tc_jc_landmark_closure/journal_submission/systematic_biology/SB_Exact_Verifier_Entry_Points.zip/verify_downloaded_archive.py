#!/usr/bin/env python3
"""Authenticate the downloaded curated proof archive."""
import hashlib
from pathlib import Path
import sys

EXPECTED_NAME = 'stc_jc_sharp_boundary_atlas_certificates_v1.1.6.tar.gz'
EXPECTED_SHA256 = 'TO_BE_FILLED_AFTER_FINAL_SEAL'
path = Path(sys.argv[1] if len(sys.argv) > 1 else EXPECTED_NAME)
if path.name != EXPECTED_NAME:
    raise SystemExit(f"expected filename {EXPECTED_NAME}, got {path.name}")
h = hashlib.sha256()
with path.open("rb") as stream:
    for block in iter(lambda: stream.read(1 << 20), b""):
        h.update(block)
actual = h.hexdigest()
if actual != EXPECTED_SHA256:
    raise SystemExit(f"SHA-256 mismatch: {actual}")
print(f"VERIFIED {path.name} {actual}")
