# Verifier entry points — navigation capsule only

This small ZIP is not the proof archive. It contains the archive identity,
checksum, minimal theorem map, runtime requirements, and a checksum verifier
so a submission reader can locate and authenticate the load-bearing object.

Canonical proof object: `stc_jc_sharp_boundary_atlas_certificates_v1.1.6.tar.gz`
SHA-256: `032574f590c27a1f80d1e5dfa1b84b6f46b1e09d8d6f19a2d7c435597690b376`
Zenodo DOI: `ZENODO_DOI_PENDING`

After downloading and extracting the canonical archive, run from its root:

```bash
bash verify.sh quick
bash verify.sh full
bash verify.sh regenerate-all
```

The archive contains the complete finite atlas, every per-relation exact
certificate and transport, restoration and probe records, primitive inputs,
and both primary and separately implemented verifiers. This capsule contains
none of those large proof records and must not be cited as the proof object.
No included script uploads files, creates a DOI, submits a manuscript, or
chooses a license.
