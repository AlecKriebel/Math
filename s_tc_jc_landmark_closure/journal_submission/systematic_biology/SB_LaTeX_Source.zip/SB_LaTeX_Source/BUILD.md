# Deterministic LaTeX build

Requirements: Tectonic 0.15 or later with its standard cached bundle.

From this extracted source directory:

```bash
cd paper
tectonic main.tex
cd ../supplement
tectonic supplement.tex
```
