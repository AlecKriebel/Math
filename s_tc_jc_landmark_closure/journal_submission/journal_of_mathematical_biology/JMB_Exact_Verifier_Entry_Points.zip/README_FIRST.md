# Verifier entry points — navigation capsule only

This small ZIP is not the proof archive. It contains the archive identity,
checksum, minimal theorem map, runtime requirements, and a checksum verifier
so a submission reader can locate and authenticate the load-bearing object.

Canonical proof object: `stc_jc_sharp_boundary_atlas_certificates_v1.1.7.tar.gz`
SHA-256: `ffcce5398c8be387d6d808620fc939490f31ac41fb48592e22608cf0e7b05db4`
Zenodo DOI: `10.5281/zenodo.22064121`

After downloading and extracting the canonical archive, run from its root:

```bash
bash verify.sh quick
bash verify.sh full
bash verify.sh regenerate-all
```

The archive contains the complete finite atlas, every per-relation exact
certificate and transport, restoration and probe records, primitive inputs,
and both primary and separately implemented verifiers. This capsule contains
none of those large proof records and must not be cited as the proof object.
No included script uploads files, creates a DOI, submits a manuscript, or
chooses a license.
