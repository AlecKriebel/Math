# Verifier entry points — navigation capsule only

This small ZIP is not the proof archive. It contains the archive identity,
checksum, minimal theorem map, runtime requirements, and a checksum verifier
so a submission reader can locate and authenticate the load-bearing object.

Canonical proof object: `stc_jc_sharp_boundary_atlas_certificates_v1.1.7.tar.gz`
SHA-256: `01f8a81ae402893a58d87c80520005d9190f0c672c9e7c839769e5eb06ac4842`
Zenodo DOI: `ZENODO_DOI_PENDING`

After downloading and extracting the canonical archive, run from its root:

```bash
bash verify.sh quick
bash verify.sh full
bash verify.sh regenerate-all
```

The archive contains the complete finite atlas, every per-relation exact
certificate and transport, restoration and probe records, primitive inputs,
and both primary and separately implemented verifiers. This capsule contains
none of those large proof records and must not be cited as the proof object.
No included script uploads files, creates a DOI, submits a manuscript, or
chooses a license.
