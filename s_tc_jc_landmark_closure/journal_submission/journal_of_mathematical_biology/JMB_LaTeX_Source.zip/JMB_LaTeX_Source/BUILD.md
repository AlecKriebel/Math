# Deterministic LaTeX build

Exact-byte replay was tested with Tectonic 0.16.9, default bundle v33,
and SOURCE_DATE_EPOCH=1786924800. requirements.txt in the complete
project archive is the Python dependency lock; Tectonic and its bundle
are separate build requirements.

From this extracted source directory:

```bash
export SOURCE_DATE_EPOCH=1786924800
cd paper
tectonic main.tex
cd ../supplement
tectonic supplement.tex
```
