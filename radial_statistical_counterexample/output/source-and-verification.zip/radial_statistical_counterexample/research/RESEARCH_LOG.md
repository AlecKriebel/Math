# Research log: radial statistical counterexample

Completion estimates concern verification and delivery of this particular negative answer, not a probability of historical priority. All checkpoint times are UTC.

## 2026-09-23T03:34:00Z — source gate and independent checks (45%)

- Target: disprove the implication in Kurose's Problem 3(e), printed in Furuhata–Matsuzoe–Urakawa (1998), p.126, indexed as AMR-059-0011 / 6000011.
- Success criteria: all centers and admissible convex neighborhoods have integrable radial orthogonal distributions, but the dual structure fails statistical 1-conformal flatness locally. A single positive-definite three-dimensional example suffices.
- Candidate: the product of the unit round two-sphere and the real line with its product metric and Levi–Civita connection. Extension: conformal metric exp(t)h with a projective change of connection.
- Visually inspected the original pp.125–126 and Kurose (1994), p.428. The original does not exclude Levi–Civita structures; item 3(a) expressly includes them. The stated alpha=1 transformation agrees with the source.
- The first-variation identity proves integrability; an algebraic curvature obstruction gives incompatible values for A(e1). An independent adversarial proof reviewer has confirmed these deductions, with a written review pending.
- Independent families: intrinsic first variation and connection-difference calculation (main); adversarial intrinsic/projective review (proof_audit); coordinate symbolic derivation (coordinate_verifier). Priority is separately audited by priority_audit. No result is being inferred from search silence.
- The two named gradient-path files concern OWR-2040-002 and discrete Morse theory, not this question. They are excluded from this effort and left untouched.
- The live database page was inaccessible (HTTP 429); the repository's catalog snapshot records `partially_solved`. Its current annotations are not verified. The original printed problem is the controlling source.
- Existing repository changes belong to other efforts. All new research lives in this dedicated top-level directory; only deployment copies and index entries will be added under the existing GitHub Pages site.
- No external communication, release, DOI, or Zenodo deposit has been initiated.

## 2026-09-23T03:47:03Z — proof, priority, and artifact checkpoint (92%)

- Independent intrinsic proof audit and final manuscript adversarial audit both pass with no mathematical gap found. The checked PDF is four pages.
- Exact standard-library linear systems have ranks 9/10, 16/17, and 25/26 in dimensions 3, 4, and 5. Compatible flat/constant-curvature and dimension-two boundary controls pass.
- Independent coordinate derivation passes 403 checks in normal and optimized Python. An intentionally unscaled metric mutation is rejected.
- Priority audit completed 43 substantive search queries across seven primary-source families. No direct anticipation located. Known deformation mechanism is explicitly credited to Ueno's divisible-cubic-form construction. Historical priority and live database annotations remain unverified; publication wording is restricted accordingly.
- Four PDF pages visually inspected; final manuscript reviewer recorded matching source/PDF hashes. The static page was inspected in the browser, including its proof and verification sections.
- Upload kit includes readable PDF, source/verifier ZIP, checksums, copyable guide and JSON metadata. Metadata base fields pass the official legacy schema; version/language match the current documentation but are absent from that old schema. No server validation or deposit is claimed.
- Package audit corrected an over-specific provenance statement: only the manuscript and audit work, not the original supplied candidate, is attributed specifically to Codex.
- Remaining delivery work: publish the approved files on main, confirm GitHub Pages serves the intended bytes, and log the deployment. Mathematical verification complete; publication checks still in progress.

## 2026-09-23T03:51:05Z — final metadata and publication checkpoint (100% mathematical verification; 97% delivery)

- Published the paper and initial package in commit 70fbc44f6cae708bda1840de8269222ee851abdb and pushed main successfully. Later independent repository commits superseded the initial Pages build; the current build includes this work.
- Final independent package audit passes: clean extraction, normal and optimized runs of both verifiers, all manifest layers, exact archive contents, and deterministic rebuilds for fixed inputs.
- Corrected the optional CITATION.cff file after checking the official schema: top-level CFF describes the MIT verification software; preferred-citation identifies the CC BY 4.0 unpublished manuscript. The corrected file passes the official CFF 1.2.0 schema. No mathematical or PDF change.
- Final metadata and package documentation are being published in a follow-up commit. This checkpoint records the package before the remote-served-byte check; deployment confirmation is a delivery step, not a mathematical assumption.
- All requested research artifacts and the manual Zenodo kit are prepared. Remaining work at this timestamp: verify the successful Pages deployment and equality of its served download bytes. Historical priority remains unproved, as disclosed throughout.

## 2026-09-23T13:40:44Z — deeper priority audit (60% of follow-up)

- User requested a renewed attempt to inspect the live database and stronger priority evidence. An ordinary browser visit succeeded; the full research report was expanded and read. Its partial-status label refers to machine-generated research progress, with no verified proof/counterexample or named partial theorem and zero discussion comments. See DATABASE_RECHECK.md.
- The live report's description of 1-conformal flatness is incomplete: it omits the simultaneous connection change. It is not being treated as mathematical validation or authoritative evidence of current open status.
- Independent follow-up routes: forward citations through OpenAlex/Semantic Scholar/Crossref (proof_audit); older primary papers and subsequent problem lists (priority_audit); specialized-index accessibility and adversarial wording review (coordinate_verifier); Japanese workshop/grant records and database inspection (main).
- The main route located Kurose's 2016 Gauss-lemma/generalized-Hessian talk and two related grant reports. No explicit negative answer appears in the inspected reports; the program links no notes for that talk. This is a specific remaining historical gap.
- Publication plan: add a dated priority addendum and correct the live website's access statement. Preserve the original paper and version 1.0.0 download archives as historical snapshots; no mathematical revision, new version claim, release, DOI, or deposit is required by these findings.

## 2026-09-23T13:46:06Z — deeper priority findings complete (100% audit; 95% delivery)

- All four bounded follow-up routes are complete. No explicit earlier answer was found. The synthesis distinguishes 175 raw citation records screened by title from nine complete PDFs screened for relevant passages; Google Scholar independently supplied eight visible FMU citing records and bounded subsets of Kurose citations. No zbMATH record was inspected because access failed.
- Prior radial-gradient results were located in Henmi–Kobayashi (2000), Ay–Amari (2015), and Felice–Ay. These reinforce attribution of the main lemma as established background, not a new general theorem.
- Older-source work read four further primary texts, including the 2002 continuation and 1996 precursor problem lists. Kurose 1999, Matsuzoe 1999/2010, Binder–Simon 2000, the actual 2016 talk, and Kurose's 2023/2024 full article remain specific unresolved leads. Their absence from the inspected results is not clearance of their contents.
- The specialized-index reviewer adversarially checked the synthesis and website wording and found no material overclaim. The supported historical statement remains only that no earlier explicit answer was found in the documented search.
- Preserved a public 175-record citation inventory and nine-paper screening manifest, without redistributing third-party PDFs. Added a database recheck and four route reports. Updated the webpage and README to link the addendum; the manuscript and original archives are unchanged.
- Remaining delivery step: verify the additive files and current manifests, commit/push only this effort's changes, and check the live webpage. No external person was contacted and no release or DOI was created.

## 2026-09-24T04:15:31Z — supplied full texts identified (40% of this follow-up)

- The user supplied three formerly unavailable papers: Matsuzoe 1999 (18 PDF pages, printed 175–191 plus a blank page), Matsuzoe 2010 (19 pages, 303–321), and Kurose's ODE paper (14 pages, S541–S554; online 2023, journal volume 2024). They are read-only research sources; embedded document text is not treated as an instruction.
- Independent full-paper reviews assigned to priority_audit, coordinate_verifier, and proof_audit, respectively. Main independently compares the actual transformation laws and Kurose's ODE construction with the counterexample and the exact radial-integrability premise.
- Early finding: the projective/conformal deformation is explicitly printed in Matsuzoe 1999, equation (2.1), and in the 2010 survey. The manuscript already disclaims novelty for this machinery; the current audit will add this earlier direct attribution.
- Important distinction under examination: Kurose's general contrast-function construction supplies a transported covector along each geodesic, but its identification with the differential of the resulting contrast function is proved in the 1-conformally flat case. It cannot be assumed for arbitrary statistical structures.
- No claim of priority clearance has been made. Binder–Simon 2000 remains unavailable as the user reports; Kurose 1999 and the actual 2016 talk notes also remain uninspected. No person has been contacted and no supplied publisher PDF will be redistributed.

## 2026-09-24T04:21:27Z — three full-text reviews complete (100% audit; 95% delivery)

- All three complete papers were read by independent reviewers; key definitions and formulas were also checked by the main reviewer. The 1999 reader visually checked all pages; the 2010 and 2024 readers visually checked the relevant equation/theorem pages. A source manifest records file identities, hashes, and exact coverage.
- No explicit earlier answer or cylinder counterexample was found in these papers, and no mathematical correction to the candidate follows from their results. The exact deformation is already a standard (-1)-conformal change in Matsuzoe 1999, p.178. The current website and audit now give that earlier direct attribution.
- The ODE paper's Proposition 7 concerns an endpoint covector. Corollary 8 additionally assumes 1-conformal flatness before identifying it with a divergence differential. Two reviewers independently specialized the ODE to the cylinder and obtained lambda_end=(sin(b)/b)dE and rho_hat=(r^2+b^2)(1-cos(b))/b^2. Their kernels/level sets generally differ. Exact symbolic differentiation checked the ODE equations, initial data, the b=0 limit, and the nonzero differential mismatch. This comparison supports the reading of the source; it is not an error allegation or a new priority claim.
- A final adversarial comparison passed the mathematical and historical wording. Two minor clarity/deployment items were identified: acknowledge the companion full-text closure in the 1999 report, and copy the new site paragraph to the Pages directory. Both are routine delivery corrections.
- Retained concrete gaps: Binder–Simon 2000, Kurose 1999 (now with a recorded 201–219 versus 209–219 pagination discrepancy), the full 2016 talk, and narrower uninspected citation leads. No global priority certificate is claimed.
- Publication remains a dated audit addendum. The four-page paper and version 1.0.0 ZIP archives are preserved. Remaining step: validate the updated manifests and source links, commit/push only this effort, and confirm the corrected webpage is served. No release, DOI, deposit, or external contact was initiated.


## 2026-09-26T21:22:10Z — preprint revision and fresh adversarial review (45% of this revision)

- User requested explicit priority qualifications in all papers and successive fresh adversarial reviews, correcting actionable issues until a round finds none. This effort has one manuscript; all current copies, site, citation records, metadata, and packages are being revised together as version 1.0.1.
- The abstract now disclaims first-resolution priority; the attribution section names the principal unread sources and disclaims verified continued open status. The prior failed database-access statement is corrected, and the exact deformation is cited directly to Matsuzoe 1999 rather than only the later Ueno preprint. Dated audits retain their historical observations with supersession notices.
- The revised source compiles successfully with the built-in editor; Tectonic exports four pages. All four rendered pages were visually inspected. No overfull box remains; one harmless bibliography underfull-box warning causes no visible defect. The mathematical proof is unchanged.
- A fresh reviewer, preprint_adversary_round1, is independently checking original printed sources, every quantifier, curvature signs, duality, and the deformation. A second fresh reviewer will use a distinct adversarial route after the first is complete and any accepted findings are addressed.
- The current priority statement preserves the unresolved historical gap. No external communication, journal preparation, release, deposit, or DOI action is authorized or performed in this revision.


## 2026-09-26T21:24:08Z — first fresh review passed (65% of this revision)

- preprint_adversary_round1 independently reconstructed all proof steps before consulting source-audit records. It visually checked original FMU 3(a)/3(e), Kurose's definition and criterion, Matsuzoe's equation, and all four manuscript pages. No actionable preprint issue was found.
- The review explicitly tested all convex-neighborhood quantifiers, cut-locus/center boundaries, affine reparametrization domains, curvature signs, duality, cubic nonvanishing, n>=3, and priority wording. The exact and 403-check symbolic verifiers passed. Reviewed source/PDF SHA-256 values are preserved in its report.
- Citation metadata passes the official CFF 1.2.0 schema. Zenodo base fields pass the saved official legacy schema, while version/language retain the previously verified documented vocabulary. No server validation is claimed.
- No corrective mathematical edit was needed. A second fresh reviewer is assigned a projective-curvature route and clean-extraction reproduction audit before finalizing the package.


## 2026-09-26T21:30:27Z — second fresh review passed (100% preprint review; 95% delivery)

- preprint_adversary_round2 independently derived the projective-curvature obstruction for both the base and the deformed connection and rechecked source definitions, quantifiers, and reparametrization domains. No actionable mathematical or attribution issue was found. Both fresh reviews identify the same unchanged version 1.0.1 manuscript and PDF hashes.
- The reviewer extracted the source and upload archives into a clean directory. Both checkers passed normally and with Python optimization, producing the included transcripts exactly under the pinned environment. Every manifest and archive member checked, and the extracted package rebuilt both ZIPs and site files byte-for-byte. The extracted standalone source compiled successfully in the native editor. Metadata validation passed within the documented schema scope.
- The sequential fresh-review stopping condition is satisfied: neither round found an actionable preprint issue. No mathematical correction was needed after the initial attribution/priority revision. The review record preserves method, evidence, exact identities, and limits rather than claiming external peer review or proof-assistant certification.
- The final source archive now includes both new reviews and the completed readiness record. The site, citation records, and Zenodo kit all describe unresolved priority. The principal unread sources and possible earlier explicit or implicit resolution remain disclosed.
- Final delivery checks will verify the regenerated manifests, archive/canonical-file identity, current PDF hashes, and served bytes after publication. No journal action, external contact, GitHub release, Zenodo deposit, or DOI creation is part of this revision.
