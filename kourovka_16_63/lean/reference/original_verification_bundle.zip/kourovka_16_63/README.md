# Kourovka Notebook 16.63 — explicit affirmative construction

**Result:** for the odd prime `p = 1009`, the group described here satisfies

```text
|G| = |Aut(G)| = 1009^52359.
```

`Aut` is the FULL automorphism group. The construction is a BCH group of a rank-31 finite Lie ring modulo `1009^1689`. Its class is at most `846 < 1009`.

Read **`report/kourovka_16_63.pdf`** for the self-contained mathematical proof. The TeX source is beside it. This is a proof with exact computational certificates; it has not been externally peer-reviewed or formalized in a proof assistant.

## One-command independent verification

From this directory:

```sh
python3 scripts/resume.py
```

Requirements for this path: Python 3 and a local GCC or Clang C++17 compiler supporting `__int128`. The code uses no network, does not install anything, and uses no paid or remote service. A compiler can be selected with `--compiler /path/to/compiler`.

The command rebuilds the verifier, reconstructs all Lie brackets and the basis change from their formulas, checks the exact linear-algebra claims, replays the Smith certificate, runs the small-group controls, and checks rejection of a deliberately corrupted certificate. Success ends with:

```text
ALL_CHECKS_PASSED
REPRODUCTION_PASSED: exact certificate checks and corrupted-certificate rejection.
```

The C++ reconstruction is independent of the Python coefficient tables. The only mathematical data it reads is `data/smith_pivot_plan.txt`; each proposed pivot is verified, not trusted. About 112 MB are needed for its main exact matrix. Tested here with g++ 14.2.0 on x86-64 Linux; portability to GCC/Clang is intended, but no separate Mac execution is claimed.

The command records a fresh run in `logs/resume_verify.log`, `logs/resume_cpp_verify.log`, `logs/resume_run.json`, and `logs/resume_negative_test.json`. A build failure stops execution; it cannot fall back to an old binary.

## Regenerate the Python computation as well

With NumPy and SymPy already available:

```sh
python3 scripts/resume.py --full
```

This regenerates the integer bracket tables, modular ranks, Smith plan at precision 12, its replay at precision 6, and the portable group description, then runs the independent C++ check. The tested versions are Python 3.13.5, NumPy 2.3.5, and SymPy 1.14.0. No random or floating-point mathematical step is used.

The report can be rebuilt separately with two or three `pdflatex` passes in `report/`; no TeX installation is needed to run the mathematical verifier.

## Explicit group description

`data/group_lie_presentation.json` contains the 31 basis definitions, all 199 nonzero skew-half bracket coefficients in the scaled basis, the coefficient modulus, and the exact BCH multiplication convention. Some coefficients exceed `2^53`; use an arbitrary-precision JSON parser, not a floating-point conversion.

Equivalently, the report specifies a rank-31 integer Lie bracket by seven raw transvectants, a unimodular basis change and the weights `(0,0,1,2,...,2)`. With `A` the weighted lattice, `L = p^2 A`, and `i = 1689`, the group is `BCH(L/p^i L)`.

The group is NOT identified only by a library number. Its 31-tuples are exact normal forms. The multiplication is the canonical finite BCH Lie polynomial through bracket length 846. That polynomial has not been expanded into an enormous monomial list, nor has a Cayley table been constructed.

## Why the count is the full count

The report proves that every finite Lie-ring automorphism, not merely every known inner or central one, preserves an ambient integral lattice and reduces to the identity on a rigid finite-field flag. Integral logarithm and exponential then give a precision-preserving bijection with the complete kernel of a linear derivation matrix.

The exact `14415 x 961` matrix has rank 931 and Smith valuations:

| Valuation at 1009 | 0 | 1 | 2 | 3 | 4 |
|---|---:|---:|---:|---:|---:|
| Multiplicity | 87 | 55 | 758 | 6 | 25 |

The valuation sum is 1689; the nullity is 30. Thus the full automorphism group of the finite **Lie ring** at every depth `i >= 7` has order `1009^(30*i+1689)`. At depth 1689 this equals `1009^(31*i)`. The class bound makes the finite Lazard correspondence applicable, preserving the FULL group automorphism group. No correspondence beyond its class-less-than-prime range is asserted.

## Bundle contents

- `report/`: mathematical proof, PDF and editable TeX.
- `scripts/`: independent Python and C++ source, reproduction driver, export code, and exhaustive small-group controls.
- `data/`: exact bracket tables, portable group description, rank and generation traces, and Smith pivot certificates.
- `logs/`: executed and inspected outputs, software versions, successful reproduction, and negative-certificate tests.
- `literature_ledger.md` and `.json`: primary-source audit and precise scope of cited theorems.
- `notes/`: chronological checkpoint and final verification map.
- `progress.json`: result, established facts, remaining obligations and exact resume command.
- `SHA256SUMS`: integrity hashes of the delivered files. The reproduction commands intentionally update run logs, so check this manifest before rerunning them.

## Attribution and boundaries

The Lie-algebra template is Omirov–Ruan, arXiv:2605.04602v1, Theorem 4.8 with six radical summands. The report independently fixes the integer normalization and proves the needed characteristic-1009 properties. The lattice construction and exact full finite-automorphism argument are developed in this research report.

The Lazard step uses the finite class-`< p` correspondence, with its actual hypotheses checked in Cicalò–de Graaf–Vaughan-Lee, Journal of Algebra 352 (2012), pp. 433–434. The previously disproved divisibility conjecture in Archive 12.77 is not mistaken for problem 16.63.

Independent implementation here means separately written code, not independent human peer review. No GAP, SageMath or Magma execution, automorphism catalogue search, formal proof assistant, or external reviewer is claimed. Neither the prime nor the order is claimed minimal. No author was contacted and nothing was published by this workflow.

### Historical logs

The earlier TeX first-pass failures and `cpp_compile_warning_repair.log` are retained as provenance. They precede repaired, successful builds. The authoritative end-to-end result is `logs/full_reproduction_console.log` together with `logs/resume_run.json`; the latter records successful full regeneration and the SHA-256 hashes of the actual independently verified C++ source and pivot plan. The final PDF build logs are `logs/latex_final_pass_*.log`.
