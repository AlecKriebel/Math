Compile source/paper/main.tex with Tectonic 0.16.0 or a compatible LaTeX installation.
