Install reproducibility/requirements.txt, then run: python3 reproducibility/verify_math.py
